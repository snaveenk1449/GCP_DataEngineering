from airflow import DAG
import os
import boto3
from airflow.operators.python_operator import PythonOperator
from datetime import datetime
import pendulum
from airflow.operators.email_operator import EmailOperator

env_val = 'qa'
email_recipient = ["MARS-Data-Engineering-d@gene.com"]
# email_recipient = ["shubham.karanjkar@roche.com","harshwardhan.singh@roche.com"]

bucket_name = 'cmg-oasis-qa-mars'
landing_dq_report_airflow_path = '/tmp/DQ_report_landing.xlsx'
normalized_dq_report_airflow_path = '/tmp/DQ_report_normalized.xlsx'
exception_report_airflow_path = '/tmp/Exception_report.xlsx'
profiling_report_airflow_path = '/tmp/MARS_Profiling.xlsx'
correlation_report_airflow_path = '/tmp/Correlation_report.xlsx'
landing_dq_report_path = 'data_quality/detailed_report/data_quality_report_attachment/DQ_report_landing.xlsx'
normalized_dq_report_path = 'data_quality/detailed_report/data_quality_report_attachment/DQ_report_normalized.xlsx'
exception_report_path = 'oasis_landing/exception_report_folder/exception_report_attachment/Exception_report.xlsx'
profiling_report_path = 'profiling_reports_attachment/MARS_Profiling.xlsx'
correlation_report_path = 'correlation_email_files/correlation_excel_attachment/Correlation_report.xlsx'


def report_failure(context):
    ti = context['task_instance']
    send_email = EmailOperator(
        task_id='email_on_failure',
        to=email_recipient,
        subject=f'Airflow dag has been failed',
        html_content=f'{ti.task_id} task is failed in Airflow dag {ti.dag_id}',
        dag=dag
    )
    send_email.execute(context)


def copy_files():
    if os.path.isfile(exception_report_airflow_path):
        os.remove(exception_report_airflow_path)

    if os.path.isfile(landing_dq_report_airflow_path):
        os.remove(landing_dq_report_airflow_path)

    if os.path.isfile(normalized_dq_report_airflow_path):
        os.remove(normalized_dq_report_airflow_path)

    if os.path.isfile(profiling_report_airflow_path):
        os.remove(profiling_report_airflow_path)

    if os.path.isfile(correlation_report_airflow_path):
        os.remove(correlation_report_airflow_path)

    s3 = boto3.client('s3')

    exception_response = s3.get_object(Bucket=bucket_name, Key=exception_report_path)
    exception_object_content = exception_response['Body'].read()
    with open(exception_report_airflow_path, "xb") as f:
        f.write(exception_object_content)

    landing_dq_response = s3.get_object(Bucket=bucket_name, Key=landing_dq_report_path)
    landing_dq_object_content = landing_dq_response['Body'].read()
    with open(landing_dq_report_airflow_path, "xb") as f:
        f.write(landing_dq_object_content)

    normalized_dq_response = s3.get_object(Bucket=bucket_name, Key=normalized_dq_report_path)
    normalized_dq_object_content = normalized_dq_response['Body'].read()
    with open(normalized_dq_report_airflow_path, "xb") as f:
        f.write(normalized_dq_object_content)

    profiling_response = s3.get_object(Bucket=bucket_name, Key=profiling_report_path)
    profiling_object_content = profiling_response['Body'].read()
    with open(profiling_report_airflow_path, "xb") as f:
        f.write(profiling_object_content)

    correlation_response = s3.get_object(Bucket=bucket_name, Key=correlation_report_path)
    correlation_object_content = correlation_response['Body'].read()
    with open(correlation_report_airflow_path, "xb") as f:
        f.write(correlation_object_content)


def del_files():
    if os.path.isfile(exception_report_airflow_path):
        os.remove(exception_report_airflow_path)

    if os.path.isfile(landing_dq_report_airflow_path):
        os.remove(landing_dq_report_airflow_path)

    if os.path.isfile(normalized_dq_report_airflow_path):
        os.remove(normalized_dq_report_airflow_path)

    if os.path.isfile(profiling_report_airflow_path):
        os.remove(profiling_report_airflow_path)

    if os.path.isfile(correlation_report_airflow_path):
        os.remove(correlation_report_airflow_path)


pst_tz = pendulum.timezone('America/Los_Angeles')
default_args = {
    'owner': 'oasis',
    'start_date': datetime(2024, 8, 4, tzinfo=pst_tz),
    'catchup': False,
    'retries': 0,
    'on_failure_callback': report_failure
}

with DAG(dag_id='mars_email_attachment', default_args=default_args, schedule_interval=None, catchup=False) as dag:

    copy_files_boto3 = PythonOperator(task_id='Copy_files_to_local', python_callable=copy_files, dag=dag)

    dq_email = EmailOperator(
        task_id='DQ_Report',
        to=email_recipient,
        subject=f'Data Quality report for landing layer and normalized layer in {env_val}',
        html_content=f'Hi,\nPFA, Please find attachment for Data Quality report for landing layer'
                     f' and normalized layer in {env_val}',
        dag=dag,
        files=[normalized_dq_report_airflow_path, landing_dq_report_airflow_path]
    )

    landing_layer_exception_email = EmailOperator(
        task_id='Landing_Layer_Exception',
        to=email_recipient,
        subject=f'MARS DQ exception report for variance threshold {env_val}',
        html_content=f'Hi,\nPFA, Please find attachment for exception report in {env_val}',
        dag=dag,
        files=[exception_report_airflow_path]
    )

    profiling_exception_email = EmailOperator(
        task_id='Profiling_Report',
        to=email_recipient,
        subject=f'Profiling report in {env_val}',
        html_content=f'Hi,\nPFA, Please find attachment for Profiling report in {env_val}',
        dag=dag,
        files=[profiling_report_airflow_path]
    )

    correlation_email = EmailOperator(
        task_id='Correlation_Report',
        to=email_recipient,
        subject=f'Correlation report in {env_val}',
        html_content=f'Hi,\nPFA, Please find attachment for Correlation report in {env_val}',
        dag=dag,
        files=[correlation_report_airflow_path]
    )

    del_file_from_airflow = PythonOperator(task_id='del_local_files', python_callable=del_files, dag=dag)

    copy_files_boto3 >> [dq_email, landing_layer_exception_email, profiling_exception_email, correlation_email] >> del_file_from_airflow
