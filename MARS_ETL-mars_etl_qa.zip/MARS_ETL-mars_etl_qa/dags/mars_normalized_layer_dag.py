from airflow import DAG
from airflow.models import Variable
from datetime import datetime, timedelta
from airflow.providers.amazon.aws.operators.glue import GlueJobOperator
import pendulum
from airflow.operators.email_operator import EmailOperator

# Vars found in admin/variables in airflow
# env_val = Variable.get("environment")
env_val = 'qa'
region_name = 'us-west-2'
additional_python_modules = "configparser"
TRUE = 'True'
FALSE = 'False'
glue_iam_role = "DMSCDC_Execution_Role"
email_recipient = ["MARS-Data-Engineering-d@gene.com"]


def report_failure(context):
    ti = context['task_instance']
    send_email = EmailOperator(
        task_id='email_on_failure',
        to=email_recipient,
        subject=f'Airflow dag has been failed',
        html_content=f'{ti.task_id} task is failed in Airflow dag {ti.dag_id}',
        dag=dag
    )
    send_email.execute(context)


pst_tz = pendulum.timezone('America/Los_Angeles')
default_args = {
    'owner': 'oasis',
    'start_date': datetime(2024, 8, 4, tzinfo=pst_tz),
    'catchup': False,
    'retries': 0,
    'on_failure_callback': report_failure
}

with DAG(dag_id='mars_etl_and_dq_stage_2', default_args=default_args,
         schedule_interval=None, tags=['mars_etl']) as dag:
    mars_staging_historical_table_creation_job = GlueJobOperator(
        job_name='mars_staging_historical_table_creation_job',
        region_name=region_name,
        iam_role_name=glue_iam_role,
        script_args={'--batch_id': f'{{{{ ds_nodash }}}}',
                     '--environment': env_val,
                     '--additional-python-modules': additional_python_modules,
                     '--load_demographic_zip_ref_tables': FALSE,
                     '--load_hcp_mdm_ref_tables': FALSE,
                     '--load_sales_tables': FALSE,
                     '--load_speaker_tables': FALSE,
                     '--load_tam_tables': FALSE,
                     '--load_xo_tables': TRUE},
        num_of_dpus=10,
        task_id='mars_staging_historical_table_creation_job',
        dag=dag,
        wait_for_completion=True
    )

    mars_hcp_org_mapping_job = GlueJobOperator(
        job_name='mars_hcp_org_mapping_job',
        region_name=region_name,
        iam_role_name=glue_iam_role,
        script_args={'--batch_id': f'{{{{ ds_nodash }}}}',
                     '--environment': env_val,
                     '--additional-python-modules': additional_python_modules},
        num_of_dpus=10,
        task_id='mars_hcp_org_mapping_job',
        dag=dag,
        wait_for_completion=True
    )

    mars_hcp_count_job = GlueJobOperator(
        job_name='mars_hcp_count_job',
        region_name=region_name,
        iam_role_name=glue_iam_role,
        script_args={'--batch_id': f'{{{{ ds_nodash }}}}',
                     '--environment': env_val,
                     '--additional-python-modules': additional_python_modules},
        num_of_dpus=10,
        task_id='mars_hcp_count_job',
        dag=dag,
        wait_for_completion=True
    )

    mars_product_sales_job = GlueJobOperator(
        job_name='mars_product_sales_job',
        region_name=region_name,
        iam_role_name=glue_iam_role,
        script_args={'--batch_id': f'{{{{ ds_nodash }}}}',
                     '--environment': env_val,
                     '--additional-python-modules': additional_python_modules},
        num_of_dpus=10,
        task_id='mars_product_sales_job',
        dag=dag,
        wait_for_completion=True
    )

    mars_sales_job = GlueJobOperator(
        job_name='mars_sales_job',
        region_name=region_name,
        iam_role_name=glue_iam_role,
        script_args={'--batch_id': f'{{{{ ds_nodash }}}}',
                     '--environment': env_val,
                     '--additional-python-modules': additional_python_modules},
        num_of_dpus=10,
        task_id='mars_sales_job',
        dag=dag,
        wait_for_completion=True
    )

    mars_net_sales_job = GlueJobOperator(
        job_name='mars_net_sales_job',
        region_name=region_name,
        iam_role_name=glue_iam_role,
        script_args={'--batch_id': f'{{{{ ds_nodash }}}}',
                     '--environment': env_val,
                     '--additional-python-modules': additional_python_modules},
        num_of_dpus=10,
        task_id='mars_net_sales_job',
        dag=dag,
        wait_for_completion=True
    )

    mars_speaker_program_job = GlueJobOperator(
        job_name='mars_speaker_program_job',
        region_name=region_name,
        iam_role_name=glue_iam_role,
        script_args={'--batch_id': f'{{{{ ds_nodash }}}}',
                     '--environment': env_val,
                     '--additional-python-modules': additional_python_modules},
        num_of_dpus=10,
        task_id='mars_speaker_program_job',
        dag=dag,
        wait_for_completion=True
    )

    mars_tam_job = GlueJobOperator(
        job_name='mars_tam_job',
        region_name=region_name,
        iam_role_name=glue_iam_role,
        script_args={'--batch_id': f'{{{{ ds_nodash }}}}',
                     '--environment': env_val,
                     '--additional-python-modules': additional_python_modules},
        num_of_dpus=10,
        task_id='mars_tam_job',
        dag=dag,
        wait_for_completion=True
    )

    mars_xo_job = GlueJobOperator(
        job_name='mars_xo_job',
        region_name=region_name,
        iam_role_name=glue_iam_role,
        script_args={'--batch_id': f'{{{{ ds_nodash }}}}',
                     '--environment': env_val,
                     '--additional-python-modules': additional_python_modules},
        num_of_dpus=10,
        task_id='mars_xo_job',
        dag=dag,
        wait_for_completion=True
    )

    mars_feature_combine_job = GlueJobOperator(
        job_name='mars_feature_combine',
        region_name=region_name,
        iam_role_name=glue_iam_role,
        script_args={'--batch_id': f'{{{{ ds_nodash }}}}',
                     '--environment': env_val,
                     '--additional-python-modules': additional_python_modules},
        num_of_dpus=10,
        task_id='mars_feature_combine_job',
        dag=dag,
        wait_for_completion=True
    )

    mars_tam_data_quality_job = GlueJobOperator(
        job_name='mars_tam_data_quality_job',
        region_name=region_name,
        iam_role_name=glue_iam_role,
        script_args={'--batch_id': f'{{{{ ds_nodash }}}}',
                     '--environment': env_val,
                     '--additional-python-modules': additional_python_modules},
        num_of_dpus=10,
        task_id='mars_tam_data_quality_job',
        dag=dag,
        wait_for_completion=True
    )

    mars_speaker_data_quality_job = GlueJobOperator(
        job_name='mars_speaker_data_quality_job',
        region_name=region_name,
        iam_role_name=glue_iam_role,
        script_args={'--batch_id': f'{{{{ ds_nodash }}}}',
                     '--environment': env_val,
                     '--additional-python-modules': additional_python_modules},
        num_of_dpus=10,
        task_id='mars_speaker_data_quality_job',
        dag=dag,
        wait_for_completion=True
    )

    mars_sales_data_quality_job = GlueJobOperator(
        job_name='mars_sales_data_quality_job',
        region_name=region_name,
        iam_role_name=glue_iam_role,
        script_args={'--batch_id': f'{{{{ ds_nodash }}}}',
                     '--environment': env_val,
                     '--additional-python-modules': additional_python_modules},
        num_of_dpus=10,
        task_id='mars_sales_data_quality_job',
        dag=dag,
        wait_for_completion=True
    )

    mars_xo_data_quality_job = GlueJobOperator(
        job_name='mars_xo_data_quality_job',
        region_name=region_name,
        iam_role_name=glue_iam_role,
        script_args={'--batch_id': f'{{{{ ds_nodash }}}}',
                     '--environment': env_val,
                     '--additional-python-modules': additional_python_modules},
        num_of_dpus=10,
        task_id='mars_xo_data_quality_job',
        dag=dag,
        wait_for_completion=True
    )

    mars_normalized_data_quality_job = GlueJobOperator(
        job_name='mars_glue_data_quality_job',
        region_name=region_name,
        iam_role_name=glue_iam_role,
        script_args={'--batch_id': f'{{{{ ds_nodash   }}}}',
                     '--environment': env_val,
                     '--additional-python-modules': "boto3==1.35.54,openpyxl,cloudpathlib",
                     '--layer': 'normalized'},
        num_of_dpus=30,
        task_id='mars_normalized_data_quality_job',
        dag=dag,
        wait_for_completion=True
    )

    mars_profiling_job = GlueJobOperator(
        job_name='mars_profiling_job',
        region_name=region_name,
        iam_role_name=glue_iam_role,
        script_args={'--batch_id': f'{{{{ ds_nodash   }}}}',
                     '--environment': env_val,
                     '--additional-python-modules': "boto3==1.35.54,openpyxl,cloudpathlib"},
        num_of_dpus=30,
        task_id='mars_profiling_job',
        dag=dag,
        wait_for_completion=True
    )

    success_email = EmailOperator(
        task_id='success_email',
        to=email_recipient,
        subject=f'Airflow DAG {dag.dag_id} completed in {env_val}',
        html_content=f'Email is to notify that Airflow dag {dag.dag_id} is successfully completed.',
        dag=dag
    )

    mars_staging_historical_table_creation_job >> mars_hcp_org_mapping_job >> mars_hcp_count_job >> [mars_tam_job, mars_xo_job, mars_speaker_program_job, mars_net_sales_job, mars_sales_job, mars_product_sales_job] >> mars_feature_combine_job >> [ mars_xo_data_quality_job, mars_sales_data_quality_job, mars_speaker_data_quality_job, mars_tam_data_quality_job] >> mars_normalized_data_quality_job >> mars_profiling_job >> success_email