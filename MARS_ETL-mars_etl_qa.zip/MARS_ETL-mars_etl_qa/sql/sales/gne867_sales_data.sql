/*
* GNE 867 Sales Qty - This dataset contains the quantity of sales made (units sold) at the site and HCP-level. HCPs are subject to MCE logic, while sites are not.
* We add the sales from the 4 Evrysdi-specific HCPs and combine them together with all the other sales.
*
* We also join net sales which is available only at the year_month and product level, unlike the gross sales, which we have at the zip level. 
*/

with hcp_org_mapping as (
    select
        mdm_id,
        product_brand_id,
        product_brand_name,
        mdm_zip
    from sandbox_measurement_analyst.mars_hcp_org_mapping_staging
),

sales_ds as (
    select
        gne.product_brand_name,
        gne.product_brand_id,
        gne.product_id,
        cast(gne.date_year_month as varchar) as year_month,
        gne.gne_867_sales_qty_eqv,
        hom.mdm_id,
        hom.mdm_zip as zip
    from sandbox_measurement_analyst.mars_sst_mcdm_hcp_site_sales_ndc_monthly_staging as gne
    inner join hcp_org_mapping as hom
        on
            coalesce(gne.mdm_id, gne.site_mdm_id) = hom.mdm_id -- Do not change the order of the coalesce function! All HCPs have a Site ID, but not vice-versa. So if we want to get both HCPs and Sites in one go, maintaining this order in the coalesce() function is crucial
            and cardinality(
                array_intersect(
                    array[gne.product_brand_id], hom.product_brand_id
                )
            )
            > 0
),

evrysdi_extra_hcp_sales as (
    select
        product_brand_name,
        product_brand_id,
        product_id,
        cast(date_year_month as varchar) as year_month,
        gne_867_sales_qty_eqv,
        ev.mdm_id,
        ev.mdm_zip as zip
    from sandbox_measurement_analyst.mars_sst_mcdm_hcp_site_sales_ndc_monthly_staging as gne
    inner join
        sandbox_measurement_analyst.mars_evrysdi_extra_hcp_zips_staging as ev
        on gne.mdm_id = ev.mdm_id
),

all_sales as (
    select
        product_brand_name,
        product_brand_id,
        product_id,
        year_month,
        gne_867_sales_qty_eqv,
        mdm_id,
        zip
    from sales_ds
    union all
    select
        product_brand_name,
        product_brand_id,
        product_id,
        year_month,
        gne_867_sales_qty_eqv,
        mdm_id,
        zip
    from evrysdi_extra_hcp_sales
),

agg_data as (
    select
        product_brand_name,
        year_month,
        zip,
        sum(gne_867_sales_qty_eqv) as sales_qty
    from all_sales
    group by
        product_brand_name,
        year_month,
        zip
),

net_sales as (
    select
        product_brand_name,
        cast(date_year_month as varchar) as year_month,
        sum(gne_867_net_sales_dollars) as net_sales
    from
        sandbox_measurement_analyst.mars_sst_ecosystem_net_sales_brand_monthly_staging
    group by product_brand_name, product_brand_id, date_year_month
),

final_agg as (
    select distinct
        coalesce(qty.product_brand_name, net.product_brand_name)
            as product_brand_name,
        coalesce(qty.year_month, net.year_month) as year_month,
        qty.zip as zip,
        qty.sales_qty,
        net.net_sales
    from agg_data as qty
    full outer join net_sales as net
        on
            qty.product_brand_name = net.product_brand_name
            and qty.year_month = net.year_month
)

select * from final_agg
