/*
* Author - Saroj Sahoo
* Created date - 5/6/2024
* 
* GNE 867 Sales Qty by Product ID - This dataset contains the quantity of sales made (units sold) at the site and HCP-level and by product ID, i.e., including the different variants of the same product.
* We add the sales from the 4 Evrysdi-specific HCPs and combine them together with all the other sales.
*
* This dataset contains the quantities with and without the MCE logic being applied to give a more holistic picture of the nature of sales.
*/

with hcp_org_mapping as (
    select
        mdm_id,
        product_brand_id,
        product_brand_name,
        mdm_zip
    from sandbox_measurement_analyst.mars_hcp_org_mapping_staging
),

-- Sales data with and without MCE exclusion
sales_ds as (
    select
        gne.product_brand_name,
        gne.product_brand_id,
        product_description,
        product_id,
        cast(date_year_month as varchar) as year_month,
        gne_867_sales_qty_eqv,
        gne_867_effective_wac_sales_dollars as gross_sales_dollars,
        coalesce(hom.mdm_id, gne.mdm_id) as mdm_id,
        coalesce(hom.mdm_zip, gne.site_zip) as site_zip,
        -- sales qty with MCE logic
        case when hom.mdm_id is not null then gne_867_sales_qty_eqv else 0 end
            as gne_867_sales_qty_eqv_inc,
        -- sales dollar amount with MCE logic
        case
            when
                hom.mdm_id is not null
                then gne_867_effective_wac_sales_dollars
            else 0
        end as gross_sales_dollars_inc
    from
        sandbox_measurement_analyst.mars_sst_mcdm_hcp_site_sales_ndc_monthly_staging
            as gne
    left join hcp_org_mapping as hom
        on
            coalesce(gne.mdm_id, gne.site_mdm_id) = hom.mdm_id
            and cardinality(
                array_intersect(
                    array[gne.product_brand_id], hom.product_brand_id
                )
            )
            > 0
),

-- 4 HCP included for Evrysdi
evrysdi_extra_hcp_sales as (
    select
        product_brand_name,
        product_brand_id,
        product_description,
        product_id,
        cast(date_year_month as varchar) as year_month,
        gne_867_sales_qty_eqv,
        ev.mdm_id,
        ev.mdm_zip as site_zip,
        gne_867_effective_wac_sales_dollars as gross_sales_dollars,
        gne_867_sales_qty_eqv as gne_867_sales_qty_eqv_inc,
        gne_867_effective_wac_sales_dollars as gross_sales_dollars_inc
    from oasis_summarized.sst_mcdm_hcp_site_sales_ndc_monthly as gne
    inner join
        sandbox_measurement_analyst.mars_evrysdi_extra_hcp_zips_staging as ev
        on gne.mdm_id = ev.mdm_id
),

-- All sales unioned
all_sales as (
    select
        product_brand_name,
        product_brand_id,
        product_description,
        product_id,
        year_month,
        gne_867_sales_qty_eqv,
        mdm_id,
        site_zip,
        gross_sales_dollars,
        gne_867_sales_qty_eqv_inc,
        gross_sales_dollars_inc
    from sales_ds
    union all
    select distinct
        product_brand_name,
        product_brand_id,
        product_description,
        product_id,
        year_month,
        gne_867_sales_qty_eqv,
        mdm_id,
        site_zip,
        gross_sales_dollars,
        gne_867_sales_qty_eqv_inc,
        gross_sales_dollars_inc
    from evrysdi_extra_hcp_sales
),

-- Aggregated data at the product_id, product_brand_name, year_month and site_zip level
agg_data as (
    select
        product_brand_name,
        product_id,
        max(product_description) as product_description,
        year_month,
        site_zip,
        sum(gne_867_sales_qty_eqv) as sales_eqv_qty,
        cast(sum(gross_sales_dollars) as double) as gross_sales_dollars,
        sum(gne_867_sales_qty_eqv_inc) as sales_qty_eqv_mce_inc,
        cast(sum(gross_sales_dollars_inc) as double)
            as gross_sales_dollars_mce_inc
    from all_sales
    group by
        product_id,
        product_brand_name,
        year_month,
        site_zip
)

select * from agg_data;
