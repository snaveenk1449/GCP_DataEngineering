with mdm_zip_ds as (
    select distinct
        mdm_id,
        mdm_zip,
        filter(
            array_distinct(
                array[primary_phyn_spcl_code, secondary_phyn_spcl_code]
            ),
            s -> s is not null
        ) as spcl_codes
    from sandbox_measurement_analyst.mars_master_cm_mdm_profile_weekly_staging
    where
        party_type = 'IND'
),

all_product_incl_codes as (
    select
        product_brand_name,
        product_brand_id,
        array_agg(code) as prod_codes
    from sandbox_measurement_analyst.mars_alignment_brand_credit_rules_staging
    where
        upper(trim(exception_type)) = 'INCLUDE'
        and product_flag_competitor = 'N'
        and source_data = 'XPO'
    group by product_brand_name, product_brand_id
),
actemra_standardized as(
    select 
        product_brand_id,
        prod_codes,
        case when 
            product_brand_name IN('ACTEMRA IV', 'ACTEMRA SC') then 'ACTEMRA'
        else product_brand_name end as product_brand_name
    from all_product_incl_codes
),
mce_incl_mdm_ds as (
    select distinct
        mz.mdm_id,
        mz.mdm_zip,
        array_distinct(array_sort(array_agg(pic.product_brand_id)))
            as product_brand_id,
        array_distinct(array_sort(array_agg(pic.product_brand_name)))
            as product_brand_name
    from mdm_zip_ds as mz
    cross join actemra_standardized as pic
    where cardinality(array_intersect(mz.spcl_codes, pic.prod_codes)) > 0
    group by mz.mdm_id, mz.mdm_zip
),
hcp_site as (
    select distinct
        hcp_outlet_mdm_id as mdm_id,
        site_zip as mdm_zip
    from sandbox_measurement_analyst.mars_hcp_outlet_affiliations_weekly_staging
    where
        flag_primary_affiliation = 'Y'
        and hcp_outlet_mdm_id is not null
        and upper(affiliation_status) = 'ACTIVE'
),

hcp_site_master_ds as (
    select distinct
        m.mdm_id,
        m.product_brand_id,
        m.product_brand_name,
        'HCP' as mdm_type,
        coalesce(hs.mdm_zip, m.mdm_zip) as mdm_zip
    from mce_incl_mdm_ds as m left join hcp_site as hs on m.mdm_id = hs.mdm_id
),

org_site as (
    select distinct
        org_mdm_id as mdm_id,
        org_zip as mdm_zip,
        'SITE' as mdm_type,
        array_distinct(array_sort(array_agg(pic.product_brand_id)))
            as product_brand_id,
        array_distinct(array_sort(array_agg(pic.product_brand_name)))
            as product_brand_name
    from sandbox_measurement_analyst.mars_master_cm_org_profile_weekly_staging
    cross join all_product_incl_codes as pic
    group by org_mdm_id, org_zip
),

hcp_org as (
    select
        mdm_id,
        mdm_zip,
        product_brand_id,
        product_brand_name,
        mdm_type
    from hcp_site_master_ds
    union
    select
        mdm_id,
        mdm_zip,
        product_brand_id,
        product_brand_name,
        mdm_type
    from org_site
),

zip_eco_map as (
    select distinct
        zip,
        state,
        ecosystem_dim_id,
        ecosystem_name
    from sandbox_measurement_analyst.mars_alignment_zip_to_ecosystem_daily_staging
    where
        flag_active = 'Y'
        and ecosystem_dim_id > 0
),

hcp_org_map as (
    select distinct
        ho.mdm_id,
        ho.mdm_zip,
        ho.product_brand_id,
        ho.product_brand_name,
        zem.ecosystem_name,
        zem.ecosystem_dim_id,
        ho.mdm_type
    from hcp_org as ho inner join zip_eco_map as zem on ho.mdm_zip = zem.zip
),

final_ds as (
    select distinct
        mdm_id,
        product_brand_id,
        product_brand_name,
        mdm_zip,
        ecosystem_name,
        ecosystem_dim_id,
        mdm_type
    from hcp_org_map
)
select * from final_ds 
