with hcp_zip_map as (
    select
        mdm_id,
        mdm_zip
    from sandbox_measurement_analyst.mars_hcp_org_mapping_staging 
    where mdm_type = 'HCP'
),

hcp_targets as (
    select distinct
        case when product_brand_name in('ACTEMRA IV', 'ACTEMRA SC') then 'ACTEMRA'
        else product_brand_name end as product_brand_name,
        hcp_mdm_id
    from sandbox_measurement_analyst.mars_target_list_hcp_weekly_staging 
    where
        flag_current = 'Y'
        and product_brand_name != 'NOT ASSOCIATED'
),
raw_data as (
    select distinct
        ht.product_brand_name,
        hzm.mdm_id,
        hzm.mdm_zip as zip_code
    from hcp_targets as ht
    inner join hcp_zip_map as hzm on ht.hcp_mdm_id = hzm.mdm_id
),
evrysdi_extra_hcps as (
    select distinct
        'EVRYSDI' as product_brand_name,
        mdm_id,
        mdm_zip as zip_code
    from sandbox_measurement_analyst.mars_evrysdi_extra_hcp_zips_staging
),

all_hcps as (
    select distinct
        product_brand_name,
        mdm_id,
        zip_code
    from raw_data
    union all
    select distinct
        product_brand_name,
        mdm_id,
        zip_code
    from evrysdi_extra_hcps
),

hcp_count_ds as (
    select distinct
        product_brand_name,
        zip_code,
        count(mdm_id)
            over (partition by product_brand_name, zip_code)
            as hcp_count
    from all_hcps
)

select * from hcp_count_ds
