
with tam_hds as (
    select distinct
        unix_id,
        start_date,
        end_date
    from
        sandbox_measurement_analyst.mars_alignment_roster_hierarchy_daily_staging
    where
        field_title_code in (
            'TAM',
            'HD',            
            'NRDS', -- For Evrysdi
            'SNRDS', -- For Evrysdi
            'NRDHD', -- For Evrysdi
            'ACM', -- For Hemlibra
            'CS', -- For Actemra
            'SCS', -- For Actemra
            'CSO_CS', -- For Actemra
            'CSO_DM', -- For Actemra
            'CSO_RD' -- For Actemra
        )
),

hcp_org_mapping as (
    select
        mdm_id,
        product_brand_id,
        product_brand_name,
        mdm_zip
    from sandbox_measurement_analyst.mars_hcp_org_mapping_staging
),

tam_hd_calls as (
       select distinct
        ci.crm_call_id,
        ci.mdm_id,
        ci.crm_display_order,
        cast(1 / ci.crm_display_order as double) as call_wt,
        ci.crm_call_datetime,
        ci.oasis_brand_name as product_brand_name,
        ci.oasis_product_brand_id as product_brand_id,
        hom.mdm_zip as zip,
        cast(year(ci.crm_call_datetime) as varchar)
        || lpad(cast(month(ci.crm_call_datetime) as varchar), 2, '0')
            as year_month
    from
        sandbox_measurement_analyst.mars_crm_commercial_interactions_staging
            as ci
    inner join
        tam_hds as th
        on
            ci.crm_user_id = th.unix_id
            and ci.crm_call_datetime between th.start_date and th.end_date
    inner join hcp_org_mapping as hom
        on
            ci.mdm_id = hom.mdm_id
            and cardinality(
                array_intersect(
                    array[ci.oasis_brand_name], hom.product_brand_name
                )
            )
            > 0
    where
        upper(crm_call_status) = 'SUBMITTED'
        and cast(crm_flag_person_account as integer) = 1
),
tam_hd_costs as (
    select
        brand,
        'CE' as audience, 
        'tam_hd' as channel,
        cost,
        year || lpad(month, 2, '0') as year_month
    from sandbox_measurement_analyst.mars_tam_costs_staging
    where brand = 'ACTEMRA'
), 
hcp_calls_costs as (
    select distinct
        crm_call_id,
        mdm_id,
        thc.channel,
        thc.audience,
        call_wt,
        crm_call_datetime,
        thd.year_month,
        product_brand_name,
        product_brand_id,
        zip,
        cost
    from tam_hd_calls as thd
    inner join
        tam_hd_costs
            as thc
        on
            thd.year_month = thc.year_month
            and thd.product_brand_name = thc.brand
    where audience = 'CE'
), 
hcp_agg_data as (
    select distinct
        product_brand_name,
        year_month,
        channel,
        audience,
        zip,
        cost,
        round(
            sum(call_wt)
                over (partition by product_brand_name, year_month, zip),
            4
        ) as reach
    from hcp_calls_costs
),
cost_distribution as (
    select
        product_brand_name,
        year_month,
        zip,
        audience,
        channel,
        reach,
        cost
        * reach
        / sum(reach)
            over (partition by product_brand_name, year_month, audience)
            as cost
    from
        hcp_agg_data
)
select * from cost_distribution
