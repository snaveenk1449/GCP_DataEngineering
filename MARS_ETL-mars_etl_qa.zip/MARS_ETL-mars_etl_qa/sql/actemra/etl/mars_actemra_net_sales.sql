with net_sales AS(
    select
        case when product_brand_name in('ACTEMRA IV', 'ACTEMRA SC') then 'ACTEMRA' else product_brand_name
                    end as product_brand_name,
        cast(date_year_month AS varchar) as year_month,
        sum(gne_867_net_sales_dollars) as net_sales
    from
        sandbox_measurement_analyst.mars_sst_ecosystem_net_sales_brand_monthly_staging
    group by 1, 2
)
select * from net_sales
