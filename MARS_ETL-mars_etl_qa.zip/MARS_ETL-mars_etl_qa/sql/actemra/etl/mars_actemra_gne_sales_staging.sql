with hcp_org_mapping as (
    select
        mdm_id,
        product_brand_id,
        product_brand_name,
        mdm_zip
    from sandbox_measurement_analyst.mars_hcp_org_mapping_staging
),
sales_ds as (
    select 
        case when gne.product_brand_name in('ACTEMRA IV', 'ACTEMRA SC') then 'ACTEMRA' 
                    else gne.product_brand_name end as product_brand_name,
        gne.product_brand_id,
        product_id,
        cast(date_year_month as varchar) as year_month,
        hom.mdm_id,
        hom.mdm_zip as zip,
        gne_867_sales_qty_eqv
    from sandbox_measurement_analyst.mars_sst_mcdm_hcp_site_sales_ndc_monthly_staging as gne
    inner join hcp_org_mapping as hom
        on
            coalesce(gne.mdm_id, gne.site_mdm_id) = hom.mdm_id -- Do not change the order of the coalesce function! All HCPs have a Site ID, but not vice-versa. So if we want to get both HCPs and Sites in one go, maintaining this order in the coalesce() function is crucial
            and cardinality(
                array_intersect(
                    array[gne.product_brand_id], hom.product_brand_id
                )
            )
            > 0
),


evrysdi_extra_hcp_sales as (
    select
        product_brand_name,
        product_brand_id,
        product_id,
        cast(date_year_month as varchar) as year_month,
        gne_867_sales_qty_eqv,
        ev.mdm_id,
        ev.mdm_zip as zip
    from sandbox_measurement_analyst.mars_sst_mcdm_hcp_site_sales_ndc_monthly_staging as gne
    inner join
        sandbox_measurement_analyst.mars_evrysdi_extra_hcp_zips_staging as ev
        on gne.mdm_id = ev.mdm_id
), 
all_sales as (
    select
        product_brand_name,
        product_brand_id,
        product_id,
        year_month,
        gne_867_sales_qty_eqv,
        mdm_id,
        zip
    from sales_ds
    union all
    select
        product_brand_name,
        product_brand_id,
        product_id,
        year_month,
        gne_867_sales_qty_eqv,
        mdm_id,
        zip
    from evrysdi_extra_hcp_sales
),

agg_data as (
    select 
        product_brand_name,
        year_month,
        zip,
        sum(gne_867_sales_qty_eqv) as sales_qty
    from all_sales
    group by         
        product_brand_name,
        year_month,
        zip
)
select 
    *
from agg_data 
