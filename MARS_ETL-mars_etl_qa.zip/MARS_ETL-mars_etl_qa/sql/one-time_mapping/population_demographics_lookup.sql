/*
* To create the population demographic lookup table, we start with creating the mars_population_demographics_us_islands and mars_population_demographics_us tables (in a separate process).
* We have US Islands population by ZIP and the contiguous US population by ZCTA (Zip Code Tabulation Area). We also have a zip code to ZCTA mapping table that we use to join with the 
* US population table and spread the population across the various zip codes. There can be many zip codes associated with a single ZCTA, and while not the most accurate method, we end up
* distributing the population evenly across the zips that make up a ZCTA (in the case of there being multiple zips mapped to a single ZCTA). We now have the population on a zip code level.
* We then union this with the US Islands population (pop_demo_combined CTE).
*
* We create multiple CTEs, which will all be joined with the population data. We get ecosystem, state, DMA and HRR/HSA data. We include the all_cities column (refer to all_city_weights.sql for more).
* We also calculate the number of states that a DMA (dma_state_count column) is spread across. This is important to handle a specific scenario in the XO data.
* We then join all these CTEs in the all_cols CTE. We then calculate weights across different dimensions. 
*/

with pop_demo_islands as (
    select
        zip_code as zip,
        dp1_0001c as zip_total,
        upper(state) as state,
        upper(name) as city,
        (
            dp1_0006c
            + dp1_0007c
            + dp1_0008c
            + dp1_0009c
            + dp1_0010c
            + dp1_0011c
        ) as zip_total_18_49,
        (
            dp1_0054c
            + dp1_0055c
            + dp1_0056c
            + dp1_0057c
            + dp1_0058c
            + dp1_0059c
        ) as zip_female_18_49,
        (
            dp1_0012c
            + dp1_0013c
            + dp1_0014c
            + dp1_0015c
            + dp1_0016c
            + dp1_0017c
            + dp1_0018c
            + dp1_0019c
        ) as zip_total_50_99
    from sandbox_measurement_analyst.mars_population_demographics_us_islands
),

pop_demo_zcta as (
    select
        zcta,
        null as state,
        null as city,
        (s0101_c01_001e) as total,
        (
            s0101_c01_023e
            + s0101_c01_007e
            + s0101_c01_008e
            + s0101_c01_009e
            + s0101_c01_010e
            + s0101_c01_011e
        ) as total_18_49,
        (
            s0101_c05_023e
            + s0101_c05_007e
            + s0101_c05_008e
            + s0101_c05_009e
            + s0101_c05_010e
            + s0101_c05_011e
        ) as female_18_49,
        (
            s0101_c01_012e
            + s0101_c01_013e
            + s0101_c01_014e
            + s0101_c01_015e
            + s0101_c01_016e
            + s0101_c01_017e 
            + s0101_c01_018e 
            + s0101_c01_019e
        ) as total_50_99
    from sandbox_measurement_analyst.mars_population_demographics_us
),

zcta_to_zip as (
    select distinct
        zip,
        state,
        zcta,
        sum(1) over (partition by zcta) as zip_per_zcta
    from sandbox_measurement_analyst.mars_zip_zcta_crosswalk
),

pop_demo_zcta_distributed as (
    select distinct
        z.zip,
        p.city,
        p.state,
        sum(coalesce(
            (p.total / z.zip_per_zcta),
            p.total
        )) as zip_total,
        sum(coalesce(
            (p.total_18_49 / z.zip_per_zcta),
            p.total_18_49
        )) as zip_total_18_49,
        sum(coalesce(
            (p.female_18_49 / z.zip_per_zcta),
            p.female_18_49
        )) as zip_female_18_49,
        sum(coalesce(
            (p.total_50_99 / z.zip_per_zcta),
            p.total_50_99
        )) as zip_total_50_99
    from pop_demo_zcta as p
    inner join zcta_to_zip as z on p.zcta = z.zcta
    group by z.zip, p.state, p.city
),

pop_demo_combined as (
    select distinct
        zip,
        city,
        state,
        zip_total,
        zip_total_18_49,
        zip_female_18_49,
        zip_total_50_99
    from pop_demo_islands
    union all
    select distinct
        zip,
        city,
        state,
        zip_total,
        zip_total_18_49,
        zip_female_18_49,
        zip_total_50_99
    from pop_demo_zcta_distributed
),

zip_state_eco as (
    select distinct
        zip,
        city,
        state,
        ecosystem_name,
        ecosystem_dim_id
    from oasis_normalized.alignment_zip_to_ecosystem_daily
    where flag_active = 'Y' and ecosystem_dim_id > 0
),

state_mapping as (
    select distinct
        site_state as state,
        site_state_name as state_name
    from oasis_normalized.hcp_outlet_affiliations_weekly
    where coalesce(site_state, 'unknown') != 'unknown'
),

hrr_data as (
    select distinct
        hospital_service_area_number,
        hospital_service_area_state_code,
        hospital_referral_region_number,
        lpad(cast(zip as varchar), 5, '0') as zip,
        trim(upper(hospital_service_area_city)) as hospital_service_area_city,
        trim(upper(hospital_referral_region_city))
            as hospital_referral_region_city,
        trim(upper(hospital_referral_region_state_code))
            as hospital_referral_region_state_code
    from
        sandbox_measurement_analyst.mars_health_equity_zip_to_hospital_referral_region_l_staging
),

all_cities_mapping as (
    select distinct
        zip_code,
        county,
        state,
        array_join(
            transform(
                filter(
                    split(all_cities, ';'), c -> c is not null and length(c) > 0
                ),
                c -> trim(c)
            ),
            ';'
        ) as all_cities
    from sandbox_measurement_analyst.mars_zipcode_to_all_cities_mapping_staging
),

zips_dma_deduped as (
    select distinct
        zip_code,
        dma_code,
        dma_name,
        county,
        state
    from sandbox_measurement_analyst.zip_to_dma_deduped
),

dma_state as (
    select distinct
        dma_code,
        state
    from zips_dma_deduped
),

dma_state_count as (
    select
        dma_code,
        count(*) as dma_state_count
    from dma_state
    group by dma_code
),

zips_dma_joined as (
    select distinct
        zips.zip_code,
        zips.dma_name,
        zips.dma_code,
        acm.all_cities,
        zips.state,
        dma.dma_state_count,
        coalesce(acm.county, zips.county) as county
    from zips_dma_deduped as zips
    left join all_cities_mapping as acm on zips.zip_code = acm.zip_code
    left join dma_state_count as dma on zips.dma_code = dma.dma_code
),

all_cols as (
    select distinct
        d.all_cities,
        d.dma_code,
        d.dma_name,
        st.state_name,
        d.dma_state_count,
        hrr.hospital_service_area_number,
        hrr.hospital_service_area_city,
        hrr.hospital_service_area_state_code,
        hrr.hospital_referral_region_number,
        hrr.hospital_referral_region_city,
        hrr.hospital_referral_region_state_code,
        zip_total,
        zip_total_18_49,
        zip_female_18_49,
        zip_total_50_99,
        coalesce(zse.city, p.city) as city,
        upper(d.county) as county,
        coalesce(zse.ecosystem_name, 'NO ECOSYSTEM') as ecosystem_name,
        coalesce(zse.ecosystem_dim_id, 999) as ecosystem_dim_id,
        coalesce(zse.state, p.state) as state,
        coalesce(zse.zip, p.zip) as zip,
        substr(coalesce(zse.zip, p.zip), 1, 3) as zip3
    from pop_demo_combined as p
    left join zips_dma_joined as d on p.zip = d.zip_code
    left join zip_state_eco as zse on p.zip = zse.zip
    left join state_mapping as st on coalesce(zse.state, p.state) = st.state
    left join hrr_data as hrr on hrr.zip = coalesce(zse.zip, p.zip)
),

final_agg as (
    select distinct
        zip,
        zip3,
        city,
        all_cities,
        county,
        dma_code,
        dma_name,
        state,
        state_name,
        dma_state_count,
        ecosystem_name,
        ecosystem_dim_id,
        hospital_service_area_number,
        hospital_service_area_city,
        hospital_service_area_state_code,
        hospital_referral_region_number,
        hospital_referral_region_city,
        hospital_referral_region_state_code,
        zip_total as total_pop,
        zip_total_18_49 as total_pop_18_49,
        zip_female_18_49 as total_pop_f_18_49,
        zip_total_50_99 as total_pop_50_99,

        zip_total / sum(cast(zip_total as double)) over () as wt_zip5_total,
        zip_total_18_49
        / sum(cast(zip_total_18_49 as double)) over () as wt_zip5_18_49,
        zip_female_18_49
        / sum(cast(zip_female_18_49 as double)) over () as wt_zip5_f_18_49,
        zip_total_50_99
        / sum(cast(zip_total_50_99 as double)) over () as wt_zip5_50_99,

        zip_total
        / sum(cast(zip_total as double))
            over (partition by city, state)
            as wt_city_total,
        zip_total_18_49
        / sum(cast(zip_total_18_49 as double))
            over (partition by city, state)
            as wt_city_18_49,
        zip_female_18_49
        / sum(cast(zip_female_18_49 as double))
            over (partition by city, state)
            as wt_city_f_18_49,
        zip_total_50_99
        / sum(cast(zip_total_50_99 as double))
            over (partition by city, state)
            as wt_city_50_99,

        zip_total
        / sum(cast(zip_total as double))
            over (partition by county, state)
            as wt_county_total,
        zip_total_18_49
        / sum(cast(zip_total_18_49 as double))
            over (partition by county, state)
            as wt_county_18_49,
        zip_female_18_49
        / sum(cast(zip_female_18_49 as double))
            over (partition by county, state)
            as wt_county_f_18_49,
        zip_total_50_99
        / sum(cast(zip_total_50_99 as double))
            over (partition by county, state)
            as wt_county_50_99,

        zip_total
        / sum(cast(zip_total as double))
            over (partition by dma_code)
            as wt_dma_total,
        zip_total_18_49
        / sum(cast(zip_total_18_49 as double)) over (partition by dma_code)
            as wt_dma_18_49,
        zip_female_18_49
        / sum(cast(zip_female_18_49 as double)) over (partition by dma_code)
            as wt_dma_f_18_49,
        zip_total_50_99
        / sum(cast(zip_total_50_99 as double)) over (partition by dma_code)
            as wt_dma_50_99,

        zip_total
        / sum(cast(zip_total as double))
            over (partition by state)
            as wt_state_total,
        zip_total_18_49
        / sum(cast(zip_total_18_49 as double))
            over (partition by state)
            as wt_state_18_49,
        zip_female_18_49
        / sum(cast(zip_female_18_49 as double))
            over (partition by state)
            as wt_state_f_18_49,
        zip_total_50_99
        / sum(cast(zip_total_50_99 as double))
            over (partition by state)
            as wt_state_50_99,

        zip_total
        / sum(cast(zip_total as double))
            over (partition by dma_code, state)
            as wt_dma_state_total,
        zip_total_18_49
        / sum(cast(zip_total_18_49 as double))
            over (partition by dma_code, state)
            as wt_dma_state_18_49,
        zip_female_18_49
        / sum(cast(zip_female_18_49 as double))
            over (partition by dma_code, state)
            as wt_dma_state_f_18_49,
        zip_total_50_99
        / sum(cast(zip_total_50_99 as double))
            over (partition by dma_code, state)
            as wt_dma_state_50_99,

        zip_total
        / sum(cast(zip_total as double))
            over (partition by ecosystem_dim_id)
            as wt_eco_total,
        zip_total_18_49
        / sum(cast(zip_total_18_49 as double))
            over (partition by ecosystem_dim_id)
            as wt_eco_18_49,
        zip_female_18_49
        / sum(cast(zip_female_18_49 as double))
            over (partition by ecosystem_dim_id)
            as wt_eco_f_18_49,
        zip_total_50_99
        / sum(cast(zip_total_50_99 as double))
            over (partition by ecosystem_dim_id)
            as wt_eco_50_99
    from all_cols
)

select * from final_agg
