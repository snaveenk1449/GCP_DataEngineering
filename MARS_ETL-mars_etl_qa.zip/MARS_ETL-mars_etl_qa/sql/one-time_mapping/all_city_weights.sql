/*
* This table is created to deal with a special case in the XO data. In the dma column provided, it contains not only the DMA name, but also counties and cities. However, it's not just the official
* city's name, but as per USPS, it contains names that are deemed either Acceptable or Unacceptable as well. Because of this, it is not enough that we calculate the weights of just the official city names,
* but we need to calculate it for every single city name that could map to a specific zip.
*/

with pop_demo_islands as (
    select
        zip_code as zip,
        dp1_0001c as zip_total,
        upper(state) as state,
        upper(name) as city,
        (
            dp1_0006c
            + dp1_0007c
            + dp1_0008c
            + dp1_0009c
            + dp1_0010c
            + dp1_0011c
        ) as zip_total_18_49,
        (
            dp1_0054c
            + dp1_0055c
            + dp1_0056c
            + dp1_0057c
            + dp1_0058c
            + dp1_0059c
        ) as zip_female_18_49,
        (
            dp1_0012c
            + dp1_0013c
            + dp1_0014c
            + dp1_0015c
            + dp1_0016c
            + dp1_0017c
            + dp1_0018c
            + dp1_0019c
        ) as zip_total_50_99
    from sandbox_measurement_analyst.mars_population_demographics_us_islands
),

pop_demo_zcta as (
    select
        zcta,
        null as state,
        null as city,
        (s0101_c01_001e) as total,
        (
            s0101_c01_023e
            + s0101_c01_007e
            + s0101_c01_008e
            + s0101_c01_009e
            + s0101_c01_010e
            + s0101_c01_011e
        ) as total_18_49,
        (
            s0101_c05_023e
            + s0101_c05_007e
            + s0101_c05_008e
            + s0101_c05_009e
            + s0101_c05_010e
            + s0101_c05_011e
        ) as female_18_49,
        (
            s0101_c01_012e
            + s0101_c01_013e
            + s0101_c01_014e
            + s0101_c01_015e
            + s0101_c01_016e
            + s0101_c01_017e + s0101_c01_018e + s0101_c01_019e
        ) as total_50_99
    from sandbox_measurement_analyst.mars_population_demographics_us
),

zcta_to_zip as (
    select distinct
        zip,
        state,
        zcta,
        sum(1) over (partition by zcta) as zip_per_zcta
    from sandbox_measurement_analyst.mars_zip_zcta_crosswalk
),

pop_demo_zcta_distributed as (
    select distinct
        z.zip,
        p.city,
        p.state,
        sum(coalesce(
            (p.total / z.zip_per_zcta),
            p.total
        )) as zip_total,
        sum(coalesce(
            (p.total_18_49 / z.zip_per_zcta),
            p.total_18_49
        )) as zip_total_18_49,
        sum(coalesce(
            (p.female_18_49 / z.zip_per_zcta),
            p.female_18_49
        )) as zip_female_18_49,
        sum(coalesce(
            (p.total_50_99 / z.zip_per_zcta),
            p.total_50_99
        )) as zip_total_50_99
    from pop_demo_zcta as p
    inner join zcta_to_zip as z on p.zcta = z.zcta
    group by z.zip, p.state, p.city
),

pop_demo_combined as (
    select distinct
        zip,
        city,
        state,
        zip_total,
        zip_total_18_49,
        zip_female_18_49,
        zip_total_50_99
    from pop_demo_islands
    union all
    select distinct
        zip,
        city,
        state,
        zip_total,
        zip_total_18_49,
        zip_female_18_49,
        zip_total_50_99
    from pop_demo_zcta_distributed
),

zip_state as (
    select distinct
        zip,
        city,
        state
    from oasis_normalized.alignment_zip_to_ecosystem_daily
    where flag_active = 'Y' and ecosystem_dim_id > 0
),

state_mapping as (
    select distinct
        site_state as state,
        site_state_name as state_name
    from oasis_normalized.hcp_outlet_affiliations_weekly
    where coalesce(site_state, 'unknown') != 'unknown'
),

all_cities_mapping as (
    select distinct
        zip_code,
        county,
        state,
        array_join(
            transform(
                filter(
                    split(all_cities, ';'), c -> c is not null and length(c) > 0
                ),
                c -> trim(c)
            ),
            ';'
        ) as all_cities
    from sandbox_measurement_analyst.mars_zipcode_to_all_cities_mapping_staging
),

zips_dma_deduped as (
    select distinct
        zip_code,
        state
    from sandbox_measurement_analyst.mars_zip_to_dma_deduped_staging
),

zips_dma_joined as (
    select distinct
        zips.zip_code,
        acm.all_cities,
        zips.state
    from zips_dma_deduped as zips
    left join all_cities_mapping as acm on zips.zip_code = acm.zip_code
),

all_cols as (
    select distinct
        d.all_cities,
        st.state_name,
        zip_total,
        zip_total_18_49,
        zip_female_18_49,
        zip_total_50_99,
        coalesce(zse.city, p.city) as city,
        coalesce(zse.state, p.state) as state,
        coalesce(zse.zip, p.zip) as zip
    from pop_demo_combined as p
    left join zips_dma_joined as d on p.zip = d.zip_code
    left join zip_state as zse on p.zip = zse.zip
    left join state_mapping as st on coalesce(zse.state, p.state) = st.state
),

all_cities as (
    select distinct
        zip,
        state,
        state_name,
        zip_total,
        zip_total_18_49,
        zip_female_18_49,
        zip_total_50_99,
        city || ';' || coalesce(all_cities, '9999999') as all_cities
    from all_cols
),

all_cities_array_ds as (
    select distinct
        zip,
        state,
        state_name,
        zip_total,
        zip_total_18_49,
        zip_female_18_49,
        zip_total_50_99,
        array_distinct(split(all_cities, ';')) as all_cities_array
    from all_cities
),

all_cities_unnested as (
    select distinct
        zip,
        u.city,
        state,
        state_name,
        zip_total,
        zip_total_18_49,
        zip_female_18_49,
        zip_total_50_99
    from all_cities_array_ds, unnest(all_cities_array) as u (city)
    where u.city != '9999999'
),

final_agg as (
    select distinct
        zip,
        city,
        state,
        state_name,
        zip_total as total_population,
        zip_total_18_49 as total_pop_18_49,
        zip_female_18_49 as total_pop_f_18_49,
        zip_total_50_99 as total_pop_50_99,

        zip_total
        / sum(cast(zip_total as double))
            over (partition by city, state)
            as wt_city_total,
        zip_total_18_49
        / sum(cast(zip_total_18_49 as double))
            over (partition by city, state)
            as wt_city_18_49,
        zip_female_18_49
        / sum(cast(zip_female_18_49 as double))
            over (partition by city, state)
            as wt_city_f_18_49,
        zip_total_50_99
        / sum(cast(zip_total_50_99 as double))
            over (partition by city, state)
            as wt_city_50_99
    from all_cities_unnested
)

select * from final_agg
