with zipcode_mapping as (
    select * from (
        values
        ('Agana Heights', '96919'),
        ('Agat', '96928'),
        ('Asan', '96922'),
        ('Barrigada', '96913'),
        ('Chalan Pago-Ordot', '96910'),
        ('Dededo', '96912'),
        ('Hagatna', '96910'),
        ('Inarajan', '96917'),
        ('Mangilao', '96923'),
        ('Merizo', '96916'),
        ('Mongmong-Toto-Maite', '96927'),
        ('Piti', '96925'),
        ('Santa Rita', '96915'),
        ('Sinajana', '96926'),
        ('Talofofo', '96930'),
        ('Tamuning', '96913'),
        ('Umatac', '96918'),
        ('Yigo', '96929'),
        ('Yona', '96914'),
        ('Saipan', '96950'),
        ('Rota', '96951'),
        ('Tinian', '96952'),
        ('St. Croix Island', '00820'),
        ('St. Croix Island', '00821'),
        ('St. Croix Island', '00822'),
        ('St. Croix Island', '00823'),
        ('St. Croix Island', '00824'),
        ('St. Croix Island', '00840'),
        ('St. Croix Island', '00841'),
        ('St. Croix Island', '00850'),
        ('St. Croix Island', '00851'),
        ('St. John Island', '00830'),
        ('St. John Island', '00831'),
        ('St. Thomas Island', '00801'),
        ('St. Thomas Island', '00802'),
        ('St. Thomas Island', '00803'),
        ('St. Thomas Island', '00804'),
        ('St. Thomas Island', '00805'),
        ('Pago Pago', '96799')
    ) as isl (name, zip_code)
),

raw_ds as (
    select
        *,
        case
            when
                name like '%municipality%'
                then
                    trim(regexp_extract(name, '^(.*?)(?=municipality)', 1))
            when
                name like '%Municipality%' and lower(name) like '%mariana%'
                then
                    trim(
                        regexp_extract(
                            split(name, ',')[2], '^(.*?)(?=Municipality)', 1
                        )
                    )
            when lower(name) like '%virgin%'
                then
                    trim(split(name, ',')[2])
            when lower(name) like '%samoa%'
                then trim(split(name, 'village')[1])
            else trim(name)
        end as cleaned_name,
        case
            when lower(name) like '%guam%' then 'GU' when
                lower(name) like '%mariana%'
                then 'MP'
            when lower(name) like '%virgin%' then 'VI'
            else 'AS'
        end as state
    from sandbox_measurement_analyst.mars_population_demographics_us_islands_raw
    where
        name not like '%not defined%'
        and name not like '%Northern Islands Municipality%'
),

agg_data as (
    select
        z.zip_code,
        cleaned_name as name,
        state,
        sum(dp1_0001c) as dp1_0001c,
        sum(dp1_0006c) as dp1_0006c,
        sum(dp1_0007c) as dp1_0007c,
        sum(dp1_0008c) as dp1_0008c,
        sum(dp1_0009c) as dp1_0009c,
        sum(dp1_0010c) as dp1_0010c,
        sum(dp1_0011c) as dp1_0011c,
        sum(dp1_0012c) as dp1_0012c,
        sum(dp1_0013c) as dp1_0013c,
        sum(dp1_0014c) as dp1_0014c,
        sum(dp1_0015c) as dp1_0015c,
        sum(dp1_0016c) as dp1_0016c,
        sum(dp1_0017c) as dp1_0017c,
        sum(dp1_0018c) as dp1_0018c,
        sum(dp1_0019c) as dp1_0019c,
        sum(dp1_0054c) as dp1_0054c,
        sum(dp1_0055c) as dp1_0055c,
        sum(dp1_0056c) as dp1_0056c,
        sum(dp1_0057c) as dp1_0057c,
        sum(dp1_0058c) as dp1_0058c,
        sum(dp1_0059c) as dp1_0059c
    from raw_ds as r
    inner join zipcode_mapping as z
        on r.cleaned_name = z.name
    group by
        state,
        cleaned_name,
        z.zip_code
),

vi_norm as (
    select
        *,
        case
            when
                state = 'VI'
                then count(zip_code) over (partition by name, state)
            else 1
        end as zip_count
    from agg_data
)

select
    zip_code,
    name,
    state,
    ceil(dp1_0001c / zip_count) as dp1_0001c,
    ceil(dp1_0006c / zip_count) as dp1_0006c,
    ceil(dp1_0007c / zip_count) as dp1_0007c,
    ceil(dp1_0008c / zip_count) as dp1_0008c,
    ceil(dp1_0009c / zip_count) as dp1_0009c,
    ceil(dp1_0010c / zip_count) as dp1_0010c,
    ceil(dp1_0011c / zip_count) as dp1_0011c,
    ceil(dp1_0012c / zip_count) as dp1_0012c,
    ceil(dp1_0013c / zip_count) as dp1_0013c,
    ceil(dp1_0014c / zip_count) as dp1_0014c,
    ceil(dp1_0015c / zip_count) as dp1_0015c,
    ceil(dp1_0016c / zip_count) as dp1_0016c,
    ceil(dp1_0017c / zip_count) as dp1_0017c,
    ceil(dp1_0018c / zip_count) as dp1_0018c,
    ceil(dp1_0019c / zip_count) as dp1_0019c,
    ceil(dp1_0054c / zip_count) as dp1_0054c,
    ceil(dp1_0055c / zip_count) as dp1_0055c,
    ceil(dp1_0056c / zip_count) as dp1_0056c,
    ceil(dp1_0057c / zip_count) as dp1_0057c,
    ceil(dp1_0058c / zip_count) as dp1_0058c,
    ceil(dp1_0059c / zip_count) as dp1_0059c
from vi_norm
