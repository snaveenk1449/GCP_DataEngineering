/*
* The zip_to_dma table is essentially a flat file provided by Nielsen that is loaded by the Oasis team. This is a good reference table to use as it provides the DMA name,
* county name, state, and all the zips that fall under that particular DMA/county/state. However, it contains duplicate zip codes as some counties fall under multiple DMAs and can therefore have 
* multiple zip codes associated with them. To get around this, Nielsen themselves provide a file that contains TVs per household information for duplicate zip-counties, which we can use as a tie-break
* and allocate a single zip to a county and DMA. However, once this logic is applied, there are still a few counties that cross state lines and we need to deduplicate those. We extend the logic
* of using the county with the higher number of TV HHs to use the state with the higher TV HHs, and use that as a second-level tie-breaker.
*
*/

-- Get all zips, DMA codes and names, county, state and TV HH, and compute the number of times a zip occurs to know if it is part of a duplicate set or not

with zip_tv_hh as (
    select distinct
        z.zip_code,
        z.dma_code,
        z.designated_market_area as dma_name,
        z.county,
        z.state,
        d.tv_hh,
        count(z.zip_code) over (partition by z.zip_code) as zip_count
    from oasis_normalized.zip_to_dma as z
    left join sandbox_measurement_analyst.mars_zip_dma_crossover_staging as d
        on
            z.zip_code = d.zip_code
            and z.dma_code = d.dma
            and upper(z.county) = d.county_name
),

-- Calculate the sum of all TV HHs across a DMA and county, and DMA and state

tv_hh_agg as (
    select distinct
        zip_code,
        dma_code,
        dma_name,
        county,
        state,
        tv_hh,
        zip_count,
        sum(tv_hh) over (partition by dma_code, county) as total_tv_hh_county,
        sum(tv_hh) over (partition by dma_code, state) as total_tv_hh_state
    from zip_tv_hh
),

-- Select all the same columns as above, except apply the tie-breaking logic, using the first_values of each and, in order,
-- the raw tv_hh value, followed by the total_tv_hh_county value and lastly, the total_tv_hh_state, to break ties 

zip_dma_dedupe as (
    select distinct
        zip_code,
        upper(
            case
                when zip_count = 1 then dma_name when
                    zip_count > 1
                    then
                        first_value(dma_name)
                            over (partition by zip_code order by tv_hh desc)
                when
                    zip_count > 1
                    and sum(tv_hh) over (partition by zip_code) is null
                    then
                        first_value(dma_name)
                            over (
                                partition by zip_code
                                order by total_tv_hh_county desc
                            )
                when
                    zip_count > 1
                    and sum(total_tv_hh_county)
                        over (partition by zip_code)
                    is null
                    then
                        first_value(dma_name)
                            over (
                                partition by zip_code
                                order by total_tv_hh_state desc
                            )
            end
        ) as dma_name,
        case
            when zip_count = 1 then dma_code when
                zip_count > 1
                then
                    first_value(dma_code)
                        over (partition by zip_code order by tv_hh desc)
            when
                zip_count > 1
                and sum(tv_hh) over (partition by zip_code) is null
                then
                    first_value(dma_code)
                        over (
                            partition by zip_code
                            order by total_tv_hh_county desc
                        )
            when
                zip_count > 1
                and sum(total_tv_hh_county) over (partition by zip_code) is null
                then
                    first_value(dma_code)
                        over (
                            partition by zip_code
                            order by total_tv_hh_state desc
                        )
        end as dma_code,
        upper(
            case
                when zip_count = 1 then county when
                    zip_count > 1
                    then
                        first_value(county)
                            over (partition by zip_code order by tv_hh desc)
                when
                    zip_count > 1
                    and sum(tv_hh) over (partition by zip_code) is null
                    then
                        first_value(county)
                            over (
                                partition by zip_code
                                order by total_tv_hh_county desc
                            )
                when
                    zip_count > 1
                    and sum(total_tv_hh_county)
                        over (partition by zip_code)
                    is null
                    then
                        first_value(county)
                            over (
                                partition by zip_code
                                order by total_tv_hh_state desc
                            )
            end
        ) as county,
        upper(
            case
                when zip_count = 1 then state when
                    zip_count > 1
                    then
                        first_value(state)
                            over (partition by zip_code order by tv_hh desc)
                when
                    zip_count > 1
                    and sum(tv_hh) over (partition by zip_code) is null
                    then
                        first_value(state)
                            over (
                                partition by zip_code
                                order by total_tv_hh_county desc
                            )
                when
                    zip_count > 1
                    and sum(total_tv_hh_county)
                        over (partition by zip_code)
                    is null
                    then
                        first_value(state)
                            over (
                                partition by zip_code
                                order by total_tv_hh_state desc
                            )
            end
        ) as state
    from tv_hh_agg
)

select * from zip_dma_dedupe
