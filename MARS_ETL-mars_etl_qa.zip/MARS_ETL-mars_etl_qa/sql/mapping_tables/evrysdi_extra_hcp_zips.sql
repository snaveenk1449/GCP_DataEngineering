/*
* There are 4 HCPs who don't make it through the MCE filtering because they don't belong to the primary or secondary specializations that would see them included, but have been identified
* as exceptions by the Evrysdi/NRD team at Genentech to be included nonetheless. This table gets their IDs and site ZIPs, so we can use it in other scripts to get their sales/TAM engagement
*/

with evrysdi_extra_hcps as (
    select
        mdm_id,
        mdm_zip
    from oasis_normalized.master_cm_mdm_profile_weekly
    where mdm_id in ('324903', '647970', '2025213', '23546250')
),

evrysdi_extra_hcp_sites as (
    select distinct
        hcp_outlet_mdm_id as mdm_id,
        site_zip as mdm_zip
    from oasis_normalized.hcp_outlet_affiliations_weekly
    where
        flag_primary_affiliation = 'Y'
        and hcp_outlet_mdm_id is not null
        and upper(affiliation_status) = 'ACTIVE'
),

evrysdi_extra_hcp_zips as (
    select distinct
        e.mdm_id,
        coalesce(es.mdm_zip, e.mdm_zip) as mdm_zip
    from evrysdi_hcps as e
    left join evrysdi_hcp_sites as es on e.mdm_id = es.mdm_id
)

select * from evrysdi_extra_hcp_zips
