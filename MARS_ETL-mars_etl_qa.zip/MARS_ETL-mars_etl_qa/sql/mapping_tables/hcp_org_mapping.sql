/*
* HCP-Org Mapping - This is a table created for the convenience of getting all HCPs and Sites (or Orgs) with their zips and ecosystems. For HCPs, if they have an affiliated site, 
* we take that site's zip and if not, default to the HCP's recorded zip (hcp_site and hcp_site_master_ds CTEs). We apply the MCE logic in this mapping table itself, creating a list of all products that the HCP is approved for.
* This way, when we join on the sales/TAM source tables and a HCP is associated with an off-label drug in those tables, they'd get filtered out because it won't be part of the included list here.
* 
* MCE Logic - We start with getting the primary and secondary specialization codes for every HCP and putting it in an array (spcl_codes column in the mdm_zip_ds CTE). 
* Next, we look at the alignment_brand_credit_rules table, which dictates which specializations are approved for which brands, and create an array of those codes 
* (prod_codes column in the all_product_incl_codes CTE). We then cross join these two tables based on the intersection of these two arrays, effectively filtering 
* any HCPs with either no specialization or no approved specializations, while also creating an array of all the brands that the HCP is approved for (mce_incl_mdm_ds CTE). 
* 
* Since MCE logic can't be applied to sites, we default it to all sites being approved for all products (org_site CTE).
* Finally, we union all the HCPs with all the sites from the master_cm_org_profile_weekly table, and join the unioned dataset with the alignment_zip_to_ecosystem_daily table to get the ecosytem information.
*
*/

with mdm_zip_ds as (
    select distinct
        mdm_id,
        mdm_zip,
        filter(
            array_distinct(
                array[primary_phyn_spcl_code, secondary_phyn_spcl_code]
            ),
            s -> s is not null
        ) as spcl_codes
    from sandbox_measurement_analyst.mars_master_cm_mdm_profile_weekly_staging
    where
        party_type = 'IND'
),

all_product_incl_codes as (
    select
        product_brand_name,
        product_brand_id,
        array_agg(code) as prod_codes
    from sandbox_measurement_analyst.mars_alignment_brand_credit_rules_staging
    where
        upper(trim(exception_type)) = 'INCLUDE'
        and product_flag_competitor = 'N'
        and source_data = 'XPO'
    group by product_brand_name, product_brand_id
),

mce_incl_mdm_ds as (
    select distinct
        mz.mdm_id,
        mz.mdm_zip,
        array_distinct(array_sort(array_agg(pic.product_brand_id)))
            as product_brand_id,
        array_distinct(array_sort(array_agg(pic.product_brand_name)))
            as product_brand_name
    from mdm_zip_ds as mz
    cross join all_product_incl_codes as pic
    where cardinality(array_intersect(mz.spcl_codes, pic.prod_codes)) > 0
    group by mz.mdm_id, mz.mdm_zip
),

hcp_site as (
    select distinct
        hcp_outlet_mdm_id as mdm_id,
        site_zip as mdm_zip
    from sandbox_measurement_analyst.mars_hcp_outlet_affiliations_weekly_staging
    where
        flag_primary_affiliation = 'Y'
        and hcp_outlet_mdm_id is not null
        and upper(affiliation_status) = 'ACTIVE'
),

hcp_site_master_ds as (
    select distinct
        m.mdm_id,
        m.product_brand_id,
        m.product_brand_name,
        'HCP' as mdm_type,
        coalesce(hs.mdm_zip, m.mdm_zip) as mdm_zip
    from mce_incl_mdm_ds as m left join hcp_site as hs on m.mdm_id = hs.mdm_id
),

org_site as (
    select distinct
        org_mdm_id as mdm_id,
        org_zip as mdm_zip,
        'SITE' as mdm_type,
        array_distinct(array_sort(array_agg(pic.product_brand_id)))
            as product_brand_id,
        array_distinct(array_sort(array_agg(pic.product_brand_name)))
            as product_brand_name
    from sandbox_measurement_analyst.mars_master_cm_org_profile_weekly_staging
    cross join all_product_incl_codes as pic
    group by org_mdm_id, org_zip
),

hcp_org as (
    select
        mdm_id,
        mdm_zip,
        product_brand_id,
        product_brand_name,
        mdm_type
    from hcp_site_master_ds
    union
    select
        mdm_id,
        mdm_zip,
        product_brand_id,
        product_brand_name,
        mdm_type
    from org_site
),

zip_eco_map as (
    select distinct
        zip,
        state,
        ecosystem_dim_id,
        ecosystem_name
    from sandbox_measurement_analyst.mars_alignment_zip_to_ecosystem_daily_staging
    where
        flag_active = 'Y'
        and ecosystem_dim_id > 0
),

hcp_org_map as (
    select distinct
        ho.mdm_id,
        ho.mdm_zip,
        ho.product_brand_id,
        ho.product_brand_name,
        zem.ecosystem_name,
        zem.ecosystem_dim_id,
        ho.mdm_type
    from hcp_org as ho inner join zip_eco_map as zem on ho.mdm_zip = zem.zip
),

final_ds as (
    select distinct
        mdm_id,
        product_brand_id,
        product_brand_name,
        mdm_zip,
        ecosystem_name,
        ecosystem_dim_id,
        mdm_type
    from hcp_org_map
)

select * from final_ds
