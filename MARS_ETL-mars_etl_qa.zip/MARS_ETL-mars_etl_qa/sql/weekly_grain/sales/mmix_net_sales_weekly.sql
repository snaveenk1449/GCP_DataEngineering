WITH daily_sales_agg AS (
    SELECT 
        product_brand_name,
        DATE(CAST(year AS VARCHAR) || '-' || LPAD(CAST(month AS VARCHAR), 2, '0') || '-' || LPAD(CAST(day AS VARCHAR), 2, '0')) AS sale_date,
        SUM(daily_sales) AS daily_sales
    FROM 
        sandbox_measurement_analyst.mmix_net_sales_daily
    GROUP BY 1, 2
),
xo_lookup AS (
    SELECT DISTINCT
        DATE(week_begin_date) AS week_begin_date, 
        DATE(week_end_date) AS week_end_date, 
        year, 
        week,
        CONCAT(CAST(year AS VARCHAR), '-', LPAD(CAST(week AS VARCHAR), 2, '0')) AS year_week
    FROM oasis_normalized.mars_xo_digital_campaign
    WHERE week > '0'
),
weekly_sales AS (
    SELECT
        ds.product_brand_name,
        xl.year_week,
        SUM(ds.daily_sales) AS net_sales
    FROM daily_sales_agg ds
    INNER JOIN xo_lookup xl
        ON ds.sale_date >= xl.week_begin_date 
        AND ds.sale_date <= xl.week_end_date
    GROUP BY 1, 2
),
final_agg AS (
    SELECT 
        CASE 
            WHEN product_brand_name IN ('ACTEMRA IV', 'ACTEMRA SC') THEN 'ACTEMRA' 
            ELSE product_brand_name 
        END AS product_brand_name,
        year_week,
        SUM(net_sales) AS net_sales
    FROM weekly_sales
    GROUP BY 1, 2
)
SELECT 
    * 
FROM final_agg