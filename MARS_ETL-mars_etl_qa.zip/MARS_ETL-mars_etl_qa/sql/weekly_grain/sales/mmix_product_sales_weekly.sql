WITH sales_data AS (
    SELECT 
        product_brand_name, 
        product_id,
        site_zip AS zip, 
        DATE(CAST(year AS VARCHAR) || '-' || LPAD(CAST(month AS VARCHAR), 2, '0') || '-' || LPAD(CAST(week AS VARCHAR), 2, '0')) AS sale_date,
        SUM(weekly_sales_eqv_qty) AS total_weekly_sales,
        SUM(weekly_gross_sales_dollars) AS total_weekly_gross_sales,
        SUM(weekly_sales_qty_eqv_mce_inc) AS total_weekly_sales_mce_inc,
        SUM(weekly_gross_sales_dollars_mce_inc) AS total_weekly_gross_sales_mce_inc
    FROM 
        sandbox_measurement_analyst.mmix_product_sales_daily 
    GROUP BY 1, 2, 3, 4
), 
xo_lookup AS (
    SELECT 
        date(week_begin_date) AS week_begin_date, 
        date(week_end_date) AS week_end_date, 
        year, 
        week,
        CONCAT(CAST(year AS VARCHAR), '-', LPAD(CAST(week AS VARCHAR), 2, '0')) AS year_week
    FROM xo_mapping_table_v2
    WHERE week > '0'
),
final_agg AS (
    SELECT
        sd.product_brand_name,
        sd.product_id,
        xo.year_week,
        sd.zip,
        SUM(sd.total_weekly_sales) AS sales_qty,
        SUM(sd.total_weekly_gross_sales) AS gross_sales_dollars,
        SUM(sd.total_weekly_sales_mce_inc) AS sales_qty_eqv_mce_inc,
        SUM(sd.total_weekly_gross_sales_mce_inc) AS gross_sales_dollars_mce_inc
    FROM sales_data AS sd 
    INNER JOIN xo_lookup xo ON sd.sale_date >= xo.week_begin_date 
                           AND sd.sale_date <= xo.week_end_date
    WHERE sd.sale_date >= DATE '2022-01-01'
    GROUP BY 1, 2, 3, 4
)
select * from final_agg 
where product_brand_name in(
            'ACTEMRA',
            'EVRYSDI',
            'GAZYVA',
            'HEMLIBRA',
            'OCREVUS',
            'PERJETA',
            'PHESGO',
            'POLIVY',
            'TECENTRIQ',
            'VABYSMO',
            'XOLAIR'
)