with sales_data as (
    select 
       product_brand_name, 
       zip, 
       DATE(CAST(year AS VARCHAR) || '-' || LPAD(CAST(month AS VARCHAR), 2, '0') || '-' || LPAD(CAST(day AS VARCHAR), 2, '0')) AS sale_date,
       SUM(daily_sales) AS total_weekly_sales  
    from 
        sandbox_measurement_analyst.mmix_sales_qty_daily
    group by 1, 2, 3
),
xo_lookup AS (
    SELECT 
        date(week_begin_date) AS week_begin_date, 
        date(week_end_date) AS week_end_date, 
        year, 
        week
    from oasis_normalized.mars_xo_digital_campaign
),
weekly_lookup AS (
    SELECT DISTINCT
        date(week_begin_date) AS week_begin_date,
        date(week_end_date) AS week_end_date,
        CONCAT(CAST(year AS VARCHAR), '-', LPAD(CAST(week AS VARCHAR), 2, '0')) AS year_week
    FROM xo_lookup
    where week > '0'
),
split_cost_distribution AS (
    SELECT
        cd.product_brand_name,
        cd.sale_date,
        cd.zip,
        cd.total_weekly_sales,
        wl.year_week
    FROM sales_data cd
    INNER JOIN weekly_lookup wl ON cd.sale_date >= wl.week_begin_date 
                             AND cd.sale_date <= wl.week_end_date
    
),
final_agg as(
    select 
        distinct 
        case when product_brand_name in('ACTEMRA IV', 'ACTEMRA SC') then 'ACTEMRA' else product_brand_name
                    end as product_brand_name,
        year_week,
        zip, 
        sum(total_weekly_sales) as sales_qty 
    from split_cost_distribution
    group by 1, 2, 3
)
select * from final_agg

