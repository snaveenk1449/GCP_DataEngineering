with tam_hds as (
    select distinct
        unix_id,
        start_date,
        end_date
    from
        sandbox_measurement_analyst.mars_alignment_roster_hierarchy_daily_staging
    where
        field_title_code in (
            'TAM',
            'HD',            
            'NRDS', -- For Evrysdi
            'SNRDS', -- For Evrysdi
            'NRDHD', -- For Evrysdi
            'ACM', -- For Hemlibra
            'CS', -- For Actemra
            'SCS', -- For Actemra
            'CSO_CS', -- For Actemra
            'CSO_DM', -- For Actemra
            'CSO_RD' -- For Actemra
        )
),

hcp_org_mapping as (
    select
        mdm_id,
        product_brand_id,
        product_brand_name,
        mdm_zip
    from mars_hcp_org_mapping_staging
),

tam_hd_calls as (
    select distinct
        ci.crm_call_id,
        ci.mdm_id,
        ci.crm_display_order,
        cast(1 / ci.crm_display_order as double) as call_wt,
        ci.crm_call_datetime, 
        date(ci.crm_call_datetime) as call_date,
        ci.oasis_brand_name as product_brand_name,
        ci.oasis_product_brand_id as product_brand_id,
        hom.mdm_zip as zip,
        'HCP' as mdm_type
    from
        oasis_normalized.crm_commercial_interactions as ci
    inner join
        tam_hds as th
        on
            ci.crm_user_id = th.unix_id
            and ci.crm_call_datetime between th.start_date and th.end_date
    inner join hcp_org_mapping as hom
        on
            ci.mdm_id = hom.mdm_id
            and cardinality(
                array_intersect(
                    array[ci.oasis_brand_name], hom.product_brand_name
                )
            ) > 0
    where upper(crm_call_status) = 'SUBMITTED' and cast(crm_flag_person_account as integer) = 1 
    and date(crm_call_datetime) >= date '2022-01-01'

), 
evrysdi_extra_tam_hd_calls as (
    select distinct
        ci.crm_call_id,
        ci.mdm_id,
        ci.crm_display_order,
        cast(1 / ci.crm_display_order as double) as call_wt,
        ci.crm_call_datetime, 
        date(ci.crm_call_datetime) as call_date,
        ci.oasis_brand_name as product_brand_name,
        ci.oasis_product_brand_id as product_brand_id,
        ev.mdm_zip as zip,
        'HCP' as mdm_type
    from
        sandbox_measurement_analyst.mars_crm_commercial_interactions_staging as ci
    inner join
        tam_hds as th
        on
            ci.crm_user_id = th.unix_id
            and ci.crm_call_datetime between th.start_date and th.end_date
    inner join
        sandbox_measurement_analyst.mars_evrysdi_extra_hcp_zips_staging as ev
        on ci.mdm_id = ev.mdm_id
    where upper(crm_call_status) = 'SUBMITTED' and cast(crm_flag_person_account as integer) = 1 
),

all_tam_hd_calls as (
    select * from tam_hd_calls
    union all
    select * from evrysdi_extra_tam_hd_calls
),

daily_reach as (
    select
        product_brand_name,
        call_date,
        zip,
        sum(call_wt) as reach
    from all_tam_hd_calls
    group by 1, 2, 3
),

monthly_reach as (
    select
        product_brand_name,
        date_format(call_date, '%Y%m') as year_month,
        sum(reach) as monthly_reach
    from daily_reach
    group by 1, 2
),
tam_costs as(
    select 
        brand as product_brand_name,
        concat(cast(year as varchar), lpad(cast(month as varchar), 2, '0')) as year_month,
        sum(cost) as cost 
    from sandbox_measurement_analyst.mars_tam_costs_staging 
    where channel = 'tam_hd' and audience = 'CE'
    group by 1, 2
),

monthly_costs as (
    select
      product_brand_name,
        year_month,
        case
            when upper(product_brand_name) = 'HEMLIBRA' and year_month  >= '202307'
            then cost / 2
            when upper(product_brand_name) = 'GAZYVA' and year_month >= '202301' 
            then 0 
        else cost
        end as cost
    from tam_costs
),
cost_allocation as (
    select
        dr.product_brand_name,
        dr.call_date,
        dr.zip,
        dr.reach,
        mc.cost * (dr.reach / mr.monthly_reach) as allocated_cost
    from daily_reach dr
    join monthly_reach mr
        on dr.product_brand_name = mr.product_brand_name
        and date_format(dr.call_date, '%Y%m') = mr.year_month
    join monthly_costs mc
        on dr.product_brand_name = mc.product_brand_name
        and date_format(dr.call_date, '%Y%m') = mc.year_month
),

xo_lookup AS (
    select 
        date(week_begin_date) AS week_begin_date, 
        date(week_end_date) AS week_end_date, 
        year, 
        week
    from oasis_normalized.mars_xo_digital_campaign
),

weekly_lookup AS (
    select distinct
        date(week_begin_date) AS week_begin_date,
        date(week_end_date) AS week_end_date,
        concat(cast(year AS varchar), '-', lpad(cast(week as varchar), 2, '0')) AS year_week
    from xo_lookup
    where week > '0'
),
daily_allocation AS (
    select
        ca.product_brand_name,
        ca.call_date,
        ca.zip,
        wl.year_week,
        ca.reach,
        ca.allocated_cost as cost 
    from cost_allocation as ca 
    join weekly_lookup wl 
        on ca.call_date >= wl.week_begin_date 
        and ca.call_date <= wl.week_end_date
    where ca.call_date >= date '2022-01-01'
), 
final_agg as(
    select 
        product_brand_name, 
        year_week, 
        zip, 
        'CE' as audience, 
        'tam_hd' as channel,
        cast(null as double) as engage,
        sum(reach) as reach, 
        sum(cost) as cost
    from daily_allocation
    group by 1, 2, 3, 4, 5
)
select *
from final_agg 
