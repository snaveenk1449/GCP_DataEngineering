-- create table mars_tam_dtc_weekly_staging as 
WITH tam_hd_costs_monthly AS (
    SELECT 
        brand, 
        channel, 
        audience, 
        concat(cast(year as varchar), lpad(cast(month as varchar), 2, '0')) as year_month,
        CASE
            WHEN concat(cast(year as varchar), lpad(cast(month as varchar), 2, '0')) >= '202307'
                THEN cost / 2
            ELSE cost
        END AS monthly_cost
    FROM sandbox_measurement_analyst.mars_tam_costs_staging
    WHERE audience = 'DTC' AND brand = 'HEMLIBRA' AND channel = 'tam'
), 
interactions_data AS (
    SELECT
        date_format(parse_datetime(interaction_date, 'MM/dd/yyyy'), '%Y-%m-%d') AS int_date,
        date_format(parse_datetime(interaction_date, 'MM/dd/yyyy'), '%Y%m') AS int_year_month,
        eco.zip,
        SUM(number_of_interactions) AS reach
    FROM sandbox_measurement_analyst.mars_tam_pccm_interactions_staging AS pccm
    INNER JOIN sandbox_measurement_analyst.mars_alignment_zip_to_ecosystem_daily_staging AS eco
        ON pccm.zip_code = eco.zip
    WHERE
        upper(pccm.product) = 'HEMLIBRA'
        AND eco.flag_active = 'Y'
        AND eco.ecosystem_dim_id > 0
        AND trim(pccm.interaction_type) != 'Attempted Contact'
        AND date_format(parse_datetime(interaction_date, 'MM/dd/yyyy'), '%Y-%m-%d') <= '2023-12-31'
        AND date_format(parse_datetime(interaction_date, 'MM/dd/yyyy'), '%Y-%m-%d') >= '2022-04-01'
    GROUP BY 1, 2, 3
),
monthly_reach AS (
    SELECT int_year_month, SUM(reach) AS total_reach
    FROM interactions_data
    GROUP BY 1
),
cost_distribution AS (
    SELECT
        'HEMLIBRA' AS product_brand_name,
        i.int_date,
        i.int_year_month,
        i.zip,
        i.reach,
        (i.reach / mr.total_reach) * c.monthly_cost AS distributed_cost
    FROM
        interactions_data i
    JOIN monthly_reach mr ON i.int_year_month = mr.int_year_month
    JOIN tam_hd_costs_monthly c ON i.int_year_month = c.year_month
),
xo_lookup AS (
    SELECT 
        date(week_begin_date) AS week_begin_date, 
        date(week_end_date) AS week_end_date, 
        year, 
        week
    FROM oasis_normalized.mars_xo_digital_campaign
),
weekly_lookup AS (
    SELECT DISTINCT
        date(week_begin_date) AS week_begin_date,
        date(week_end_date) AS week_end_date,
        CONCAT(CAST(year AS VARCHAR), '-', LPAD(CAST(week AS VARCHAR), 2, '0')) AS year_week
    FROM xo_lookup
    where week > '0' 
),
split_cost_distribution AS (
    SELECT
        cd.product_brand_name,
        cd.int_date,
        cd.zip,
        cd.reach,
        cd.distributed_cost as cost,
        wl.year_week
    FROM cost_distribution cd
    INNER JOIN weekly_lookup wl 
        ON date(cd.int_date) >= wl.week_begin_date 
        AND date(cd.int_date) <= wl.week_end_date
),
final_agg as(
    select 
        distinct
        product_brand_name, 
        year_week, 
        zip, 
        'DTC' as audience, 
        'tam' as channel,
        cast(null as double) as engage,
        sum(reach) as reach, 
        sum(cost) as cost
    from split_cost_distribution
    group by 1, 2, 3, 4, 5
)
select 
    *
from 
    final_agg 
    


    
    
