-- create table mars_xo_weekly_staging as 
with xo_raw_ds as (
    select distinct
        brand,
        channel,
        audience,
        month,
        week,
        year,
        zip_code,
        upper(trim(dma)) as dma,
        country,
        reach,
        engage,
        cost,
        case
            when state like '%District%' then 'District of Columbia' else state
        end as state
    from oasis_normalized.mars_xo_digital_campaign
),

zips_weights as (
    select distinct
        zip,
        dma_code,
        dma_name,
        county,
        state,
        state_name,
        dma_state_count,
        total_population,
        total_pop_18_49,
        total_pop_f_18_49,
        total_pop_50_99,
        wt_zip5_total,
        wt_zip5_18_49,
        wt_zip5_f_18_49,
        wt_zip5_50_99,
        wt_county_total,
        wt_county_18_49,
        wt_county_f_18_49,
        wt_county_50_99,
        wt_dma_total,
        wt_dma_18_49,
        wt_dma_f_18_49,
        wt_dma_50_99,
        wt_state_total,
        wt_state_18_49,
        wt_state_f_18_49,
        wt_state_50_99,
        wt_dma_state_total,
        wt_dma_state_18_49,
        wt_dma_state_f_18_49,
        wt_dma_state_50_99
    from sandbox_measurement_analyst.mars_population_demographics_final
    where state is not null
),

city_weights as (
    select distinct
        zip,
        regexp_replace(
            regexp_replace(
                city,
                '(AIR\s+FORCE\s+BASE|AIR\s+RESERVE\s+BASE|A\s+F\s+B)',
                'AFB'
            ),
            '(TWP)',
            'TOWNSHIP'
        ) as city,
        state,
        state_name,
        total_population,
        total_pop_18_49,
        total_pop_f_18_49,
        total_pop_50_99,
        wt_city_total,
        wt_city_18_49,
        wt_city_f_18_49,
        wt_city_50_99
    from
    sandbox_measurement_analyst.mars_all_city_weights
),

state_values as (
    select distinct
        state,
        state_name
    from zips_weights
),

xo_norm_stg_1 as (
    select distinct
        xd.audience,
        xd.zip_code,
        dma,
        xd.country,
        cast(xd.reach as DOUBLE) as reach,
        cast(xd.engage as DOUBLE) as engage,
        cast(xd.cost as DOUBLE) as cost,
        concat(cast(xd.year AS VARCHAR), '-', lpad(cast(xd.week AS VARCHAR), 2, '0')) AS year_week,
        concat(xd.year, lpad(xd.month, 2, '0')) as year_month,
        upper(trim(xd.brand)) as brand,
        lower(regexp_replace(xd.channel, '[^A-Za-z0-9]+', '_')) as channel,
        case
            when upper(trim(dma)) = 'MC CONNELSVILLE' then 'MCCONNELSVILLE'
            when upper(trim(dma)) = 'MC KEESPORT' then 'MCKEESPORT'
            when upper(trim(dma)) in ('NATIONAL', 'PUERTO RICO', 'UNCLASSIFIED', 'UNKNOWN', 'UNASSIGNED', 'OTHER VERIFIED') then null
            when dma like '%COUNTY%' then trim(split(dma, 'COUNTY')[1])
            when upper(trim(dma)) != 'SANTA FE' and regexp_like(dma, '^[a-zA-Z0-9 ]+$') and cardinality(split(dma, ' ')) = 2 and length(trim(split(dma, ' ')[2])) = 2 then trim(split(dma, ' ')[1]) -- If we split on a space and there are 2 elements and the 2nd one is exactly 2 characters long, we treat that as the state, and keep the 1st element as the DMA/City
            when cardinality(split(dma, ',')) = 2 and (length(trim(split(dma, ',')[2])) = 2 or (regexp_like(split(dma, ',')[2], '-') and all_match(split(split(dma, ',')[2], '-'), x -> length(trim(x)) = 2))) then trim(split(dma, ',')[1]) -- If we split on a comma and there are 2 elements and the 2nd one is exactly 2 characters long or the 2nd one has hyphens, and we split on the hyphen and each of those elements is exactly 2 characters long, we treat them as state, and keep the 1st element as the DMA/City
            when upper(dma) like '%WASH%HAG%' or upper(xd.state) like '%HAG%' or upper(trim(xd.state)) = 'DC-MD-PA-VA-WV' then 'WASHINGTON, DC (HAGRSTWN)' -- If the DMA or state contains the word HAG (short for HAGRSTWN and its variations), we set the DMA to WASHINGTON, DC (HAGRSTWN)
            else
                regexp_replace(
                    dma,
                    '(AIR\s+FORCE\s+BASE|AIR\s+RESERVE\s+BASE|A\s+F\s+B)',
                    'AFB'
                )
        end as cleaned_dma,
        upper(trim(coalesce(sz.state, xd.state))) as state,
        case
            when upper(trim(xd.state)) in ('OTHER UNCLASSIFIED', 'UNKNOWN', 'DIGITAL ISSUE') then null
            when upper(trim(dma)) = 'PUERTO RICO' then 'PR'
            when dma != 'SANTA FE' and regexp_like(dma, '^[a-zA-Z0-9 ]+$') and cardinality(split(dma, ' ')) = 2 and length(trim(split(dma, ' ')[2])) = 2 then trim(split(dma, ' ')[2]) -- If we split on a space and there are 2 elements and the 2nd one is exactly 2 characters long, we treat that as the state, and keep the 2nd element as the State
            when cardinality(split(dma, ',')) = 2 and (length(trim(split(dma, ',')[2])) = 2 or (regexp_like(split(dma, ',')[2], '-') and all_match(split(split(dma, ',')[2], '-'), x -> length(trim(x)) = 2))) then array_join(transform(split(split(dma, ',')[2], '-'), x -> trim(x)), '-') -- If we split on a comma and there are 2 elements and the 2nd one is exactly 2 characters long or the 2nd one has hyphens, and we split on the hyphen and each of those elements is exactly 2 characters long, we treat them as state, and keep the 2nd element as the State, reconstructing it back with the hyphens, when present
            when upper(xd.state) like '%OPELIKA%' then 'GA-AL' when upper(xd.state) like '%HAG%' or upper(trim(xd.state)) = 'D)' or upper(trim(xd.state)) = 'DC-MD-PA-VA-WV' then null -- If the DMA or state contains the word HAG (short for HAGRSTWN and its variations), we set the DMA to WASHINGTON, DC (HAGRSTWN)
            else upper(trim(coalesce(sz.state, xd.state)))
        end as cleaned_state
    from xo_raw_ds as xd
    left join state_values as sz on upper(xd.state) = upper(sz.state_name)
),

xo_norm_stg_2 as (
    select distinct
        audience,
        zip_code,
        dma,
        country,
        reach,
        engage,
        cost,
        year_week,
        year_month,
        brand,
        channel,
        state,
        cleaned_state,
        case
            when cleaned_dma like '%WARREN AFB%' then 'FT WARREN AFB'
            when cleaned_dma like '%FORT MITCHELL%' then 'FT MITCHELL'
            when cleaned_dma like '%FT. POLK%' then 'FORT POLK'
            when cleaned_dma like '%ST CLAIR%' then 'ST. CLAIR'
            when
                cleaned_dma not like 'FT%MITCHELL%'
                then
                    regexp_replace(
                        regexp_replace(cleaned_dma, '^(FT) ', 'FORT '),
                        '^(ST) ', 'SAINT '
                    )
            else cleaned_dma
        end as cleaned_dma,
        coalesce(cardinality(split(cleaned_state, '-')), 0) as xo_state_count
    from xo_norm_stg_1
),

her2_perjeta as (
    select distinct
        audience,
        zip_code,
        dma,
        country,
        year_week,
        year_month,
        'PERJETA' as brand,
        channel,
        cleaned_dma,
        state,
        cleaned_state,
        xo_state_count,
        reach * 0.6 as reach,
        engage * 0.6 as engage,
        cost * 0.6 as cost
    from xo_norm_stg_2
    where brand = 'HER2'
),

her2_phesgo as (
    select distinct
        audience,
        zip_code,
        dma,
        country,
        year_week,
        year_month,
        'PHESGO' as brand,
        channel,
        cleaned_dma,
        state,
        cleaned_state,
        xo_state_count,
        reach * 0.2 as reach,
        engage * 0.2 as engage,
        cost * 0.2 as cost
    from xo_norm_stg_2
    where brand = 'HER2'
),

her2_kadcyla as (
    select distinct
        audience,
        zip_code,
        dma,
        country,
        year_week,
        year_month,
        'KADCYLA' as brand,
        channel,
        cleaned_dma,
        state,
        cleaned_state,
        xo_state_count,
        reach * 0.2 as reach,
        engage * 0.2 as engage,
        cost * 0.2 as cost
    from xo_norm_stg_2
    where brand = 'HER2'
),

xo_norm_ds as (
    select distinct
        audience,
        zip_code,
        dma,
        country,
        reach,
        engage,
        cost,
        year_week,
        year_month,
        brand,
        channel,
        cleaned_dma,
        state,
        cleaned_state,
        xo_state_count
    from xo_norm_stg_2
    where brand != 'HER2'
    union all
    select distinct
        audience,
        zip_code,
        dma,
        country,
        reach,
        engage,
        cost,
        year_week,
        year_month,
        brand,
        channel,
        cleaned_dma,
        state,
        cleaned_state,
        xo_state_count
    from her2_perjeta
    union all
    select distinct
        audience,
        zip_code,
        dma,
        country,
        reach,
        engage,
        cost,
        year_week,
        year_month,
        brand,
        channel,
        cleaned_dma,
        state,
        cleaned_state,
        xo_state_count
    from her2_phesgo
    union all
    select distinct
        audience,
        zip_code,
        dma,
        country,
        reach,
        engage,
        cost,
        year_week,
        year_month,
        brand,
        channel,
        cleaned_dma,
        state,
        cleaned_state,
        xo_state_count
    from her2_kadcyla
),

xo_zip_map as (
    select distinct
        xdc.year_month,
        xdc.year_week,
        xdc.brand,
        xdc.audience,
        xdc.channel,
        pdz.zip,
        xdc.state,
        xdc.country,
        xdc.cost,
        xdc.reach
        * case
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'OCREVUS'
                then pdz.total_pop_f_18_49 / 100 / 2
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'VABYSMO'
                then pdz.total_pop_50_99 / 100 / 2
            when xdc.channel in ('puerto_rico_local_tv')
                then pdz.total_pop_18_49 / 100 / 2
            else 1
        end as reach,
        xdc.engage
        * case
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'OCREVUS'
                then pdz.total_pop_f_18_49 / 100 / 2
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'VABYSMO'
                then pdz.total_pop_50_99 / 100 / 2
            when xdc.channel in ('puerto_rico_local_tv')
                then pdz.total_pop_18_49 / 100 / 2
            else 1
        end as engage
    from xo_norm_ds as xdc
    inner join zips_weights as pdz
        on trim(xdc.zip_code) = trim(pdz.zip)
    where
        xdc.zip_code is not null
),

xo_state_map as (
    select distinct
        xdc.year_week,
        xdc.year_month,
        xdc.brand,
        xdc.audience,
        xdc.channel,
        pdz.zip,
        xdc.state,
        xdc.country,
        xdc.reach
        * case
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'OCREVUS'
                then pdz.total_pop_f_18_49 / 100 / 2
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'VABYSMO'
                then pdz.total_pop_50_99 / 100 / 2
            when xdc.channel in ('puerto_rico_local_tv')
                then pdz.total_pop_18_49 / 100 / 2
            else pdz.wt_state_total
        end as reach,
        xdc.engage
        * case
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'OCREVUS'
                then pdz.total_pop_f_18_49 / 100 / 2
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'VABYSMO'
                then pdz.total_pop_50_99 / 100 / 2
            when xdc.channel in ('puerto_rico_local_tv')
                then pdz.total_pop_18_49 / 100 / 2
            else pdz.wt_state_total
        end as engage,
        xdc.cost
        * case
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'OCREVUS'
                then pdz.wt_state_f_18_49
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'VABYSMO'
                then pdz.wt_state_50_99
            when xdc.channel in ('puerto_rico_local_tv')
                then pdz.wt_state_18_49
            else pdz.wt_state_total
        end as cost
    from xo_norm_ds as xdc
    inner join zips_weights as pdz
        on xdc.cleaned_state = pdz.state
    where
        xdc.zip_code is null
        and xdc.cleaned_dma is null
        and xdc.cleaned_state is not null
),

xo_nation_map as (
    select distinct
        xdc.year_week,
        xdc.year_month,
        xdc.brand,
        xdc.audience,
        xdc.channel,
        pdz.zip,
        pdz.state,
        xdc.country,
        xdc.reach
        * case
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'OCREVUS'
                then pdz.total_pop_f_18_49 / 100 / 2
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'VABYSMO'
                then pdz.total_pop_50_99 / 100 / 2
            when xdc.channel in ('puerto_rico_local_tv')
                then pdz.total_pop_18_49 / 100 / 2
            else pdz.wt_zip5_total
        end as reach,
        xdc.engage
        * case
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'OCREVUS'
                then pdz.total_pop_f_18_49 / 100 / 2
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'VABYSMO'
                then pdz.total_pop_50_99 / 100 / 2
            when xdc.channel in ('puerto_rico_local_tv')
                then pdz.total_pop_18_49 / 100 / 2
            else pdz.wt_zip5_total
        end as engage,
        xdc.cost
        * case
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'OCREVUS'
                then pdz.wt_zip5_f_18_49
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'VABYSMO'
                then pdz.wt_zip5_50_99
            when xdc.channel in ('puerto_rico_local_tv')
                then pdz.wt_zip5_18_49
            else pdz.wt_zip5_total
        end as cost
    from xo_norm_ds as xdc
    cross join zips_weights as pdz
    where
        xdc.zip_code is null
        and xdc.cleaned_dma is null
        and xdc.cleaned_state is null
),

xo_county_map as (
    select distinct
        xdc.year_week,
        xdc.year_month,
        xdc.brand,
        xdc.audience,
        xdc.channel,
        xdc.dma,
        xdc.cleaned_dma,
        xdc.cleaned_state,
        xdc.xo_state_count,
        xdc.zip_code,
        pdz.zip,
        pdz.county,
        xdc.state,
        xdc.country,
        coalesce(
            xdc.reach
            * case
                when
                    xdc.channel in (
                        'dr_cable', 'linear_tv', 'hispanic_linear_tv'
                    )
                    and xdc.brand = 'OCREVUS'
                    then
                        pdz.total_pop_f_18_49 / 100 / 2
                when
                    xdc.channel in (
                        'dr_cable', 'linear_tv', 'hispanic_linear_tv'
                    )
                    and xdc.brand = 'VABYSMO'
                    then pdz.total_pop_50_99 / 100 / 2
                when xdc.channel in ('puerto_rico_local_tv')
                    then pdz.total_pop_18_49 / 100 / 2
                else pdz.wt_county_total
            end, xdc.reach
        ) as reach,
        coalesce(
            xdc.engage
            * case
                when
                    xdc.channel in (
                        'dr_cable', 'linear_tv', 'hispanic_linear_tv'
                    )
                    and xdc.brand = 'OCREVUS'
                    then
                        pdz.total_pop_f_18_49 / 100 / 2
                when
                    xdc.channel in (
                        'dr_cable', 'linear_tv', 'hispanic_linear_tv'
                    )
                    and xdc.brand = 'VABYSMO'
                    then pdz.total_pop_50_99 / 100 / 2
                when xdc.channel in ('puerto_rico_local_tv')
                    then pdz.total_pop_18_49 / 100 / 2
                else pdz.wt_county_total
            end, xdc.engage
        ) as engage,
        coalesce(
            xdc.cost
            * case
                when
                    xdc.channel in (
                        'dr_cable', 'linear_tv', 'hispanic_linear_tv'
                    )
                    and xdc.brand = 'OCREVUS'
                    then pdz.wt_county_f_18_49
                when
                    xdc.channel in (
                        'dr_cable', 'linear_tv', 'hispanic_linear_tv'
                    )
                    and xdc.brand = 'VABYSMO'
                    then pdz.wt_county_50_99
                when xdc.channel in ('puerto_rico_local_tv')
                    then pdz.wt_county_18_49
                else pdz.wt_county_total
            end, xdc.cost
        ) as cost,
        not coalesce (pdz.county is null, false) as is_county
    from xo_norm_ds as xdc
    left join zips_weights as pdz
        on
            xdc.cleaned_dma = pdz.county
            and xdc.cleaned_state = pdz.state
    where
        xdc.zip_code is null
        and xdc.cleaned_dma is not null
),

xo_city_map as (
    select distinct
        xdc.year_week,
        xdc.year_month,
        xdc.brand,
        xdc.audience,
        xdc.channel,
        pdz.zip,
        xdc.zip_code,
        xdc.state,
        xdc.cleaned_state,
        xdc.xo_state_count,
        xdc.country,
        xdc.dma,
        xdc.cleaned_dma,
        coalesce(
            xdc.reach
            * case
                when
                    xdc.channel in (
                        'dr_cable', 'linear_tv', 'hispanic_linear_tv'
                    )
                    and xdc.brand = 'OCREVUS'
                    then pdz.total_pop_f_18_49 / 100 / 2
                when
                    xdc.channel in (
                        'dr_cable', 'linear_tv', 'hispanic_linear_tv'
                    )
                    and xdc.brand = 'VABYSMO'
                    then pdz.total_pop_50_99 / 100 / 2
                when xdc.channel in ('puerto_rico_local_tv')
                    then pdz.total_pop_18_49 / 100 / 2
                else pdz.wt_city_total
            end, xdc.reach
        ) as reach,
        coalesce(
            xdc.engage
            * case
                when
                    xdc.channel in (
                        'dr_cable', 'linear_tv', 'hispanic_linear_tv'
                    )
                    and xdc.brand = 'OCREVUS'
                    then pdz.total_pop_f_18_49 / 100 / 2
                when
                    xdc.channel in (
                        'dr_cable', 'linear_tv', 'hispanic_linear_tv'
                    )
                    and xdc.brand = 'VABYSMO'
                    then pdz.total_pop_50_99 / 100 / 2
                when xdc.channel in ('puerto_rico_local_tv')
                    then pdz.total_pop_18_49 / 100 / 2
                else pdz.wt_city_total
            end, xdc.engage
        ) as engage,
        coalesce(
            xdc.cost
            * case
                when
                    xdc.channel in (
                        'dr_cable', 'linear_tv', 'hispanic_linear_tv'
                    )
                    and xdc.brand = 'OCREVUS'
                    then pdz.wt_city_f_18_49
                when
                    xdc.channel in (
                        'dr_cable', 'linear_tv', 'hispanic_linear_tv'
                    )
                    and xdc.brand = 'VABYSMO'
                    then pdz.wt_city_50_99
                when xdc.channel in ('puerto_rico_local_tv')
                    then pdz.wt_city_18_49
                else pdz.wt_city_total
            end, xdc.cost
        ) as cost,
        not coalesce (pdz.city is null, false) as is_city
    from xo_county_map as xdc
    left join city_weights as pdz
        on
            xdc.cleaned_dma = pdz.city
            and xdc.cleaned_state = pdz.state
    where
        not xdc.is_county
),

xo_dmas as (
    select distinct 
        audience, 
        dma,
        country,
        reach,
        engage,
        cost,
        year_week,
        year_month,
        brand,
        channel,
        cleaned_dma,
        regexp_replace(regexp_replace(regexp_replace(regexp_replace(regexp_replace(regexp_replace(trim(regexp_replace(regexp_replace(regexp_replace(split(regexp_replace(split(cleaned_dma, ',')[1], ',[^-,&]*', '') , ',')[1], ',\s*[^-]+-', '-'), '\s*-\s*', '-'), ' ([!@#$%^&{}_+=?|<>-]) *', '$1')), '([^ ])-', '$1 - '), '\s*&\s*', ' & '), '(\S)&', '$1 &'), '&(\S)', '& $1'), '([^ ])\(', '$1 ('), '\.([^ ])', '. $1') as standardized_dma,
        state,
        cleaned_state,
        xo_state_count
    from xo_city_map where not is_city
),

non_std_dma_list as (
    select distinct 
        dma_name, 
        dma_code 
    from sandbox_measurement_analyst.mars_dma_state_code_staging
),

non_std_dmas_stg_1 as (
    select distinct
        dma_code,
        case
            when dma_name like '%HAG%' then 'WASHINGTON, DC (HAGRSTWN)' else
                regexp_replace(regexp_replace(regexp_replace(regexp_replace(regexp_replace(regexp_replace(trim(regexp_replace(regexp_replace(regexp_replace(split(regexp_replace(split(dma_name, ',')[1], ',[^-,&]*', '') , ',')[1], ',\s*[^-]+-', '-'), '\s*-\s*', '-'), ' ([!@#$%^&{}_+=?|<>-]) *', '$1')), '([^ ])-', '$1 - '), '\s*&\s*', ' & '), '(\S)&', '$1 &'), '&(\S)', '& $1'), '([^ ])\(', '$1 ('), '\.([^ ])', '. $1')
        end as dma_name
    from non_std_dma_list
),

std_dmas as (
    select distinct 
        dma_name as dma_name_orig,
        regexp_replace(regexp_replace(regexp_replace(regexp_replace(regexp_replace(regexp_replace(trim(regexp_replace(regexp_replace(regexp_replace(split(regexp_replace(split(dma_name, ',')[1], ',[^-,&]*', '') , ',')[1], ',\s*[^-]+-', '-'), '\s*-\s*', '-'), ' ([!@#$%^&{}_+=?|<>-]) *', '$1')), '([^ ])-', '$1 - '), '\s*&\s*', ' & '), '(\S)&', '$1 &'), '&(\S)', '& $1'), '([^ ])\(', '$1 ('), '\.([^ ])', '. $1') as dma_name,
        dma_code,
        dma_state_count
    from zips_weights
),

non_std_dmas as (
    select distinct
        nsd.dma_code,
        nsd.dma_name,
        sd.dma_state_count
    from non_std_dmas_stg_1 nsd
    join std_dmas sd
    on nsd.dma_code = sd.dma_code
),

all_dmas_list as (
    select distinct
        dma_name,
        dma_code,
        dma_state_count
    from std_dmas
    union all
    select distinct
        dma_name,
        dma_code,
        dma_state_count
    from non_std_dmas
),

xo_dma_match_stg_1 as (
    select distinct
        audience,
        dma,
        country,
        reach,
        engage,
        cost,
        year_week,
        year_month,
        brand,
        channel,
        cleaned_dma,
        standardized_dma,
        x.state,
        cleaned_state,
        xo_state_count,
        zw.dma_name,
        zw.dma_code,
        zw.dma_state_count,
        case 
            when zw.dma_name is null then false 
        else true end as is_std_match
    from xo_dmas as x
    left join
        all_dmas_list as zw
        on
            trim(x.standardized_dma) = trim(zw.dma_name)
),

xo_dma_match_stg_2 as (
    select distinct
        audience,
        dma,
        country,
        reach,
        engage,
        cost,
        year_week,
        year_month,
        brand,
        channel,
        cleaned_dma,
        standardized_dma,
        state,
        cleaned_state,
        xo_state_count,
        dma_state_count
    from xo_dma_match_stg_1 x
    where not is_std_match
),

unmatched_dmas as (
    select distinct cleaned_dma from xo_dma_match_stg_2
),

good_dmas as (
    select distinct dma_name from zips_weights
),

levenshtein_distances as (
    select
        cleaned_dma,
        cast(min(lev_distance) as double) as dist,
        min_by(dma_name, lev_distance) as dma_name,
        cast(min(lev_distance) as double) / length(cleaned_dma) as pct_dist
    from (
        select
            *,
            levenshtein_distance(cleaned_dma, dma_name) as lev_distance
        from unmatched_dmas, good_dmas
    )
    group by cleaned_dma
),

dist_dma_values as (
    select distinct
        dma_name,
        dma_code,
        dma_state_count
    from std_dmas
),

matching_dmas as (
    select distinct
        ld.cleaned_dma,
        ld.dma_name,
        ddv.dma_code,
        ddv.dma_state_count
    from levenshtein_distances as ld
    inner join dist_dma_values as ddv on ld.dma_name = ddv.dma_name
    where
        pct_dist < 0.5
        and ld.cleaned_dma not in (
            'BANGKOK', 'OAKVILLE', 'ST. JOHN''S', 'ILOILO CITY'
        )
),

xo_dma_match_stg_2_codes as (
    select distinct
        audience,
        dma,
        x.cleaned_dma,
        country,
        reach,
        engage,
        cost,
        year_week,
        year_month,
        brand,
        channel,
        state,
        cleaned_state,
        xo_state_count,
        d.dma_code,
        d.dma_state_count
    from xo_dma_match_stg_2 as x
    inner join matching_dmas as d on x.cleaned_dma = d.cleaned_dma
),

all_xo_dma_match as (
    select distinct
        year_week,
        year_month,
        brand,
        audience,
        channel,
        state,
        cleaned_state,
        xo_state_count,
        country,
        reach,
        engage,
        cost,
        dma_code,
        dma_state_count
    from xo_dma_match_stg_1
    where is_std_match
    union all
    select distinct
        year_week,
        year_month,
        brand,
        audience,
        channel,
        state,
        cleaned_state,
        xo_state_count,
        country,
        reach,
        engage,
        cost,
        dma_code,
        dma_state_count
    from xo_dma_match_stg_2_codes
),

xo_dma_map_pt_1 as (
    select distinct
        xdc.year_week,
        xdc.year_month,
        xdc.brand,
        xdc.audience,
        xdc.channel,
        pdz.zip,
        xdc.state,
        xdc.country,
        xdc.xo_state_count,
        pdz.dma_state_count,
        xdc.reach
        * case
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'OCREVUS'
                then pdz.total_pop_f_18_49 / 100 / 2
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'VABYSMO'
                then pdz.total_pop_50_99 / 100 / 2
            when xdc.channel in ('puerto_rico_local_tv')
                then pdz.total_pop_18_49 / 100 / 2
            else pdz.wt_dma_total
        end as reach,
        xdc.engage
        * case
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'OCREVUS'
                then pdz.total_pop_f_18_49 / 100 / 2
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'VABYSMO'
                then pdz.total_pop_50_99 / 100 / 2
            when xdc.channel in ('puerto_rico_local_tv')
                then pdz.total_pop_18_49 / 100 / 2
            else pdz.wt_dma_total
        end as engage,
        xdc.cost
        * case
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'OCREVUS'
                then pdz.wt_dma_f_18_49
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'VABYSMO'
                then pdz.wt_dma_50_99
            when xdc.channel in ('puerto_rico_local_tv')
                then pdz.wt_dma_18_49
            else pdz.wt_dma_total
        end as cost
    from all_xo_dma_match as xdc
    inner join zips_weights as pdz
        on
            xdc.dma_code = pdz.dma_code
    where
        xdc.xo_state_count = 0
        or xdc.xo_state_count = xdc.dma_state_count
),

multi_state_dma_stg_1 as (
    select distinct
        year_week,
        year_month,
        brand,
        audience,
        channel,
        state,
        cleaned_state,
        split(cleaned_state, '-') as state_array,
        xo_state_count,
        country,
        reach,
        engage,
        cost,
        dma_code,
        dma_state_count
    from all_xo_dma_match
    where xo_state_count > 0 and xo_state_count < dma_state_count
),

multi_state_dma_ds as (
    select distinct
        year_week,
        year_month,
        brand,
        audience,
        channel,
        state,
        u.cleaned_state,
        xo_state_count,
        country,
        reach,
        engage,
        cost,
        dma_code,
        dma_state_count
    from multi_state_dma_stg_1, unnest(state_array) as u(cleaned_state)
),

xo_dma_map_pt_2 as (
    select distinct
        xdc.year_week,
        xdc.year_month,
        xdc.brand,
        xdc.audience,
        xdc.channel,
        pdz.zip,
        xdc.state,
        xdc.country,
        xdc.xo_state_count,
        pdz.dma_state_count,
        (xdc.reach / xo_state_count)
        * case
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'OCREVUS'
                then
                    pdz.total_pop_f_18_49 / 100 / 2 / xo_state_count
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'VABYSMO'
                then
                    pdz.total_pop_50_99 / 100 / 2 / xo_state_count
            when xdc.channel in ('puerto_rico_local_tv')
                then
                    pdz.total_pop_18_49 / 100 / 2 / xo_state_count
            else pdz.wt_dma_state_total / xo_state_count
        end as reach,
        (xdc.engage / xo_state_count)
        * case
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'OCREVUS'
                then
                    pdz.total_pop_f_18_49 / 100 / 2 / xo_state_count
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'VABYSMO'
                then
                    pdz.total_pop_50_99 / 100 / 2 / xo_state_count
            when xdc.channel in ('puerto_rico_local_tv')
                then
                    pdz.total_pop_18_49 / 100 / 2 / xo_state_count
            else pdz.wt_dma_state_total / xo_state_count
        end as engage,
        (xdc.cost / xo_state_count)
        * case
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'OCREVUS'
                then pdz.wt_dma_state_f_18_49 / xo_state_count
            when
                xdc.channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv')
                and xdc.brand = 'VABYSMO'
                then pdz.wt_dma_state_50_99 / xo_state_count
            when xdc.channel in ('puerto_rico_local_tv')
                then pdz.wt_dma_state_18_49 / xo_state_count
            else pdz.wt_dma_state_total / xo_state_count
        end as cost
    from multi_state_dma_ds as xdc
    inner join zips_weights as pdz
        on
            xdc.dma_code = pdz.dma_code
            and xdc.cleaned_state = pdz.state
),

all_xo_data as (
    select distinct
        year_week,
        year_month,
        brand,
        zip,
        channel,
        audience,
        reach,
        engage,
        cost
    from xo_zip_map
    union all
    select distinct
        year_week,
        year_month,
        brand,
        zip,
        channel,
        audience,
        reach,
        engage,
        cost
    from xo_state_map
    union all
    select distinct
        year_week,
        year_month,
        brand,
        zip,
        channel,
        audience,
        reach,
        engage,
        cost
    from xo_nation_map
    union all
    select distinct
        year_week,
        year_month,
        brand,
        zip,
        channel,
        audience,
        reach,
        engage,
        cost
    from xo_county_map where is_county
    union all
    select distinct
        year_week,
        year_month,
        brand,
        zip,
        channel,
        audience,
        reach,
        engage,
        cost
    from xo_city_map where is_city
    union all
    select distinct
        year_week,
        year_month,
        brand,
        zip,
        channel,
        audience,
        reach,
        engage,
        cost
    from xo_dma_map_pt_1
    union all
    select distinct
        year_week,
        year_month,
        brand,
        zip,
        channel,
        audience,
        reach,
        engage,
        cost
    from xo_dma_map_pt_2
),

agg_data as (
    select distinct
        brand as product_brand_name,
        year_week,
        year_month,
        zip,
        channel,
        audience,
        sum(reach)
            over (partition by brand, year_week, channel, audience, zip)
            as reach,
        sum(engage)
            over (partition by brand, year_week, channel, audience, zip)
            as engage,
        sum(cost)
            over (partition by brand, year_week, channel, audience, zip)
            as cost
    from all_xo_data
)

select *
from agg_data
where not is_nan(reach) or not is_nan(cost) or not is_nan(engage)
