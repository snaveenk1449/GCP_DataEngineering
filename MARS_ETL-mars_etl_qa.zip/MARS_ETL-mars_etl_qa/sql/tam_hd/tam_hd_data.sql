/*
* TAM HD Calls - This dataset is to capture all Commercial Interactions between TAMs and HDs (and their brand-specific counterpart roles) and HCPs, and for Hemlibra, Patient interactions too.
* We start off by getting the set of all TAM/HD field agents and the dates on which they were in those particular roles. We then get a list of all HCPs and the list of all products they are approved for.
* We join these two datasets with the primary dataset - crm_commercial_interactions - to get all the interactions by the TAMs/HDs and the HCPs, filtered to only those products which the HCPs are approved for. 
* Additionally, we filter on crm_flag_person_account = 1 because every interaction always has to be with an HCP. We also filter for only interactions with a status of "Submitted".
* The display order (crm_display_order field in the crm_commercial_interactions table) acts as a way to set call priority. 
* Weights for these calls are assigned as the inverse of the display order, i.e., display order 1 gets a weight of 1, display order 2 gets a weight of 1/2 and so on. 
* When aggregated over a product, zip and year_month, this weight is what is considered as reach. We then add any interactions the 4 extra Evrysdi HCPs might have made and union the datasets.
* 
* For Patient interactions, it is more straightforward, where we simply use the number_of_interactions column as reach and filter out any interactions of type "Attempted Contact".
* We join this dataset with the alignment_zip_to_ecosystem_daily table to filter out any invalid ZIP codes. 
*
* For both datasets, we join on the tam_hd_costs table, and allocate costs at the product and year_month level. For Hemlibra, since there was a role consolidation in Q3 2023, we split the costs
* for that brand going forward from July 2023 onwards into two. For all others, we keep it as is. We then union the HCP and DTC interactions. 
* Since the costs are at the year and month level, but the data is at the zip level, we distribute costs proportionally based on overall reach.
*/

with tam_hds as (
    select distinct
        unix_id,
        start_date,
        end_date
    from
        sandbox_measurement_analyst.mars_alignment_roster_hierarchy_daily_staging
    where
        field_title_code in (
            'TAM',
            'HD',            
            'NRDS', -- For Evrysdi
            'SNRDS', -- For Evrysdi
            'NRDHD', -- For Evrysdi
            'ACM', -- For Hemlibra
            'CS', -- For Actemra
            'SCS', -- For Actemra
            'CSO_CS', -- For Actemra
            'CSO_DM', -- For Actemra
            'CSO_RD' -- For Actemra
        )
),

hcp_org_mapping as (
    select
        mdm_id,
        product_brand_id,
        product_brand_name,
        mdm_zip
    from sandbox_measurement_analyst.mars_hcp_org_mapping_staging
),

tam_hd_calls as (
    select distinct
        ci.crm_call_id,
        ci.mdm_id,
        ci.crm_display_order,
        cast(1 / ci.crm_display_order as double) as call_wt,
        ci.crm_call_datetime,
        ci.oasis_brand_name as product_brand_name,
        ci.oasis_product_brand_id as product_brand_id,
        hom.mdm_zip as zip,
        cast(year(ci.crm_call_datetime) as varchar)
        || lpad(cast(month(ci.crm_call_datetime) as varchar), 2, '0')
            as year_month
    from
        sandbox_measurement_analyst.mars_crm_commercial_interactions_staging
            as ci
    inner join
        tam_hds as th
        on
            ci.crm_user_id = th.unix_id
            and ci.crm_call_datetime between th.start_date and th.end_date
    inner join hcp_org_mapping as hom
        on
            ci.mdm_id = hom.mdm_id
            and cardinality(
                array_intersect(
                    array[ci.oasis_product_brand_id], hom.product_brand_id
                )
            )
            > 0
    where
        upper(crm_call_status) = 'SUBMITTED'
        and cast(crm_flag_person_account as integer) = 1
),

evrysdi_extra_tam_hd_calls as (
    select distinct
        ci.crm_call_id,
        ci.mdm_id,
        ci.crm_display_order,
        cast(1 / ci.crm_display_order as double) as call_wt,
        ci.crm_call_datetime,
        ci.oasis_brand_name as product_brand_name,
        ci.oasis_product_brand_id as product_brand_id,
        ev.mdm_zip as zip,
        cast(year(ci.crm_call_datetime) as varchar)
        || lpad(cast(month(ci.crm_call_datetime) as varchar), 2, '0')
            as year_month
    from
        sandbox_measurement_analyst.mars_crm_commercial_interactions_staging
            as ci
    inner join
        tam_hds as th
        on
            ci.crm_user_id = th.unix_id
            and ci.crm_call_datetime between th.start_date and th.end_date
    inner join
        sandbox_measurement_analyst.mars_evrysdi_extra_hcp_zips_staging as ev
        on ci.mdm_id = ev.mdm_id
    where upper(crm_call_status) = 'SUBMITTED'
),

all_tam_hd_calls as (
    select distinct
        crm_call_id,
        mdm_id,
        crm_display_order,
        call_wt,
        crm_call_datetime,
        product_brand_name,
        product_brand_id,
        zip,
        year_month
    from tam_hd_calls
    union all
    select distinct
        crm_call_id,
        mdm_id,
        crm_display_order,
        call_wt,
        crm_call_datetime,
        product_brand_name,
        product_brand_id,
        zip,
        year_month
    from evrysdi_extra_tam_hd_calls
),

tam_hd_costs as (
    select
        brand,
        channel,
        audience,
        cost,
        year || lpad(month, 2, '0') as year_month
    from sandbox_measurement_analyst.mars_tam_hd_costs_staging
),

hcp_calls_costs as (
    select distinct
        crm_call_id,
        mdm_id,
        thc.channel,
        thc.audience,
        call_wt,
        crm_call_datetime,
        thd.year_month,
        product_brand_name,
        product_brand_id,
        zip,
        case
            when
                product_brand_name = 'HEMLIBRA' and thd.year_month >= '202307'
                then thc.cost / 2
            else thc.cost
        end as cost
    from tam_hd_calls as thd
    inner join
        tam_hd_costs
            as thc
        on
            thd.year_month = thc.year_month
            and thd.product_brand_name = thc.brand
    where audience = 'CE'
),

hcp_agg_data as (
    select distinct
        product_brand_name,
        year_month,
        channel,
        audience,
        zip,
        cost,
        round(
            sum(call_wt)
                over (partition by product_brand_name, year_month, zip),
            4
        ) as reach
    from hcp_calls_costs
),

hemlibra_tam_dtc_calls as (
    select
        eco.zip,
        costs.cost,
        costs.audience,
        costs.channel,
        upper(product) as product_brand_name,
        coalesce(
            date_format(date_parse(interaction_date, '%m/%d/%Y'), '%Y%m'),
            costs.year_month
        ) as year_month,
        sum(number_of_interactions) as reach
    from sandbox_measurement_analyst.mars_tam_pccm_interactions_staging as pccm
    full outer join tam_hd_costs as costs
        on
            date_format(date_parse(interaction_date, '%m/%d/%Y'), '%Y%m')
            = costs.year_month
    inner join sandbox_measurement_analyst.mars_alignment_zip_to_ecosystem_daily_staging as eco
        on pccm.zip_code = eco.zip
    where
        costs.audience = 'DTC'
        and costs.brand = 'HEMLIBRA'
        and eco.flag_active = 'Y'
        and eco.ecosystem_dim_id > 0
        and trim(pccm.interaction_type) != 'Attempted Contact'
    group by
        product,
        coalesce(
            date_format(date_parse(interaction_date, '%m/%d/%Y'), '%Y%m'),
            costs.year_month
        ),
        eco.zip, costs.cost, costs.audience, costs.channel
),

tam_dtc_cost_split as (
    select
        product_brand_name,
        year_month,
        zip,
        audience,
        channel,
        reach,
        case
            when product_brand_name = 'HEMLIBRA' and year_month >= '202307'
                then cost / 2
            else cost
        end as cost
    from
        hemlibra_tam_dtc_calls
),

dtc_hcp_combined as (
    select
        product_brand_name,
        year_month,
        zip,
        audience,
        channel,
        cost,
        reach
    from
        hcp_agg_data
    union all
    select
        product_brand_name,
        year_month,
        zip,
        audience,
        channel,
        cost,
        reach
    from
        tam_dtc_cost_split
),

cost_distribution as (
    select
        product_brand_name,
        year_month,
        zip,
        audience,
        channel,
        reach,
        cost
        * reach
        / sum(reach)
            over (partition by product_brand_name, year_month, audience)
            as cost
    from
        dtc_hcp_combined
)

select * from cost_distribution
