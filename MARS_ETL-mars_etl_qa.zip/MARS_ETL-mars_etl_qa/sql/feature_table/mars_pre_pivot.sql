-- Union the ETL output tables for XO, Speaker and TAM together. 
-- This will serve as our base table to do the pivot.

with combined_data as (
    select distinct
        product_brand_name,
        year_month,
        zip as zip_code,
        audience,
        channel,
        reach,
        engage,
        cost
    from
        sandbox_measurement_analyst.mars_xo_staging
    union all
    select distinct
        product_brand_name,
        year_month,
        zip as zip_code,
        audience,
        channel,
        reach,
        null as engage,
        cost
    from
        sandbox_measurement_analyst.mars_tam_hd_staging
    union all
    select distinct
        product_brand_name,
        year_month,
        zip as zip_code,
        audience,
        channel,
        reach,
        null as engage,
        cost
    from
        sandbox_measurement_analyst.mars_speaker_staging
)

select * from combined_data
