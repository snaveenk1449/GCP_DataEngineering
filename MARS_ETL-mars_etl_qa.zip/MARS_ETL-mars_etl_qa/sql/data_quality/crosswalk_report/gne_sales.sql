with hcp_org_mapping as (
    select
        mdm_id,
        product_brand_id,
        product_brand_name,
        mdm_zip
    from sandbox_measurement_analyst.mars_hcp_org_mapping_staging
),
--Sales data with and without MCE exclusion
sales_ds as (
    select 
        gne.product_brand_name,
        gne.product_brand_id,
        product_description,
        product_id,
        cast(date_year_month as varchar) as year_month,
        gne_867_sales_qty_eqv,
        hom.mdm_id,
        hom.mdm_zip as site_zip,
        gne_867_effective_wac_sales_dollars gross_sales_dollars,
        case when  hom.mdm_id is not null then gne_867_sales_qty_eqv else 0 end sales_qty_eqv_inc, -- sales qty with MCE exc
         case when  hom.mdm_id is not null then gne_867_effective_wac_sales_dollars else 0 end sales_dollars_inc -- sales doller with MCE exc
    from sandbox_measurement_analyst.mars_sst_mcdm_hcp_site_sales_ndc_monthly_staging as gne
    left join hcp_org_mapping as hom
        on
            coalesce(gne.mdm_id, gne.site_mdm_id) = hom.mdm_id
            and cardinality(
                array_intersect(
                    array[gne.product_brand_id], hom.product_brand_id
                )
            )
            > 0
),

evrysdi_extra_hcp_sales as (
    select 
        product_brand_name,
        product_brand_id,
        product_description,
        product_id,
        cast(date_year_month as varchar) as year_month,
        gne_867_sales_qty_eqv,
        ev.mdm_id,
        ev.mdm_zip as site_zip,
        gne_867_effective_wac_sales_dollars gross_sales_dollars,
        gne_867_sales_qty_eqv as sales_qty_eqv_inc,
        gne_867_effective_wac_sales_dollars as  sales_dollars_inc
    from sandbox_measurement_analyst.mars_sst_mcdm_hcp_site_sales_ndc_monthly_staging as gne
    inner join
        sandbox_measurement_analyst.mars_evrysdi_extra_hcp_zips_staging as ev
        on gne.mdm_id = ev.mdm_id
),

all_sales as (
    select 
        product_brand_name,
        product_brand_id,
        product_description,
        product_id,
        year_month,
        gne_867_sales_qty_eqv,
        mdm_id,
        site_zip,
        gross_sales_dollars,
        sales_qty_eqv_inc,
        sales_dollars_inc
    from sales_ds
    union all
    select distinct
        product_brand_name,
        product_brand_id,
        product_description,
        product_id,
        year_month,
        gne_867_sales_qty_eqv,
        mdm_id,
        site_zip,
        gross_sales_dollars,
        sales_qty_eqv_inc,
        sales_dollars_inc
    from evrysdi_extra_hcp_sales
)
,
final_sales_data as (
select 
s.year_month,
s.product_brand_name,
round(sum(s.gne_867_sales_qty_eqv)) total_sales,
round(sum( case when mdm_id is not null then s.gne_867_sales_qty_eqv else 0 end)) total_sales_mce_inc  ,
round(sum( case when mdm_id is null then s.gne_867_sales_qty_eqv else 0 end)) total_sales_mce_exc  
from  all_sales s 
group by 1,2
),
output_data as
(select product_brand_name,year_month, round(sum(sales_qty)) sales_qty from sandbox_measurement_analyst.mars_gne_867_sales_staging 
group by 1,2)
select 
s.year_month,
s.product_brand_name,
s.total_sales,
s.total_sales_mce_inc,
s.total_sales_mce_exc,
sales_qty total_out_sales
from final_sales_data s
full join 
output_data o
on 
s.year_month=o.year_month and
s.product_brand_name=o.product_brand_name
where 
s.product_brand_name in ('ACTEMRA',
            'ERIVEDGE',
            'EVRYSDI',
            'GAZYVA',
            'HEMLIBRA',
            'OCREVUS',
            'PERJETA',
            'PHESGO',
            'POLIVY',
            'PULMOZYME',
            'RITUXAN',
            'TECENTRIQ',
            'VABYSMO',
            'VENCLEXTA',
            'XOLAIR') and 
s.year_month between '202201' and '202312'
order by 1,2;
