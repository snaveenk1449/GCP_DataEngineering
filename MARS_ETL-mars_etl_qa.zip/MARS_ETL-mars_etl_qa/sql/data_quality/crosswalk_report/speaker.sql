with    
evt_curricula as (
    select distinct
        event_vendor_id,
        product_brand_name,
        product_brand_id
    from oasis_normalized.speaker_bureau_event_curriculum_daily
    where upper(product_brand_name) != 'NOT ASSOCIATED'
),
evt_curricula_cnt as (
    select distinct
        event_vendor_id,
        product_brand_name,
        product_brand_id,
        count(product_brand_id)
            over (partition by event_vendor_id)
            as product_count
    from evt_curricula
),
input_data as
(select e.product_brand_name,to_char(event_start_date,'yyyymm') yearmm ,
round(sum(cast (event_total_cost as double)/product_count)) total_cost,
round(sum(patients_attended + customers_attended),1) total_reach,
sum(patients_attended) dtc_attendance,
sum(customers_attended) hcp_attendance
from oasis_normalized.speaker_bureau_events_daily s
join evt_curricula_cnt e on s.event_vendor_id=e.event_vendor_id
where 
 upper(event_status) not in ('DROPPED', 'PENDING')
group by 1,2
),
output_data
as (
select 
product_brand_name,
year_month,
round(sum(cost)) total_cost,
round(sum(case when 	
audience='HCP' then cost else 0 end)) hcp_cost , 
round(sum(case when 	
audience='DTC' then cost else 0 end)) dtc_cost ,
round(sum(reach)) total_reach,
round(sum(case when 	
audience='HCP' then reach else 0 end)) hcp_reach , 
round(sum(case when 	
audience='DTC' then reach else 0 end)) dtc_reach 
from sandbox_measurement_analyst.mars_speaker_staging 
group by 1,2)
select
o.product_brand_name,
o.year_month,
i.total_cost in_total_cost,
o.total_cost out_total_cost,
i.total_cost - o.total_cost cost_diff,
o.hcp_cost,
o.dtc_cost,
i.dtc_attendance,
i.hcp_attendance,
i.total_reach in_total_reach,
o.hcp_reach out_hcp_reach,
o.dtc_reach out_dtc_reach,
o.total_reach out_total_reach,
round(o.total_reach*100/i.total_reach) reach_per
from output_data o full join input_data i on 
i.product_brand_name=o.product_brand_name
and i.yearmm=o.year_month
where
o.year_month between '202201' and '202312'
        and o.product_brand_name in (
            'ACTEMRA',
            'ERIVEDGE',
            'EVRYSDI',
            'GAZYVA',
            'HEMLIBRA',
            'OCREVUS',
            'PERJETA',
            'PHESGO',
            'POLIVY',
            'PULMOZYME',
            'RITUXAN',
            'TECENTRIQ',
            'VABYSMO',
            'VENCLEXTA',
            'XOLAIR'
)
order by 1,2
