

with tam_hds as (
    select distinct
        unix_id,
        start_date,
        end_date
    from
        sandbox_measurement_analyst.mars_alignment_roster_hierarchy_daily_staging
    where
        field_title_code in (
            'TAM',
            'NRDS',
            'SNRDS',
            'HD',
            'NRDHD',
            'ACM',
            'CS',
            'SCS',
            'CSO_CS',
            'CSO_DM',
            'CSO_RD'
        )
),

hcp_org_mapping as (
    select
        mdm_id,
        product_brand_id,
        product_brand_name,
        mdm_zip
    from sandbox_measurement_analyst.mars_hcp_org_mapping_staging
),

tam_hd_calls as (
    select distinct
        ci.crm_call_id,
        ci.mdm_id,
        ci.crm_display_order,
        cast(1 / ci.crm_display_order as double) as call_wt,
        ci.crm_call_datetime,
        ci.oasis_brand_name as product_brand_name,
        ci.oasis_product_brand_id as product_brand_id,
        hom.mdm_zip as zip,
        case
            when cast(crm_flag_person_account as integer) = 0 then 'SITE' else
                'HCP'
        end as mdm_type,
        cast(year(ci.crm_call_datetime) as varchar)
        || lpad(cast(month(ci.crm_call_datetime) as varchar), 2, '0')
            as year_month
    from
        sandbox_measurement_analyst.mars_crm_commercial_interactions_staging
            as ci
    inner join
        tam_hds as th
        on
            ci.crm_user_id = th.unix_id
            and ci.crm_call_datetime between th.start_date and th.end_date
    left join hcp_org_mapping as hom
        on
            ci.mdm_id = hom.mdm_id
            and cardinality(
                array_intersect(
                    array[ci.oasis_product_brand_id], hom.product_brand_id
                )
            )
            > 0
    where upper(crm_call_status) = 'SUBMITTED'
),

evrysdi_extra_tam_hd_calls as (
    select distinct
        ci.crm_call_id,
        ci.mdm_id,
        ci.crm_display_order,
        cast(1 / ci.crm_display_order as double) as call_wt,
        ci.crm_call_datetime,
        ci.oasis_brand_name as product_brand_name,
        ci.oasis_product_brand_id as product_brand_id,
        ev.mdm_zip as zip,
        'HCP' as mdm_type,
        cast(year(ci.crm_call_datetime) as varchar)
        || lpad(cast(month(ci.crm_call_datetime) as varchar), 2, '0')
            as year_month
    from
        sandbox_measurement_analyst.mars_crm_commercial_interactions_staging
            as ci
    inner join
        tam_hds as th
        on
            ci.crm_user_id = th.unix_id
            and ci.crm_call_datetime between th.start_date and th.end_date
    inner join
        sandbox_measurement_analyst.mars_evrysdi_extra_hcp_zips_staging as ev
        on ci.mdm_id = ev.mdm_id
    where upper(crm_call_status) = 'SUBMITTED'
),

all_tam_hd_calls as (
    select distinct
        crm_call_id,
        mdm_id,
        crm_display_order,
        call_wt,
        crm_call_datetime,
        product_brand_name,
        product_brand_id,
        zip,
        mdm_type,
        year_month
    from tam_hd_calls
    union all
    select distinct
        crm_call_id,
        mdm_id,
        crm_display_order,
        call_wt,
        crm_call_datetime,
        product_brand_name,
        product_brand_id,
        zip,
        mdm_type,
        year_month
    from evrysdi_extra_tam_hd_calls
)
,
tam_hd_total as (
select 
i.product_brand_name,
i.year_month,
round(sum(i.call_wt)) total_call_wt,
round(sum(case when zip is not null then i.call_wt else 0 end)) total_call_wt_after_exc,
round(sum(case when i.mdm_type='SITE' then i.call_wt else 0 end ))as site_call_wt,
round(sum(case when i.mdm_type='HCP' then i.call_wt else 0 end)) as HCP_call_wt,
round(sum(case when i.mdm_type='HCP'  and i.zip is not null then i.call_wt else 0 end)) as HCP_inc_call_wt,
round(sum(case when i.mdm_type='SITE'  and i.zip is not null then i.call_wt else 0 end)) as Site_inc_call_wt
from all_tam_hd_calls i
where 
i.product_brand_name in ('ACTEMRA',
            'ERIVEDGE',
            'EVRYSDI',
            'GAZYVA',
            'HEMLIBRA',
            'OCREVUS',
            'PERJETA',
            'PHESGO',
            'POLIVY',
            'PULMOZYME',
            'RITUXAN',
            'TECENTRIQ',
            'VABYSMO',
            'VENCLEXTA',
            'XOLAIR') and 
i.year_month between '202201' and '202312'
group by 1,2  
),
out_data as
(SELECT
       product_brand_name,year_month,
       round(sum(reach)) reach,
    --round(sum(case when audiance='SITE' and  then reach else 0 end ))as site_reach,
        round(sum(case when audience='DTC' then reach else 0 end)) as tam_dtc_reach
   FROM sandbox_measurement_analyst.mars_tam_hd_staging
    where product_brand_name in (
            'ACTEMRA',
            'ERIVEDGE',
            'EVRYSDI',
            'GAZYVA',
            'HEMLIBRA',
            'OCREVUS',
            'PERJETA',
            'PHESGO',
            'POLIVY',
            'PULMOZYME',
            'RITUXAN',
            'TECENTRIQ',
            'VABYSMO',
            'VENCLEXTA',
            'XOLAIR'
) and 
year_month between '202201' and '202312'
group by 1,2)
select 
i.product_brand_name,
i.year_month,
total_call_wt,
total_call_wt_after_exc,
site_call_wt,
HCP_call_wt,
HCP_inc_call_wt,
Site_inc_call_wt,
reach as total_reach,
--site_reach,
tam_dtc_reach
from
tam_hd_total i
left join 
out_data
 ON i.year_month = out_data.year_month
 and i.product_brand_name = out_data.product_brand_name
order by 1,2
;