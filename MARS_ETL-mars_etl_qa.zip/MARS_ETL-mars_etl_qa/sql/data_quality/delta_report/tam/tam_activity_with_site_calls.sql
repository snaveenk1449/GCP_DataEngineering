
WITH yr_qtr AS (
    SELECT DISTINCT
        yrmo_cal_nm,
        yrqtr_cal_nm
    FROM
        oasis_landing.date_dim
),

new AS (
    SELECT
        product_brand_name,
        year_month,
        dim.yrqtr_cal_nm,
        SUM(reach) AS total_reach
    FROM sandbox_measurement_analyst.mars_tam_hd_staging AS new
    INNER JOIN yr_qtr AS dim ON new.year_month = dim.yrmo_cal_nm
    WHERE
        product_brand_name IN (
            'ACTEMRA',
            'ERIVEDGE',
            'EVRYSDI',
            'GAZYVA',
            'HEMLIBRA',
            'OCREVUS',
            'PERJETA',
            'PHESGO',
            'POLIVY',
            'PULMOZYME',
            'RITUXAN',
            'TECENTRIQ',
            'VABYSMO',
            'VENCLEXTA',
            'XOLAIR'
        ) AND year_month BETWEEN '202201' AND '202312'
    and audience = 'CE'
    GROUP BY product_brand_name, year_month, dim.yrqtr_cal_nm
),

old AS (
    SELECT
        product_brand_name,
        date_year_month,
        dim.yrqtr_cal_nm,
        SUM(tam_hd_total_wgtd) AS total_reach
    FROM sandbox_measurement_analyst.icx_mmix_calls_site_no_indi AS old
    INNER JOIN yr_qtr AS dim ON old.date_year_month = dim.yrmo_cal_nm
    WHERE time_grain = 'R1M'
    GROUP BY product_brand_name, date_year_month, dim.yrqtr_cal_nm
),
site_calls AS(
     SELECT
        product_brand_name,
        year_month,
        dim.yrqtr_cal_nm,
        SUM(tam_hd_wt) AS total_reach
    FROM sandbox_measurement_analyst.mars_tam_hd_site_calls_staging AS new
    INNER JOIN yr_qtr AS dim ON new.year_month = dim.yrmo_cal_nm
    WHERE
        product_brand_name IN (
            'ACTEMRA',
            'ERIVEDGE',
            'EVRYSDI',
            'GAZYVA',
            'HEMLIBRA',
            'OCREVUS',
            'PERJETA',
            'PHESGO',
            'POLIVY',
            'PULMOZYME',
            'RITUXAN',
            'TECENTRIQ',
            'VABYSMO',
            'VENCLEXTA',
            'XOLAIR'
        ) AND year_month BETWEEN '202201' AND '202312'
    GROUP BY product_brand_name, year_month, dim.yrqtr_cal_nm
)

SELECT
    new.product_brand_name,
    new.yrqtr_cal_nm AS year_quarter,
    ROUND(COALESCE(SUM(sc.total_reach), 0), 2) AS site_call_reach,
    ROUND(COALESCE(SUM(old.total_reach), 0), 2) AS old_total_tam_reach,
    ROUND(COALESCE(SUM(new.total_reach), 0), 2) AS new_total_tam_reach,
    ROUND(
        (COALESCE(SUM(new.total_reach), 0) - COALESCE(SUM(old.total_reach), 0)),
        2
    )
        AS new_vs_old_tam_reach_diff
FROM new
INNER JOIN site_calls as sc ON 
    new.product_brand_name = sc.product_brand_name
        AND new.year_month = sc.year_month
        AND new.yrqtr_cal_nm = sc.yrqtr_cal_nm
LEFT JOIN old 
    ON
        new.product_brand_name = old.product_brand_name
        AND new.year_month = old.date_year_month
        AND new.yrqtr_cal_nm = old.yrqtr_cal_nm
GROUP BY new.product_brand_name, new.yrqtr_cal_nm
ORDER BY new.product_brand_name ASC, new.yrqtr_cal_nm ASC

