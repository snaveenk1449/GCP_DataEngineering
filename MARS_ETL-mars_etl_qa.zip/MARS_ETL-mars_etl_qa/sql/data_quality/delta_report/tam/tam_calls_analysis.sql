with tam_hds as (
    select distinct
        unix_id,
        start_date,
        end_date
    from oasis_normalized.alignment_roster_hierarchy_daily
    where field_title_code in ('TAM', 'NRDS', 'SNRDS', 'HD', 'NRDHD', 'ACM')
),

hcp_org_mapping as (
    select
        mdm_id,
        mdm_zip,
        mdm_type
    from sandbox_measurement_analyst.hcp_org_zip_mapping
),

tam_hd_calls as (
    select distinct
        ci.crm_call_id,
        ci.mdm_id,
        hom.mdm_type,
        th.unix_id,
        ci.crm_display_order,
        cast(1 / ci.crm_display_order as double) as call_wt,
        ci.oasis_brand_name as product_brand_name,
        ci.oasis_product_brand_id as product_brand_id,
        upper(ci.crm_call_status) as crm_call_status,
        date(ci.crm_call_datetime) as crm_call_datetime
    from oasis_normalized.crm_commercial_interactions as ci
    inner join hcp_org_mapping as hom on ci.mdm_id = hom.mdm_id
    left join
        tam_hds as th
        on
            ci.crm_user_id = th.unix_id
            and ci.crm_call_datetime between th.start_date and th.end_date
    where
        year(crm_call_datetime) >= 2019 and oasis_brand_name != 'NOT ASSOCIATED'
),

call_stats as (
    select distinct
        crm_call_datetime,
        mdm_id,
        product_brand_name,
        product_brand_id,
        count(crm_call_id)
            over (
                partition by
                    crm_call_datetime,
                    mdm_id,
                    product_brand_name,
                    product_brand_id,
                    crm_display_order
            )
            as call_cnt,
        sum(case when crm_call_status = 'SUBMITTED' then 1 else 0 end)
            over (
                partition by
                    crm_call_datetime,
                    mdm_id,
                    product_brand_name,
                    product_brand_id,
                    crm_display_order
            )
            as submitted_call_cnt,
        sum(case when mdm_type = 'SITE' then 1 else 0 end)
            over (
                partition by
                    crm_call_datetime,
                    mdm_id,
                    product_brand_name,
                    product_brand_id,
                    crm_display_order
            )
            as site_call_cnt,
        sum(
            case
                when
                    mdm_type = 'SITE' and crm_call_status = 'SUBMITTED'
                    then 1
                else 0
            end
        )
            over (
                partition by
                    crm_call_datetime,
                    mdm_id,
                    product_brand_name,
                    product_brand_id,
                    crm_display_order
            )
            as submitted_site_call_cnt,
        sum(
            case
                when
                    mdm_type = 'SITE'
                    and crm_call_status = 'SUBMITTED'
                    and unix_id is not null
                    then 1
                else 0
            end
        )
            over (
                partition by
                    crm_call_datetime,
                    mdm_id,
                    product_brand_name,
                    product_brand_id,
                    crm_display_order
            )
            as submitted_site_tam_hd_call_cnt,
        sum(
            case
                when
                    mdm_type = 'SITE'
                    and crm_call_status = 'SUBMITTED'
                    and unix_id is not null
                    and crm_display_order <= 4
                    then 1
                else 0
            end
        )
            over (
                partition by
                    crm_call_datetime,
                    mdm_id,
                    product_brand_name,
                    product_brand_id,
                    crm_display_order
            )
            as submitted_site_tam_hd_p1_4_call_cnt,
        sum(case when mdm_type = 'HCP' then 1 else 0 end)
            over (
                partition by
                    crm_call_datetime,
                    mdm_id,
                    product_brand_name,
                    product_brand_id,
                    crm_display_order
            )
            as hcp_call_cnt,
        sum(
            case
                when
                    mdm_type = 'HCP' and crm_call_status = 'SUBMITTED'
                    then 1
                else 0
            end
        )
            over (
                partition by
                    crm_call_datetime,
                    mdm_id,
                    product_brand_name,
                    product_brand_id,
                    crm_display_order
            )
            as submitted_hcp_call_cnt,
        sum(
            case
                when
                    mdm_type = 'HCP'
                    and crm_call_status = 'SUBMITTED'
                    and unix_id is not null
                    then 1
                else 0
            end
        )
            over (
                partition by
                    crm_call_datetime,
                    mdm_id,
                    product_brand_name,
                    product_brand_id,
                    crm_display_order
            )
            as submitted_hcp_tam_hd_call_cnt,
        sum(
            case
                when
                    mdm_type = 'HCP'
                    and crm_call_status = 'SUBMITTED'
                    and unix_id is not null
                    and crm_display_order <= 4
                    then 1
                else 0
            end
        )
            over (
                partition by
                    crm_call_datetime,
                    mdm_id,
                    product_brand_name,
                    product_brand_id,
                    crm_display_order
            )
            as submitted_hcp_tam_hd_p1_4_call_cnt
    from tam_hd_calls
),

hcp_calls as (
    select * from tam_hd_calls
    where
        unix_id is not null
        and crm_display_order <= 4
        and crm_call_status = 'SUBMITTED'
        and mdm_type = 'HCP'
),

mdm_spcl as (
    select
        mdm_id,
        primary_phyn_spcl_desc,
        secondary_phyn_spcl_desc
    from sandbox_measurement_analyst.hcp_spcl_desc_mapping

),

hcp_calls_spcl as (
    select
        emp.*,
        ms.primary_phyn_spcl_desc,
        ms.secondary_phyn_spcl_desc
    from hcp_calls as emp
    inner join mdm_spcl as ms on emp.mdm_id = ms.mdm_id
),

mce_excl_mapping as (
    select
        product_brand_id,
        exception_type,
        specialty_description
    from sandbox_measurement_analyst.mce_exception_map
),

mce_excl_ds as (
    select distinct
        ems.*,
        case
            when
                prim.exception_type = 'INCLUDE'
                or sec.exception_type = 'INCLUDE'
                or coalesce(prim.exception_type, sec.exception_type) = 'INCLUDE'
                then 'N'
            else 'Y'
        end as flag_mce_exclusion
    from hcp_calls_spcl as ems
    left join mce_excl_mapping as prim
        on
            ems.primary_phyn_spcl_desc = prim.specialty_description
            and ems.product_brand_id = prim.product_brand_id
    left join mce_excl_mapping as sec
        on
            ems.secondary_phyn_spcl_desc = sec.specialty_description
            and ems.product_brand_id = sec.product_brand_id
),

included_hcp_calls as (
    select
        crm_call_datetime,
        mdm_id,
        product_brand_name,
        product_brand_id,
        sum(case when flag_mce_exclusion = 'N' then 1 else 0 end)
            as submitted_hcp_tam_hd_p1_4_mce_incl_call_cnt
    from mce_excl_ds group by 1, 2, 3, 4, crm_display_order
),

all_calls_raw as (
    select distinct
        c.*,
        coalesce(ih.submitted_hcp_tam_hd_p1_4_mce_incl_call_cnt, 0)
            as submitted_hcp_tam_hd_p1_4_mce_incl_call_cnt,
        (
            coalesce(ih.submitted_hcp_tam_hd_p1_4_mce_incl_call_cnt, 0)
            + c.submitted_site_tam_hd_p1_4_call_cnt
        ) as total_incl_call_cnt
    from call_stats as c
    left join included_hcp_calls as ih
        on
            c.mdm_id = ih.mdm_id
            and c.crm_call_datetime = ih.crm_call_datetime
            and c.product_brand_name = ih.product_brand_name
            and c.product_brand_id = ih.product_brand_id
)


select
    product_brand_name,
    cast(year(crm_call_datetime) as varchar)
    || lpad(cast(month(crm_call_datetime) as varchar), 2, '0') as year_month,
    sum(call_cnt) as call_cnt,
    sum(submitted_call_cnt) as submitted_call_cnt,
    sum(site_call_cnt) as site_call_cnt,
    sum(submitted_site_call_cnt) as submitted_site_call_cnt,
    sum(submitted_site_tam_hd_call_cnt) as submitted_site_tam_hd_call_cnt,
    sum(submitted_site_tam_hd_p1_4_call_cnt)
        as submitted_site_tam_hd_p1_4_call_cnt,
    sum(hcp_call_cnt) as hcp_call_cnt,
    sum(submitted_hcp_call_cnt) as submitted_hcp_call_cnt,
    sum(submitted_hcp_tam_hd_call_cnt) as submitted_hcp_tam_hd_call_cnt,
    sum(submitted_hcp_tam_hd_p1_4_call_cnt)
        as submitted_hcp_tam_hd_p1_4_call_cnt,
    sum(submitted_hcp_tam_hd_p1_4_mce_incl_call_cnt)
        as submitted_hcp_tam_hd_p1_4_mce_incl_call_cnt,
    sum(total_incl_call_cnt) as total_incl_call_cnt
from all_calls_raw
group by 1, 2
order by 1, 2
