with new_file as (
    select
        distinct
        brand,
        audience,
        channel,
        year,
        SUM(CAST(cost AS BIGINT)) as cost
    from sandbox_measurement_analyst.mars_tam_hd_costs_staging
    where year in ('2022', '2023')
    GROUP BY 1, 2, 3, 4
),

old_file as (
    select
        distinct 
        brand,
        audience,
        channel,
        year,
        SUM(CAST(cost AS BIGINT)) as cost
    from sandbox_measurement_analyst.mars_tam_hd_cost_final
    WHERE year in ('2022', '2023')
    GROUP BY 1, 2, 3, 4
),
final as(
select
    n.brand,
    n.audience,
    n.channel,
    n.year,
    COALESCE(c.cost, 0) as old_costs,
    COALESCE(n.cost, 0) as new_costs,
    COALESCE(n.cost - c.cost, 0) as cost_diff
from new_file as n
LEFT JOIN old_file as c
    on
        n.brand = c.brand
        and n.audience = c.audience
        and n.channel = c.channel
        and n.year = c.year
order by n.brand asc, n.year asc
)

SELECT * FROM final 
order by year, brand