with all_evts as (
    select
        event_vendor_id,
        event_start_date,
        event_status,
        event_type,
        event_format
    from oasis_normalized.speaker_bureau_events_daily
    where event_sub_type != 'Patient' and total_attendees > 0
),

evt_curr as (
    select distinct
        event_vendor_id,
        product_brand_name,
        product_brand_id
    from oasis_normalized.speaker_bureau_event_curriculum_daily
    where product_brand_name != 'NOT ASSOCIATED'
),

evt_curr_cnt as (
    select distinct
        event_vendor_id,
        product_brand_name,
        product_brand_id,
        count(product_brand_name)
            over (partition by event_vendor_id)
            as curr_cnt
    from evt_curr
),

all_evts_curr as (
    select
        a.*,
        c.product_brand_name,
        c.product_brand_id,
        c.curr_cnt
    from all_evts as a
    inner join evt_curr_cnt as c on a.event_vendor_id = c.event_vendor_id
),

evt_prtcpnt_data as (
    select distinct
        event_vendor_id,
        sum(case when event_vendor_id is not null then 1 else 0 end)
            over (partition by event_vendor_id)
            as listed_participants_count,
        sum(
            case
                when
                    attendance is not null and upper(attendance) != 'NO'
                    then 1
                else 0
            end
        ) over (partition by event_vendor_id) as participants_attended_count,
        sum(case when upper(participant_role) = 'ATTENDEE' then 1 else 0 end)
            over (partition by event_vendor_id)
            as listed_attendee_participants_count,
        sum(
            case
                when
                    upper(participant_role) = 'ATTENDEE'
                    and attendance is not null
                    and upper(attendance) != 'NO'
                    then 1
                else 0
            end
        ) over (partition by event_vendor_id) as attendees_attended_count,
        sum(
            case
                when
                    upper(participant_role) = 'ATTENDEE'
                    and attendance is not null
                    and upper(attendance) != 'NO'
                    and participant_mdm_id is not null
                    then 1
                else 0
            end
        ) over (partition by event_vendor_id) as attendees_with_mdm_id_count
    from oasis_normalized.speaker_bureau_participants_daily
),

evt_attendees_cons as (
    select distinct
        a.event_vendor_id,
        a.event_start_date,
        a.product_brand_name,
        a.product_brand_id,
        a.event_status,
        a.event_type,
        a.event_format,
        p.listed_participants_count,
        p.participants_attended_count,
        p.listed_attendee_participants_count,
        p.attendees_attended_count,
        p.attendees_with_mdm_id_count
    from all_evts_curr as a
    inner join evt_prtcpnt_data as p on a.event_vendor_id = p.event_vendor_id
),

evt_mdm_prtcpnts as (
    select
        a.*,
        p.participant_mdm_id
    from all_evts_curr as a
    inner join
        oasis_normalized.speaker_bureau_participants_daily as p
        on a.event_vendor_id = p.event_vendor_id
    where
        p.participant_mdm_id is not null
        and attendance is not null
        and upper(attendance) != 'NO'
        and upper(participant_role) = 'ATTENDEE'
),

mdm_spcl as (
    select
        mdm_id,
        primary_phyn_spcl_desc,
        secondary_phyn_spcl_desc
    from sandbox_measurement_analyst.hcp_spcl_desc_mapping

),

evt_mdm_spcl as (
    select
        emp.*,
        ms.primary_phyn_spcl_desc,
        ms.secondary_phyn_spcl_desc
    from evt_mdm_prtcpnts as emp
    inner join mdm_spcl as ms on emp.participant_mdm_id = ms.mdm_id
),

mce_excl_mapping as (
    select
        product_brand_id,
        exception_type,
        specialty_description
    from sandbox_measurement_analyst.mce_exception_map
),

mce_excl_ds as (
    select distinct
        ems.*,
        case
            when
                prim.exception_type = 'INCLUDE'
                or sec.exception_type = 'INCLUDE'
                or coalesce(prim.exception_type, sec.exception_type) = 'INCLUDE'
                then 'N'
            else 'Y'
        end as flag_mce_exclusion
    from evt_mdm_spcl as ems
    left join mce_excl_mapping as prim
        on
            ems.primary_phyn_spcl_desc = prim.specialty_description
            and ems.product_brand_id = prim.product_brand_id
    left join mce_excl_mapping as sec
        on
            ems.secondary_phyn_spcl_desc = sec.specialty_description
            and ems.product_brand_id = sec.product_brand_id
),

included_events as (
    select
        event_vendor_id,
        curr_cnt,
        sum(case when flag_mce_exclusion = 'N' then 1 else 0 end)
            as evt_attendee_mce_pass_count
    from
        mce_excl_ds group by event_vendor_id,
    curr_cnt
)

select
    eac.*,
    ie.evt_attendee_mce_pass_count / curr_cnt as attendees_mce_included_count
from evt_attendees_cons as eac
left join included_events as ie on eac.event_vendor_id = ie.event_vendor_id
