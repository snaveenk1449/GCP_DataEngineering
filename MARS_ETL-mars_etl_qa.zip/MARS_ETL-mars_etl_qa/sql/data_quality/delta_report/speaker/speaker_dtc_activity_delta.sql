WITH yr_qtr AS (
    SELECT DISTINCT
        yrmo_cal_nm,
        yrqtr_cal_nm
    FROM
        oasis_landing.date_dim
),
new AS (
    SELECT
        product_brand_name,
        year_month,
        yrqtr_cal_nm,
        SUM(reach) AS total_reach
    FROM
        sandbox_measurement_analyst.mars_speaker_staging AS new
    INNER JOIN
        yr_qtr AS dim
        ON new.year_month = dim.yrmo_cal_nm
    WHERE
        year_month BETWEEN '202201' AND '202312'
        AND audience LIKE 'DTC%'
        AND UPPER(
            product_brand_name) IN (
            'ACTEMRA',
            'ERIVEDGE',
            'EVRYSDI',
            'GAZYVA',
            'HEMLIBRA',
            'OCREVUS',
            'PERJETA',
            'PHESGO',
            'POLIVY',
            'PULMOZYME',
            'RITUXAN',
            'TECENTRIQ',
            'VABYSMO',
            'VENCLEXTA',
            'XOLAIR'
        )
    GROUP BY product_brand_name, year_month, yrqtr_cal_nm
),

old AS (
    SELECT DISTINCT
        product_brand_name,
        date_year_month,
        attendees,
        yrqtr_cal_nm
    FROM
        sandbox_measurement_analyst.icx_mmix_speaker_patient_program_ecosystem
            AS old
    INNER JOIN
        yr_qtr AS dim
        ON old.date_year_month = dim.yrmo_cal_nm
    WHERE time_grain = 'R1M'
),

total AS (
    SELECT
        product_brand_name,
        date_year_month,
        yrqtr_cal_nm,
        SUM(attendees) AS total_reach
    FROM old
    GROUP BY product_brand_name, date_year_month, yrqtr_cal_nm
)

SELECT
    new.product_brand_name,
    new.yrqtr_cal_nm AS year_quarter,
    COALESCE(SUM(old.total_reach), 0) AS old_total_reach,
    COALESCE(SUM(new.total_reach), 0) AS new_total_reach,
    (COALESCE(SUM(new.total_reach), 0) - COALESCE(SUM(old.total_reach), 0))
        AS new_vs_old_dtc_reach_diff
FROM new
LEFT JOIN
    total AS old
    ON
        new.product_brand_name = old.product_brand_name
        AND new.year_month = old.date_year_month
        AND new.yrqtr_cal_nm = old.yrqtr_cal_nm
GROUP BY new.product_brand_name, new.yrqtr_cal_nm
ORDER BY new.product_brand_name ASC, new.yrqtr_cal_nm ASC








-- WITH yr_qtr AS (
--     SELECT DISTINCT
--         yrmo_cal_nm,
--         yrqtr_cal_nm
--     FROM
--         oasis_landing.date_dim
-- ),
-- speaker_without_mce AS(
--     SELECT 
--         product_brand_name,
--         year_month,
--         yrqtr_cal_nm,
--         SUM(reach) AS total_reach_without_mce
--     FROM
--         sandbox_measurement_analyst.mars_speaker_without_mce_logic AS new
--     INNER JOIN
--         yr_qtr AS dim
--         ON new.year_month = dim.yrmo_cal_nm
--     WHERE
--         year_month BETWEEN '202201' AND '202312'
--         AND audience LIKE 'DTC%'
--         AND UPPER(
--             product_brand_name) IN (
--             'ACTEMRA',
--             'ERIVEDGE',
--             'EVRYSDI',
--             'GAZYVA',
--             'HEMLIBRA',
--             'OCREVUS',
--             'PERJETA',
--             'PHESGO',
--             'POLIVY',
--             'PULMOZYME',
--             'RITUXAN',
--             'TECENTRIQ',
--             'VABYSMO',
--             'VENCLEXTA',
--             'XOLAIR'
--         )
--     GROUP BY product_brand_name, year_month, yrqtr_cal_nm
-- ),
-- new AS (
--     SELECT
--         product_brand_name,
--         year_month,
--         yrqtr_cal_nm,
--         SUM(reach) AS total_reach
--     FROM
--         sandbox_measurement_analyst.mars_speaker_data_new_logic AS new
--     INNER JOIN
--         yr_qtr AS dim
--         ON new.year_month = dim.yrmo_cal_nm
--     WHERE
--         year_month BETWEEN '202201' AND '202312'
--         AND audience LIKE 'DTC%'
--         AND UPPER(
--             product_brand_name) IN (
--             'ACTEMRA',
--             'ERIVEDGE',
--             'EVRYSDI',
--             'GAZYVA',
--             'HEMLIBRA',
--             'OCREVUS',
--             'PERJETA',
--             'PHESGO',
--             'POLIVY',
--             'PULMOZYME',
--             'RITUXAN',
--             'TECENTRIQ',
--             'VABYSMO',
--             'VENCLEXTA',
--             'XOLAIR'
--         )
--     GROUP BY product_brand_name, year_month, yrqtr_cal_nm
-- ),

-- old AS (
--     SELECT DISTINCT
--         product_brand_name,
--         date_year_month,
--         attendees,
--         yrqtr_cal_nm
--     FROM
--         sandbox_measurement_analyst.icx_mmix_speaker_patient_program_ecosystem
--             AS old
--     INNER JOIN
--         yr_qtr AS dim
--         ON old.date_year_month = dim.yrmo_cal_nm
--     WHERE time_grain = 'R1M'
-- ),

-- total AS (
--     SELECT
--         product_brand_name,
--         date_year_month,
--         yrqtr_cal_nm,
--         SUM(attendees) AS total_reach
--     FROM old
--     GROUP BY product_brand_name, date_year_month, yrqtr_cal_nm
-- )

-- SELECT
--     new.product_brand_name,
--     new.yrqtr_cal_nm AS year_quarter,
--     COALESCE(SUM(old.total_reach), 0) AS old_total_reach,
--     COALESCE(SUM(mce.total_reach_without_mce), 0) as new_total_reach_without_mce,
--     COALESCE(SUM(new.total_reach), 0) AS new_total_reach,
--     (COALESCE(SUM(new.total_reach), 0) - COALESCE(SUM(old.total_reach), 0))
--         AS new_vs_old_dtc_reach_diff
-- FROM new
-- INNER JOIN 
--     speaker_without_mce as mce 
--     ON new.product_brand_name = mce.product_brand_name
--     AND new.year_month = mce.year_month
--     AND new.yrqtr_cal_nm = mce.yrqtr_cal_nm
-- LEFT JOIN
--     total AS old
--     ON
--         new.product_brand_name = old.product_brand_name
--         AND new.year_month = old.date_year_month
--         AND new.yrqtr_cal_nm = old.yrqtr_cal_nm
-- GROUP BY new.product_brand_name, new.yrqtr_cal_nm
-- ORDER BY new.product_brand_name ASC, new.yrqtr_cal_nm ASC
