WITH yr_qtr AS (
    SELECT DISTINCT
        yrmo_cal_nm,
        yrqtr_cal_nm
    FROM
        oasis_landing.date_dim
),
new AS (
    SELECT
        product_brand_name,
        year_month,
        yrqtr_cal_nm,
        SUM(reach) AS total_reach
    FROM sandbox_measurement_analyst.mars_speaker_staging AS new
    INNER JOIN yr_qtr AS dim ON new.year_month = dim.yrmo_cal_nm
    WHERE
        year_month BETWEEN '202201' AND '202312'
        AND audience LIKE 'HCP%'
        AND product_brand_name IN (
            'ACTEMRA',
            'ERIVEDGE',
            'EVRYSDI',
            'GAZYVA',
            'HEMLIBRA',
            'OCREVUS',
            'PERJETA',
            'PHESGO',
            'POLIVY',
            'PULMOZYME',
            'RITUXAN',
            'TECENTRIQ',
            'VABYSMO',
            'VENCLEXTA',
            'XOLAIR'
        )
    GROUP BY product_brand_name, year_month, yrqtr_cal_nm
),

old AS (
    SELECT DISTINCT
        product_brand_name,
        date_year_month,
        yrqtr_cal_nm,
        SUM(speaker_program_hcp_reach) AS total_reach
    FROM sandbox_measurement_analyst.mars_combined_pivoted_staging_20240328 AS old
    INNER JOIN yr_qtr AS dim ON old.date_year_month = dim.yrmo_cal_nm

    GROUP BY product_brand_name, date_year_month, yrqtr_cal_nm
)

SELECT
    new.product_brand_name,
    new.yrqtr_cal_nm AS year_quarter,
    COALESCE(SUM(old.total_reach), 0) AS old_total_reach,
    COALESCE(ROUND(SUM(new.total_reach), 0), 2) AS new_total_reach,
    ROUND(COALESCE(SUM(new.total_reach), 0) - COALESCE(SUM(old.total_reach), 0), 2)
        AS new_vs_old_hcp_reach_diff
FROM new
LEFT JOIN old
    ON
        new.product_brand_name = old.product_brand_name
        AND new.year_month = old.date_year_month
        AND new.yrqtr_cal_nm = old.yrqtr_cal_nm
GROUP BY new.product_brand_name, new.yrqtr_cal_nm
ORDER BY new.product_brand_name ASC, new.yrqtr_cal_nm ASC
