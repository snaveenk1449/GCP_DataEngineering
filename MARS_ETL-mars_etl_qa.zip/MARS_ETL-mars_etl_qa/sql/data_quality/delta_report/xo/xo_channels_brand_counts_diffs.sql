WITH new_channels AS (
    SELECT
        channel AS channels_new,
        ROW_NUMBER() OVER (ORDER BY channel) AS row_num
    FROM sandbox_measurement_analyst.mars_mars_xo_digital_campaign_staging_20240526
    GROUP BY channel
),

old_channels AS (
    SELECT
        channel AS channels_old,
        ROW_NUMBER() OVER (ORDER BY channel) AS row_num
    FROM sandbox_measurement_analyst.mars_mars_xo_digital_campaign_historical
    WHERE
        version_number
        = (
            SELECT MAX(version_number)
            FROM
                sandbox_measurement_analyst.mars_mars_xo_digital_campaign_historical
        )
    GROUP BY channel
),

new_brands AS (
    SELECT
        brand AS brands_new,
        ROW_NUMBER() OVER (ORDER BY brand) AS row_num
    FROM sandbox_measurement_analyst.mars_mars_xo_digital_campaign_staging_20240526
    GROUP BY brand
),

old_brands AS (
    SELECT
        brand AS brands_old,
        ROW_NUMBER() OVER (ORDER BY brand) AS row_num
    FROM sandbox_measurement_analyst.mars_mars_xo_digital_campaign_historical
    WHERE
        version_number
        = (
            SELECT MAX(version_number)
            FROM
                sandbox_measurement_analyst.mars_mars_xo_digital_campaign_historical
        )
    GROUP BY brand
),

new_count AS (
    SELECT COUNT(*) AS new_total_record_count
    FROM sandbox_measurement_analyst.mars_mars_xo_digital_campaign_staging_20240526
),

old_count AS (
    SELECT COUNT(*) AS old_total_record_count
    FROM sandbox_measurement_analyst.mars_mars_xo_digital_campaign_historical
    WHERE
        version_number
        = (
            SELECT MAX(version_number)
            FROM
                sandbox_measurement_analyst.mars_mars_xo_digital_campaign_historical
        )
)

SELECT
    oc.channels_old,
    nc.channels_new,
    ob.brands_old,
    nb.brands_new,
    (SELECT new_total_record_count FROM new_count) AS new_total_record_count,
    (SELECT old_total_record_count FROM old_count) AS old_total_record_count
FROM
    new_channels AS nc
FULL OUTER JOIN old_channels AS oc ON nc.row_num = oc.row_num
FULL OUTER JOIN new_brands AS nb ON nc.row_num = nb.row_num
FULL OUTER JOIN old_brands AS ob ON oc.row_num = ob.row_num
ORDER BY
    COALESCE(nc.row_num, oc.row_num, nb.row_num, ob.row_num);
