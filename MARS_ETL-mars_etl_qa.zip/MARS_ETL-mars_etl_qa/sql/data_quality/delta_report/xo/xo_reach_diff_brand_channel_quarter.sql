WITH yr_qtr AS (
    SELECT DISTINCT
        yrmo_cal_nm,
        yrqtr_cal_nm
    FROM
        oasis_landing.date_dim
),

new AS (
    SELECT
        new_tbl.brand,
        new_tbl.channel,
        new_tbl.year,
        dim.yrqtr_cal_nm,
        SUM(CAST(new_tbl.reach AS DOUBLE)) AS total_reach
    FROM
        sandbox_measurement_analyst.mars_mars_xo_digital_campaign_staging_20240526
            AS new_tbl
    INNER JOIN
        yr_qtr AS dim
        ON CONCAT(new_tbl.year, LPAD(new_tbl.month, 2, '0')) = dim.yrmo_cal_nm
    GROUP BY
        new_tbl.brand,
        new_tbl.channel,
        new_tbl.year,
        dim.yrqtr_cal_nm
),

old AS (
    SELECT
        old_tbl.brand,
        old_tbl.channel,
        old_tbl.year,
        dim.yrqtr_cal_nm,
        SUM(CAST(old_tbl.reach AS DOUBLE)) AS total_reach
    FROM
        sandbox_measurement_analyst.mars_mars_xo_digital_campaign_historical
            AS old_tbl
    INNER JOIN
        yr_qtr AS dim
        ON CONCAT(old_tbl.year, LPAD(old_tbl.month, 2, '0')) = dim.yrmo_cal_nm
    WHERE
        old_tbl.version_number = (
            SELECT MAX(version_number)
            FROM
                sandbox_measurement_analyst.mars_mars_xo_digital_campaign_historical
        )
    GROUP BY
        old_tbl.brand,
        old_tbl.channel,
        old_tbl.year,
        dim.yrqtr_cal_nm
)

SELECT
    new.brand,
    new.channel,
    new.yrqtr_cal_nm AS year_quarter,
    ROUND(COALESCE(old.total_reach, 0), 2) AS old_quarterly_reach,
    ROUND(COALESCE(new.total_reach, 0), 2) AS new_quarterly_reach,
    ROUND(COALESCE(new.total_reach, 0) - COALESCE(old.total_reach, 0), 2)
        AS new_vs_old_quarterly_diff
FROM
    new
FULL JOIN
    old
    ON
        new.brand = old.brand
        AND new.channel = old.channel
        AND new.year = old.year
        AND new.yrqtr_cal_nm = old.yrqtr_cal_nm
ORDER BY
    new.brand ASC, new.yrqtr_cal_nm ASC
