WITH yr_qtr AS (
    SELECT DISTINCT
        yrmo_cal_nm,
        yrqtr_cal_nm
    FROM
        oasis_landing.date_dim
),

new_data AS (
    SELECT
        new_tbl.brand,
        new_tbl.audience,
        new_tbl.year,
        dim.yrqtr_cal_nm,
        SUM(CAST(reach AS DOUBLE)) AS total_reach
    FROM
        sandbox_measurement_analyst.mars_mars_xo_digital_campaign_staging_20240526
            AS new_tbl
    INNER JOIN
        yr_qtr AS dim
        ON CONCAT(new_tbl.year, LPAD(new_tbl.month, 2, '0')) = dim.yrmo_cal_nm
    GROUP BY
        new_tbl.brand,
        new_tbl.audience,
        new_tbl.year,
        dim.yrqtr_cal_nm
),

old_data AS (
    SELECT
        old_tbl.brand,
        old_tbl.audience,
        old_tbl.year,
        dim.yrqtr_cal_nm,
        SUM(CAST(reach AS DOUBLE)) AS total_reach
    FROM
        sandbox_measurement_analyst.mars_mars_xo_digital_campaign_historical
            AS old_tbl
    INNER JOIN
        yr_qtr AS dim
        ON CONCAT(old_tbl.year, LPAD(old_tbl.month, 2, '0')) = dim.yrmo_cal_nm
    WHERE
        old_tbl.version_number = (
            SELECT MAX(version_number)
            FROM
                sandbox_measurement_analyst.mars_mars_xo_digital_campaign_historical
        )
    GROUP BY
        old_tbl.brand,
        old_tbl.audience,
        old_tbl.year,
        dim.yrqtr_cal_nm
),

aggs AS (
    SELECT
        new_data.brand,
        new_data.audience,
        new_data.yrqtr_cal_nm,
        COALESCE(old_data.total_reach, 0) AS old_quarterly_reach,
        COALESCE(new_data.total_reach, 0) AS new_quarterly_reach,
        ROUND(
            (
                COALESCE(new_data.total_reach, 0)
                - COALESCE(old_data.total_reach, 0)
            ),
            2
        ) AS new_vs_old_quarterly_reach_diffs
    FROM
        new_data
    FULL JOIN
        old_data ON
        new_data.brand = old_data.brand
        AND new_data.audience = old_data.audience
        AND new_data.year = old_data.year
        AND new_data.yrqtr_cal_nm = old_data.yrqtr_cal_nm
)

SELECT
    aggs.brand,
    aggs.audience,
    aggs.yrqtr_cal_nm AS year_quarter,
    ROUND(aggs.old_quarterly_reach, 2) AS old_quarterly_reach,
    ROUND(aggs.new_quarterly_reach, 2) AS new_quarterly_reach,
    aggs.new_vs_old_quarterly_reach_diffs
FROM
    aggs
ORDER BY
    aggs.brand, aggs.yrqtr_cal_nm
