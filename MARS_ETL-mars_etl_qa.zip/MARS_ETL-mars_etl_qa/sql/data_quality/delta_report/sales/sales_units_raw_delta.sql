
with old AS(
    SELECT 
        product_brand_name, 
        date_year_month, 
        SUM(gne_867_sales_qty_eqv) as gne_867_sales_qty_eqv
    FROM sandbox_measurement_analyst.sst_mcdm_hcp_site_sales_ndc_monthly_historical 
    WHERE version_number = 1 
    AND date_year_month BETWEEN 202201 AND 202312
    AND UPPER(product_brand_name) in('ACTEMRA', 'ERIVEDGE', 'EVRYSDI',
    'GAZYVA', 'HEMLIBRA','OCREVUS','PERJETA','PHESGO','POLIVY','PULMOZYME','RITUXAN','TECENTRIQ',
    'VABYSMO','VENCLEXTA','XOLAIR')
    GROUP By 1, 2
),
new AS(
    SELECT 
        product_brand_name, 
        date_year_month, 
        SUM(gne_867_sales_qty_eqv) as gne_867_sales_qty_eqv
    FROM sandbox_measurement_analyst.mars_sst_mcdm_hcp_site_sales_ndc_monthly_staging
    WHERE date_year_month BETWEEN 202201 AND 202312
    AND UPPER(product_brand_name) in('ACTEMRA', 'ERIVEDGE', 'EVRYSDI',
    'GAZYVA', 'HEMLIBRA','OCREVUS','PERJETA','PHESGO','POLIVY','PULMOZYME','RITUXAN','TECENTRIQ',
    'VABYSMO','VENCLEXTA','XOLAIR')
    GROUP By 1, 2
)

SELECT 
    new.product_brand_name,
    new.date_year_month,
    COALESCE(old.gne_867_sales_qty_eqv, 0) as old_gne_867_sales_qty_eqv,
    COALESCE(new.gne_867_sales_qty_eqv, 0) as new_gne_867_sales_qty_eqv,
    new.gne_867_sales_qty_eqv - old.gne_867_sales_qty_eqv as sales_diff 
FROM old 
FULL JOIN new 
ON old.product_brand_name = new.product_brand_name 
AND old.date_year_month = new.date_year_month
ORDER BY 1, 2


