
WITH yr_qtr AS (
    SELECT DISTINCT
        yrmo_cal_nm,
        yrqtr_cal_nm
    FROM
        oasis_landing.date_dim
),

new AS (
    SELECT
        product_brand_name,
        year_month,
        dim.yrqtr_cal_nm,
        SUM(sales_qty) AS total_sales
    FROM sandbox_measurement_analyst.mars_gne_867_sales_staging AS new
    INNER JOIN
        yr_qtr AS dim
        ON new.year_month = dim.yrmo_cal_nm
    WHERE
        product_brand_name IN (
            'ACTEMRA',
            'ERIVEDGE',
            'EVRYSDI',
            'GAZYVA',
            'HEMLIBRA',
            'OCREVUS',
            'PERJETA',
            'PHESGO',
            'POLIVY',
            'PULMOZYME',
            'RITUXAN',
            'TECENTRIQ',
            'VABYSMO',
            'VENCLEXTA',
            'XOLAIR'
        ) AND year_month >= '202201' AND year_month <= '202312'
    GROUP BY product_brand_name, year_month, yrqtr_cal_nm
),

old AS (
    SELECT
        product_brand_name,
        date_year_month,
        dim.yrqtr_cal_nm,
        SUM(gne_867_sales_qty_eqv) AS total_sales
    FROM sandbox_measurement_analyst.icx_mmix_867_sales_site_no_indi AS old
    INNER JOIN
        yr_qtr AS dim
        ON old.date_year_month = dim.yrmo_cal_nm
    WHERE time_grain = 'R1M'
    GROUP BY product_brand_name, date_year_month, dim.yrqtr_cal_nm
)

SELECT
    new.product_brand_name,
    new.yrqtr_cal_nm AS year_quarter,
    ROUND(COALESCE(SUM(old.total_sales), 0), 2) AS old_total_sales,
    ROUND(COALESCE(SUM(new.total_sales), 0), 2) AS new_total_sales,
    ROUND(
        COALESCE(SUM(new.total_sales), 0) - COALESCE(SUM(old.total_sales), 0), 2
    ) AS new_vs_old_sales_diff
FROM new LEFT JOIN old
    ON
        new.product_brand_name = old.product_brand_name
        AND new.year_month = old.date_year_month
        AND new.yrqtr_cal_nm = old.yrqtr_cal_nm
GROUP BY new.product_brand_name, new.yrqtr_cal_nm
ORDER BY new.product_brand_name ASC, year_quarter ASC
