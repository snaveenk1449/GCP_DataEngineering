with staging as (
    select
        product_brand_name,
        year_month,
        SUM(cost) as tam_cost
    from sandbox_measurement_analyst.mars_tam_hd_staging
    where
        product_brand_name in ('EVRYSDI', 'TECENTRIQ', 'OCREVUS')
        and year_month between '202201' and '202312'
        and audience = 'CE'
    group by product_brand_name, year_month
),

pivoted as (
    select
        product_brand_name,
        date_year_month,
        SUM(tam_hd_ce_cost) as tam_cost
    from sandbox_measurement_analyst.mmix_combined_pivoted_final_20240516
    where
        product_brand_name in ('EVRYSDI', 'TECENTRIQ', 'OCREVUS')
        and date_year_month between '202201' and '202312'
    group by product_brand_name, date_year_month
)

select
    p.product_brand_name,
    p.date_year_month,
    'CE' as audience,
    ROUND(COALESCE(s.tam_cost, 0), 2) as raw_tbl_cost,
    ROUND(COALESCE(p.tam_cost, 0), 2) as pivoted_tbl_cost,
    ROUND(COALESCE(s.tam_cost, 0) - COALESCE(p.tam_cost, 0), 2) as delta_diff
from pivoted as p full join staging as s
    on
        p.product_brand_name = s.product_brand_name
        and p.date_year_month = s.year_month
order by p.product_brand_name asc, p.date_year_month asc

















-- with staging_ce as (
--    select
--         upper(brand) as product_brand_name,
--         year || lpad(month, 2, '0') as year_month,
--         SUM(cost) as tam_cost
--     from sandbox_measurement_analyst.mars_tam_hd_costs_staging 
--     where audience = 'CE'
--     group by brand, year || lpad(month, 2, '0')
-- ),

-- pivoted_ce as (
--     select
--         product_brand_name,
--         date_year_month as year_month,
--         SUM(tam_hd_ce_cost) as tam_cost
--     from sandbox_measurement_analyst.mmix_combined_pivoted_final_20240513
--     where
--         product_brand_name in ('EVRYSDI', 'TECENTRIQ', 'OCREVUS')
--         and date_year_month between '202201' and '202312'
--     group by product_brand_name, date_year_month
-- ),
-- delta_ce as(
-- select
--     p.product_brand_name,
--     p.year_month,
--     'CE' as audience,
--     ROUND(COALESCE(s.tam_cost, 0), 2) as input_ce_cost,
--     ROUND(COALESCE(p.tam_cost, 0), 2) as pivoted_ce_cost,
--     ROUND(COALESCE(s.tam_cost, 0) - COALESCE(p.tam_cost, 0), 2) as delta_diff_ce
-- from pivoted_ce as p full join staging_ce as s
--     on
--         p.product_brand_name = s.product_brand_name
--         and p.year_month = s.year_month
-- order by p.product_brand_name asc, p.year_month asc
-- ),
-- staging_dtc as (
--    select
--         upper(brand) as product_brand_name,
--         year || lpad(month, 2, '0') as year_month,
--         SUM(cost) as tam_cost
--     from sandbox_measurement_analyst.mars_tam_hd_costs_staging 
--     where audience = 'DTC'
--     group by brand, year || lpad(month, 2, '0')
-- ),

-- pivoted_dtc as (
--     select
--         product_brand_name,
--         date_year_month as year_month,
--         SUM(tam_dtc_cost) as tam_cost
--     from sandbox_measurement_analyst.mmix_combined_pivoted_final_20240513
--     where
--         product_brand_name in ('EVRYSDI', 'TECENTRIQ', 'OCREVUS')
--         and date_year_month between '202201' and '202312'
--     group by product_brand_name, date_year_month
-- ),
-- delta_dtc as(
--     select
--     p.product_brand_name,
--     p.year_month,
--     'CE' as audience,
--     ROUND(COALESCE(s.tam_cost, 0), 2) as input_dtc_cost,
--     ROUND(COALESCE(p.tam_cost, 0), 2) as pivoted_dtc_cost,
--     ROUND(COALESCE(s.tam_cost, 0) - COALESCE(p.tam_cost, 0), 2) as delta_diff_dtc
-- from pivoted_dtc as p full join staging_dtc as s
--     on
--         p.product_brand_name = s.product_brand_name
--         and p.year_month = s.year_month
-- order by p.product_brand_name asc, p.year_month asc
-- ),
-- unioned as(
--     select 
--     product_brand_name,
--     year_month, 
--     audience, 
--     input_ce_cost, 
--     pivoted_ce_cost, 
--     delta_diff_ce
--     from delta_ce 
--     union all 
--     select 
--     product_brand_name,
--     year_month, 
--     audience, 
--     input_dtc_cost, 
--     pivoted_dtc_cost, 
--     delta_diff_dtc
--     from delta_dtc
-- )
-- select product_brand_name, year_month, audience, input_ce_cost, pivoted_ce_cost, delta_diff_ce, input_dtc_cost, pivoted_dtc_cost, delta_diff_dtc 
-- from unioned



