
with input as(
    select 
        upper(product) as product_brand_name,
        date_format(date_parse(interaction_date, '%m/%d/%Y'), '%Y%m') as year_month,
        sum(number_of_interactions) as total_reach
    from sandbox_measurement_analyst.mars_tam_pccm_interactions_staging 
    where interaction_type != 'Attempted Contact'
    group by 1, 2
),
output as(
    select 
        product_brand_name, 
        date_year_month, 
        sum(tam_dtc_reach) as total_reach
    from sandbox_measurement_analyst.mmix_combined_pivoted_final_20240516
    group by 1, 2 
)
select 
    i.product_brand_name, 
    i.year_month, 
    i.total_reach as input_reach,
    o.total_reach as output_reach 
from input i 
join output o 
on i.product_brand_name = o.product_brand_name 
and i.year_month = o.date_year_month 
order by 2
