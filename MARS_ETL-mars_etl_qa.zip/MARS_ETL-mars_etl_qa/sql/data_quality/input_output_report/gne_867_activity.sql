with stage as (
    select
        upper(product_brand_name) as product_brand_name,
        cast(date_year_month as varchar) as year_month,
        sum(gne_867_sales_qty_eqv) as total_env
    from sandbox_measurement_analyst.mars_sst_mcdm_hcp_site_sales_ndc_monthly_staging
    group by 1, 2

),

pivoted as (
    select
        product_brand_name,
        date_year_month,
        SUM(
            gne_867_sales_qty_eqv
        ) as total_env
    from sandbox_measurement_analyst.mmix_combined_pivoted_20240526
    where
        date_year_month between '202201' and '202312'
        and product_brand_name IN(
            'EVRYSDI',
            'GAZYVA',
            'HEMLIBRA',
            'OCREVUS',
            'PERJETA',
            'PHESGO',
            'POLIVY',
            'TECENTRIQ',
            'VABYSMO',
            'VENCLEXTA',
            'XOLAIR')
    group by product_brand_name, date_year_month
)

select
    p.product_brand_name,
    p.date_year_month,
    ROUND(COALESCE(s.total_env, 0), 2) as raw_tbl_sales,
    ROUND(COALESCE(p.total_env, 0), 2) as pivoted_sales,
    ROUND(COALESCE(s.total_env, 0) - COALESCE(p.total_env, 0), 2) as delta_diff
from pivoted as p inner join stage as s
    on
        p.product_brand_name = s.product_brand_name
        and p.date_year_month = s.year_month
order by 1, 2