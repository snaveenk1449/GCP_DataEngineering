WITH normalized AS (
    SELECT
        brand AS product_brand_name,
        year || SUBSTRING('0' || month, -2, 2) AS year_month,
        SUM(CAST(cost AS DOUBLE)) AS raw_cost
    FROM sandbox_measurement_analyst.mars_mars_xo_digital_campaign_staging
    WHERE
        year IN ('2022', '2023')
        AND channel = 'Display' AND audience = 'DTC'  
    GROUP BY brand, year || SUBSTRING('0' || month, -2, 2)
),

pivoted AS (
    SELECT
        product_brand_name,
        date_year_month,
        SUM(display_dtc_cost) AS pivoted_cost
    FROM sandbox_measurement_analyst.mmix_combined_pivoted_final_20240516
    GROUP BY product_brand_name, date_year_month
)

SELECT
    n.product_brand_name,
    n.year_month,
    'Display' AS channel,
    'DTC' AS audience,
    ROUND(n.raw_cost, 2) AS raw_table_costs,
    ROUND(p.pivoted_cost, 2) AS pivoted_table_costs,
    ROUND(COALESCE(n.raw_cost, 0) - COALESCE(p.pivoted_cost, 0), 2)
        AS delta_diff
FROM normalized AS n INNER JOIN pivoted AS p
    ON
        UPPER(n.product_brand_name) = UPPER(p.product_brand_name)
        AND
        CAST(n.year_month AS VARCHAR) = CAST(p.date_year_month AS VARCHAR)
ORDER BY n.year_month, n.product_brand_name
