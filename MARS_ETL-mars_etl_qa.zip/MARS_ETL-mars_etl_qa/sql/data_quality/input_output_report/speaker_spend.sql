with pivoted_one as (
    select
        product_brand_name,
        date_year_month,
        'DTC' as audience,
        SUM(speaker_program_dtc_cost) as costs
    from sandbox_measurement_analyst.mmix_combined_pivoted_final_20240516
    where
        product_brand_name in ('EVRYSDI', 'HEMLIBRA')
        and date_year_month between '202201' and '202312'
    group by product_brand_name, date_year_month
),

pivoted_two as (
    select
        product_brand_name,
        date_year_month,
        'HCP' as audience,
        SUM(speaker_program_hcp_cost) as costs
    from sandbox_measurement_analyst.mmix_combined_pivoted_final_20240516
    where
        product_brand_name in ('EVRYSDI', 'HEMLIBRA')
        and date_year_month between '202201' and '202312'
    group by product_brand_name, date_year_month
),

unioned as (
    select * from pivoted_one
    union all
    select * from pivoted_two
),

input as (
    select
        product_brand_name,
        year_month,
        audience,
        SUM(cost) as costs
    from
        sandbox_measurement_analyst.mars_speaker_staging
    where
        audience in ('DTC', 'HCP')
        and product_brand_name in ('EVRYSDI', 'HEMLIBRA')
        and year_month between '202201' and '202312'
    group by
        product_brand_name, year_month, audience
)

select
    u.product_brand_name,
    u.date_year_month,
    u.audience,
    ROUND(COALESCE(i.costs, 0), 2) as raw_tbl_costs,
    ROUND(COALESCE(u.costs, 0), 2) as pivoted_tbl_costs,
    ROUND(COALESCE(i.costs, 0) - COALESCE(u.costs, 0), 2) as delta_diff_costs
from unioned as u
full join input as i
    on
        u.product_brand_name = i.product_brand_name
        and u.date_year_month = i.year_month
        and u.audience = i.audience
order by u.product_brand_name asc, u.date_year_month asc, u.audience asc






--dtc spend 
-- with raw_evts as (
--     select distinct
--         event_vendor_id,
--         event_start_date,
--         'speaker_program' as channel,
--         cast(event_total_cost as double) as event_total_cost,
--         upper(event_status) as event_status,
--         'DTC' as audience,
--         case
--             when
--                 upper(event_status) in ('CLOSED', 'OCCURRED')
--                 then cast(patients_attended as double)
--             else 0
--         end as patients_attended,
--         cast(year(event_start_date) as varchar)
--         || lpad(cast(month(event_start_date) as varchar), 2, '0')
--             as year_month
--     from
--         sandbox_measurement_analyst.mars_speaker_bureau_events_daily_staging
--             as sb
--     where
--         upper(event_status) not in ('DROPPED', 'PENDING')
--         and upper(event_sub_type) = 'PATIENT'
--         and (
--             cast(event_total_cost as double)
--             + patients_attended
--             + customers_attended
--         )
--         > 0
--         and event_start_date < current_date
-- ),

-- evt_curricula as (
--     select distinct
--         event_vendor_id,
--         product_brand_name,
--         product_brand_id
--     from
--         sandbox_measurement_analyst.mars_speaker_bureau_event_curriculum_daily_staging
--     where upper(product_brand_name) != 'NOT ASSOCIATED'
-- ),

-- evt_curricula_cnt as (
--     select distinct
--         event_vendor_id,
--         product_brand_name,
--         product_brand_id,
--         count(product_brand_id)
--             over (partition by event_vendor_id)
--             as product_count
--     from evt_curricula
-- ),

-- evt_ds as (
--     select distinct
--         ec.product_brand_name,
--         re.patients_attended,
--         re.year_month,
--         re.audience,
--         re.event_total_cost / ec.product_count as event_total_cost
--     from raw_evts as re
--     inner join
--         evt_curricula_cnt as ec
--         on re.event_vendor_id = ec.event_vendor_id
-- ),

-- patient_evts as (
--     select distinct
--         year_month,
--         product_brand_name,
--         SUM(event_total_cost) as dtc_cost
--     from evt_ds
--     where audience = 'DTC'
--     group by 1, 2
-- ),
-- pivoted as (
--     select
--         product_brand_name,
--         date_year_month,
--         SUM(COALESCE(speaker_program_dtc_cost, 0)) as dtc_cost
--     from sandbox_measurement_analyst.mmix_combined_pivoted_final_20240516
--     where product_brand_name in (
--             'EVRYSDI',
--             'GAZYVA',
--             'HEMLIBRA',
--             'OCREVUS',
--             'PERJETA',
--             'PHESGO',
--             'POLIVY',
--             'TECENTRIQ',
--             'VABYSMO',
--             'VENCLEXTA',
--             'XOLAIR')
--     and
--      date_year_month between '202201' and '202312'
--     group by product_brand_name, date_year_month
-- )
-- select
--     p.product_brand_name,
--     p.date_year_month,
--     'DTC' as audience,
--     COALESCE(s.dtc_cost, 0) as raw_tbl_cost
--     round(COALESCE(p.dtc_cost, 0), 2) as pivoted_tbl_cost,
--     round(COALESCE(s.dtc_cost, 0) - COALESCE(p.dtc_cost, 0), 2) as delta_diff
-- from patient_evts as s
-- inner join pivoted as p
--     on
--         s.product_brand_name = p.product_brand_name
--         and s.year_month = p.date_year_month
-- order by p.product_brand_name asc, p.date_year_month asc

