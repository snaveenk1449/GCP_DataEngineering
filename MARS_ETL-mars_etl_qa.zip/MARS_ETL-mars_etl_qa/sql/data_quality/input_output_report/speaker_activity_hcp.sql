with staging as (
    select
        product_brand_name,
        year_month,
        SUM(reach) as hcp_reach
    from sandbox_measurement_analyst.mars_speaker_staging
    where
        product_brand_name in ('EVRYSDI', 'OCREVUS')
        and year_month between '202201' and '202312'
        and audience like 'HCP%'
    group by product_brand_name, year_month
),

pivoted as (
    select
        product_brand_name,
        date_year_month,
        SUM(COALESCE(speaker_program_hcp_reach, 0)) as hcp_reach
    from sandbox_measurement_analyst.mmix_combined_pivoted_final_20240516
    where
        product_brand_name in ('EVRYSDI', 'OCREVUS')
        and date_year_month between '202201' and '202312'
    group by product_brand_name, date_year_month
)

select
    p.product_brand_name,
    p.date_year_month,
    'HCP' as audience,
    COALESCE(s.hcp_reach, 0) as raw_tbl_reach,
    COALESCE(p.hcp_reach, 0) as pivoted_tbl_reach,
    COALESCE(s.hcp_reach, 0) - COALESCE(p.hcp_reach, 0) as delta_diff
from staging as s
full join pivoted as p
    on
        s.product_brand_name = p.product_brand_name
        and s.year_month = p.date_year_month
order by p.product_brand_name asc, p.date_year_month asc
