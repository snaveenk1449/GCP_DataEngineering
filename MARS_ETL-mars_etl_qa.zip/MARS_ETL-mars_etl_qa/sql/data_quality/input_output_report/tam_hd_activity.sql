with tam_hds as (
    select distinct
        unix_id,
        start_date,
        end_date
    from
        sandbox_measurement_analyst.mars_alignment_roster_hierarchy_daily_staging
    where
        field_title_code in (
            'TAM',
            'NRDS',
            'SNRDS',
            'HD',
            'NRDHD',
            'ACM',
            'CS',
            'SCS',
            'CSO_CS',
            'CSO_DM',
            'CSO_RD'
        )
),
staging as (
    select
        upper(oasis_brand_name) as product_brand_name,
        cast(year(crm_call_datetime) as varchar)
        || lpad(cast(month(crm_call_datetime) as varchar), 2, '0')
            as date_year_month,
        sum((1/crm_display_order)) as tam_reach
    from sandbox_measurement_analyst.mars_crm_commercial_interactions_staging ci
    inner join tam_hds as th
    on ci.crm_user_id = th.unix_id
    and ci.crm_call_datetime between th.start_date and th.end_date
    where upper(crm_call_status) = 'SUBMITTED' and cast(crm_flag_person_account as integer) = 1
    group by 1, 2
),
pivoted as (
    select
        product_brand_name,
        date_year_month,
        SUM(tam_hd_ce_reach) as tam_reach
    from sandbox_measurement_analyst.mmix_combined_pivoted_20240526
    where
        product_brand_name in (
            'EVRYSDI',
            'GAZYVA',
            'HEMLIBRA',
            'OCREVUS',
            'PERJETA',
            'PHESGO',
            'POLIVY',
            'TECENTRIQ',
            'VABYSMO',
            'VENCLEXTA',
            'XOLAIR')
        and date_year_month between '202201' and '202312'
    group by product_brand_name, date_year_month
)

select
    p.product_brand_name,
    p.date_year_month,
    'CE' as audience,
    ROUND(COALESCE(s.tam_reach, 0), 2) as raw_tbl_reach,
    ROUND(COALESCE(p.tam_reach, 0), 2) as pivoted_tbl_reach,
    ROUND(COALESCE(s.tam_reach, 0) - COALESCE(p.tam_reach, 0), 2) as delta_diff
from pivoted as p inner join staging as s
    on
        p.product_brand_name = s.product_brand_name
        and p.date_year_month = s.date_year_month
order by p.product_brand_name asc, p.date_year_month asc
