/*
* Speaker Events - This dataset gives the reach and cost of HCPs and DTCs for speaker events. Broadly speaking, we have Patient events and HCP events, 
* i.e., speaker events aimed at Patients and events aimed at HCPs. A second-level hierarchy is the level at which these events are held. One is at the National level and the other at the Ecosystem level.
* Since this dataset is at the zip level, the national level events are spread across all zips in the country, while ecosystem level events are spread across all zips in that ecosystem.
*
* For Patient events, since we don't have anything beyond the number of patients, we use the event site's ecosystem to spread the reach and cost across.
* For HCP events, since we know which ecosystems the HCPs belong to, once we apply the MCE logic, we spread the reach and cost across their ecosystem.
*
* While the reach is calculated only for Closed or Occurred events, the costs are taken for all event statuses except Dropped and Pending events.
* There are scenarios where HCPs attend a Patient speaker event. When this happens, we split the costs proportionately between Patients and HCPs. 
* There are also events where multiple products can be discussed (speaker_bureau_event_curriculum_daily table) and in these cases, we split the cost equally into how many ever products were discussed.
*
* For HCP ecosystem level events, we split the costs based on the number of HCPs per ecosystem. For example, if 25 HCPs attended an event and they belonged to 4 different ecosystems, 
* instead of splitting the cost into 4, we split it based on the number of HCPs per ecosystem. So if there was 1 HCP from Ecosystem A, we'd attribute only 1/25 of the total cost and so on.
*
* Once all the cost allocation for both HCPs and Patients is done, we union the ecosystem datasets and nation-level datasets from each, 
* and then distribute across the ecosystem zips and national zips respectively. We then union the resultsets of those distributed datasets and aggregate on the product, zip, channel and year_month level.
*/

with zip_eco_map as (
    select
        zip,
        ecosystem_name,
        ecosystem_dim_id
    from oasis_normalized.alignment_zip_to_ecosystem_daily
    where flag_active = 'Y' and ecosystem_dim_id > 0
),

speaker_evt_acct as (
    select distinct
        unix_id,
        fedex_zip
    from oasis_normalized.alignment_employee_dim_daily
),

-- Get all speaker events, demarcate them as National or Ecosystem level events, with HCP or DTC audiences, but only if they are not DROPPED or PENDING
-- and if the cost and attendee count combined is more than 0

raw_evts as (
    select distinct
        event_vendor_id,
        event_start_date,
        'speaker_program' as channel,
        cast(event_total_cost as double) as event_total_cost,
        customers_attended,
        coalesce(zem.ecosystem_name, azem.ecosystem_name) as ecosystem_name,
        coalesce(zem.ecosystem_dim_id, azem.ecosystem_dim_id)
            as ecosystem_dim_id,
        upper(event_status) as event_status,
        case
            when
                upper(event_status) in ('CLOSED', 'OCCURRED')
                then cast(patients_attended as double)
            else 0
        end as patients_attended,
        case
            when
                (
                    event_type in (
                        'Product Theater',
                        'Training',
                        'National Broadcast',
                        'GPO'
                    )
                    or lower(event_format) like '%virtual%'
                    or lower(setting_type) like '%virtual%'
                )
                then 'national'
            else 'ecosystem'
        end as event_level,
        cast(year(event_start_date) as varchar)
        || lpad(cast(month(event_start_date) as varchar), 2, '0')
            as year_month,
        case when upper(event_sub_type) = 'PATIENT' then 'DTC' else 'HCP' end
            as audience
    from
        sandbox_measurement_analyst.mars_speaker_bureau_events_daily_staging
            as sb
    left join zip_eco_map as zem on sb.site_postal_code = zem.zip
    left join speaker_evt_acct as sea on sb.accountable_unix_id = sea.unix_id
    left join zip_eco_map as azem on sea.fedex_zip = azem.zip
    where
        upper(event_status) not in ('DROPPED', 'PENDING')
        and (
            cast(event_total_cost as double)
            + patients_attended
            + customers_attended
        )
        > 0
        and event_start_date < current_date
),

-- Get all the brands discussed at the event

evt_curricula as (
    select distinct
        event_vendor_id,
        product_brand_name,
        product_brand_id
    from
        sandbox_measurement_analyst.mars_speaker_bureau_event_curriculum_daily_staging
    where upper(product_brand_name) != 'NOT ASSOCIATED'
),

-- Get the number of brands per event

evt_curricula_cnt as (
    select distinct
        event_vendor_id,
        product_brand_name,
        product_brand_id,
        count(product_brand_id)
            over (partition by event_vendor_id)
            as product_count
    from evt_curricula
),

-- Use that to divide the costs between the number of brands discussed
-- Also for Patient events attended by HCPs, calculate the share of each

evt_ds as (
    select distinct
        re.event_vendor_id,
        re.event_start_date,
        re.channel,
        ec.product_brand_name,
        ec.product_brand_id,
        re.ecosystem_name,
        re.ecosystem_dim_id,
        re.event_status,
        re.patients_attended,
        re.customers_attended,
        re.event_level,
        re.year_month,
        re.audience,
        re.event_total_cost / ec.product_count as event_total_cost,
        case
            when
                audience = 'DTC' and customers_attended > 0
                then
                    patients_attended / (patients_attended + customers_attended)
        end as patient_cost_share,
        case
            when
                audience = 'DTC' and customers_attended > 0
                then
                    customers_attended
                    / (patients_attended + customers_attended)
        end as hcp_cost_share
    from raw_evts as re
    inner join
        evt_curricula_cnt as ec
        on re.event_vendor_id = ec.event_vendor_id
),

-- Get just the DTC events

patient_evts as (
    select distinct
        event_vendor_id,
        year_month,
        product_brand_name,
        product_brand_id,
        ecosystem_name,
        ecosystem_dim_id,
        event_level,
        channel,
        patients_attended as reach,
        audience,
        case
            when
                patient_cost_share > 0
                then patient_cost_share * event_total_cost
            else event_total_cost
        end as event_total_cost
    from evt_ds
    where audience = 'DTC'
),

-- Roll up all patient events by either national or ecosystem levels

dtc_evts_rollup as (
    select distinct
        year_month,
        product_brand_name,
        product_brand_id,
        ecosystem_name,
        ecosystem_dim_id,
        event_level,
        channel,
        audience,
        case
            when
                event_level = 'national'
                then
                    sum(reach)
                        over (
                            partition by
                                product_brand_name, year_month, event_level
                        )
            else
                sum(reach)
                    over (
                        partition by
                            product_brand_name,
                            year_month,
                            event_level,
                            ecosystem_name
                    )
        end as reach,
        case
            when
                event_level = 'national'
                then
                    sum(event_total_cost)
                        over (
                            partition by
                                product_brand_name, year_month, event_level
                        )
            else
                sum(event_total_cost)
                    over (
                        partition by
                            product_brand_name,
                            year_month,
                            event_level,
                            ecosystem_name
                    )
        end as cost
    from patient_evts
),

-- Get just the HCP events

hcp_evts as (
    select distinct
        event_vendor_id,
        year_month,
        product_brand_name,
        product_brand_id,
        ecosystem_name,
        ecosystem_dim_id,
        event_status,
        event_level,
        channel,
        'HCP' as audience,
        case
            when
                hcp_cost_share > 0
                then hcp_cost_share * event_total_cost
            else event_total_cost
        end as event_total_cost
    from evt_ds
    where audience = 'HCP' or customers_attended > 0
),

incl_hcp_eco_map as (
    select distinct
        mdm_id,
        product_brand_id,
        ecosystem_name,
        ecosystem_dim_id
    from sandbox_measurement_analyst.mars_hcp_org_mapping_staging
    where mdm_type = 'HCP'
),

-- Using the HCP mapping table, get all attendees who make it through the MCE logic filter
-- for all Closed and Occurred events. We want to count reach for only Closed and Occurred events,
-- but need costs from all events

incl_hcp_evts as (
    select distinct
        he.event_vendor_id,
        he.year_month,
        sp.participant_mdm_id as mdm_id,
        he.product_brand_name,
        he.product_brand_id,
        ihem.ecosystem_name,
        ihem.ecosystem_dim_id,
        he.event_level,
        he.channel,
        he.audience
    from hcp_evts as he
    inner join
        sandbox_measurement_analyst.mars_speaker_bureau_participants_daily_staging
            as sp
        on he.event_vendor_id = sp.event_vendor_id
    inner join incl_hcp_eco_map as ihem
        on
            sp.participant_mdm_id = ihem.mdm_id
            and cardinality(
                array_intersect(
                    array[he.product_brand_id], ihem.product_brand_id
                )
            )
            > 0
    where
        he.event_status in ('CLOSED', 'OCCURRED')
        and upper(sp.participant_role) = 'ATTENDEE'
        and upper(coalesce(attendance, 'No')) != 'NO'
),

-- Get the number of HCPs per-event, but also per-ecosystem. This is so we can apportion the costs fairly.

hcp_cnts as (
    select distinct
        event_vendor_id,
        year_month,
        product_brand_name,
        ecosystem_name,
        ecosystem_dim_id,
        event_level,
        audience,
        channel,
        count(mdm_id)
            over (
                partition by
                    event_vendor_id,
                    year_month,
                    product_brand_name,
                    ecosystem_dim_id,
                    event_level
            )
            as reach,
        count(mdm_id)
            over (
                partition by
                    event_vendor_id
            )
            as total_reach
    from incl_hcp_evts
),

-- Join back to the main HCP event dataset to get all events and costs (even with no attendees)

all_hcp_evts as (
    select distinct
        he.event_vendor_id,
        he.year_month,
        he.product_brand_name,
        he.event_level,
        he.audience,
        he.channel,
        he.event_total_cost,
        coalesce(her.ecosystem_name, he.ecosystem_name) as ecosystem_name,
        coalesce(her.ecosystem_dim_id, he.ecosystem_dim_id) as ecosystem_dim_id,
        coalesce(her.reach, 0) as reach,
        coalesce(her.total_reach, 0) as total_reach
    from hcp_evts as he
    left join hcp_cnts as her
        on he.event_vendor_id = her.event_vendor_id
),

-- Distribute costs according to the HCP counts 

all_hcp_evts_cost_breakdown as (
    select distinct
        event_vendor_id,
        year_month,
        product_brand_name,
        event_level,
        audience,
        channel,
        ecosystem_name,
        ecosystem_dim_id,
        reach,
        total_reach,
        case
            when reach + total_reach = 0 then event_total_cost else
                event_total_cost * reach / total_reach
        end as event_total_cost
    from all_hcp_evts
),

-- Rollup HCP events, just like we did for DTC events

hcp_evts_rollup as (
    select distinct
        year_month,
        product_brand_name,
        ecosystem_name,
        ecosystem_dim_id,
        event_level,
        channel,
        audience,
        case
            when
                event_level = 'national'
                then
                    sum(reach)
                        over (
                            partition by
                                product_brand_name, year_month, event_level
                        )
            else
                sum(reach)
                    over (
                        partition by
                            product_brand_name,
                            year_month,
                            event_level,
                            ecosystem_name
                    )
        end as reach,
        case
            when
                event_level = 'national'
                then
                    sum(event_total_cost)
                        over (
                            partition by
                                product_brand_name, year_month, event_level
                        )
            else
                sum(event_total_cost)
                    over (
                        partition by
                            product_brand_name,
                            year_month,
                            event_level,
                            ecosystem_name
                    )
        end as cost
    from all_hcp_evts_cost_breakdown
),

-- Combine the HCP and DTC ecosytem events

all_ecosystem_evts as (
    select distinct
        year_month,
        product_brand_name,
        ecosystem_name,
        ecosystem_dim_id,
        event_level,
        channel,
        audience,
        reach,
        cost
    from dtc_evts_rollup
    where event_level = 'ecosystem'
    union all
    select distinct
        year_month,
        product_brand_name,
        ecosystem_name,
        ecosystem_dim_id,
        event_level,
        channel,
        audience,
        reach,
        cost
    from hcp_evts_rollup
    where event_level = 'ecosystem'
),

-- And combine the HCP and DTC national events

all_natl_evts as (
    select distinct
        year_month,
        product_brand_name,
        event_level,
        channel,
        audience,
        reach,
        cost
    from dtc_evts_rollup
    where event_level = 'national'
    union all
    select distinct
        year_month,
        product_brand_name,
        event_level,
        channel,
        audience,
        reach,
        cost
    from hcp_evts_rollup
    where event_level = 'national'
),

pop_wts as (
    select distinct
        zip,
        ecosystem_dim_id,
        wt_zip5_total as zip5_weight,
        wt_eco_total as ecosystem_weight
    from sandbox_measurement_analyst.mars_population_demographics_final
),

-- Spread the reach and cost across all zips in the ecosytem

wt_ecosystem_evts as (
    select distinct
        year_month,
        product_brand_name,
        pw.zip,
        channel,
        audience,
        reach,
        cost,
        reach * pw.ecosystem_weight as wt_reach,
        round(cost * pw.ecosystem_weight, 2) as wt_cost
    from all_ecosystem_evts as ee
    inner join pop_wts as pw on ee.ecosystem_dim_id = pw.ecosystem_dim_id
),

-- Spread the reach and cost across all zips in the nation

wt_natl_evts as (
    select distinct
        year_month,
        product_brand_name,
        pw.zip,
        channel,
        audience,
        reach,
        cost,
        reach * pw.zip5_weight as wt_reach,
        round(cost * pw.zip5_weight, 2) as wt_cost
    from all_natl_evts
    cross join pop_wts as pw
),

-- Combine both national and ecosystem events

all_evts_wt as (
    select distinct
        year_month,
        product_brand_name,
        zip,
        channel,
        audience,
        reach,
        cost,
        wt_reach,
        wt_cost
    from wt_ecosystem_evts
    union all
    select distinct
        year_month,
        product_brand_name,
        zip,
        channel,
        audience,
        reach,
        cost,
        wt_reach,
        wt_cost
    from wt_natl_evts
),

-- Final aggregation over year_month, product, audience and zip

agg_data as (
    select distinct
        year_month,
        product_brand_name,
        zip,
        channel,
        audience,
        sum(wt_reach)
            over (partition by year_month, product_brand_name, audience, zip)
            as reach,
        round(
            sum(wt_cost)
                over (partition by year_month, product_brand_name, audience, zip),
            2
        ) as cost
    from all_evts_wt
)

select * from agg_data
