import awswrangler as wr
import logging
from pathlib import Path as Path
import time
from typing import List

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

target_database = 'sandbox_measurement_analyst'
target_workgroup = 'cmg-oasis-prod-measurement_analyst-wkgrp'

def get_query_execution(exec_ids: List[int]) -> str:
    """
    This function continuously checks the status of each query in the provided list of execution IDs. 
    It keeps track of the status until all queries have successfully executed or until any one of them fails. 
    If any queries fail, exception is thrown.
    """
    while True:
        exec_status = []
        for exec_id in exec_ids:
            status = wr.athena.get_query_execution(query_execution_id=exec_id)['Status']['State']
            exec_status.append(status)
        if set(exec_status) == {'SUCCEEDED'}:
            print("All queries successfully executed. Exiting.")
            return "SUCCESS"
        elif 'FAILED' in exec_status:
            failed_table_index = exec_status.index('FAILED')
            failed_table_name = exec_ids[failed_table_index]
            raise Exception(f"Query {failed_table_name} failed.")
        else:
            print("Waiting for queries to complete...")
            time.sleep(3)


def insert_into_historical(insert_queries: List[str]) -> str:
    """
    This function takes in the insert queries from the main function, executes them sequentially
    and inserts the id of each query into the get_query_execution function to return query execution statuses.
    """
    table_insert_ids = []
    for query in insert_queries:
        try:
            insert_id = wr.athena.start_query_execution(query, database=target_database,
                                                        workgroup=target_workgroup)
            table_insert_ids.append(insert_id)
            time.sleep(5)
            logger.info(f"Inserting data into query {query}")
        except Exception as e:
            raise Exception(f"Error running query {query}: {e}")
    return get_query_execution(table_insert_ids)


def drop_staging_tables(drop_queries: List[str]) -> str:
    """
    This function takes in the drop queries from the main function, executes the query and
    inserts the id of each query into the get_query_execution function to return query execution statuses
    """
    drop_query_ids = []
    for query in drop_queries:
        try:
            drop_id = wr.athena.start_query_execution(query, database=target_database,
                                                      workgroup=target_workgroup)
            drop_query_ids.append(drop_id)
            time.sleep(5)
            logger.info(f"Dropping table using query: {query}")
        except Exception as e:
            raise Exception(f"Error running query {query} : {e}")
    return get_query_execution(drop_query_ids)


def create_staging_tables(create_queries: List[str], table_names_staging:List[str]) -> str:
    """
    This function takes in the create table queries and table names from the main function, 
    executes the query using create_ctas_table
    and inserts the id of each query into the get_query_execution function to return query execution statuses
    """
    create_staging_query_ids = []
    for query_str, table_name_staging in zip(create_queries, table_names_staging):
        try:
            table_name = table_name_staging.split('.')[-1]
            create_id = wr.athena.create_ctas_table(
                sql=query_str,
                ctas_table=table_name,
                database=target_database,
                workgroup=target_workgroup,
            )['ctas_query_id']
            create_staging_query_ids.append(create_id)
            time.sleep(5)
        except Exception as e:
            raise Exception(f"Error running query {query_str} : {e}")
    return get_query_execution(create_staging_query_ids)


def construct_queries(input_list: List) -> str:
    """
    This function takes in the list of input tables and constructs the insert, drop and create queries for them.
    It then calls the insert_into_historical, drop_staging_tables and create_staging_tables functions
    to execute the queries and return query execution statuses.
    """
    insert_queries = []
    drop_queries = []
    create_queries = []
    table_names_staging = []

    for item in input_list:
        path = Path(item)
        if path.is_dir():
            logging.info("Using directory")
            for sql_file_path in path.glob("*.sql"):
                if sql_file_path.is_file():
                    with sql_file_path.open('r') as f:
                        query_str = f.read()
                    table_name = sql_file_path.name.replace('.sql', '')
                else:
                    raise FileNotFoundError(f"File {sql_file_path} not found.")
        elif path.is_file():
            logger.info("Using files")
            with path.open('r') as f:
                query_str = f.read()
            table_name = path.name.replace('.sql', '')
        else:
            logger.info("using tables")
            if item.count('.') != 1:
                raise ValueError(f'invalid table name format: {item}')
            source_database, source_table = item.split('.')
            query_str = f"SELECT * FROM {source_database}.{source_table}"

        table_name_staging = f"{target_database}.mars_{source_table}_staging"
        table_name_historical = f"{target_database}.mars_{source_table}_historical"
        
        query_str = f"SELECT *, current_date AS etl_load_date FROM {'(' + query_str + ')' if path.name else query_str}"
        
        insert_query = f"""
        INSERT INTO {table_name_historical}
            SELECT *,
            1 + (SELECT MAX(version_number) FROM {table_name_historical})
        FROM {table_name_staging}
        """
        insert_queries.append(insert_query)

        drop_query = f"""DROP TABLE IF EXISTS {table_name_staging}"""
        drop_queries.append(drop_query)

        create_queries.append(query_str)
        table_names_staging.append(table_name_staging)

    return insert_queries, drop_queries, create_queries, table_names_staging


def trigger_all_functions(input_list: List) -> str:
    """
    This function calls and executes the insert_into_historical, drop_staging_tables and create_staging_tables functions.
    """
    insert_queries, drop_queries, create_queries, table_names_staging = construct_queries(input_list)
    
    try:
        insert_status = insert_into_historical(insert_queries)
        if insert_status != 'SUCCESS':
            print(f'Insert query failed: {insert_status}')
            return 'FAILED'
        
        drop_status = drop_staging_tables(drop_queries)
        if drop_status != 'SUCCESS':
            print(f'Drop query failed: {drop_status}')
            return 'FAILED'
        
        create_status = create_staging_tables(create_queries, table_names_staging)
        if create_status != 'SUCCESS':
            print(f'Create query failed: {create_status}')
            return 'FAILED'
    except Exception as e:
        print(str(e))
        return 'FAILED'

    print(f"Insert status: {insert_status}")
    print(f"Drop status: {drop_status}")
    print(f"Create status: {create_status}")
    return 'SUCCESS'
    
    
    
