import json
import logging
import configparser
import boto3
import sys
import time
from pyspark.sql import SparkSession
from awsglue.utils import getResolvedOptions
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import *
import datetime

MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def read_config_file(config_file_name):
    config = configparser.ConfigParser()
    config.read(config_file_name)
    return config


def check_config_section(config, env):
    if not config.has_section(env):
        raise Exception("Environment details doesn't exist in configuration file")


class Data_copy:
    def __init__(self, config, args, glue_context):
        """
        This is init method used to initialize variables in class
        :param config: Config file object
        :param args: Arguments given to Glue job
        """
        self.env = args['environment']
        self.args = args
        self.bucket_name = config.get(self.env, "bucket_name")
        self.s3_path_list = []
        self.summarized_database = json.loads(config.get(self.env, "athena_database"))['summarized']
        self.summarized_folder = json.loads(config.get(self.env, "folder_names"))['summarized']
        self.crawler_name = 'mars_eda_data_copy_crawler'
        self.glue_context = glue_context
        self.crawler_role = config.get(self.env, "crawler_role")
        self.eda_mapping = json.loads(config.get(self.env, "eda_dashboard_mapping"))
        self.eda_bucket = config.get(self.env, "eda_bucket")

    def core(self, sprk):
        
        ERROR_PATHS = []

        for mapping in self.eda_mapping:            
            try:
                input_path = "s3://" + self.eda_bucket + "/" + mapping['path'] + "/"
                output_table_name = mapping['table_name']
                output_path = "s3://" + self.bucket_name + "/" + self.summarized_folder + "/eda/" + output_table_name + "/"
                logger.info(f'Table name : {output_table_name}')
                logger.info(f'File path : {output_path}')
                # if output_table_name in ['dashboard_combined_vif_geo','dashboard_combined_nt']:
                #     logger.info(f'Skipping table name : {output_table_name}')
                #     logger.info(f'Input path : {input_path}')
                #     continue
    
                sprk.read.parquet(input_path).coalesce(1).write.mode('overwrite').parquet(output_path)
                self.s3_path_list += [output_path]
            except Exception as e:
                logger.error(f"Error processing table: {str(output_table_name)}, path : {str(output_path)}")
                ERROR_PATHS.append(input_path)
                

    def create_update_crawler(self, client):
        """
        Crawler has to be created if it doesn't exist, if it exists then we have to update it s3 path for it.
        :param client: glue boto3 client used to create or update crawler
        """
        # Creating list of s3 path that has to be crawled
        s3_crawl_list = []
        for s3_path in list(set(self.s3_path_list)):
            s3_crawl_list.append(
                {"Path": s3_path})

        crawler_exist = True

        # Checking if crawler is already existing or not
        try:
            res = client.get_crawler(Name=self.crawler_name)
            response = json.dumps(res, indent=4, sort_keys=True, default=str)
            print(response)
        except client.exceptions.EntityNotFoundException as e:
            logger.info("Crawler doesnt exist, need to create")
            crawler_exist = False

        # Creating crawler if it doesn't exist
        if crawler_exist:
            response = client.update_crawler(
                Name=self.crawler_name,
                Role=self.crawler_role,
                DatabaseName=self.summarized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Updated\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

        else:
            response = client.create_crawler(
                Name=self.crawler_name,
                Role=self.crawler_role,
                DatabaseName=self.summarized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Created\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

    def start_crawler(self, client):
        """
        This method is used to start the crawler
        :param client: glue boto3 client used to create or update crawler
        """
        response_start = client.start_crawler(Name=self.crawler_name)
        logger.info("Crawler Started\nName : " + self.crawler_name)
        logger.info(json.dumps(response_start, indent=4, sort_keys=True, default=str))

    def monitor_crawler(self, client):
        """
        This method is used to monitor the crawler which we started just now
        :param client: glue boto3 client used to create or update crawler
        """
        need_to_wait = True
        state_previous = None
        while need_to_wait:
            time.sleep(20)
            response_get = client.get_crawler(Name=self.crawler_name)
            state = response_get["Crawler"]["State"]
            if state == "READY" or state == "STOPPING":  # Other known states: RUNNING
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                need_to_wait = False
                break
            if state != state_previous:
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                state_previous = state


def main():
    arg = getResolvedOptions(sys.argv, ['JOB_NAME', 'environment'])

    logger.info("Glue job started")

    environment = arg['environment']
    config_obj = read_config_file('configuration.ini')
    check_config_section(config_obj, environment)

    sc = SparkContext()
    glue_context = GlueContext(sc)
    sprk = glue_context.spark_session
    job = Job(glue_context)
    job.init(arg['JOB_NAME'], arg)
    logger.info("Writing data from internal data exchange bucket")

    data_copy = Data_copy(config_obj, arg, glue_context)

    data_copy.core(sprk)

    crawler_client = boto3.client('glue', region_name="us-west-2")

    data_copy.create_update_crawler(crawler_client)

    data_copy.start_crawler(crawler_client)

    data_copy.monitor_crawler(crawler_client)

    logger.info("Glue job completed successfully")
    job.commit()


if __name__ == "__main__":
    main()
