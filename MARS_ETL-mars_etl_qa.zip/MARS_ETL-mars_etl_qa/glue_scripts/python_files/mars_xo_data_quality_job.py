import json
import logging
import configparser
import boto3
import sys
import time
from pyspark.sql.window import Window
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import *
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.types import *
import datetime

MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def read_config_file(config_file_name):
    """
    This function is reading config file and returning config object
    :type config_file_name: string
    """
    config = configparser.ConfigParser()
    config.read(config_file_name)
    return config


def check_config_section(config, env):
    """
    This function check if section specified in job parameters is present in config file or not
    :param config: Config file object
    :param env: environment which is specified in job parameters
    """
    if not config.has_section(env):
        raise Exception("Environment details doesn't exist in configuration file")


class XODataQualityReports:
    def __init__(self, config, args, glue_context, spark):
        """
        This is init method used to initialize variables in class
        :param config: Config file object
        :param args: Arguments given to Glue job
        """

        self.env = args['environment']
        self.speaker_event_landing_tbl = config.get(self.env, "event_tbl")
        self.args = args
        self.bucket_name = config.get(self.env, "bucket_name")
        self.normalized_folder = json.loads(config.get(self.env, "folder_names"))['normalized']
        self.s3_path_list = []
        self.normalized_database = json.loads(config.get(self.env, "athena_database"))['normalized']
        self.summarized_database = json.loads(config.get(self.env, "athena_database"))['summarized']
        self.landing_database = json.loads(config.get(self.env, "athena_database"))['landing']
        self.config = config
        self.crawler_name = 'mars_normalized_xo_dq_crawler'
        self.glue_context = glue_context
        self.mars_xo_tbl = config.get(self.env, "mars_xo_tbl")
        self.mars_pivot_tbl = config.get(self.env, "mars_pivot_table_name")
        self.xo_bimonthly_staging = config.get(self.env, "xo_bimonthly_staging")
        self.spark = spark
        self.upper_bound_year_month = int(config.get(self.env, "upper_bound_year_month"))
        self.lower_bound_year_month = int(config.get(self.env, "lower_bound_year_month"))
        self.mars_product_names = "'" + "','".join(
            json.loads(self.config.get(self.env, "mars_product_names_list"))) + "'"
        self.group_channels = json.loads(config.get(self.env, "grp_channels"))
        # self.sst_all_media_summary_indication_bimonthly = config.get(self.env, "xo_digital_indication_tbl")
        # self.mars_xo_indication_tbl = config.get(self.env, "mars_xo_indication_tbl")

    def create_update_crawler(self, client):
        """
        Crawler has to be created if it doesn't exist, if it exists then we have to update it s3 path for it.
        :param client: glue boto3 client used to create or update crawler
        """
        # Creating list of s3 path that has to be crawled
        s3_crawl_list = []
        for s3_path in list(set(self.s3_path_list)):
            s3_crawl_list.append(
                {"Path": s3_path, 'Exclusions': json.loads(self.config.get(self.env, "crawl_exclusion_paths"))})

        crawler_exist = True

        # Checking if crawler is already existing or not
        try:
            res = client.get_crawler(Name=self.crawler_name)
            response = json.dumps(res, indent=4, sort_keys=True, default=str)
            print(response)
        except client.exceptions.EntityNotFoundException as e:
            logger.info("Crawler doesnt exist, need to create")
            crawler_exist = False

        # Creating crawler if it doesn't exist
        if crawler_exist:
            response = client.update_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.normalized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Updated\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

        else:
            response = client.create_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.normalized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Created\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

    def start_crawler(self, client):
        """
        This method is used to start the crawler
        :param client: glue boto3 client used to create or update crawler
        """
        response_start = client.start_crawler(Name=self.crawler_name)
        logger.info("Crawler Started\nName : " + self.crawler_name)
        logger.info(json.dumps(response_start, indent=4, sort_keys=True, default=str))

    def monitor_crawler(self, client):
        """
        This method is used to monitor the crawler which we started just now
        :param client: glue boto3 client used to create or update crawler
        """
        need_to_wait = True
        state_previous = None
        while need_to_wait:
            time.sleep(20)
            response_get = client.get_crawler(Name=self.crawler_name)
            state = response_get["Crawler"]["State"]
            if state == "READY" or state == "STOPPING":  # Other known states: RUNNING
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                need_to_wait = False
                break
            if state != state_previous:
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                state_previous = state

    def xo_indication_input_output(self, athena_client):

        group_channel_case_str = f'case '
        for gc in self.group_channels:
            group_channel_case_str += (" WHEN lower(s.audience) = '" + gc['audience'] +
                                       "' AND upper(s.product_brand_name) = '" + gc['product_brand_name'] +
                                       "' AND lower(s.channel) = '" + gc['channel'] + "'  THEN '" + gc['group_chanel'] +
                                       "' ")
        group_channel_case_str += " ELSE 'Not Grouped' END"

        # logger.info(f'Group Channel Case statement: {group_channel_case_str}')

        logger.info("XO input Output Spends DQ started")

        her2_df_distribution_df = self.spark.sql(f"""with perjeta as ( 
            select  'PERJETA' AS brand_name, indication, channel, publisher, audience, cast(year as string) || SUBSTRING('0' || cast(month as string), -2, 2) AS year_month, 0.6 * CAST(reach AS DOUBLE) AS reach, 0.6 * CAST(cost AS DOUBLE) AS cost, 0.6 * CAST(engage AS DOUBLE) AS engage 
            from {self.landing_database}.{self.sst_all_media_summary_indication_bimonthly}
            where upper(brand_name) = 'HER2' 
        ),
        phesgo as ( select  'PHESGO' AS brand_name, indication, channel, publisher, audience, cast(year as string) || SUBSTRING('0' || cast(month as string), -2, 2) AS year_month, 0.2 * CAST(reach AS DOUBLE) AS reach, 0.2 * CAST(cost AS DOUBLE) AS cost, 0.2 * CAST(engage AS DOUBLE) AS engage 
            from {self.landing_database}.{self.sst_all_media_summary_indication_bimonthly}
            where upper(brand_name) = 'HER2' 
        ),
        all_products as ( select brand_name, channel, indication, publisher, audience, cast(year as string) || SUBSTRING('0' || cast(month as string), -2, 2) AS year_month, CAST(reach AS DOUBLE) as reach, CAST(cost AS DOUBLE) as cost, CAST(engage AS DOUBLE) as engage 
            from {self.landing_database}.{self.sst_all_media_summary_indication_bimonthly}
            where upper(brand_name) != 'HER2' 
        ),
        union_df as ( select * from perjeta
            union all
            select * from phesgo
            union all
            select * from all_products
        )
        select upper(brand_name) AS product_brand_name,
        lower(regexp_replace(channel, '[^A-Za-z0-9]+', '_')) as channel,
        lower(trim(publisher)) as publisher,
        lower(audience) as audience,
        year_month,
        upper(trim(indication)) as indication,
        SUM(CAST(reach AS DOUBLE)) AS raw_reach,
        SUM(CAST(cost AS DOUBLE)) AS raw_cost,
        SUM(CAST(engage AS DOUBLE)) AS raw_engage 
        from union_df 
        WHERE year_month >= '{str(self.lower_bound_year_month)}' and upper(brand_name) in ({self.mars_product_names})
        and channel not in ('dr_cable', 'linear_tv', 'hispanic_linear_tv', 'local_tv')
        GROUP BY 1,2,3,4,5,6         
        """)
        her2_df_distribution_df.registerTempTable('her2_df_distribution')

        normalized_df = self.spark.sql(f"""SELECT
        upper(product_brand_name) as product_brand_name,
        lower(channel) as channel,
        lower(trim(publisher)) as publisher,
        lower(audience) as audience,
        year_month,
        upper(trim(indication)) as indication,
        SUM(reach) AS nor_reach,
        SUM(engage) AS nor_engage,
        SUM(cost) AS nor_cost
        FROM {self.normalized_database}.{self.mars_xo_indication_tbl}
        WHERE year_month >= '{self.lower_bound_year_month}' and upper(product_brand_name) in ({self.mars_product_names})
        and channel not in ('dr_cable', 'linear_tv', 'hispanic_linear_tv', 'local_tv')
        GROUP BY 1,2,3,4,5,6""")
        normalized_df.registerTempTable('normalized')

        final_df = self.spark.sql(f"""SELECT
        upper(n.product_brand_name) as product_brand_name,
        case when n.channel = 'local_tv' then 'puerto_rico_local_tv' else n.channel end channel,
        n.publisher,
        n.audience,
        cast(n.year_month as int) as year_month,
        n.indication,
        ROUND(n.raw_reach, 2) AS raw_table_reach,
        ROUND(s.nor_reach, 2) AS stg_table_reach,
        ROUND(COALESCE(n.raw_reach, 0) - COALESCE(s.nor_reach, 0), 2) AS reach_delta_diff,
        ROUND(n.raw_cost, 2) AS raw_table_cost,
        ROUND(s.nor_cost, 2) AS stg_table_cost,
        ROUND(COALESCE(n.raw_cost, 0) - COALESCE(s.nor_cost, 0), 2) AS cost_delta_diff,
        ROUND(n.raw_engage, 2) AS raw_table_engage,
        ROUND(s.nor_engage, 2) AS stg_table_engage,
        ROUND(COALESCE(n.raw_engage, 0) - COALESCE(s.nor_engage, 0), 2) AS engage_delta_diff,
        {group_channel_case_str} AS Group_channel        
        FROM her2_df_distribution AS n INNER JOIN normalized AS s
        ON
        n.product_brand_name = s.product_brand_name
        AND
        CAST(n.year_month AS string) = CAST(s.year_month AS string)
        AND 
        n.channel = s.channel
        AND
        n.indication = s.indication
        AND
        n.audience = s.audience
        AND 
        n.publisher = s.publisher""")

        final_df.registerTempTable('final')

        compare_df_persisted = (
            final_df.withColumn('publisher', when(col('publisher') == '', 'NA').otherwise(col('publisher')))
            .withColumn('year', col('year_month').cast('string').substr(1, 4))
            .withColumn('year_quarter', expr(
                "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)"))
            .persist())
        audit_info = []
        audit_info += [{'table_name': f"{self.normalized_database}.mars_xo_indication_input_output_dq_staging",
                        'rows_updated': compare_df_persisted.count()}]

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_xo_indication_input_output_dq_staging' + "/")
        compare_df_persisted.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)

        if 'mars_xo_indication_input_output_dq_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                                table_name='mars_xo_indication_input_output_dq_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            hist_df = compare_df_persisted.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = compare_df_persisted.withColumn('version', lit(1))
            logger.info(
                f"Back up table does not exist for mars_xo_indication_input_output_dq_historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_database}.mars_xo_indication_input_output_dq_historical",
             'rows_updated': compare_df_persisted.count()})

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_xo_indication_input_output_dq_historical' + "/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def xo_input_output(self, athena_client):

        group_channel_case_str = f'case '
        for gc in self.group_channels:
            group_channel_case_str += (" WHEN lower(s.audience) = '" + gc['audience'] +
                                       "' AND upper(s.product_brand_name) = '" + gc['product_brand_name'] +
                                       "' AND lower(s.channel) = '" + gc['channel'] + "'  THEN '" + gc['group_chanel'] +
                                       "' ")
        group_channel_case_str += " ELSE 'Not Grouped' END"

        # logger.info(f'Group Channel Case statement: {group_channel_case_str}')

        logger.info("XO input Output Spends DQ started")

        her2_df_distribution_df = self.spark.sql(f"""with perjeta as ( 
            select  'PERJETA' AS brand_name, channel, publisher, audience, cast(year as string) || SUBSTRING('0' || cast(month as string), -2, 2) AS year_month, 0.6 * CAST(reach AS DOUBLE) AS reach, 0.6 * CAST(cost AS DOUBLE) AS cost, 0.6 * CAST(engage AS DOUBLE) AS engage 
            from {self.normalized_database}.{self.xo_bimonthly_staging}
            where upper(brand_name) = 'HER2' 
        ),
        phesgo as ( select  'PHESGO' AS brand_name, channel, publisher, audience, cast(year as string) || SUBSTRING('0' || cast(month as string), -2, 2) AS year_month, 0.2 * CAST(reach AS DOUBLE) AS reach, 0.2 * CAST(cost AS DOUBLE) AS cost, 0.2 * CAST(engage AS DOUBLE) AS engage 
            from {self.normalized_database}.{self.xo_bimonthly_staging}
            where upper(brand_name) = 'HER2' 
        ),
        all_products as ( select brand_name, channel, publisher, audience, cast(year as string) || SUBSTRING('0' || cast(month as string), -2, 2) AS year_month, CAST(reach AS DOUBLE) as reach, CAST(cost AS DOUBLE) as cost, CAST(engage AS DOUBLE) as engage 
            from {self.normalized_database}.{self.xo_bimonthly_staging}
            where upper(brand_name) != 'HER2' 
        ),
        union_df as ( select * from perjeta
            union all
            select * from phesgo
            union all
            select * from all_products
        )
        select upper(brand_name) AS product_brand_name,
        lower(regexp_replace(channel, '[^A-Za-z0-9]+', '_')) as channel,
        lower(trim(publisher)) as publisher,
        lower(audience) as audience,
        year_month,
        SUM(CAST(reach AS DOUBLE)) AS raw_reach,
        SUM(CAST(cost AS DOUBLE)) AS raw_cost,
        SUM(CAST(engage AS DOUBLE)) AS raw_engage 
        from union_df 
        WHERE year_month >= '{str(self.lower_bound_year_month)}' and upper(brand_name) in ({self.mars_product_names})
        and channel not in ('dr_cable', 'linear_tv', 'hispanic_linear_tv', 'local_tv')
        GROUP BY 1,2,3,4,5         
        """)
        her2_df_distribution_df.registerTempTable('her2_df_distribution')

        normalized_df = self.spark.sql(f"""SELECT
        upper(product_brand_name) as product_brand_name,
        lower(channel) as channel,
        lower(trim(publisher)) as publisher,
        lower(audience) as audience,
        year_month,
        SUM(reach) AS nor_reach,
        SUM(engage) AS nor_engage,
        SUM(cost) AS nor_cost
        FROM {self.normalized_database}.{self.mars_xo_tbl}
        WHERE year_month >= '{self.lower_bound_year_month}' and upper(product_brand_name) in ({self.mars_product_names})
        and channel not in ('dr_cable', 'linear_tv', 'hispanic_linear_tv', 'local_tv')
        GROUP BY 1,2,3,4,5""")
        normalized_df.registerTempTable('normalized')

        final_df = self.spark.sql(f"""SELECT
        upper(n.product_brand_name) as product_brand_name,
        case when n.channel = 'local_tv' then 'puerto_rico_local_tv' else n.channel end channel,
        n.publisher,
        n.audience,
        cast(n.year_month as int) as year_month,
        ROUND(n.raw_reach, 2) AS raw_table_reach,
        ROUND(s.nor_reach, 2) AS stg_table_reach,
        ROUND(COALESCE(n.raw_reach, 0) - COALESCE(s.nor_reach, 0), 2) AS reach_delta_diff,
        ROUND(n.raw_cost, 2) AS raw_table_cost,
        ROUND(s.nor_cost, 2) AS stg_table_cost,
        ROUND(COALESCE(n.raw_cost, 0) - COALESCE(s.nor_cost, 0), 2) AS cost_delta_diff,
        ROUND(n.raw_engage, 2) AS raw_table_engage,
        ROUND(s.nor_engage, 2) AS stg_table_engage,
        ROUND(COALESCE(n.raw_engage, 0) - COALESCE(s.nor_engage, 0), 2) AS engage_delta_diff,
        {group_channel_case_str} AS Group_channel        
        FROM her2_df_distribution AS n INNER JOIN normalized AS s
        ON
        n.product_brand_name = s.product_brand_name
        AND
        CAST(n.year_month AS string) = CAST(s.year_month AS string)
        AND 
        n.channel = s.channel
        AND
        n.audience = s.audience
        AND 
        n.publisher = s.publisher""")

        final_df.registerTempTable('final')

        compare_df_persisted = (
            final_df.withColumn('publisher', when(col('publisher') == '', 'NA').otherwise(col('publisher')))
            .withColumn('year', col('year_month').cast('string').substr(1, 4))
            .withColumn('year_quarter', expr(
                "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)"))
            .persist())
        audit_info = []
        audit_info += [{'table_name': f"{self.normalized_database}.mars_xo_input_output_dq_staging",
                        'rows_updated': compare_df_persisted.count()}]

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_xo_input_output_dq_staging' + "/")
        compare_df_persisted.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)

        if 'mars_xo_input_output_dq_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                                table_name='mars_xo_input_output_dq_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            hist_df = compare_df_persisted.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = compare_df_persisted.withColumn('version', lit(1))
            logger.info(f"Back up table does not exist for mars_xo_input_output_dq_historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_database}.mars_xo_input_output_dq_historical",
             'rows_updated': compare_df_persisted.count()})

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_xo_input_output_dq_historical' + "/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def grp_dq_agg(self, athena_client):
        logger.info("XO GRP DQ started")

        group_channel_case_str = f'case '
        for gc in self.group_channels:
            group_channel_case_str += (" WHEN lower(audience) = '" + gc['audience'] +
                                       "' AND upper(product_brand_name) = '" + gc['product_brand_name'] +
                                       "' AND lower(channel) = '" + gc['channel'] + "'  THEN '" + gc['group_chanel'] +
                                       "' ")
        group_channel_case_str += " ELSE 'Not Grouped' END"

        grp_channel_agg_df = self.spark.sql(f"""SELECT
                upper(product_brand_name) as product_brand_name,
                upper(audience) as audience,
                case when channel = 'local_tv' then 'puerto_rico_local_tv' else channel end channel,
                lower(trim(publisher)) as publisher,
                year_month,
                SUM(reach) AS reach,
                SUM(engage) AS engage,
                SUM(cost) AS cost  
                FROM {self.normalized_database}.{self.mars_xo_tbl}
                WHERE year_month >= '{self.lower_bound_year_month}' 
                and upper(product_brand_name) in ({self.mars_product_names}, 'EYLEA HD', 'VUMERITY', 'SYFOVRE', 'KESIMPTA')
                and channel in ('dr_cable', 'linear_tv', 'hispanic_linear_tv', 'local_tv')
                GROUP BY 1,2,3,4,5""")

        grp_channel_agg_df_persisted = (
            grp_channel_agg_df.withColumn('publisher', when(col('publisher') == '', 'NA').otherwise(col('publisher')))
            .withColumn('year', col('year_month').cast('string').substr(1, 4))
            .withColumn('year_quarter', expr(
                "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)"))
            .withColumn('Group_channel', expr(group_channel_case_str)).persist())
        grp_row_count = grp_channel_agg_df_persisted.count()
        audit_info = []
        audit_info += [{'table_name': f"{self.normalized_database}.mars_xo_grp_channels_dq_staging",
                        'rows_updated': grp_row_count}]

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_xo_grp_channels_dq_staging' + "/")
        grp_channel_agg_df_persisted.coalesce(1).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)

        if 'mars_xo_grp_channels_dq_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                                table_name='mars_xo_grp_channels_dq_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            hist_df = grp_channel_agg_df_persisted.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = grp_channel_agg_df_persisted.withColumn('version', lit(1))
            logger.info(f"Back up table does not exist for mars_xo_grp_channels_dq_historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_database}.mars_xo_grp_channels_dq_historical",
             'rows_updated': grp_row_count})

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_xo_grp_channels_dq_historical' + "/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def group_channel(self, athena_client):
        logger.info("Group Channel started")
        channel_audience_agg_df = self.spark.sql(f"""SELECT
                        upper(product_brand_name) as product_brand_name,
                        lower(audience) as audience, 
                        lower(channel) as channel,
                        publisher,
                        year_month,
                        SUM(reach) AS reach,
                        SUM(engage) AS engage,
                        SUM(cost) AS cost
                        FROM {self.normalized_database}.{self.mars_xo_tbl}
                        WHERE year_month >= '{self.lower_bound_year_month}' 
                        and upper(product_brand_name) in ({self.mars_product_names}, 'EYLEA HD', 'VUMERITY', 'SYFOVRE', 'KESIMPTA')
                        GROUP BY 1,2,3,4,5""")
        channel_audience_agg_df.registerTempTable('channel_audience_agg')

        group_channel_case_str = f'case '
        for gc in self.group_channels:
            group_channel_case_str += (" WHEN lower(audience) = '" + gc['audience'] +
                                       "' AND upper(product_brand_name) = '" + gc['product_brand_name'] +
                                       "' AND lower(channel) = '" + gc['channel'] + "'  THEN '" + gc['group_chanel'] +
                                       "' ")
        group_channel_case_str += " ELSE 'Not Grouped' END"

        group_channel_df = self.spark.sql(f"""
                        select * , lower(channel) || '_' ||  lower(audience) as channel_audience,
                        {group_channel_case_str} AS Group_channel
                        from channel_audience_agg
        """)
        group_channel_persisted_df = (group_channel_df
                                      .withColumn('year', col('year_month').cast('string').substr(1, 4))
                                      .withColumn('year_quarter', expr(
            "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)"))
                                      .persist())
        group_channel_count = group_channel_persisted_df.count()
        audit_info = []
        audit_info += [{'table_name': f"{self.normalized_database}.mars_xo_group_channels",
                        'rows_updated': group_channel_count}]

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_xo_group_channels' + "/")
        group_channel_persisted_df.coalesce(1).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)

        if 'mars_xo_group_channels_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                                table_name='mars_xo_group_channels_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            hist_df = group_channel_persisted_df.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = group_channel_persisted_df.withColumn('version', lit(1))
            logger.info(f"Back up table does not exist for mars_xo_grp_channels_dq_historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_database}.mars_xo_group_channels_historical",
             'rows_updated': group_channel_count})

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_xo_group_channels_historical' + "/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info


def audit_job_info(spark_obj, job_srt_time, job_name, batch_id, audit_path, audit_dict):
    """
    This function is used to write audit stats of this etl job to athena table.
    :param audit_path:
    :param spark_obj:
    :param job_srt_time:
    :param job_name:
    :param batch_id:
    :param audit_dict:
    """
    logger.info("Writing to audit table")
    if audit_dict is not None:
        logger.info(audit_dict)
        audit_df = (spark_obj.createDataFrame(audit_dict)
                    .withColumn("log_id_status", lit("COMPLETED"))
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", current_timestamp().cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("etl_layer", lit("normalized_dq"))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)
    else:
        audit_df = (spark_obj.createDataFrame([{'etl_layer': 'normalized_dq', 'log_id_status': 'INITIATED'}])
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", lit(None).cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("table_name", lit(None).cast(StringType()))
                    .withColumn("rows_updated", lit(None).cast(IntegerType()))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)


if __name__ == "__main__":
    # Getting AWS Glue job parameters, creating session and initiating job
    arg = getResolvedOptions(sys.argv, ['JOB_NAME', 'environment', 'batch_id'])

    logger.info("MARS XO Data Quality reports job started")

    environment = arg['environment']
    config_obj = read_config_file('configuration.ini')
    check_config_section(config_obj, environment)
    job_start_time = datetime.datetime.now()

    sc = SparkContext()
    glueContext = GlueContext(sc)
    sprk = glueContext.spark_session
    job = Job(glueContext)
    job.init(arg['JOB_NAME'], arg)
    sprk.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'), audit_dict=None)

    xo_data_quality = XODataQualityReports(config_obj, arg, glueContext, sprk)

    audit_list = []

    athena_cl = boto3.client('athena', region_name="us-west-2")

    audit_list += xo_data_quality.xo_input_output(athena_cl)

    # audit_list += xo_data_quality.xo_indication_input_output(athena_cl)

    audit_list += xo_data_quality.grp_dq_agg(athena_cl)

    audit_list += xo_data_quality.group_channel(athena_cl)

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'), audit_dict=audit_list)

    crawler_client = boto3.client('glue', region_name="us-west-2")

    xo_data_quality.create_update_crawler(crawler_client)

    xo_data_quality.start_crawler(crawler_client)

    xo_data_quality.monitor_crawler(crawler_client)

    job.commit()
