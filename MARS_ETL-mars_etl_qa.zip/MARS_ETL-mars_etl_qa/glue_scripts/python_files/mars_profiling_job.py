import json
import logging
import configparser
import boto3
import sys
import time
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import *
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.types import *
from datetime import datetime
from pyspark.sql.types import StringType
import pandas as pd

MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def read_config_file(config_file_name):
    """
    This function is reading config file and returning config object
    :type config_file_name: string
    """
    config = configparser.ConfigParser()
    config.read(config_file_name)
    return config


def check_config_section(config, env):
    """
    This function check if section specified in job parameters is present in config file or not
    :param config: Config file object
    :param env: environment which is specified in job parameters
    """
    if not config.has_section(env):
        raise Exception("Environment details doesn't exist in configuration file")


class Profiling:
    def __init__(self, config, args, glue_context, spark):
        """
        This is init method used to initialize variables in class
        :param config: Config file object
        :param args: Arguments given to Glue job
        """

        self.args = args
        self.bucket_name = config["bucket_name"]
        # self.s3_path_list = []
        self.config = config
        self.crawler_name = 'mars_profile_crawler'
        self.crawler_role = config["crawler_role"]
        self.glue_context = glue_context
        self.spark = spark
        self.old_table = config["old_table"]
        self.new_table = config["new_table"]
        # self.xo_etl_table = config["xo_etl_table_name"]
        self.old_table_version = config["old_table_version"]
        self.new_table_version = config["new_table_version"]
        self.old_table_product_brand_col_name = config["old_table_product_brand_col_name"]
        self.new_table_product_brand_col_name = config["new_table_product_brand_col_name"]
        self.product_names = config["product_names"]
        self.profiling_start_year_month = config["profiling_start_year_month"]
        self.profiling_end_year_month = config["profiling_end_year_month"]
        self.output_table_database = config["output_table_database"]
        self.group_channels = config["group_channel_mapping"]

    def core(self, athena_client):

        new_table_conditions_list = []
        old_table_conditions_list = []
        # xo_etl_table_conditions_list = []

        if self.new_table is None or self.old_table is None:
            raise Exception("Old table name or new table name cannot be None")

        if self.new_table_version is not None:
            new_table_conditions_list.append(f"version='{self.new_table_version}'")

        if self.old_table_version is not None:
            old_table_conditions_list.append(f"version='{self.old_table_version}'")

        if self.product_names is not None:
            new_table_conditions_list.append(
                f"""upper({self.new_table_product_brand_col_name}) in ('{"','".join(config_json['product_names'])}')""")
            old_table_conditions_list.append(
                f"""upper({self.old_table_product_brand_col_name}) in ('{"','".join(config_json['product_names'])}')""")
            # xo_etl_table_conditions_list.append(
            #     f"""upper(product_brand_name) in ('{"','".join(config_json['product_names'])}')""")

        if self.profiling_start_year_month is not None:
            new_table_conditions_list.append(
                f"concat(year, lpad(month, 2, '0')) >= '{self.profiling_start_year_month}'")
            old_table_conditions_list.append(
                f"concat(year, lpad(month, 2, '0')) >= '{self.profiling_start_year_month}'")
            # xo_etl_table_conditions_list.append(f"year_month >= '{self.profiling_start_year_month}'")

        if self.profiling_end_year_month is not None:
            new_table_conditions_list.append(f"concat(year, lpad(month, 2, '0')) <= '{self.profiling_end_year_month}'")
            old_table_conditions_list.append(f"concat(year, lpad(month, 2, '0')) <= '{self.profiling_end_year_month}'")
            # xo_etl_table_conditions_list.append(f"year_month <= '{self.profiling_end_year_month}'")

        # if len(xo_etl_table_conditions_list) > 0:
        #     xo_etl_table_conditions = " and ".join(xo_etl_table_conditions_list)
        #     xo_etl_table_conditions = " where " + xo_etl_table_conditions
        # else:
        #     xo_etl_table_conditions = ""

        if len(new_table_conditions_list) > 0:
            new_table_conditions = " and ".join(new_table_conditions_list)
            new_table_conditions = " where " + new_table_conditions
        else:
            new_table_conditions = ""

        if len(old_table_conditions_list) > 0:
            old_table_conditions = " and ".join(old_table_conditions_list)
            old_table_conditions = " where " + old_table_conditions
        else:
            old_table_conditions = ""
        self.spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")

        excel_filename = f"MARS_Profiling_{datetime.now().strftime('%Y-%b-%d_%H:%M:%S')}_sheet.xlsx"
        with pd.ExcelWriter(excel_filename) as writer:

            brand_channel_query = f"""with new_data as (
                        select distinct
                            case 
                                when {self.new_table_product_brand_col_name} = 'her2 mu' then 'HER2' 
                                else upper(trim({self.new_table_product_brand_col_name})) 
                            end as brand_new, 
                            upper(trim(channel)) AS channel_new 
                        from {self.new_table} {new_table_conditions}
                        ), 
                        old_data as (
                        select distinct 
                            case 
                                when {self.old_table_product_brand_col_name} = 'her2 mu' then 'HER2' 
                                else upper(trim({self.old_table_product_brand_col_name})) 
                            end as brand_old, 
                            upper(trim(channel)) as channel_old 
                        from {self.old_table} {old_table_conditions}
                        )
                        SELECT 
                            coalesce(o.brand_old, 'N/A') as brand_old,
                            coalesce(n.brand_new, 'N/A') as brand_new,
                            coalesce(o.channel_old, 'N/A') as channel_old,
                            coalesce(n.channel_new, 'N/A') as channel_new
                        from new_data n 
                        full join old_data o  
                        on n.brand_new = o.brand_old 
                        and n.channel_new = o.channel_old
                        order by 
                        coalesce(o.brand_old, n.brand_new)"""
            logger.info("brand_channel_query : " + brand_channel_query)
            brand_channel_query_df = self.spark.sql(brand_channel_query)

            brand_channel_query_df.toPandas().to_excel(writer, sheet_name='xo_missing_channels', index=False)

            delta_new_old_query = f"""
                        with old_data as(
                        select 
                            distinct
                            case when upper({self.old_table_product_brand_col_name}) = 'HER2 MU' then 'HER2' else 
                                    upper({self.old_table_product_brand_col_name}) end as brand, 
                            upper(channel) as channel, 
                            concat(cast(year as string), lpad(cast(month as string), 2, '0')) as year_month,
                            sum(reach) as reach, 
                            sum(engage) as engage, 
                            sum(cost) as cost 
                        from {self.old_table} {old_table_conditions} 
                        group by 1, 2, 3
                        ), 
                        new_data as(
                            select 
                                distinct
                                case when upper({self.new_table_product_brand_col_name}) = 'HER2 MU' then 'HER2' else 
                                    upper({self.new_table_product_brand_col_name}) end as brand, 
                                upper(channel) as channel, 
                                concat(cast(year as string), lpad(cast(month as string), 2, '0')) as year_month,
                                sum(reach) as reach, 
                                sum(engage) as engage, 
                                sum(cost) as cost 
                            from {self.new_table}  {new_table_conditions}
                            group by 1, 2, 3
                        )

                        select 
                            distinct
                            coalesce(o.brand, n.brand) as brand, 
                            coalesce(o.channel, n.channel) as channel, 
                            coalesce(o.year_month, n.year_month) as year_month,
                            o.reach as old_reach, 
                            n.reach as new_reach, 
                            (n.reach-o.reach)*100/coalesce(o.reach,n.reach) as delta_reach_percent,
                            o.engage as old_engage, 
                            n.engage as new_engage, 
                            (n.engage-o.engage)*100/coalesce(o.engage,n.engage) as delta_engage_percent,
                            o.cost as old_cost, 
                            n.cost as new_cost,
                            (n.cost-o.cost)*100/coalesce(o.cost,n.cost) as delta_cost_percent
                        from old_data o 
                        full join new_data n 
                        on o.brand = n.brand
                        and o.channel = n.channel 
                        and o.year_month = n.year_month"""

            logger.info("delta_new_old_query : " + delta_new_old_query)
            delta_new_old_query_df = self.spark.sql(delta_new_old_query)

            delta_new_old_query_df.toPandas().to_excel(writer, sheet_name='xo_channel_level_comparison', index=False)

            delta_new_old_audience_query = f"""
            with old_data as(
                select 
                    distinct
                    upper({self.old_table_product_brand_col_name}) as brand, 
                    upper(channel) as channel, 
                    upper(audience) as audience,
                    concat(year, lpad(month, 2, '0')) as year_month,
                    sum(reach) as reach, 
                    sum(engage) as engage, 
                    sum(cost) as cost 
                from {self.old_table} {old_table_conditions}  
                group by 1, 2, 3, 4
            ), 
            new_data as(
                select 
                    distinct
                    upper({self.new_table_product_brand_col_name}) as brand,
                    upper(channel) as channel, 
                    upper(audience) as audience,
                    concat(cast(year as string), lpad(cast(month as string), 2, '0')) as year_month,
                    sum(reach) as reach, 
                    sum(engage) as engage, 
                    sum(cost) as cost 
                from {self.new_table}  {new_table_conditions}
                group by 1, 2, 3, 4
            )

            select 
                distinct
                coalesce(o.brand, n.brand) as brand, 
                coalesce(o.channel, n.channel) as channel, 
                coalesce(o.year_month, n.year_month) as year_month,
                coalesce(o.audience, n.audience) as audience,
                coalesce(o.reach, 0) as old_reach, 
                coalesce(n.reach, 0) as new_reach, 
                (n.reach-o.reach)*100/coalesce(o.reach,n.reach) as delta_reach_percent,
                coalesce(o.engage, 0) as old_engage, 
                coalesce(n.engage, 0) as new_engage, 
                (n.engage-o.engage)*100/coalesce(o.engage,n.engage) as delta_engage_percent,
                coalesce(o.cost, 0) as old_cost, 
                coalesce(n.cost, 0) as new_cost,
                (n.cost-o.cost)*100/coalesce(o.cost,n.cost) as delta_cost_percent
            from old_data o 
            full join new_data n 
            on o.brand = n.brand
            and o.channel = n.channel 
            and o.year_month = n.year_month 
            and o.audience = n.audience 
            order by 1, 3
            """

            logger.info("delta_new_old_audience_query : " + delta_new_old_audience_query)
            delta_new_old_audience_query_df = self.spark.sql(delta_new_old_audience_query)

            delta_new_old_audience_query_df.toPandas().to_excel(writer,
                                                                sheet_name='xo_channel_audience_level_comparison',
                                                                index=False)

            new_old_yearly_channel_query = f"""
            with old_data as(
                select 
                    distinct
                    upper({self.old_table_product_brand_col_name}) as brand, 
                    upper(channel) as channel, 
                    cast(year as string) as year,
                    sum(reach) as reach, 
                    sum(engage) as engage, 
                    sum(cost) as cost 
                from {self.old_table} {old_table_conditions} 
                group by 1, 2, 3
            ), 
            new_data as(
                select 
                    distinct
                    upper({self.new_table_product_brand_col_name}) as brand,
                    upper(channel) as channel, 
                    cast(year as string) as year,
                    sum(reach) as reach, 
                    sum(engage) as engage, 
                    sum(cost) as cost 
                from {self.new_table}  {new_table_conditions}
                group by 1, 2, 3
            )

            select 
                distinct
                coalesce(o.brand, n.brand) as brand, 
                coalesce(o.channel, n.channel) as channel, 
                coalesce(o.year, n.year) as year,
                coalesce(o.reach, 0) as old_reach, 
                coalesce(n.reach, 0) as new_reach, 
                (n.reach-o.reach)*100/coalesce(o.reach,n.reach) as delta_reach_percent,
                coalesce(o.engage, 0) as old_engage, 
                coalesce(n.engage, 0) as new_engage, 
                (n.engage-o.engage)*100/coalesce(o.engage,n.engage) as delta_engage_percent,
                coalesce(o.cost, 0) as old_cost, 
                coalesce(n.cost, 0) as new_cost,
                (n.cost-o.cost)*100/coalesce(o.cost,n.cost) as delta_cost_percent
            from old_data o 
            full join new_data n 
            on o.brand = n.brand
            and o.channel = n.channel 
            and o.year = n.year
            """
            logger.info("new_old_yearly_channel_query : " + new_old_yearly_channel_query)
            new_old_yearly_channel_query_df = self.spark.sql(new_old_yearly_channel_query)

            new_old_yearly_channel_query_df.toPandas().to_excel(writer, sheet_name='xo_channel_level_yearly_comparison',
                                                                index=False)

            new_old_yearly_audience_query = f"""
            with old_data as(
                select 
                    distinct
                    upper({self.old_table_product_brand_col_name}) as brand, 
                    upper(channel) as channel, 
                    cast(year as string) as year,
                    upper(audience) as audience,
                    sum(reach) as reach, 
                    sum(engage) as engage, 
                    sum(cost) as cost 
                from {self.old_table} {old_table_conditions}  
                group by 1, 2, 3, 4
            ), 
            new_data as(
                select 
                    distinct
                    upper({self.new_table_product_brand_col_name}) as brand, 
                    upper(channel) as channel, 
                    cast(year as string) as year,
                    upper(audience) as audience,
                    sum(reach) as reach, 
                    sum(engage) as engage, 
                    sum(cost) as cost 
                from {self.new_table}  {new_table_conditions}
                group by 1, 2, 3, 4
            )

            select 
                distinct
                coalesce(o.brand, n.brand) as brand, 
                coalesce(o.channel, n.channel) as channel, 
                coalesce(o.year, n.year) as year,
                coalesce(o.audience, n.audience) as audience,             
                (n.reach-o.reach)*100/coalesce(o.reach,n.reach) as delta_reach_percent,
                coalesce(o.engage, 0) as old_engage, 
                coalesce(n.engage, 0) as new_engage, 
                (n.engage-o.engage)*100/coalesce(o.engage,n.engage) as delta_engage_percent,
                coalesce(o.cost, 0) as old_cost, 
                coalesce(n.cost, 0) as new_cost,
                (n.cost-o.cost)*100/coalesce(o.cost,n.cost) as delta_cost_percent
            from old_data o 
            full join new_data n 
            on o.brand = n.brand
            and o.channel = n.channel 
            and o.year = n.year 
            and o.audience = n.audience        
            """

            logger.info("new_old_yearly_audience_query : " + new_old_yearly_audience_query)
            new_old_yearly_audience_query_df = self.spark.sql(new_old_yearly_audience_query)

            new_old_yearly_audience_query_df.toPandas().to_excel(writer,
                                                                 sheet_name='xo_channel_audience_yearly_comparison',
                                                                 index=False)

            reach_and_engage_null_query = f"""
                select 
                upper({self.new_table_product_brand_col_name}) as product_brand_name, 
                channel, 
                dma,
                count(*) as number_of_rows,
                sum(reach) as reach, 
                sum(engage) as engage, 
                sum(cost) as cost 
                from {self.new_table} 
            where reach = 0 and cost > 0 and engage = 0 {new_table_conditions.replace("where", "and")}
            group by 1, 2, 3
            """
            logger.info("reach_and_engage_null_query : " + reach_and_engage_null_query)
            reach_and_engage_null_query_df = self.spark.sql(reach_and_engage_null_query)

            reach_and_engage_null_query_df.toPandas().to_excel(writer, sheet_name='xo_reach_and_engage_null',
                                                               index=False)

            invalid_zips_query = f"""
                    select *
                    from {self.new_table} 
                    where not (
                        zip_code like '_____' 
                        or zip_code like '_____-____'
                    )
                    and zip_code != '' {new_table_conditions.replace("where", "and")}
                    """

            logger.info("invalid_zips_query : " + invalid_zips_query)
            invalid_zips_df = self.spark.sql(invalid_zips_query)

            invalid_zips_df.toPandas().to_excel(writer, sheet_name='empty_zip', index=False)

            delta_new_old_publisher_query = f"""
                        with old_data as(
                            select 
                                distinct
                                upper({self.old_table_product_brand_col_name}) as brand, 
                                lower(trim(publisher)) as publisher,
                                upper(channel) as channel,
                                upper(audience) as audience,
                                concat(year, lpad(month, 2, '0')) as year_month,
                                sum(reach) as reach, 
                                sum(engage) as engage, 
                                sum(cost) as cost 
                            from {self.old_table} {old_table_conditions}  
                            group by 1, 2, 3, 4, 5
                        ), 
                        new_data as(
                            select 
                                distinct
                                upper({self.new_table_product_brand_col_name}) as brand,
                                lower(trim(publisher)) as publisher,
                                upper(channel) as channel, 
                                upper(audience) as audience,
                                concat(cast(year as string), lpad(cast(month as string), 2, '0')) as year_month,
                                sum(reach) as reach, 
                                sum(engage) as engage, 
                                sum(cost) as cost 
                            from {self.new_table}  {new_table_conditions}
                            group by 1, 2, 3, 4, 5
                        )

                        select 
                            distinct
                            coalesce(o.brand, n.brand) as brand, 
                            coalesce(o.channel, n.channel) as channel, 
                            coalesce(o.year_month, n.year_month) as year_month,
                            coalesce(o.audience, n.audience) as audience,
                            coalesce(o.publisher, n.publisher) as publisher,
                            coalesce(o.reach, 0) as old_reach, 
                            coalesce(n.reach, 0) as new_reach, 
                            (n.reach-o.reach)*100/coalesce(o.reach,n.reach) as delta_reach_percent,
                            coalesce(o.engage, 0) as old_engage, 
                            coalesce(n.engage, 0) as new_engage, 
                            (n.engage-o.engage)*100/coalesce(o.engage,n.engage) as delta_engage_percent,
                            coalesce(o.cost, 0) as old_cost, 
                            coalesce(n.cost, 0) as new_cost,
                            (n.cost-o.cost)*100/coalesce(o.cost,n.cost) as delta_cost_percent
                        from old_data o 
                        full join new_data n 
                        on o.brand = n.brand
                        and o.channel = n.channel 
                        and o.year_month = n.year_month 
                        and o.audience = n.audience 
                        and o.publisher = n.publisher 
                        order by 1, 3, 4, 2, 5
                        """

            logger.info("delta_new_old_audience_query : " + delta_new_old_publisher_query)
            delta_new_old_publisher_query_df = self.spark.sql(delta_new_old_publisher_query)

            delta_new_old_publisher_query_df.toPandas().to_excel(writer,
                                                                 sheet_name='xo_channel_audience_publisher_level_comparison',
                                                                 index=False)
            
            # group channel profiling added
            group_channel_case_str = f'case '
            for gc in self.group_channels:
                group_channel_case_str += (" WHEN lower(audience) = '" + gc['audience'] +
                                           "' AND upper(brand_name) = '" + gc['product_brand_name'] +
                                           "' AND lower(regexp_replace(channel, '[^A-Za-z0-9]+', '_')) = '" + gc['channel'] + "'  THEN '" + gc['group_chanel'] +
                                           "' ")
            # group_channel_case_str += " ELSE 'Not Grouped' END"
            group_channel_case_str += " ELSE lower(regexp_replace(channel, '[^A-Za-z0-9]+', '_')) END"            

            delta_new_channel_grouping_level_query = f"""
                        with old_data AS (
                            select 
                                case 
                                    when upper(brand_name) = 'HER2 MU' then 'HER2'
                                    else upper(trim(brand_name))
                                end as product_brand_name,
                                {group_channel_case_str} as group_channel,
                                concat(cast(year AS string), lpad(cast(month AS string), 2, '0')) as year_month,
                                sum(reach) as reach,
                                sum(engage) as engage,
                                sum(cost) as cost
                            from {self.old_table} {old_table_conditions}  
                            group BY 1, 2, 3
                        ),
                        new_data AS (
                            select 
                                case 
                                    when upper(brand_name) = 'HER2 MU' then 'HER2'
                                    else upper(trim(brand_name))
                                end as product_brand_name,
                                {group_channel_case_str} as group_channel,
                                concat(cast(year AS string), lpad(cast(month AS string), 2, '0')) as year_month,
                                sum(reach) AS reach,
                                sum(engage) AS engage,
                                sum(cost) AS cost
                            from {self.new_table}  {new_table_conditions}
                            group by 1, 2, 3
                        )
                        select 
                            coalesce(o.product_brand_name, n.product_brand_name) AS product_brand_name,
                            coalesce(o.group_channel, n.group_channel) AS group_channel,
                            coalesce(o.year_month, n.year_month) AS year_month,
                            o.reach AS old_reach,
                            n.reach AS new_reach,
                            (n.reach - o.reach) * 100 / coalesce(o.reach, n.reach) AS delta_reach_percent,
                            o.engage AS old_engage,
                            n.engage AS new_engage,
                            (n.engage - o.engage) * 100 / coalesce(o.engage, n.engage) AS delta_engage_percent,
                            o.cost AS old_cost,
                            n.cost AS new_cost,
                            (n.cost - o.cost) * 100 / coalesce(o.cost, n.cost) AS delta_cost_percent
                        from old_data o
                        full join new_data n
                            on o.product_brand_name = n.product_brand_name
                            and o.group_channel = n.group_channel
                            and o.year_month = n.year_month
                        order by product_brand_name, year_month, group_channel"""

            logger.info("delta_new_channel_grouping_level_query : " + delta_new_channel_grouping_level_query)
            delta_new_channel_grouping_level_query_df = self.spark.sql(delta_new_channel_grouping_level_query)

            delta_new_channel_grouping_level_query_df.toPandas().to_excel(writer, index=False,
                                                                          sheet_name='xo_group_channel_level_comparison'
                                                                          )

            # input_output_audience_channel_query = f"""
            # with input_data as (
            #     select
            #         upper({self.new_table_product_brand_col_name}) as product_brand_name,
            #         lower(regexp_replace(channel, '[^A-Za-z0-9]+', '_')) as channel,
            #         upper(audience) as audience,
            #         sum(cast(reach as double)) as input_reach,
            #         sum(cast(engage as double)) as input_engage,
            #         sum(cast(cost as double)) as input_cost
            #     from {self.new_table}  {new_table_conditions}
            #     group by 1, 2, 3
            #     order by 1, 2
            # ),
            # output_data as(
            #     select
            #         upper(product_brand_name) as product_brand_name,
            #         channel,
            #         upper(audience) as audience,
            #         sum(reach) as output_reach,
            #         sum(engage) as output_engage,
            #         sum(cost) as output_cost
            #     from {self.xo_etl_table} {xo_etl_table_conditions}
            #     group by 1, 2, 3
            #     order by 1, 2
            # )
            #
            # select
            #     coalesce(i.product_brand_name, o.product_brand_name) AS product_brand_name,
            #     coalesce(i.audience, o.audience) AS audience,
            #     coalesce(i.channel, o.channel) AS channel,
            #     i.input_reach,
            #     o.output_reach,
            #     i.input_engage,
            #     o.output_engage,
            #     i.input_cost,
            #     o.output_cost
            # from input_data i
            # full join output_data o
            # on i.product_brand_name = o.product_brand_name
            # and i.channel = o.channel
            # and i.audience = o.audience
            # """
            #
            # logger.info("input_output_audience_channel_query : " + input_output_audience_channel_query)
            # input_output_audience_channel_df = self.spark.sql(input_output_audience_channel_query)
            #
            # input_output_audience_channel_df.toPandas().to_excel(writer, sheet_name='Sheet_7', index=False)
        s3_client = boto3.resource('s3')
        s3_client.Object(self.bucket_name, 'profiling_reports/' + excel_filename).upload_file(excel_filename)
        logger.info(f'Excel file path : {self.bucket_name}/profiling_reports/{excel_filename}')

        s3_client.Object(self.bucket_name, 'profiling_reports_attachment/MARS_Profiling.xlsx').upload_file(
            excel_filename)
        logger.info(f'Excel file path : {self.bucket_name}/profiling_reports_attachment/MARS_Profiling.xlsx')


def audit_job_info(spark_obj, job_srt_time, job_name, batch_id, audit_path, audit_dict):
    """
    This function is used to write audit stats of this etl job to athena table.
    :param audit_path:
    :param spark_obj:
    :param job_srt_time:
    :param job_name:
    :param batch_id:
    :param audit_dict:
    """
    if audit_dict is not None:
        logger.info("Writing completion stats to audit table")
        logger.info(audit_dict)
        audit_df = (spark_obj.createDataFrame(audit_dict)
                    .withColumn("log_id_status", lit("COMPLETED"))
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", current_timestamp().cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("etl_layer", lit("normalized"))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').csv(audit_path)
        logger.info("Auditing is complete")
    else:
        logger.info("Writing initiating stats to audit table")
        audit_df = (spark_obj.createDataFrame([{'etl_layer': 'normalized', 'log_id_status': 'INITIATED'}])
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", lit(None).cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("table_name", lit(None).cast(StringType()))
                    .withColumn("rows_updated", lit(None).cast(IntegerType()))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').csv(audit_path)


if __name__ == "__main__":
    # Getting AWS Glue job parameters, creating session and initiating job
    arg = getResolvedOptions(sys.argv,
                             ['JOB_NAME', 'environment', 'batch_id'])

    logger.info("MARS XO job started")

    environment = arg['environment']
    config_json = json.load(open('profile_config.json'))
    logger.info(config_json)

    job_start_time = datetime.now()

    sc = SparkContext()
    glueContext = GlueContext(sc)
    sprk = glueContext.spark_session
    job = Job(glueContext)
    job.init(arg['JOB_NAME'], arg)

    xo_profiling = Profiling(config_json, arg, glueContext, sprk)

    crawler_client = boto3.client('glue', region_name="us-west-2")

    athena_cl = boto3.client('athena', region_name="us-west-2")

    xo_profiling.core(athena_cl)

    job.commit()
