import json
import logging
import configparser
import boto3
import sys
import time
from pyspark.sql.window import Window
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import *
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.types import *
import datetime

MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def read_config_file(config_file_name):
    """
    This function is reading config file and returning config object
    :type config_file_name: string
    """
    config = configparser.ConfigParser()
    config.read(config_file_name)
    return config


def check_config_section(config, env):
    """
    This function check if section specified in job parameters is present in config file or not
    :param config: Config file object
    :param env: environment which is specified in job parameters
    """
    if not config.has_section(env):
        raise Exception("Environment details doesn't exist in configuration file")


class TAMQualityReports:
    def __init__(self, config, args, glue_context, spark):
        """
        This is init method used to initialize variables in class
        :param config: Config file object
        :param args: Arguments given to Glue job
        """

        self.env = args['environment']
        self.speaker_event_landing_tbl = config.get(self.env, "event_tbl")
        self.args = args
        self.bucket_name = config.get(self.env, "bucket_name")
        self.normalized_folder = json.loads(config.get(self.env, "folder_names"))['normalized']
        self.s3_path_list = []
        self.normalized_database = json.loads(config.get(self.env, "athena_database"))['normalized']
        self.summarized_database = json.loads(config.get(self.env, "athena_database"))['summarized']
        self.landing_database = json.loads(config.get(self.env, "athena_database"))['landing']
        self.config = config
        self.crawler_name = 'mars_normalized_tam_dq_crawler'
        self.glue_context = glue_context
        self.mars_tam_tbl = config.get(self.env, "mars_tam_tbl")
        self.mars_pivot_tbl = config.get(self.env, "mars_pivot_table_name")
        self.tam_tbl_stg = config.get(self.env, "tam_tbl_stg")
        self.hcp_org_map_tbl = config.get(self.env, 'hcp_org_map_tbl')
        self.tam_pccm_stg_tbl = config.get(self.env, 'tam_pccm_stg_tbl')
        self.tam_pccm_hist_tbl = str(config.get(self.env, "tam_pccm_stg_tbl")).replace('_staging', '_historical')
        self.mstr_roster_hierarchy_dly_stg_tbl = config.get(self.env, 'mstr_roster_hierarchy_dly_stg_tbl')
        self.evrysdi_hcp_zip_tbl = config.get(self.env, 'evrysdi_hcp_zip_tbl')
        self.spark = spark
        self.upper_bound_year_month = int(config.get(self.env, "upper_bound_year_month"))
        self.lower_bound_year_month = int(config.get(self.env, "lower_bound_year_month"))
        self.mars_product_names = "'" + "','".join(
            json.loads(self.config.get(self.env, "mars_product_names_list"))) + "'"
        self.title_codes = "'" + "','".join(json.loads(self.config.get(self.env, "roster_title_code_list"))) + "'"
        self.mars_finance_ce_spend_quarterly_stg = config.get(self.env, "mars_finance_ce_spend_quarterly_stg")
        # self.tam_pccm_stg_tbl_021925 = config.get(self.env, "tam_pccm_stg_tbl_021925")
        self.dcx_ramp_daily_staging = config.get(self.env, "dcx_ramp_daily_staging")
        self.crm_commercial_approved_email = config.get(self.env, "crm_commercial_approved_email")

    def create_update_crawler(self, client):
        """
        Crawler has to be created if it doesn't exist, if it exists then we have to update it s3 path for it.
        :param client: glue boto3 client used to create or update crawler
        """
        # Creating list of s3 path that has to be crawled
        s3_crawl_list = []
        for s3_path in list(set(self.s3_path_list)):
            s3_crawl_list.append(
                {"Path": s3_path, 'Exclusions': json.loads(self.config.get(self.env, "crawl_exclusion_paths"))})

        crawler_exist = True

        # Checking if crawler is already existing or not
        try:
            res = client.get_crawler(Name=self.crawler_name)
            response = json.dumps(res, indent=4, sort_keys=True, default=str)
            print(response)
        except client.exceptions.EntityNotFoundException as e:
            logger.info("Crawler doesnt exist, need to create")
            crawler_exist = False

        # Creating crawler if it doesn't exist
        if crawler_exist:
            response = client.update_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.normalized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Updated\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

        else:
            response = client.create_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.normalized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Created\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

    def start_crawler(self, client):
        """
        This method is used to start the crawler
        :param client: glue boto3 client used to create or update crawler
        """
        response_start = client.start_crawler(Name=self.crawler_name)
        logger.info("Crawler Started\nName : " + self.crawler_name)
        logger.info(json.dumps(response_start, indent=4, sort_keys=True, default=str))

    def monitor_crawler(self, client):
        """
        This method is used to monitor the crawler which we started just now
        :param client: glue boto3 client used to create or update crawler
        """
        need_to_wait = True
        state_previous = None
        while need_to_wait:
            time.sleep(20)
            response_get = client.get_crawler(Name=self.crawler_name)
            state = response_get["Crawler"]["State"]
            if state == "READY" or state == "STOPPING":  # Other known states: RUNNING
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                need_to_wait = False
                break
            if state != state_previous:
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                state_previous = state

    def tam_crosswalk(self, athena_client):
        logger.info("Tam Crosswalk DQ started")
        tam_hds_df = self.spark.sql(f"""
                select position_number,
                    min(start_date) as start_date,
                    max(end_date) as end_date, 
                    field_title_code
                from
                    {self.normalized_database}.{self.mstr_roster_hierarchy_dly_stg_tbl}
                group by 1, 4
        """)
        tam_hds_df.registerTempTable('tam_hds')

        staging_df_evrysdi_hemlibra = self.spark.sql(f"""
                    select distinct
                        ci.crm_call_id,
                        ci.crm_position_number,
                        ci.crm_position_name,
                        ci.mdm_id,
                        ci.crm_display_order,
                        cast(1 / ci.crm_display_order as double) as call_wt,
                        ci.crm_call_datetime,
                        date(ci.crm_call_datetime) as call_date,
                        ci.oasis_brand_name as product_brand_name,
                        ci.oasis_product_brand_id as product_brand_id,
                        'HCP' as mdm_type,
                        'TAM' as channel
                    from
                        {self.normalized_database}.{self.tam_tbl_stg} as ci 
                    where
                        upper(crm_call_status) = 'SUBMITTED'
                        and cast(crm_flag_person_account as integer) = 1
                        and upper(ci.oasis_brand_name) in('EVRYSDI', 'HEMLIBRA')    
                        and crm_call_topic not in( 
                            'Access / Coverage', 
                            'Access/Coverage', 
                            'Copay Card Discussion', 
                            'Genentech Patient Support Services', 
                            'Genentech Patient Support Services In-Service', 
                            'Local Coverage and Reimbursement Education', 
                            'Patient Access Issue - Benefits Verification', 
                            'Patient Access Issue - Claims Processing', 
                            'Patient Access Issue - Drug Delivery (B&B) / (SP)', 
                            'Patient Access Issue - Practice Process',
                            'Patient Access Issue - Patient Assistance', 
                            'Patient Access Issue - Prior Authorization', 
                            'Patient Access Issue - Re - verification', 
                            'Patient Access/Support Services', 
                            'Rebate Program Engagement'
                    )                                              
                """)
        staging_df_evrysdi_hemlibra.registerTempTable('staging_evrysdi_hemlibra')

        staging_df = self.spark.sql(f"""
                    select distinct
                        ci.crm_call_id,
                        ci.crm_position_number,
                        ci.crm_position_name,
                        ci.mdm_id,
                        ci.crm_display_order,
                        cast(1 / ci.crm_display_order as double) as call_wt,
                        ci.crm_call_datetime,
                        date(ci.crm_call_datetime) as call_date,
                        ci.oasis_brand_name as product_brand_name,
                        ci.oasis_product_brand_id as product_brand_id,
                        'HCP' as mdm_type,
                        'TAM' as channel
                    from
                        {self.normalized_database}.{self.tam_tbl_stg} as ci 
                    where
                        upper(crm_call_status) = 'SUBMITTED'
                        and cast(crm_flag_person_account as integer) = 1
                        and upper(ci.oasis_brand_name) not in('ACTEMRA', 'EVRYSDI', 'HEMLIBRA')
                """)
        staging_df.registerTempTable('staging')

        staging_with_actemra_df = self.spark.sql(f"""
                            select distinct
                                ci.crm_call_id,
                                ci.crm_position_number,
                                ci.crm_position_name,
                                ci.mdm_id,
                                ci.crm_display_order,
                                cast(1 / ci.crm_display_order as double) as call_wt,
                                ci.crm_call_datetime,
                                date(ci.crm_call_datetime) as call_date,
                                ci.oasis_brand_name as product_brand_name,
                                ci.oasis_product_brand_id as product_brand_id,
                                'HCP' as mdm_type,
                                case when th.field_title_code like '%CSO%' then 'CSO' else 'TAM' end as channel
                            from
                                {self.normalized_database}.{self.tam_tbl_stg} as ci 
                            left join
                                tam_hds as th
                                on
                                    ci.crm_position_number = th.position_number
                                    and ci.crm_call_datetime between th.start_date and th.end_date
                            where
                                upper(crm_call_status) = 'SUBMITTED'
                                and cast(crm_flag_person_account as integer) = 1
                                and ci.oasis_brand_name = 'ACTEMRA'
                        """)
        staging_with_actemra_df.registerTempTable('staging_with_actemra')

        union_df = self.spark.sql("""
                with all_tam_hd as(
                    select crm_position_name, crm_position_number, product_brand_name, channel, call_date, call_wt from staging_with_actemra
                    union all
                    select crm_position_name, crm_position_number, product_brand_name, channel, call_date, call_wt from staging  
                    union all 
                    select crm_position_name, crm_position_number, product_brand_name, channel, call_date, call_wt from staging_evrysdi_hemlibra
                ), 
                all_tam_hd_calls as (
                    select 
                        th.crm_position_number,
                        th.crm_position_name,
                        th.call_wt,
                        th.call_date,
                        th.product_brand_name,
                        th.channel,
                        case 
                            when f.field_title_code is null then 
                                case
                                    when th.crm_position_name like '%CSO%' then 'CSO' 
                                    when th.crm_position_name like '%_TAM_%' then 'TAM' 
                                    when th.crm_position_name like '%_HD_%' then 'HD' 
                                    when th.crm_position_name like '%NRDS_%' then 'NRDS' 
                                    when th.crm_position_name like '%_ACM_%' then 'ACM' 
                                    else null 
                                end
                            else f.field_title_code 
                        end as field_title_code
                    from all_tam_hd th
                    left join tam_hds f
                        on th.crm_position_number = f.position_number 
                        and th.call_date between f.start_date and f.end_date
                    where f.field_title_code in ('ACM','CRDP_TAM','CS','CSO_CS','CSO_DM','CSO_RD','HD','INTERN_TAM','NRDHD','NRDS','SCS','SNRDS','TAM')
            )
            select * from all_tam_hd_calls
        """)
        union_df.registerTempTable('union')

        agg_df = self.spark.sql("""
                    with daily_reach as ( 
                        select    
                            product_brand_name,
                            channel,
                            call_date,
                            sum(call_wt) as reach
                        from union
                        group by 1, 2, 3
                    ), 

                    final_agg as (
                        select 
                            product_brand_name,
                            channel,
                            date_format(call_date, 'yyyyMM') as date_year_month,
                            sum(reach) as tam_reach
                        from daily_reach
                        group by 1, 2, 3
                    )
                    select * from final_agg 
                """)
        agg_df.registerTempTable('input_agg')

        df_vae_all = self.spark.sql(f"""
                    with tam_hds as(
                        select distinct
                            unix_id,
                            start_date,
                            end_date, 
                            field_title_code, 
                            position_number
                        from
                            {self.normalized_database}.{self.mstr_roster_hierarchy_dly_stg_tbl}
                        where
                            field_title_code in ('ACM','CRDP_TAM','CS','CSO_CS','CSO_DM','CSO_RD','HD','INTERN_TAM','NRDHD','NRDS','SCS','SNRDS','TAM')
                    ),     
                    tam_hds_for_crm as(
                            select position_number,
                                min(start_date) as start_date,
                                max(end_date) as end_date, 
                                field_title_code
                            from
                                {self.normalized_database}.{self.mstr_roster_hierarchy_dly_stg_tbl}
                                group by 1,4
                    ), 
                    dcx_ramp_raw as(
                        select 
                            distinct 
                            mdm_id, 
                            imdb_id,
                            group_id, 
                            sender_username, 
                            case when product_brand_name in('ACTEMRA IV', 'ACTEMRA SC') then 'ACTEMRA' else upper(product_brand_name) 
                                    end as product_brand_name,
                            territory_id,
                            to_date(from_unixtime(unix_timestamp(input_date_time, 'yyyy-MM-dd HH:mm:ss'))) as input_date_time,
                            activity_type
                        from {self.normalized_database}.{self.dcx_ramp_daily_staging}
                        where upper(activity_type) in('DELIVERED', 'OPEN')
                    ), 
                    dcx_ramp_emails as(
                        select 
                            dr.product_brand_name, 
                            date_format(input_date_time, 'yyyyMM') as date_year_month,
                            'CE' as audience, 
                            'VAE' as channel, 
                            th.field_title_code, 
                            count(
                                distinct case when upper(activity_type) in('DELIVERED') then group_id end
                            ) as reach, 
                            count(
                                distinct case when upper(activity_type) in ('OPEN') then group_id end
                            ) as engage
                        from dcx_ramp_raw as dr 
                        inner join tam_hds as th 
                        on
                            dr.sender_username = th.unix_id
                            and dr.input_date_time between th.start_date and th.end_date
                        -- inner join hcp_org_mapping as hom
                        --     on dr.mdm_id = hom.mdm_id
                        --         and size(
                        --             array_intersect(
                        --                 array(dr.product_brand_name), hom.product_brand_name
                        --             )
                        --         ) > 0
                            group by 1, 2, 3, 4, 5   
                    ), 
                    vae_raw as(
                        select 
                            distinct 
                            mdm_id, 
                            product_brand_name, 
                            position_number,
                            position_name,
                            date_year_month, 
                            email_status,
                            activity_type,
                            sent_email_id,
                            crm_activity_client_name,
                            crm_activity_client_operating_system,
                            crm_activity_client_type,
                            crm_activity_device_type,
                            crm_activity_user_agent,
                            date(email_sent_date) as email_sent_date
                        from {self.normalized_database}.{self.crm_commercial_approved_email} 
                        where upper(activity_type) not in('DROPPED', 'BOUNCED')
                    ), 
                    vae_emails as(
                            select 
                                vr.product_brand_name,
                                vr.date_year_month,
                                'CE' as audience, 
                                'VAE' as channel,
                                case 
                                    when th.field_title_code is null then 
                                        case
                                            when vr.position_name like '%CSO%' then 'CSO' 
                                            when vr.position_name like '%_TAM_%' then 'TAM' 
                                            when vr.position_name like '%_HD_%' then 'HD' 
                                            when vr.position_name like '%NRDS_%' then 'NRDS' 
                                            when vr.position_name like '%_ACM_%' then 'ACM' 
                                            else null 
                                        end
                                    else th.field_title_code 
                                end as field_title_code,
                                count(
                                    distinct 
                                    case when upper(email_status) in('DELIVERED', 'MARKED_SPAM', 'UNSUBSCRIBED') then sent_email_id end
                                ) as reach, 
                                count(
                                    distinct 
                                    case when 
                                        upper(activity_type) = 'OPENED' 
                                        and (
                                            crm_activity_client_name != 'unknown'
                                            or crm_activity_client_operating_system != 'unknown'
                                            or crm_activity_client_type != 'unknown'
                                            or crm_activity_device_type != 'unknown'
                                            or crm_activity_user_agent != 'Mozilla/5.0'
                                        )
                                    then sent_email_id end
                                ) as engage
                            from vae_raw as vr 
                            left join tam_hds th
                                on vr.position_number = th.position_number 
                                and vr.email_sent_date between th.start_date and th.end_date            
                            -- inner join hcp_org_mapping as hom
                            --     on vr.mdm_id = hom.mdm_id
                            --         and size(
                            --             array_intersect(
                            --                 array(vr.product_brand_name), hom.product_brand_name
                            --             )
                            --         ) > 0
                            where th.field_title_code in ('ACM','CRDP_TAM','CS','CSO_CS','CSO_DM','CSO_RD','HD','INTERN_TAM','NRDHD','NRDS','SCS','SNRDS','TAM')
                            group by 1, 2, 3, 4, 5
                        )
                        select 
                            product_brand_name,
                            date_year_month as year_month, 
                            lower(audience) as audience,
                            lower(channel) as channel,
                            sum(reach) as reach,
                            sum(engage) as engage 
                        from dcx_ramp_emails
                        group by 1, 2, 3, 4
                        union all 
                        select 
                            product_brand_name,
                            date_year_month as year_month, 
                            lower(audience) as audience,
                            lower(channel) as channel,
                            sum(reach) as reach,
                            sum(engage) as engage 
                        from vae_emails
                        group by 1, 2, 3, 4
                    """)
        df_vae_all.registerTempTable('vae_unioned')

        pivoted_df = self.spark.sql(f"""
                with pivot_tam as (
                    select
                    product_brand_name, year_month, SUM(reach) as pivot_tam_reach
                    from {self.normalized_database}.{self.mars_tam_tbl}
                    where
                    upper(product_brand_name) in ( {self.mars_product_names})
                    and channel='tam_hd'                    
                    and audience='ce'
                    and year_month >= '{self.lower_bound_year_month}'
                    group by product_brand_name,year_month
                ),
                agg_vae_ip as (
                    select product_brand_name, year_month, channel , sum(reach) as ip_tam_reach, sum(engage) as ip_tam_engage
                    from vae_unioned
                    where upper(product_brand_name) in ( {self.mars_product_names})
                    group by 1,2,3
                ),

                agg_vae_op as (
                    select
                    product_brand_name, year_month, channel, SUM(reach) as etl_tam_reach, sum(engage) as etl_tam_engage
                    from {self.normalized_database}.{self.mars_tam_tbl}
                    where
                    upper(product_brand_name) in ( {self.mars_product_names}) and
                    lower(channel)='vae'                    
                    and lower(audience)='ce'
                    and year_month >= '{self.lower_bound_year_month}'
                    group by 1,2,3
                ),

                join_vae as (
                    select o.product_brand_name, o.year_month, o.channel, i.ip_tam_reach, o.etl_tam_reach, o.etl_tam_engage, i.ip_tam_engage
                    from agg_vae_op as o inner join agg_vae_ip as i 
                    on o.product_brand_name = i.product_brand_name 
                    and o.year_month = i.year_month 
                    and lower(o.channel) = lower(i.channel) 
                ),

                input_tam as (
                    select product_brand_name, 'tam_hd' as channel, date_year_month, tam_reach as ip_tam_reach
                        from input_agg where channel = 'TAM'
                ),
                input_cso as (
                    select product_brand_name, 'cso' as channel, date_year_month, tam_reach as ip_tam_reach
                        from input_agg where channel = 'CSO'
                ),
                pivot_cso as (
                    select
                    product_brand_name, year_month, SUM(reach) as pivot_tam_reach
                    from {self.normalized_database}.{self.mars_tam_tbl}
                    where
                    upper(product_brand_name) in ( {self.mars_product_names})
                    and channel='cso'
                    and audience='ce'
                    and year_month >= '{self.lower_bound_year_month}'
                    group by product_brand_name, year_month
                ),
                join_cso as (
                    select p.product_brand_name, p.year_month, i.channel, i.ip_tam_reach, p.pivot_tam_reach
                    from pivot_cso as p inner join input_cso as i
                    on p.product_brand_name = i.product_brand_name and p.year_month = i.date_year_month
                ),
                join_tam as (
                    select p.product_brand_name, p.year_month, i.channel, i.ip_tam_reach, p.pivot_tam_reach
                    from pivot_tam as p inner join input_tam as i
                    on p.product_brand_name = i.product_brand_name and p.year_month = i.date_year_month
                )

                select product_brand_name, year_month, channel, ip_tam_reach, pivot_tam_reach, cast(null as double) as etl_tam_engage, cast(null as double) as ip_tam_engage from join_cso
                union all
                select product_brand_name, year_month, channel, ip_tam_reach, pivot_tam_reach, cast(null as double) as etl_tam_engage, cast(null as double) as ip_tam_engage  from join_tam
                union all
                select product_brand_name, year_month, channel, ip_tam_reach, etl_tam_reach as pivot_tam_reach, etl_tam_engage, ip_tam_engage from join_vae 

                """)
        pivoted_df.registerTempTable('pivoted')

        final_df = self.spark.sql(f"""
                select
                p.product_brand_name,
                cast(p.year_month as int) as date_year_month,
                lower(p.channel) as channel,
                ROUND(COALESCE(p.ip_tam_reach, 0), 2) as reach_before_mce,
                ROUND(COALESCE(p.pivot_tam_reach, 0), 2) as reach_after_mce,
                ROUND(COALESCE(p.ip_tam_reach, 0) - COALESCE(p.pivot_tam_reach, 0), 2) as mce_diff_reach,
                ROUND(COALESCE(p.ip_tam_engage, 0), 2) as engage_before_mce,
                ROUND(COALESCE(p.etl_tam_engage, 0), 2) as engage_after_mce,
                ROUND(COALESCE(p.ip_tam_engage, 0) - COALESCE(p.etl_tam_engage, 0), 2) as mce_diff_engage
                from pivoted as p
                """)
        final_df.registerTempTable('final')

        compare_df_persisted = (final_df
                                .withColumn('year', col('date_year_month').cast('string').substr(1, 4))
                                .withColumn('year_quarter', expr(
            "substr(date_year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(date_year_month, 5, 2) as int) / 3.0) as string)"))
                                .persist())
        audit_info = []
        audit_info += [{'table_name': f"{self.normalized_database}.mars_tam_crosswalk_dq_staging",
                        'rows_updated': compare_df_persisted.count()}]

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_tam_crosswalk_dq_staging' + "/")
        compare_df_persisted.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)

        if 'mars_tam_crosswalk_dq_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                                table_name='mars_tam_crosswalk_dq_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            hist_df = compare_df_persisted.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = compare_df_persisted.withColumn('version', lit(1))
            logger.info(f"Back up table does not exist for mars_tam_crosswalk_dq_historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_database}.mars_tam_crosswalk_dq_historical",
             'rows_updated': compare_df_persisted.count()})

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_tam_crosswalk_dq_historical' + "/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def tam_input_output_cost(self, athena_client):
        """
        Comparing MARS TAM Table with pivot table
        :param athena_client:
        :return:
        """
        logger.info("TAM input output cost dq report started")
        df_tam_hds = self.spark.sql(f"""
                            select position_number,
                                min(start_date) as start_date,
                                max(end_date) as end_date, 
                                field_title_code
                            from
                                {self.normalized_database}.{self.mstr_roster_hierarchy_dly_stg_tbl}
                            group by 1, 4
                        """)
        df_tam_hds.registerTempTable('tam_hds')

        df_tam_hd_calls = self.spark.sql(f"""
                            select distinct
                                ci.crm_call_id,
                                ci.crm_position_number,
                                ci.crm_position_name,
                                ci.mdm_id,
                                ci.crm_display_order,
                                cast(1 / ci.crm_display_order as double) as call_wt,
                                ci.crm_call_datetime,
                                date(ci.crm_call_datetime) as call_date,
                                ci.oasis_brand_name as product_brand_name,
                                ci.oasis_product_brand_id as product_brand_id,
                                'HCP' as mdm_type, 
                                'TAM' as channel, 
                                case 
                                    when th.field_title_code is null then 
                                        case
                                            when ci.crm_position_name like '%CSO%' then 'CSO' 
                                            when ci.crm_position_name like '%_TAM_%' then 'TAM' 
                                            when ci.crm_position_name like '%_HD_%' then 'HD' 
                                            when ci.crm_position_name like '%NRDS_%' then 'NRDS' 
                                            when ci.crm_position_name like '%_ACM_%' then 'ACM' 
                                            else null 
                                        end
                                    else th.field_title_code 
                                end as field_title_code
                            from
                                {self.normalized_database}.{self.tam_tbl_stg} as ci 
                            left join tam_hds as th
                                on ci.crm_position_number = th.position_number 
                                and ci.call_date between th.start_date and th.end_date
                            where
                                upper(crm_call_status) = 'SUBMITTED'
                                and cast(crm_flag_person_account as integer) = 1
                                and ci.oasis_brand_name in ({"'" + "','".join(json.loads(self.config.get(self.env, "mars_product_names_list"))) + "'"})
                                and th.field_title_code in ('ACM','CRDP_TAM','CS','CSO_CS','CSO_DM','CSO_RD','HD','INTERN_TAM','NRDHD','NRDS','SCS','SNRDS','TAM')
                        """)
        df_tam_hd_calls.registerTempTable('all_tam_hd_calls')

        df_daily_reach = self.spark.sql("""
                            select
                                product_brand_name,
                                call_date,
                                channel,
                                sum(call_wt) as reach
                            from all_tam_hd_calls
                            where upper(product_brand_name) != 'ACTEMRA'
                            group by 1, 2, 3
                        """)
        df_daily_reach.registerTempTable('daily_reach')

        df_quarterly_reach = self.spark.sql("""
                            select
                                product_brand_name,
                                cast(year(call_date) as string) as year,
                                cast(quarter(call_date) as string) as quarter,
                                sum(reach) as quarterly_reach
                            from daily_reach
                            group by 1, 2, 3
                        """)
        df_quarterly_reach.registerTempTable('quarterly_reach')

        df_tam_hd_costs = self.spark.sql(f"""
                            select
                                upper(brand_name) as product_brand_name,
                                channels,
                                audience,
                                cast(year as string) as year,
                                substring(cast(quarter as string), 2, 1) as quarter,
                                sum(spend_amount) as quarterly_cost
                            from {self.normalized_database}.{self.mars_finance_ce_spend_quarterly_stg}
                            group by 1, 2, 3, 4, 5
                        """)
        df_tam_hd_costs.registerTempTable('tam_hd_costs')

        df_unit_cost = self.spark.sql("""
                            with unit_cost as(
                                select
                                    c.product_brand_name,
                                    c.year,
                                    c.quarter,
                                    c.quarterly_cost / nullif(r.quarterly_reach, 0) as unit_cost_tam
                                from tam_hd_costs c
                                join quarterly_reach r 
                                    on c.product_brand_name = r.product_brand_name 
                                    and c.year = r.year 
                                    and c.quarter = r.quarter
                                where c.channels in('TAM', 'ACM')
                                and r.product_brand_name != 'ACTEMRA'
                            ), 
                            cost_allocation as (
                                select
                                    dr.product_brand_name,
                                    dr.call_date,
                                    dr.channel,
                                    dr.reach,
                                    uc.unit_cost_tam,
                                    dr.reach * uc.unit_cost_tam as allocated_cost
                                from daily_reach dr
                                join unit_cost uc
                                    on dr.product_brand_name = uc.product_brand_name
                                    and cast(year(dr.call_date) as string) = uc.year
                                    and cast(quarter(dr.call_date) as string) = uc.quarter
                            )
                            select * from cost_allocation
                        """)
        df_unit_cost.createOrReplaceTempView('cost_allocation')

        df_tam_hd_calls_actemra = self.spark.sql(f"""
                            select distinct
                                ci.crm_call_id,
                                ci.crm_position_number,
                                ci.crm_position_name,
                                ci.mdm_id,
                                ci.crm_display_order,
                                cast(1 / ci.crm_display_order as double) as call_wt,
                                ci.crm_call_datetime,
                                date(ci.crm_call_datetime) as call_date,
                                ci.oasis_brand_name as product_brand_name,
                                ci.oasis_product_brand_id as product_brand_id,
                                'HCP' as mdm_type, 
                                case when th.field_title_code like '%CSO%' then 'CSO' else 'TAM' end as channel, 
                                case 
                                    when th.field_title_code is null then 
                                        case
                                            when ci.crm_position_name like '%CSO%' then 'CSO' 
                                            when ci.crm_position_name like '%_TAM_%' then 'TAM' 
                                            when ci.crm_position_name like '%_HD_%' then 'HD' 
                                            when ci.crm_position_name like '%NRDS_%' then 'NRDS' 
                                            when ci.crm_position_name like '%_ACM_%' then 'ACM' 
                                            else null 
                                        end
                                    else th.field_title_code 
                                end as field_title_code
                            from
                                {self.normalized_database}.{self.tam_tbl_stg} as ci 
                            left join tam_hds th
                                on ci.crm_position_number = th.position_number 
                                and ci.call_date between th.start_date and th.end_date
                            where
                                upper(crm_call_status) = 'SUBMITTED'
                                and cast(crm_flag_person_account as integer) = 1
                                and ci.oasis_brand_name = 'ACTEMRA'
                                and th.field_title_code in ('ACM','CRDP_TAM','CS','CSO_CS','CSO_DM','CSO_RD','HD','INTERN_TAM','NRDHD','NRDS','SCS','SNRDS','TAM')
                    """)
        df_tam_hd_calls_actemra.createOrReplaceTempView('all_tam_hd_calls_actemra')

        df_actemra_cost_allocation = self.spark.sql(f"""
                        with daily_reach_actemra as(
                            select
                                product_brand_name,
                                call_date,
                                channel,
                                sum(call_wt) as reach
                            from all_tam_hd_calls_actemra
                            group by 1, 2, 3                               
                        ),

                        quarterly_reach_actemra as (
                            select
                                product_brand_name,
                                channel,
                                cast(year(call_date) as string) as year,
                                cast(quarter(call_date) as string) as quarter,
                                sum(reach) as quarterly_reach
                            from daily_reach_actemra
                            group by 1, 2, 3, 4
                        ),  

                        tam_only_quarters AS (
                            select 
                                c.product_brand_name,
                                c.year,
                                c.quarter,
                                c.quarterly_cost,
                                r.quarterly_reach
                            from tam_hd_costs c
                            join quarterly_reach_actemra r 
                            on c.product_brand_name = r.product_brand_name 
                            and c.year = r.year 
                            and c.quarter = r.quarter
                            where r.channel = 'TAM'
                            and not exists (
                                select 1
                                from quarterly_reach_actemra cso
                                where cso.product_brand_name = c.product_brand_name
                                and cso.year = c.year
                                and cso.quarter = c.quarter
                                and cso.channel = 'CSO'
                            )
                        ),

                        tam_unit_cost as (
                            select avg(quarterly_cost / nullif(quarterly_reach, 0)) as u_t
                            from tam_only_quarters
                        ),

                        cso_dominant_quarters as (
                            select 
                                c.product_brand_name,
                                c.year,
                                c.quarter,
                                c.quarterly_cost,
                                tam.quarterly_reach as tam_reach,
                                cso.quarterly_reach as cso_reach
                            from tam_hd_costs c
                            join quarterly_reach_actemra tam 
                            on c.product_brand_name = tam.product_brand_name 
                            and c.year = tam.year 
                            and c.quarter = tam.quarter
                            and tam.channel = 'TAM'
                            join quarterly_reach_actemra cso
                            on c.product_brand_name = cso.product_brand_name 
                            and c.year = cso.year 
                            and c.quarter = cso.quarter
                            and cso.channel = 'CSO'
                            where cso.quarterly_reach > tam.quarterly_reach
                        ),

                        cso_unit_cost AS (
                            select avg((c.quarterly_cost - (c.tam_reach * t.u_t)) / nullif(c.cso_reach, 0)) as u_c
                            from cso_dominant_quarters c
                            cross join tam_unit_cost t
                        ),

                        cost_allocation_actemra_with_unit_cost as (
                            select
                                qr.product_brand_name,
                                qr.year,
                                qr.quarter,
                                qr.channel,
                                qr.quarterly_reach,
                                c.quarterly_cost,
                                t.u_t AS tam_unit_cost,
                                cs.u_c AS cso_unit_cost,
                                case
                                    when qr.channel = 'TAM' and oc.channel is null then c.quarterly_cost
                                    when qr.channel = 'CSO' and oc.channel is null then c.quarterly_cost
                                    else
                                        case
                                            when qr.channel = 'TAM' then
                                                c.quarterly_cost * (qr.quarterly_reach * t.u_t) /
                                                (qr.quarterly_reach * t.u_t + coalesce(oc.quarterly_reach, 0) * cs.u_c)
                                            when qr.channel = 'CSO' then
                                                c.quarterly_cost * (qr.quarterly_reach * cs.u_c) /
                                                (coalesce(oc.quarterly_reach, 0) * t.u_t + qr.quarterly_reach * cs.u_c)
                                        end
                                    end as allocated_cost
                            from quarterly_reach_actemra qr
                            join tam_hd_costs c on qr.product_brand_name = c.product_brand_name and qr.year = c.year and qr.quarter = c.quarter
                            cross join tam_unit_cost t
                            cross join cso_unit_cost cs
                            left join quarterly_reach_actemra oc on
                                oc.product_brand_name = qr.product_brand_name and
                                oc.year = qr.year and
                                oc.quarter = qr.quarter and
                                oc.channel = case when qr.channel = 'TAM' then 'CSO' else 'TAM' end
                        ), 

                        daily_allocation as (
                            select
                                dr.product_brand_name,
                                dr.call_date,
                                dr.channel,
                                dr.reach,
                                ca.allocated_cost * (dr.reach / ca.quarterly_reach) as allocated_cost
                            from daily_reach_actemra dr
                            join cost_allocation_actemra_with_unit_cost ca 
                            on dr.product_brand_name = ca.product_brand_name
                            and cast(year(dr.call_date) as string) = ca.year
                            and cast(quarter(dr.call_date) as string) = ca.quarter
                            and dr.channel = ca.channel
                        )
                        select * from daily_allocation 
                    """)
        df_actemra_cost_allocation.createOrReplaceTempView('cost_allocation_actemra')

        df_combined_all = self.spark.sql("""
                        select 
                            product_brand_name,
                            cast(year(call_date) as string) || lpad(cast(quarter(call_date) as string), 2, 'Q') as year_quarter,
                            channel, 
                            sum(allocated_cost) as allocated_cost
                        from cost_allocation_actemra group by 1,2,3
                        union all 
                        select 
                            product_brand_name,
                            cast(year(call_date) as string) || lpad(cast(quarter(call_date) as string), 2, 'Q') as year_quarter,
                            channel, 
                            sum(allocated_cost) as allocated_cost
                        from cost_allocation  group by 1,2,3
                    """)
        df_combined_all.createOrReplaceTempView('df_combined_all')

        pivoted_df = self.spark.sql(f"""
                with pivot_tam as (
                    select
                    product_brand_name, 
                    substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string) as year_quarter, 
                    SUM(cost) as pivot_tam_cost
                    from {self.normalized_database}.{self.mars_tam_tbl}
                    where
                    upper(product_brand_name) in ( {self.mars_product_names})
                    and channel='tam_hd'                    
                    and audience='ce'
                    and year_month >= '{self.lower_bound_year_month}'
                    group by 1,2
                ),
                input_tam as (
                    select product_brand_name, 'tam_hd' as channel, year_quarter, allocated_cost as ip_tam_cost
                        from df_combined_all where channel = 'TAM'
                ),
                input_cso as (
                    select product_brand_name, 'cso' as channel, year_quarter, allocated_cost as ip_tam_cost
                        from df_combined_all where channel = 'CSO'
                ),
                pivot_cso as (
                    select
                    product_brand_name, 
                    substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string) as year_quarter, 
                    SUM(cost) as pivot_tam_cost
                    from {self.normalized_database}.{self.mars_tam_tbl}
                    where
                    upper(product_brand_name) in ( {self.mars_product_names})
                    and channel='cso'
                    and audience='ce'
                    and year_month >= '{self.lower_bound_year_month}'
                    group by 1,2
                ),
                join_cso as (
                    select p.product_brand_name, p.year_quarter, i.channel, i.ip_tam_cost, p.pivot_tam_cost
                    from pivot_cso as p inner join input_cso as i
                    on p.product_brand_name = i.product_brand_name and p.year_quarter = i.year_quarter
                ),
                join_tam as (
                    select p.product_brand_name, p.year_quarter, i.channel, i.ip_tam_cost, p.pivot_tam_cost
                    from pivot_tam as p inner join input_tam as i
                    on p.product_brand_name = i.product_brand_name and p.year_quarter = i.year_quarter
                )

                select product_brand_name, year_quarter, 
                channel, ip_tam_cost, pivot_tam_cost 
                from join_cso
                union all
                select product_brand_name, year_quarter, 
                channel, ip_tam_cost, pivot_tam_cost 
                from join_tam

                """)
        pivoted_df.registerTempTable('pivoted')

        quarter_names_changes_df = self.spark.sql("""
            select 
                product_brand_name,
                year_quarter,
                lower(channel) as channel,
                ip_tam_cost as input_cost, 
                pivot_tam_cost as output_cost,
                coalesce(ip_tam_cost - pivot_tam_cost, 0) as delta_diff 
            from pivoted                            
        """)

        compare_df_persisted = (quarter_names_changes_df
                                .withColumn('year', col('year_quarter').cast('string').substr(1, 4))
                                .persist())
        audit_info = []
        audit_info += [{'table_name': f"{self.normalized_database}.mars_tam_input_output_cost_dq_staging",
                        'rows_updated': compare_df_persisted.count()}]

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_tam_input_output_cost_dq_staging' + "/")
        compare_df_persisted.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)

        if 'mars_tam_input_output_cost_dq_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                                table_name='mars_tam_input_output_cost_dq_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            hist_df = compare_df_persisted.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = compare_df_persisted.withColumn('version', lit(1))
            logger.info(
                f"Back up table does not exist for mars_tam_input_output_cost_dq_historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_database}.mars_tam_input_output_cost_dq_historical",
             'rows_updated': compare_df_persisted.count()})

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_tam_input_output_cost_dq_historical' + "/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def tam_dtc_input_output_cost(self, athena_client):
        """
        Comparing MARS TAM DTC Table with pivot table
        :param athena_client:
        :return:
        """
        logger.info("TAM DTC input output cost dq report started")
        df_tam_input = self.spark.sql(f"""
            select
                upper(brand_name) as product_brand_name,
                    channels,
                    audience,
                    cast(year as varchar(4)) as year,
                    substring(cast(quarter as varchar(2)), 2, 1) as quarter,
                    sum(spend_amount) as cost
                from {self.normalized_database}.{self.mars_finance_ce_spend_quarterly_stg}
                where channels in('ACM', 'PCCM') and brand_name = 'HEMLIBRA'
                group by 1, 2, 3, 4, 5                               
        """)
        df_tam_input.registerTempTable('tam_input')

        df_tam_input.select('year', 'quarter').distinct().show()

        df_pivot_costs = self.spark.sql(f"""
           select 
                product_brand_name,
                cast(substr(year_month, 1, 4) as int) as year,
                cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as int) as quarter,
                cast(sum(cost) as bigint) as tam_cost
            from {self.normalized_database}.{self.mars_tam_tbl}
            where channel='tam'                    
                and audience='dtc'
                and year_month >= '202201'
                and product_brand_name = 'HEMLIBRA'
            group by 
                1, 2, 3                       
        """)
        df_pivot_costs.registerTempTable('pivot_costs')

        df_pivot_costs.select('year', 'quarter').distinct().show()

        final_df = self.spark.sql("""
            select 
                th.product_brand_name, 
                th.year,
                case when th.quarter = '1' then 'Q1' when th.quarter = '2' then 'Q2' when th.quarter = '3' then 'Q3' when th.quarter = '4' then 'Q4' end as quarter,
                th.cost as input_cost, 
                p.tam_cost as output_cost,
                coalesce(th.cost - p.tam_cost, 0) as delta_diff 
            from tam_input as th 
            inner join pivot_costs p 
            on th.product_brand_name = p.product_brand_name 
            and cast(th.year as string) = cast(p.year as string)
            and cast(th.quarter as string) = cast(p.quarter as string)                                
        """)
        final_df.registerTempTable('final_df')

        quarter_names_changes_df = self.spark.sql("""select product_brand_name, year || quarter as year_quarter, 
        input_cost, output_cost, delta_diff, year from final_df""")

        compare_df_persisted = quarter_names_changes_df.persist()
        audit_info = []
        audit_info += [{'table_name': f"{self.normalized_database}.mars_tam_dtc_input_output_cost_dq_staging",
                        'rows_updated': compare_df_persisted.count()}]

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_tam_dtc_input_output_cost_dq_staging' + "/")
        compare_df_persisted.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)

        if 'mars_tam_dtc_input_output_cost_dq_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                                table_name='mars_tam_dtc_input_output_cost_dq_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            hist_df = compare_df_persisted.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = compare_df_persisted.withColumn('version', lit(1))
            logger.info(
                f"Back up table does not exist for mars_tam_dtc_input_output_cost_dq_historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_database}.mars_tam_dtc_input_output_cost_dq_historical",
             'rows_updated': compare_df_persisted.count()})

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_tam_dtc_input_output_cost_dq_historical' + "/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def tam_input_output_activity(self, athena_client):
        logger.info("Tam Input Output Activity DQ started")
        tam_hds_df = self.spark.sql(f"""
                select position_number,
                    min(start_date) as start_date,
                    max(end_date) as end_date, 
                    field_title_code
                from
                    {self.normalized_database}.{self.mstr_roster_hierarchy_dly_stg_tbl}
                group by 1, 4
        """)
        tam_hds_df.registerTempTable('tam_hds')

        staging_df = self.spark.sql(f"""
            select distinct
                ci.crm_call_id,
                ci.crm_position_number,
                ci.crm_position_name,
                ci.mdm_id,
                ci.crm_display_order,
                cast(1 / ci.crm_display_order as double) as call_wt,
                ci.crm_call_datetime,
                date(ci.crm_call_datetime) as call_date,
                ci.oasis_brand_name as product_brand_name,
                ci.oasis_product_brand_id as product_brand_id,
                'HCP' as mdm_type,
                'TAM' as channel
            from
                {self.normalized_database}.{self.tam_tbl_stg} as ci 
            where
                upper(crm_call_status) = 'SUBMITTED'
                and cast(crm_flag_person_account as integer) = 1
                and ci.oasis_brand_name != 'ACTEMRA'                 
        """)
        staging_df.registerTempTable('staging')

        staging_with_actemra_df = self.spark.sql(f"""
                    select distinct
                        ci.crm_call_id,
                        ci.crm_position_number,
                        ci.crm_position_name,
                        ci.mdm_id,
                        ci.crm_display_order,
                        cast(1 / ci.crm_display_order as double) as call_wt,
                        ci.crm_call_datetime,
                        date(ci.crm_call_datetime) as call_date,
                        ci.oasis_brand_name as product_brand_name,
                        ci.oasis_product_brand_id as product_brand_id,
                        'HCP' as mdm_type,
                        case when th.field_title_code like '%CSO%' then 'CSO' else 'TAM' end as channel
                    from
                        {self.normalized_database}.{self.tam_tbl_stg} as ci 
                    left join
                    tam_hds as th
                    on
                        ci.crm_position_number = th.position_number
                        and ci.crm_call_datetime between th.start_date and th.end_date
                    where
                        upper(crm_call_status) = 'SUBMITTED'
                        and cast(crm_flag_person_account as integer) = 1
                        and ci.oasis_brand_name = 'ACTEMRA'                 
                """)
        staging_with_actemra_df.registerTempTable('staging_with_actemra')

        union_df = self.spark.sql("""
            with all_tam_hd as(
                    select crm_position_name, crm_position_number, product_brand_name, channel, call_date, call_wt from staging_with_actemra
                    union all
                    select crm_position_name, crm_position_number, product_brand_name, channel, call_date, call_wt from staging  
                ), 
                all_tam_hd_calls as (
                    select 
                        th.crm_position_number,
                        th.crm_position_name,
                        th.call_wt,
                        th.call_date,
                        th.product_brand_name,
                        th.channel,
                        case 
                            when f.field_title_code is null then 
                                case
                                    when th.crm_position_name like '%CSO%' then 'CSO' 
                                    when th.crm_position_name like '%_TAM_%' then 'TAM' 
                                    when th.crm_position_name like '%_HD_%' then 'HD' 
                                    when th.crm_position_name like '%NRDS_%' then 'NRDS' 
                                    when th.crm_position_name like '%_ACM_%' then 'ACM' 
                                    else null 
                                end
                            else f.field_title_code 
                        end as field_title_code
                    from all_tam_hd th
                    left join tam_hds f
                        on th.crm_position_number = f.position_number 
                        and th.call_date between f.start_date and f.end_date
                    where f.field_title_code in ('ACM','CRDP_TAM','CS','CSO_CS','CSO_DM','CSO_RD','HD','INTERN_TAM','NRDHD','NRDS','SCS','SNRDS','TAM')
            )
            select * from all_tam_hd_calls
        """)
        union_df.registerTempTable('union')

        agg_df = self.spark.sql("""
            with daily_reach as ( 
                select    
                    product_brand_name,
                    channel,
                    call_date,
                    sum(call_wt) as reach
                from union
                group by 1, 2, 3
            ), 

            final_agg as (
                select 
                    product_brand_name,
                    channel,
                    date_format(call_date, 'yyyyMM') as date_year_month,
                    sum(reach) as tam_reach
                from daily_reach
                group by 1, 2, 3
            )
            select * from final_agg 
        """)
        agg_df.registerTempTable('input_agg')

        df_vae_all = self.spark.sql(f"""
            with tam_hds as(
                select distinct
                    unix_id,
                    start_date,
                    end_date, 
                    field_title_code, 
                    position_number
                from
                    {self.normalized_database}.{self.mstr_roster_hierarchy_dly_stg_tbl}
                where
                    field_title_code in ('ACM','CRDP_TAM','CS','CSO_CS','CSO_DM','CSO_RD','HD','INTERN_TAM','NRDHD','NRDS','SCS','SNRDS','TAM')
            ),     
            tam_hds_for_crm as(
                    select position_number,
                        min(start_date) as start_date,
                        max(end_date) as end_date, 
                        field_title_code
                    from
                        {self.normalized_database}.{self.mstr_roster_hierarchy_dly_stg_tbl}
                        group by 1,4
            ), 
            dcx_ramp_raw as(
                select 
                    distinct 
                    group_id, 
                    sender_username, 
                    case when product_brand_name in('ACTEMRA IV', 'ACTEMRA SC') then 'ACTEMRA' else upper(product_brand_name) 
                            end as product_brand_name,
                    territory_id,
                    to_date(from_unixtime(unix_timestamp(input_date_time, 'yyyy-MM-dd HH:mm:ss'))) as input_date_time,
                    activity_type
                from {self.normalized_database}.{self.dcx_ramp_daily_staging}
                where upper(activity_type) in ('DELIVERED', 'OPEN')
            ), 
            dcx_ramp_emails as(
                select 
                    dr.product_brand_name, 
                    date_format(input_date_time, 'yyyyMM') as date_year_month,
                    'CE' as audience, 
                    'VAE' as channel, 
                    count(
                        distinct case when upper(activity_type) in('DELIVERED') then group_id end
                    ) as reach, 
                    count(
                        distinct case when upper(activity_type) in ('OPEN') then group_id end
                    ) as engage
                from dcx_ramp_raw as dr 
                inner join tam_hds as th 
                on
                    dr.sender_username = th.unix_id
                    and dr.input_date_time between th.start_date and th.end_date
                -- inner join hcp_org_mapping as hom
                --     on dr.mdm_id = hom.mdm_id
                --         and size(
                --             array_intersect(
                --                 array(dr.product_brand_name), hom.product_brand_name
                --             )
                --         ) > 0
                    group by 1, 2, 3, 4  
            ), 
            vae_raw as(
                select 
                    distinct 
                    mdm_id, 
                    product_brand_name, 
                    position_number,
                    position_name,
                    date_year_month, 
                    email_status,
                    activity_type,
                    sent_email_id,
                    crm_activity_client_name,
                    crm_activity_client_operating_system,
                    crm_activity_client_type,
                    crm_activity_device_type,
                    crm_activity_user_agent,
                    date(email_sent_date) as email_sent_date
                from {self.normalized_database}.{self.crm_commercial_approved_email} 
                where upper(activity_type) not in('DROPPED', 'BOUNCED')
            ), 
            vae_emails as(
                    select 
                        vr.product_brand_name,
                        vr.date_year_month,
                        'CE' as audience, 
                        'VAE' as channel,
                        count(
                            distinct 
                            case when upper(email_status) in('DELIVERED', 'MARKED_SPAM', 'UNSUBSCRIBED') then sent_email_id end
                        ) as reach, 
                        count(
                            distinct 
                            case when 
                                upper(activity_type) = 'OPENED' 
                                and (
                                    crm_activity_client_name != 'unknown'
                                    or crm_activity_client_operating_system != 'unknown'
                                    or crm_activity_client_type != 'unknown'
                                    or crm_activity_device_type != 'unknown'
                                    or crm_activity_user_agent != 'Mozilla/5.0'
                                )
                            then sent_email_id end
                        ) as engage
                    from vae_raw as vr 
                    left join tam_hds th
                        on vr.position_number = th.position_number 
                        and vr.email_sent_date between th.start_date and th.end_date            
                    -- inner join hcp_org_mapping as hom
                    --     on vr.mdm_id = hom.mdm_id
                    --         and size(
                    --             array_intersect(
                    --                 array(vr.product_brand_name), hom.product_brand_name
                    --             )
                    --         ) > 0
                    where th.field_title_code in ('ACM','CRDP_TAM','CS','CSO_CS','CSO_DM','CSO_RD','HD','INTERN_TAM','NRDHD','NRDS','SCS','SNRDS','TAM')
                    group by 1, 2, 3, 4
                )
                select 
                    product_brand_name,
                    date_year_month as year_month, 
                    lower(audience) as audience,
                    lower(channel) as channel,
                    sum(reach) as reach,
                    sum(engage) as engage 
                from dcx_ramp_emails
                group by 1, 2, 3, 4
                union all 
                select 
                    product_brand_name,
                    date_year_month as year_month, 
                    lower(audience) as audience,
                    lower(channel) as channel,
                    sum(reach) as reach,
                    sum(engage) as engage 
                from vae_emails
                group by 1, 2, 3, 4
            """)
        df_vae_all.registerTempTable('vae_unioned')

        pivoted_df = self.spark.sql(f"""
        with pivot_tam as (
            select
            product_brand_name, year_month, SUM(reach) as pivot_tam_reach
            from {self.normalized_database}.{self.mars_tam_tbl}
            where
            upper(product_brand_name) in ( {self.mars_product_names})
            and channel='tam_hd'                    
            and audience='ce'
            and year_month >= '{self.lower_bound_year_month}'
            group by product_brand_name, year_month
        ),

        agg_vae_ip as (
            select product_brand_name, year_month, channel , sum(reach) as ip_tam_reach, sum(engage) as ip_tam_engage
            from vae_unioned
            group by 1,2,3
        ),

        agg_vae_op as (
            select
            product_brand_name, year_month, channel, SUM(reach) as etl_tam_reach, sum(engage) as etl_tam_engage
            from {self.normalized_database}.{self.mars_tam_tbl}
            where
            upper(product_brand_name) in ( {self.mars_product_names}) and
            lower(channel)='vae'                    
            and lower(audience)='ce'
            and year_month >= '{self.lower_bound_year_month}'
            group by 1,2,3
        ),

        join_vae as (
            select o.product_brand_name, o.year_month, o.channel, i.ip_tam_reach, o.etl_tam_reach, o.etl_tam_engage, i.ip_tam_engage
            from agg_vae_op as o inner join agg_vae_ip as i 
            on o.product_brand_name = i.product_brand_name 
            and o.year_month = i.year_month 
            and lower(o.channel) = lower(i.channel) 
        ),

        input_tam as (
            select product_brand_name, 'tam_hd' as channel, date_year_month, tam_reach as ip_tam_reach
                from input_agg where channel = 'TAM'
        ),
        input_cso as (
            select product_brand_name, 'cso' as channel, date_year_month, tam_reach as ip_tam_reach
                from input_agg where channel = 'CSO'
        ),
        pivot_cso as (
            select
            product_brand_name, year_month, SUM(reach) as pivot_tam_reach
            from {self.normalized_database}.{self.mars_tam_tbl}
            where
            upper(product_brand_name) in ( {self.mars_product_names})
            and channel='cso'                    
            and audience='ce'
            and year_month >= '{self.lower_bound_year_month}'
            group by product_brand_name, year_month
        ),            
        join_cso as (
            select p.product_brand_name, p.year_month, i.channel, i.ip_tam_reach, p.pivot_tam_reach
            from pivot_cso as p inner join input_cso as i
            on p.product_brand_name = i.product_brand_name and p.year_month = i.date_year_month
        ),
        join_tam as (
            select p.product_brand_name, p.year_month, i.channel, i.ip_tam_reach, p.pivot_tam_reach
            from pivot_tam as p inner join input_tam as i
            on p.product_brand_name = i.product_brand_name and p.year_month = i.date_year_month
        )

        select product_brand_name, year_month, channel, ip_tam_reach, pivot_tam_reach, cast(null as double) as etl_tam_engage, cast(null as double) as ip_tam_engage from join_cso
        union all
        select product_brand_name, year_month, channel, ip_tam_reach, pivot_tam_reach, cast(null as double) as etl_tam_engage, cast(null as double) as ip_tam_engage  from join_tam
        union all
        select product_brand_name, year_month, channel, ip_tam_reach, etl_tam_reach as pivot_tam_reach, etl_tam_engage, ip_tam_engage from join_vae 

        """)
        pivoted_df.registerTempTable('pivoted')

        final_df = self.spark.sql(f"""
        select
        p.product_brand_name,
        cast(p.year_month as int) as date_year_month,
        lower(p.channel) as channel,
        ROUND(COALESCE(p.ip_tam_reach, 0), 2) as raw_tbl_reach,
        ROUND(COALESCE(p.pivot_tam_reach, 0), 2) as pivoted_tbl_reach,
        ROUND(COALESCE(p.ip_tam_reach, 0) - COALESCE(p.pivot_tam_reach, 0), 2) as delta_diff_reach,
        ROUND(COALESCE(p.ip_tam_engage, 0), 2) as raw_tbl_engage,
        ROUND(COALESCE(p.etl_tam_engage, 0), 2) as pivoted_tbl_engage,
        ROUND(COALESCE(p.ip_tam_engage, 0) - COALESCE(p.etl_tam_engage, 0), 2) as delta_diff_engage
        from pivoted as p
        """)
        final_df.registerTempTable('final')

        compare_df_persisted = (final_df
                                .withColumn('year', col('date_year_month').cast('string').substr(1, 4))
                                .withColumn('year_quarter', expr(
            "substr(date_year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(date_year_month, 5, 2) as int) / 3.0) as string)"))
                                .persist())
        audit_info = []
        audit_info += [{'table_name': f"{self.normalized_database}.mars_tam_input_output_reach_dq_staging",
                        'rows_updated': compare_df_persisted.count()}]

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_tam_input_output_reach_dq_staging' + "/")
        compare_df_persisted.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)

        if 'mars_tam_input_output_reach_dq_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                                table_name='mars_tam_input_output_reach_dq_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            hist_df = compare_df_persisted.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = compare_df_persisted.withColumn('version', lit(1))
            logger.info(
                f"Back up table does not exist for mars_tam_input_output_reach_dq_historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_database}.mars_tam_input_output_reach_dq_historical",
             'rows_updated': compare_df_persisted.count()})

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_tam_input_output_reach_dq_historical' + "/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def tam_input_output_pccm_activity(self, athena_client):
        logger.info("Tam Input Output PCCM Activity DQ started")

        hemlibra_dtc_union_df = self.spark.sql(f"""
        -- select 
        --     zip_code, product, interaction_date, interaction_type, topic_discussed, number_of_patients, number_of_interactions
        -- from {self.normalized_database}.{self.tam_pccm_hist_tbl}
        -- where (date_format(to_date(interaction_date, 'M/d/yyyy'), 'yyyyMM') between '202201' and '202312')
        -- and (version = (select cast(max(cast(version as int))-1 as string) as version from {self.normalized_database}.{self.tam_pccm_hist_tbl}))
        -- union all 
        select 
            zip_code, product, interaction_date, interaction_type, topic_discussed, number_of_patients, number_of_interactions
        from {self.normalized_database}.{self.tam_pccm_stg_tbl}
        -- where date_format(to_date(interaction_date, 'M/d/yyyy'), 'yyyyMM') >= '202401'       
        """)
        hemlibra_dtc_union_df.registerTempTable('hemlibra_dtc_union')

        tam_hds_df = self.spark.sql(f"""select 
        upper(product) as product_brand_name,
        date_format(to_date(interaction_date, 'M/d/yyyy'), 'yyyyMM') as year_month,
        sum(number_of_interactions) as total_reach
        from hemlibra_dtc_union
        where interaction_type != 'Attempted Contact'
        group by 1, 2 """)
        tam_hds_df.registerTempTable('tam_hds')

        output_df = self.spark.sql(f"""select 
        product_brand_name, 
        year_month, 
        sum(reach) as total_reach
        from {self.normalized_database}.{self.mars_tam_tbl}
        where year_month >= '{self.lower_bound_year_month}'
        and channel='tam'
        and audience='dtc'
        group by 1, 2 """)
        output_df.registerTempTable('output')

        final_df = self.spark.sql(f"""select 
        i.product_brand_name,  cast(i.year_month as int),  i.total_reach as input_reach, o.total_reach as output_reach, 
        round(coalesce(i.total_reach, 0) - coalesce(o.total_reach, 0), 2) as reach_diff
        from tam_hds i 
        inner join output o 
        on i.product_brand_name = o.product_brand_name 
        and i.year_month = o.year_month 
        order by 2""")

        compare_df_persisted = (final_df
                                .withColumn('year', col('year_month').cast('string').substr(1, 4))
                                .withColumn('year_quarter', expr(
            "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)"))
                                .persist())
        audit_info = []
        audit_info += [{'table_name': f"{self.normalized_database}.mars_tam_input_output_pccm_reach_dq_staging",
                        'rows_updated': compare_df_persisted.count()}]

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_tam_input_output_pccm_reach_dq_staging' + "/")
        compare_df_persisted.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)

        if 'mars_tam_input_output_pccm_reach_dq_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                                table_name='mars_tam_input_output_pccm_reach_dq_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            hist_df = compare_df_persisted.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = compare_df_persisted.withColumn('version', lit(1))
            logger.info(
                f"Back up table does not exist for mars_tam_input_output_pccm_reach_dq_historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_database}.mars_tam_input_output_pccm_reach_dq_historical",
             'rows_updated': compare_df_persisted.count()})

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_tam_input_output_pccm_reach_dq_historical' + "/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info


def audit_job_info(spark_obj, job_srt_time, job_name, batch_id, audit_path, audit_dict):
    """
    This function is used to write audit stats of this etl job to athena table.
    :param audit_path:
    :param spark_obj:
    :param job_srt_time:
    :param job_name:
    :param batch_id:
    :param audit_dict:
    """
    logger.info("Writing to audit table")
    if audit_dict is not None:
        logger.info(audit_dict)
        audit_df = (spark_obj.createDataFrame(audit_dict)
                    .withColumn("log_id_status", lit("COMPLETED"))
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", current_timestamp().cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("etl_layer", lit("normalized_dq"))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)
    else:
        audit_df = (spark_obj.createDataFrame([{'etl_layer': 'normalized_dq', 'log_id_status': 'INITIATED'}])
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", lit(None).cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("table_name", lit(None).cast(StringType()))
                    .withColumn("rows_updated", lit(None).cast(IntegerType()))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)


if __name__ == "__main__":
    # Getting AWS Glue job parameters, creating session and initiating job
    arg = getResolvedOptions(sys.argv, ['JOB_NAME', 'environment', 'batch_id'])

    logger.info("MARS TAM Data Quality reports job started")

    environment = arg['environment']
    config_obj = read_config_file('configuration.ini')
    check_config_section(config_obj, environment)
    job_start_time = datetime.datetime.now()

    sc = SparkContext()
    glueContext = GlueContext(sc)
    sprk = glueContext.spark_session
    job = Job(glueContext)
    job.init(arg['JOB_NAME'], arg)
    sprk.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'), audit_dict=None)

    tam_data_quality = TAMQualityReports(config_obj, arg, glueContext, sprk)

    audit_list = []

    athena_cl = boto3.client('athena', region_name="us-west-2")

    audit_list += tam_data_quality.tam_input_output_cost(athena_cl)

    audit_list += tam_data_quality.tam_dtc_input_output_cost(athena_cl)

    audit_list += tam_data_quality.tam_input_output_activity(athena_cl)

    audit_list += tam_data_quality.tam_input_output_pccm_activity(athena_cl)

    audit_list += tam_data_quality.tam_crosswalk(athena_cl)

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'), audit_dict=audit_list)

    crawler_client = boto3.client('glue', region_name="us-west-2")

    tam_data_quality.create_update_crawler(crawler_client)

    tam_data_quality.start_crawler(crawler_client)

    tam_data_quality.monitor_crawler(crawler_client)

    job.commit()
