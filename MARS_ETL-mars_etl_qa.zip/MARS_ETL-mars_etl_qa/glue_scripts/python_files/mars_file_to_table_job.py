import json
import logging
import configparser
import boto3
import sys
import time
from pyspark.sql.window import Window
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import *
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.types import *
import datetime

MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def read_config_file(config_file_name):
    """
    This function is reading config file and returning config object
    :type config_file_name: string
    """
    config = configparser.ConfigParser()
    config.read(config_file_name)
    return config


def check_config_section(config, env):
    """
    This function check if section specified in job parameters is present in config file or not
    :param config: Config file object
    :param env: environment which is specified in job parameters
    """
    if not config.has_section(env):
        raise Exception("Environment details doesn't exist in configuration file")


def audit_job_info(spark_obj, job_srt_time, job_name, batch_id, audit_path, audit_dict):
    """
    This function is used to write audit stats of this etl job to athena table.
    :param audit_path:
    :param spark_obj:
    :param job_srt_time:
    :param job_name:
    :param batch_id:
    :param audit_dict:
    """
    logger.info("Writing to audit table")
    if audit_dict is not None:
        logger.info(audit_dict)
        audit_df = (spark_obj.createDataFrame(audit_dict)
                    .withColumn("log_id_status", lit("COMPLETED"))
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", current_timestamp().cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("etl_layer", lit("Normalized"))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)
    else:
        audit_df = (spark_obj.createDataFrame([{'etl_layer': 'Normalized', 'log_id_status': 'INITIATED'}])
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", lit(None).cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("table_name", lit(None).cast(StringType()))
                    .withColumn("rows_updated", lit(None).cast(IntegerType()))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)


class FileToTable:
    def __init__(self, config, args, glue_context, spark):
        """
        This is init method used to initialize variables in class
        :param config: Config file object
        :param args: Arguments given to Glue job
        """
        self.env = args['environment']
        self.args = args
        self.bucket_name = config.get(self.env, "bucket_name")
        self.normalized_folder = json.loads(config.get(self.env, "folder_names"))['normalized']
        self.s3_path_list = []
        self.normalized_db = json.loads(config.get(self.env, "athena_database"))['normalized']
        self.config = config
        self.crawler_name = 'mars_file_to_table_crawler'
        self.glue_context = glue_context
        self.spark = spark
        self.folder_name = 'file_to_table'
        self.existing_historical_table_names = []

    def get_list_hist_tables(self, athena_client):
        logger.info("Calculating list of historical tables in normalized db")
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_db)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in normalized database
        self.existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                self.existing_historical_table_names.append(tbl_name)

    def dma_state_code(self):
        logger.info("Loading DMA STATE CODE into table")
        target_table_name = 'mars_dma_state_code_staging'
        dma_state_code_df = (self.spark.read.format("csv")
                             .option("header", "true")
                             .option("delimiter", "|")
                             .load(self.config.get(self.env, "dma_state_code_file_path"))
                             .withColumn('dma_code', col('dma_code'))
                             .withColumn("etl_load_date", current_timestamp().cast(TimestampType()))
                             .withColumn('dma_name', col('dma_state')))

        s3_path = "s3://" + self.bucket_name + "/" + self.normalized_folder + "/" + self.folder_name + "/" + target_table_name + "/"
        df = dma_state_code_df.persist()
        updated_row_cnt = df.count()
        logger.info("Row counts for table " + target_table_name + " : " + str(updated_row_cnt))
        audit_info = [{'table_name': f"{self.normalized_db}.{target_table_name}", 'rows_updated': updated_row_cnt}]
        df.coalesce(1).write.mode('overwrite').format('parquet').save(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def zip_dma_crossover(self):
        logger.info("Loading ZIP DMA CROSSOVER into table")
        table_name = 'mars_zip_dma_crossover'
        stg_table_name = table_name + '_staging'
        hist_table_name = table_name + '_historical'
        zip_dma_crossover_df = (self.spark.read.format("csv")
                                .option("header", "true")
                                .load(self.config.get(self.env, "zip_dma_crossover_file_path"))
                                .withColumn('County_Name', regexp_replace(col('County_Name'), '\t', ''))
                                .withColumn("etl_load_date", current_timestamp().cast(TimestampType()))
                                .withColumn('TV_HH', col('TV_HH').cast(DoubleType())))

        s3_path = "s3://" + self.bucket_name + "/" + self.normalized_folder + "/" + self.folder_name + "/" + stg_table_name + "/"
        df = zip_dma_crossover_df.persist()
        updated_row_cnt = df.count()
        logger.info("Row counts for table " + stg_table_name + " : " + str(updated_row_cnt))
        audit_info = [{'table_name': f"{self.normalized_db}.{stg_table_name}", 'rows_updated': updated_row_cnt}]
        df.coalesce(1).write.mode('overwrite').format('parquet').save(s3_path)
        self.s3_path_list += [s3_path]

        if hist_table_name in self.existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_db,
                                                                                table_name=hist_table_name)
            last_version = historical_up_df.select([max("version")]).head()[0]
            hist_df = df.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = df.withColumn('version', lit(1))
            logger.info(
                f"Back up table does not exist for mars zip dma cross over historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_db}.{hist_table_name}",
             'rows_updated': updated_row_cnt})

        s3_path = (
                    "s3://" + self.bucket_name + "/" + self.normalized_folder + "/" + self.folder_name + "/" + hist_table_name + "/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def tam_pccm_interactions(self):
        logger.info("Loading TAM PCCM Interactions into table")
        table_name = 'mars_tam_pccm_interactions'
        stg_table_name = table_name + '_staging'
        hist_table_name = table_name + '_historical'
        tam_pccm_interactions_df = (self.spark.read.format("csv")
                                    .option("header", "true")
                                    .load(self.config.get(self.env, "tam_pccm_interactions_file_path"))
                                    .selectExpr('`Zip Code (Zip5)` as zip_code', '`Product` as product',
                                                '`Interaction Date` as interaction_date',
                                                '`Interaction Type` as interaction_type',
                                                '`Topic Discussed` as topic_discussed',
                                                '`# of Patients` as number_of_patients',
                                                '`# of Interactions` as number_of_interactions')
                                    .withColumn('number_of_patients', col('number_of_patients').cast(DoubleType()))
                                    .withColumn('number_of_interactions',
                                                col('number_of_interactions').cast(DoubleType()))
                                    .withColumn("etl_load_date", current_timestamp().cast(TimestampType())))

        s3_path = "s3://" + self.bucket_name + "/" + self.normalized_folder + "/" + self.folder_name + "/" + stg_table_name + "/"
        df = tam_pccm_interactions_df.persist()
        updated_row_cnt = df.count()
        logger.info("Row counts for table " + stg_table_name + " : " + str(updated_row_cnt))
        audit_info = [{'table_name': f"{self.normalized_db}.{stg_table_name}", 'rows_updated': updated_row_cnt}]
        df.coalesce(1).write.mode('overwrite').format('parquet').save(s3_path)
        self.s3_path_list += [s3_path]

        if hist_table_name in self.existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_db,
                                                                                table_name=hist_table_name)
            last_version = historical_up_df.select([max("version")]).head()[0]
            hist_df = df.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = df.withColumn('version', lit(1))
            logger.info(
                f"Back up table does not exist for mars zip dma cross over historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_db}.{hist_table_name}",
             'rows_updated': updated_row_cnt})

        s3_path = (
                    "s3://" + self.bucket_name + "/" + self.normalized_folder + "/" + self.folder_name + "/" + hist_table_name + "/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def zip_zcta_crosswalk(self):
        logger.info("Loading ZIP ZCTA Crosswalk into table")
        table_name = 'mars_zip_zcta_crosswalk'
        stg_table_name = table_name + '_staging'
        hist_table_name = table_name + '_historical'
        zip_zcta_crosswalk_df = (self.spark.read.format("csv")
                                 .option("header", "true")
                                 .load(self.config.get(self.env, "zip_zcta_crosswalk_file_path"))
                                 .selectExpr('ZIP_CODE as zip', 'zcta as zcta', 'STATE as state')
                                 .withColumn("etl_load_date", current_timestamp().cast(TimestampType())))

        s3_path = "s3://" + self.bucket_name + "/" + self.normalized_folder + "/" + self.folder_name + "/" + stg_table_name + "/"
        df = zip_zcta_crosswalk_df.persist()
        updated_row_cnt = df.count()
        logger.info("Row counts for table " + stg_table_name + " : " + str(updated_row_cnt))
        audit_info = [{'table_name': f"{self.normalized_db}.{stg_table_name}", 'rows_updated': updated_row_cnt}]
        df.coalesce(1).write.mode('overwrite').format('parquet').save(s3_path)
        self.s3_path_list += [s3_path]

        if hist_table_name in self.existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_db,
                                                                                table_name=hist_table_name)
            last_version = historical_up_df.select([max("version")]).head()[0]
            hist_df = df.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = df.withColumn('version', lit(1))
            logger.info(
                f"Back up table does not exist for mars zip zcta crosswalk historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_db}.{hist_table_name}",
             'rows_updated': updated_row_cnt})

        s3_path = (
                    "s3://" + self.bucket_name + "/" + self.normalized_folder + "/" + self.folder_name + "/" + hist_table_name + "/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def population_demographics_us_islands(self):
        logger.info("Loading Population Demographics US Islands into table")
        table_name = 'mars_population_demographics_us_islands_raw'
        stg_table_name = table_name + '_staging'
        hist_table_name = table_name + '_historical'

        file_list = json.loads(self.config.get(self.env, "population_demographics_us_islands_file_path"))

        pd_us_islands_df = (self.spark.read.format("csv").option("header", "true")
                            .load(file_list[0])
                            .withColumn("index", monotonically_increasing_id())
                            .selectExpr("NAME", 'cast(DP1_0006C as integer) as DP1_0006C',
                                        'cast(DP1_0007C as integer) as DP1_0007C',
                                        'cast(DP1_0009C as integer) as DP1_0009C',
                                        'cast(DP1_0010C as integer) as DP1_0010C',
                                        'cast(DP1_0011C as integer) as DP1_0011C',
                                        'cast(DP1_0012C as integer) as DP1_0012C',
                                        'cast(DP1_0013C as integer) as DP1_0013C',
                                        'cast(DP1_0014C as integer) as DP1_0014C',
                                        'cast(DP1_0015C as integer) as DP1_0015C',
                                        'cast(DP1_0016C as integer) as DP1_0016C',
                                        'cast(DP1_0017C as integer) as DP1_0017C',
                                        'cast(DP1_0018C as integer) as DP1_0018C',
                                        'cast(DP1_0019C as integer) as DP1_0019C',
                                        'cast(DP1_0054C as integer) as DP1_0054C',
                                        'cast(DP1_0055C as integer) as DP1_0055C',
                                        'cast(DP1_0056C as integer) as DP1_0056C',
                                        'cast(DP1_0057C as integer) as DP1_0057C',
                                        'cast(DP1_0058C as integer) as DP1_0058C',
                                        'cast(DP1_0059C as integer) as DP1_0059C',
                                        'cast(DP1_0008C as integer) as DP1_0008C',
                                        'cast(DP1_0001C as integer) as DP1_0001C', "index")
                            )

        for file in file_list[1:]:
            pd_us_islands_df = pd_us_islands_df.union(self.spark.read.format("csv").option("header", "true")
                                                      .load(file)
                                                      .withColumn("index", monotonically_increasing_id())
                                                      .selectExpr("NAME", 'cast(DP1_0006C as integer) as DP1_0006C',
                                                                  'cast(DP1_0007C as integer) as DP1_0007C',
                                                                  'cast(DP1_0009C as integer) as DP1_0009C',
                                                                  'cast(DP1_0010C as integer) as DP1_0010C',
                                                                  'cast(DP1_0011C as integer) as DP1_0011C',
                                                                  'cast(DP1_0012C as integer) as DP1_0012C',
                                                                  'cast(DP1_0013C as integer) as DP1_0013C',
                                                                  'cast(DP1_0014C as integer) as DP1_0014C',
                                                                  'cast(DP1_0015C as integer) as DP1_0015C',
                                                                  'cast(DP1_0016C as integer) as DP1_0016C',
                                                                  'cast(DP1_0017C as integer) as DP1_0017C',
                                                                  'cast(DP1_0018C as integer) as DP1_0018C',
                                                                  'cast(DP1_0019C as integer) as DP1_0019C',
                                                                  'cast(DP1_0054C as integer) as DP1_0054C',
                                                                  'cast(DP1_0055C as integer) as DP1_0055C',
                                                                  'cast(DP1_0056C as integer) as DP1_0056C',
                                                                  'cast(DP1_0057C as integer) as DP1_0057C',
                                                                  'cast(DP1_0058C as integer) as DP1_0058C',
                                                                  'cast(DP1_0059C as integer) as DP1_0059C',
                                                                  'cast(DP1_0008C as integer) as DP1_0008C',
                                                                  'cast(DP1_0001C as integer) as DP1_0001C', "index"))

        population_demographics_us_islands_df = (pd_us_islands_df.where(col('index') != 0).drop("index")
                                                 .withColumn("etl_load_date",
                                                             current_timestamp().cast(TimestampType())))

        s3_path = "s3://" + self.bucket_name + "/" + self.normalized_folder + "/" + self.folder_name + "/" + stg_table_name + "/"
        df = population_demographics_us_islands_df.persist()
        updated_row_cnt = df.count()
        logger.info("Row counts for table " + stg_table_name + " : " + str(updated_row_cnt))
        audit_info = [{'table_name': f"{self.normalized_db}.{stg_table_name}", 'rows_updated': updated_row_cnt}]
        df.coalesce(1).write.mode('overwrite').format('parquet').save(s3_path)
        self.s3_path_list += [s3_path]

        if hist_table_name in self.existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_db,
                                                                                table_name=hist_table_name)
            last_version = historical_up_df.select([max("version")]).head()[0]
            hist_df = df.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = df.withColumn('version', lit(1))
            logger.info(
                f"Back up table does not exist for mars population demographics us islands historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_db}.{hist_table_name}",
             'rows_updated': updated_row_cnt})

        s3_path = (
                    "s3://" + self.bucket_name + "/" + self.normalized_folder + "/" + self.folder_name + "/" + hist_table_name + "/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def population_demographics_us(self):
        logger.info("Loading Population Demographics US into table")
        table_name = 'mars_population_demographics_us'
        stg_table_name = table_name + '_staging'
        hist_table_name = table_name + '_historical'

        population_demographics_us_df = (self.spark.read.format("csv")
                                         .option("header", "true")
                                         .load(self.config.get(self.env, "population_demographics_us_file_path"))
                                         .withColumn("index", monotonically_increasing_id())
                                         .where(col('index') != 0)
                                         .selectExpr("GEO_ID", "NAME", 
                                                     'cast(S0101_C01_001E as integer) as S0101_C01_001E',
                                                     'cast(S0101_C01_023E as integer) as S0101_C01_023E',
                                                     'cast(S0101_C01_007E as integer) as S0101_C01_007E',
                                                     'cast(S0101_C01_008E as integer) as S0101_C01_008E',
                                                     'cast(S0101_C01_009E as integer) as S0101_C01_009E',
                                                     'cast(S0101_C01_010E as integer) as S0101_C01_010E',
                                                     'cast(S0101_C01_011E as integer) as S0101_C01_011E',
                                                     'cast(S0101_C03_023E as integer) as S0101_C03_023E',
                                                     'cast(S0101_C03_007E as integer) as S0101_C03_007E',
                                                     'cast(S0101_C03_008E as integer) as S0101_C03_008E',
                                                     'cast(S0101_C03_009E as integer) as S0101_C03_009E',
                                                     'cast(S0101_C03_010E as integer) as S0101_C03_010E',
                                                     'cast(S0101_C03_011E as integer) as S0101_C03_011E',
                                                     'cast(S0101_C05_023E as integer) as S0101_C05_023E',
                                                     'cast(S0101_C05_007E as integer) as S0101_C05_007E',
                                                     'cast(S0101_C05_008E as integer) as S0101_C05_008E',
                                                     'cast(S0101_C05_009E as integer) as S0101_C05_009E',
                                                     'cast(S0101_C05_010E as integer) as S0101_C05_010E',
                                                     'cast(S0101_C05_011E as integer) as S0101_C05_011E',
                                                     'cast(S0101_C01_012E as integer) as S0101_C01_012E',
                                                     'cast(S0101_C01_013E as integer) as S0101_C01_013E',
                                                     'cast(S0101_C01_014E as integer) as S0101_C01_014E',
                                                     'cast(S0101_C01_015E as integer) as S0101_C01_015E',
                                                     'cast(S0101_C01_016E as integer) as S0101_C01_016E',
                                                     'cast(S0101_C01_017E as integer) as S0101_C01_017E',
                                                     'cast(S0101_C01_018E as integer) as S0101_C01_018E',
                                                     'cast(S0101_C01_019E as integer) as S0101_C01_019E'
                                                     )
                                         .withColumn("etl_load_date",
                                                     current_timestamp().cast(TimestampType()))
                                         .withColumn('zcta', col('NAME').substr(6, 5))
                                         .where(col('GEO_ID') != 'Geography')
                                         .filter(col('zcta').cast(IntegerType()).isNotNull())
                                         .drop('name')
                                         )

        s3_path = "s3://" + self.bucket_name + "/" + self.normalized_folder + "/" + self.folder_name + "/" + stg_table_name + "/"
        df = population_demographics_us_df.persist()
        updated_row_cnt = df.count()
        logger.info("Row counts for table " + stg_table_name + " : " + str(updated_row_cnt))
        audit_info = [{'table_name': f"{self.normalized_db}.{stg_table_name}", 'rows_updated': updated_row_cnt}]
        df.coalesce(1).write.mode('overwrite').format('parquet').save(s3_path)
        self.s3_path_list += [s3_path]

        if hist_table_name in self.existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_db,
                                                                                table_name=hist_table_name)
            last_version = historical_up_df.select([max("version")]).head()[0]
            hist_df = df.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = df.withColumn('version', lit(1))
            logger.info(
                f"Back up table does not exist for mars population demographics us historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_db}.{hist_table_name}",
             'rows_updated': updated_row_cnt})

        s3_path = (
                    "s3://" + self.bucket_name + "/" + self.normalized_folder + "/" + self.folder_name + "/" + hist_table_name + "/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def create_update_crawler(self, client):
        """
        Crawler has to be created if it doesn't exist, if it exists then we have to update it s3 path for it.
        :param client: glue boto3 client used to create or update crawler
        """
        # Creating list of s3 path that has to be crawled
        s3_crawl_list = []
        for s3_path in list(set(self.s3_path_list)):
            s3_crawl_list.append(
                {"Path": s3_path, 'Exclusions': json.loads(self.config.get(self.env, "crawl_exclusion_paths"))})

        crawler_exist = True

        # Checking if crawler is already existing or not
        try:
            res = client.get_crawler(Name=self.crawler_name)
            response = json.dumps(res, indent=4, sort_keys=True, default=str)
            print(response)
        except client.exceptions.EntityNotFoundException as e:
            logger.info("Crawler doesnt exist, need to create")
            crawler_exist = False

        # Creating crawler if it doesn't exist
        if crawler_exist:
            response = client.update_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.normalized_db,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Updated\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

        else:
            response = client.create_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.normalized_db,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Created\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

    def start_crawler(self, client):
        """
        This method is used to start the crawler
        :param client: glue boto3 client used to create or update crawler
        """
        response_start = client.start_crawler(Name=self.crawler_name)
        logger.info("Crawler Started\nName : " + self.crawler_name)
        logger.info(json.dumps(response_start, indent=4, sort_keys=True, default=str))

    def monitor_crawler(self, client):
        """
        This method is used to monitor the crawler which we started just now
        :param client: glue boto3 client used to create or update crawler
        """
        need_to_wait = True
        state_previous = None
        while need_to_wait:
            time.sleep(20)
            response_get = client.get_crawler(Name=self.crawler_name)
            state = response_get["Crawler"]["State"]
            if state == "READY" or state == "STOPPING":  # Other known states: RUNNING
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                need_to_wait = False
                break
            if state != state_previous:
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                state_previous = state


if __name__ == "__main__":
    # Getting AWS Glue job parameters, creating session and initiating job
    arg = getResolvedOptions(sys.argv, ['JOB_NAME', 'environment', 'batch_id'])

    logger.info("MARS landing layer data quality job started")

    environment = arg['environment']
    config_obj = read_config_file('configuration.ini')
    check_config_section(config_obj, environment)
    job_start_time = datetime.datetime.now()

    sc = SparkContext()
    glueContext = GlueContext(sc)
    sprk = glueContext.spark_session
    job = Job(glueContext)
    job.init(arg['JOB_NAME'], arg)
    sprk.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'), audit_dict=None)

    file_to_table = FileToTable(config_obj, arg, glueContext, sprk)

    athena_cl = boto3.client('athena', region_name="us-west-2")
    file_to_table.get_list_hist_tables(athena_cl)

    audit_list = []

    audit_list += file_to_table.population_demographics_us_islands()
    audit_list += file_to_table.population_demographics_us()
    audit_list += file_to_table.zip_dma_crossover()
    audit_list += file_to_table.dma_state_code()
    audit_list += file_to_table.zip_zcta_crosswalk()
    # audit_list += file_to_table.tam_pccm_interactions()

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'), audit_dict=audit_list)

    crawler_client = boto3.client('glue', region_name="us-west-2")

    file_to_table.create_update_crawler(crawler_client)

    file_to_table.start_crawler(crawler_client)

    file_to_table.monitor_crawler(crawler_client)

    job.commit()
