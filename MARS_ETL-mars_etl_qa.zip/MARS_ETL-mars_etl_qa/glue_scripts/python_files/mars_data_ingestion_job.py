import json
import logging
import configparser
import boto3
import sys
import time
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import *
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.types import *
import datetime

MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def read_config_file(config_file_name):
    """
    This function is reading config file and returning config object
    :type config_file_name: string
    """
    config = configparser.ConfigParser()
    config.read(config_file_name)
    return config


def check_config_section(config, env):
    """
    This function check if section specified in job parameters is present in config file or not
    :param config: Config file object
    :param env: environment which is specified in job parameters
    """
    if not config.has_section(env):
        raise Exception("Environment details doesn't exist in configuration file")


class DataIngestion:
    def __init__(self, config, args, glue_context, spark):
        """
        This is init method used to initialize variables in class
        :param config: Config file object
        :param args: Arguments given to Glue job
        """
        self.env = args['environment']
        self.args = args
        self.bucket_name = config.get(self.env, "bucket_name")
        self.landing_folder = json.loads(config.get(self.env, "folder_names"))['landing']
        self.ingestion_table_list = []
        self.onboard_ingestion_table_list = []
        self.s3_path_list = []
        self.landing_database = json.loads(config.get(self.env, "athena_database"))['landing']
        self.config = config
        self.crawler_name = 'mars_ingestion_crawler'
        self.glue_context = glue_context
        self.spark = spark

    def prep_table_load_list(self):
        """
        This function is to prepare list of tables that has to be loaded to landing layer
        """
        # Check do we have to demographic zip ref tables
        if self.args['load_demographic_zip_ref_tables'] == 'True':
            one_time_ingestion_table_list = json.loads(
                self.config.get(self.env, "demographic_zip_ref_ingestion_table_list"))
            self.ingestion_table_list += (s + '.demographic_zip_ref' for s in one_time_ingestion_table_list)
        else:
            logger.info("Not loading demographic zip ref tables as flag in job parameters is not 'True'")

        # Check do we have to load sales tables
        if self.args['load_sales_tables'] == 'True':
            sales_ingestion_table_list = json.loads(self.config.get(self.env, "sales_ingestion_table_list"))
            self.ingestion_table_list += (s + '.sales' for s in sales_ingestion_table_list)
        else:
            logger.info("Not loading sales tables as flag in job parameters is not 'True'")

        # Check do we have to load xo tables
        if self.args['load_xo_tables'] == 'True':
            xo_ingestion_table_list = json.loads(self.config.get(self.env, "xo_ingestion_table_list"))
            self.ingestion_table_list += (s + '.xo' for s in xo_ingestion_table_list)
        else:
            logger.info("Not loading xo tables as flag in job parameters is not 'True'")

        # Check do we have to load speaker tables
        if self.args['load_speaker_tables'] == 'True':
            speaker_ingestion_table_list = json.loads(self.config.get(self.env, "speaker_ingestion_table_list"))
            self.ingestion_table_list += (s + '.speaker' for s in speaker_ingestion_table_list)
        else:
            logger.info("Not loading speaker tables as flag in job parameters is not 'True'")

        # Check do we have to load tam tables
        if self.args['load_tam_tables'] == 'True':
            tam_ingestion_table_list = json.loads(self.config.get(self.env, "tam_ingestion_table_list"))
            self.ingestion_table_list += (s + '.tam' for s in tam_ingestion_table_list)
        else:
            logger.info("Not loading tam tables as flag in job parameters is not 'True'")

        # Check do we have to load hcp mdm ref tables
        if self.args['load_hcp_mdm_ref_tables'] == 'True':
            common_ingestion_table_list = json.loads(self.config.get(self.env, "hcp_mdm_ref_ingestion_table_list"))
            self.ingestion_table_list += (s + '.hcp_mdm_ref' for s in common_ingestion_table_list)
        else:
            logger.info("Not loading hcp mdm ref tables as flag in job parameters is not 'True'")

    def write_to_s3(self, athena_client):
        """
        This method is to write data to s3 for all tables in landing layer and in back up folders
        :param athena_client: This client is used to crawl athena tables for back up folders.
        :return: audit_info : List of stats for audit purpose
        """
        audit_info = []
        logger.info("Landing Database : " + self.landing_database)
        landing_folder = self.landing_folder

        # Checking historical tables in staging database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.landing_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in staging database
        existing_backup_table_names = []
        for tbl_name in all_table_names:
            if 'backup' in tbl_name:
                existing_backup_table_names.append(tbl_name)

        for ingestion_table in self.ingestion_table_list:
            src_database = ingestion_table.split('.')[0]
            src_table = ingestion_table.split('.')[1]
            domain = ingestion_table.split('.')[2]
            table = src_table.replace("prodsrc7_", "").replace("prod_stg_",
                                                               "")  # This slicing of table name is to remove prod_src_ from table in config file

            landing_tbl_name = table
            backup_tbl_name = table + '_backup'

            logger.info("Table : " + landing_tbl_name + "/" + backup_tbl_name)
            logger.info("Domain : " + domain)

            # Reading dataframes from Glue Catalog
            df = self.glue_context.create_data_frame.from_catalog(database=src_database, table_name=src_table)
            for cols in df.columns:
                df = df.withColumnRenamed(cols, cols.lower())

            # Adding load date
            etl_df = df.withColumn('etl_load_date', current_timestamp())
            etl_persisted_df = etl_df.persist()
            updated_row_cnt = etl_persisted_df.count()

            if backup_tbl_name in existing_backup_table_names:
                backup_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                             table_name=backup_tbl_name)
                last_version = backup_df.select([max("version")]).head()[0]
                full_data_backup_df = etl_persisted_df.withColumn('version', lit(int(last_version) + 1))
            else:  # This means table is new to landing, it is getting loaded into backup for first time
                full_data_backup_df = etl_persisted_df.withColumn('version', lit(1))
                logger.info(f"Back up table does not exist for {backup_tbl_name} in landing layer")

            # Calculating Audit info
            audit_info.append(
                {'table_name': f"{self.landing_database}.{landing_tbl_name}", 'rows_updated': updated_row_cnt})
            audit_info.append(
                {'table_name': f"{self.landing_database}.{backup_tbl_name}", 'rows_updated': updated_row_cnt})
            logger.info("Row counts for table " + landing_tbl_name + " : " + str(updated_row_cnt))

            # Writing to staging layer and backup folders
            etl_persisted_df.coalesce(8).write.mode('overwrite').parquet(
                "s3://" + self.bucket_name + "/" + landing_folder + "/" + domain + "/" + landing_tbl_name + "/")
            full_data_backup_df.coalesce(8).write.partitionBy("version").mode('append').parquet(
                "s3://" + self.bucket_name + "/" + landing_folder + "/" + domain + "/" + backup_tbl_name + "/")
            logger.info("Data has written to s3 for " + table + " as well as backup")

            # Adding to crawl table list
            self.s3_path_list += [
                "s3://" + self.bucket_name + "/" + landing_folder + "/" + domain + "/" + landing_tbl_name + "/"]
            self.s3_path_list += [
                "s3://" + self.bucket_name + "/" + landing_folder + "/" + domain + "/" + backup_tbl_name + "/"]

        logger.info("Writing to S3 is completed")
        return audit_info

    def create_update_crawler(self, client):
        """
        Crawler has to be created if it doesn't exist, if it exists then we have to update it s3 path for it.
        :param client: glue boto3 client used to create or update crawler
        """
        # Creating list of s3 path that has to be crawled
        s3_crawl_list = []
        for s3_path in list(set(self.s3_path_list)):
            s3_crawl_list.append(
                {"Path": s3_path, 'Exclusions': json.loads(self.config.get(self.env, "crawl_exclusion_paths"))})

        crawler_exist = True

        # Checking if crawler is already existing or not
        try:
            res = client.get_crawler(Name=self.crawler_name)
            response = json.dumps(res, indent=4, sort_keys=True, default=str)
            print(response)
        except client.exceptions.EntityNotFoundException as e:
            logger.info("Crawler doesnt exist, need to create")
            crawler_exist = False

        # Creating crawler if it doesn't exist
        if crawler_exist:
            response = client.update_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.landing_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Updated\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

        else:
            response = client.create_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.landing_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Created\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

    def start_crawler(self, client):
        """
        This method is used to start the crawler
        :param client: glue boto3 client used to create or update crawler
        """
        response_start = client.start_crawler(Name=self.crawler_name)
        logger.info("Crawler Started\nName : " + self.crawler_name)
        logger.info(json.dumps(response_start, indent=4, sort_keys=True, default=str))

    def monitor_crawler(self, client):
        """
        This method is used to monitor the crawler which we started just now
        :param client: glue boto3 client used to create or update crawler
        """
        need_to_wait = True
        state_previous = None
        while need_to_wait:
            time.sleep(20)
            response_get = client.get_crawler(Name=self.crawler_name)
            state = response_get["Crawler"]["State"]
            if state == "READY" or state == "STOPPING":  # Other known states: RUNNING
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                need_to_wait = False
                break
            if state != state_previous:
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                state_previous = state

    def onboard_prep_table_list(self):
        """
        This method is used ot create list of tables which we have to use for onboarding one single brand
        """
        if self.args['load_demographic_zip_ref_tables'] == 'True':
            one_time_ingestion_table_list = json.loads(
                self.config.get(self.env, "demographic_zip_ref_ingestion_onboarding_table_list"))
            self.onboard_ingestion_table_list += (
                {'column_name': s['column_name'], 'table_name': s['src_table_name'] + '.demographic_zip_ref'}
                for s in one_time_ingestion_table_list)
        else:
            logger.info("Not loading one time tables as flag in job parameters is not 'True'")

            # Check do we have to load sales tables
        if self.args['load_sales_tables'] == 'True':
            sales_ingestion_table_list = json.loads(self.config.get(self.env, "sales_ingestion_onboarding_table_list"))
            self.onboard_ingestion_table_list += (
                {'column_name': s['column_name'], 'table_name': s['src_table_name'] + '.sales'} for
                s in sales_ingestion_table_list)
        else:
            logger.info("Not loading sales tables as flag in job parameters is not 'True'")

            # Check do we have to load xo tables
        if self.args['load_xo_tables'] == 'True':
            xo_ingestion_table_list = json.loads(self.config.get(self.env, "xo_ingestion_onboarding_table_list"))
            self.onboard_ingestion_table_list += (
                {'column_name': s['column_name'], 'table_name': s['src_table_name'] + '.xo'} for s
                in xo_ingestion_table_list)
        else:
            logger.info("Not loading xo tables as flag in job parameters is not 'True'")

            # Check do we have to load speaker tables
        if self.args['load_speaker_tables'] == 'True':
            speaker_ingestion_table_list = json.loads(
                self.config.get(self.env, "speaker_ingestion_onboarding_table_list"))
            self.onboard_ingestion_table_list += (
                {'column_name': s['column_name'], 'table_name': s['src_table_name'] + '.speaker'}
                for s in speaker_ingestion_table_list)
        else:
            logger.info("Not loading speaker tables as flag in job parameters is not 'True'")

            # Check do we have to load tam tables
        if self.args['load_tam_tables'] == 'True':
            tam_ingestion_table_list = json.loads(self.config.get(self.env, "tam_ingestion_onboarding_table_list"))
            self.onboard_ingestion_table_list += (
                {'column_name': s['column_name'], 'table_name': s['src_table_name'] + '.tam'} for s
                in tam_ingestion_table_list)
        else:
            logger.info("Not loading tam tables as flag in job parameters is not 'True'")

    @staticmethod
    def onboard_new_brand(src_df, trg_df, brand, col_name):
        """
        This function is used to calculate what data to add data of particular product_brand into landing layer
        """
        logger.info("Brand : " + brand)
        # Selecting all the brands from trg_df except onboarding brand
        trg_anti_filter_df = trg_df.where(col(col_name) != brand)

        # Selecting only brand from src which has to onboarded
        src_filter_df = src_df.where(col(col_name) == brand).withColumn('etl_load_date', current_timestamp())

        # union both df to get full data along with new brand that has tobe onboarded
        return trg_anti_filter_df.union(src_filter_df)

    def onboard_tables_write_to_s3(self, athena_client):
        """
        This method is to write data to s3 for all tables for onboarding brand
        :return: audit_info : List of stats for audit purpose
        """
        # Checking historical tables in staging database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.landing_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in staging database
        existing_backup_table_names = []
        for tbl_name in all_table_names:
            if 'backup' in tbl_name:
                existing_backup_table_names.append(tbl_name)
        brand = self.config.get(self.env, "brand")
        audit_info = []
        # Iterating through all the tables that has to be ingested in landing layer
        for ingestion_table in self.onboard_ingestion_table_list:
            database = ingestion_table['table_name'].split('.')[0]
            table = ingestion_table['table_name'].split('.')[1]
            domain = ingestion_table['table_name'].split('.')[2]
            column_name = ingestion_table['column_name']
            # landing_table = table[:-3]
            landing_table = table[9:]
            backup_table = landing_table + '_backup'
            logger.info("Source Database : " + database)
            logger.info("Source Table : " + table)
            logger.info("Domain : " + domain)
            logger.info("Landing Database : " + self.landing_database)
            logger.info("Landing Table : " + landing_table)
            logger.info("Backup table : " + backup_table)

            # Reading dataframes from Glue Catalog
            src_df = self.glue_context.create_data_frame.from_catalog(database=database, table_name=table)
            dest_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                       table_name=landing_table)

            full_brand_df = self.onboard_new_brand(src_df, dest_df, brand, column_name)

            for cols in full_brand_df.columns:
                full_brand_df = full_brand_df.withColumnRenamed(cols, cols.lower())

            full_df = full_brand_df.persist()

            if backup_table in existing_backup_table_names:
                backup_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                             table_name=backup_table)
                last_version = backup_df.select([max("version")]).head()[0]
                full_data_backup_df = full_df.withColumn('version', lit(int(last_version) + 1))
            else:  # This means table is new to landing, it is getting loaded into backup for first time
                full_data_backup_df = full_df.withColumn('version', lit(1))
                logger.info(f"Back up table does not exist for {backup_table} in landing layer")

            # Calculating Audit info
            updated_row_cnt = full_df.count()
            audit_info.append(
                {'table_name': f"{self.landing_database}.{landing_table}", 'rows_updated': updated_row_cnt})
            audit_info.append(
                {'table_name': f"{self.landing_database}.{backup_table}", 'rows_updated': updated_row_cnt})

            logger.info("Onboarding count : " + str(updated_row_cnt))

            # Writing to landing layer and backup folders
            full_df.coalesce(8).write.mode('overwrite').parquet(
                "s3://" + self.bucket_name + "/" + self.landing_folder + "/" + domain + "/" + landing_table + "/")
            full_data_backup_df.coalesce(8).write.partitionBy("version").mode('append').parquet(
                "s3://" + self.bucket_name + "/" + self.landing_folder + "/" + domain + "/" + backup_table + "/")

            self.s3_path_list += ["s3://" + self.bucket_name + "/" + self.landing_folder + "/" + domain + "/" +
                                  landing_table + "/"]
            self.s3_path_list += ["s3://" + self.bucket_name + "/" + self.landing_folder + "/" + domain + "/" +
                                  backup_table + "/"]
            logger.info("Data has written to s3 for " + table + " as well as backup")

        return audit_info
        
    def tam_pccm_interactions(self, athena_client):
        logger.info("Loading TAM PCCM Interactions Files into table")
        table_name = 'tam_pccm_interactions'
        stg_table_name = table_name
        backup_table_name = table_name + '_backup'

        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.landing_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        tam_pccm_interactions_df = (self.spark.read.format("csv")
                                    .option("header", "true")
                                    .load(self.config.get(self.env, "tam_pccm_interactions_file_path"))
                                    .selectExpr('`Zip Code (Zip5)` as zip_code', '`Product` as product',
                                                '`Interaction Date` as interaction_date',
                                                '`Interaction Type` as interaction_type',
                                                '`Topic Discussed` as topic_discussed',
                                                '`# of Patients` as number_of_patients',
                                                '`# of Interactions` as number_of_interactions')
                                    .withColumn('number_of_patients', col('number_of_patients').cast(DoubleType()))
                                    .withColumn('number_of_interactions',
                                                col('number_of_interactions').cast(DoubleType()))
                                    .withColumn("etl_load_date", current_timestamp().cast(TimestampType()))
                                    .withColumn("File_Interaction_Date", to_date(col('interaction_date'), 'M/d/yyyy')))
        logger.info("Row counts for old file " + str(tam_pccm_interactions_df.count()))

        tam_pccm_interactions_021925_df = (self.spark.read.format("csv")
                                           .option("header", "true")
                                           .load(self.config.get(self.env, "tam_pccm_interactions_file_021925_path"))
                                           .selectExpr('`Zip Code (Zip5)` as zip_code', '`Product` as product',
                                                       '`Interaction Date` as interaction_date',
                                                       '`Interaction Type` as interaction_type',
                                                       '`Topic Discussed` as topic_discussed',
                                                       '`# of Patients` as number_of_patients',
                                                       '`# of Interactions` as number_of_interactions')
                                           .withColumn('number_of_patients',
                                                       col('number_of_patients').cast(DoubleType()))
                                           .withColumn('number_of_interactions',
                                                       col('number_of_interactions').cast(DoubleType()))
                                           .withColumn("etl_load_date", current_timestamp().cast(TimestampType()))
                                           .withColumn("File_Interaction_Date",
                                                       to_date(col('interaction_date'), 'M/d/yyyy')))
        logger.info("Row counts for 021925 file " + str(tam_pccm_interactions_021925_df.count()))

        min_date_in_021925_file = tam_pccm_interactions_021925_df.select([min("File_Interaction_Date")]).head()[0]

        old_dates_df = tam_pccm_interactions_df.where(col('File_Interaction_Date') < min_date_in_021925_file)

        logger.info("Row counts for after filtering dates " + str(old_dates_df.count()))

        final_tam_pccm_df = old_dates_df.union(tam_pccm_interactions_021925_df).drop(col('File_Interaction_Date'))

        s3_path = "s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'tam_pccm_interactions' + "/" + stg_table_name + "/"
        df = final_tam_pccm_df.persist()
        updated_row_cnt = df.count()
        logger.info("Row counts for table after union " + stg_table_name + " : " + str(updated_row_cnt))
        audit_info = [{'table_name': f"{self.landing_database}.{stg_table_name}", 'rows_updated': updated_row_cnt}]
        df.coalesce(1).write.mode('overwrite').format('parquet').save(s3_path)
        self.s3_path_list += [s3_path]

        # Creating list of backup tables in normalized database
        existing_backup_table_names = []
        for tbl_name in all_table_names:
            if 'backup' in tbl_name:
                existing_backup_table_names.append(tbl_name)

        if backup_table_name in existing_backup_table_names:
            landing_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                          table_name=backup_table_name)
            last_version = landing_df.select([max("version")]).head()[0]
            hist_df = df.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = df.withColumn('version', lit(1))
            logger.info(f"Back up table does not exist for tam pccm interactions in landing layer")

        audit_info.append(
            {'table_name': f"{self.landing_database}.{backup_table_name}",'rows_updated': updated_row_cnt})

        s3_path = (
                "s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'tam_pccm_interactions' + "/" + backup_table_name + "/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def creative_cost(self, athena_client):
        logger.info("Loading MARS Creative costs into table")
        table_name = 'creative_costs'
        stg_table_name = table_name
        backup_table_name = table_name + '_backup'

        creative_cost_file_df = (self.spark.read.format("csv")
                                 .option("header", "true").option("quote", '"').option("delimiter", ',')
                                 .load(self.config.get(self.env, "creative_cost_file_path"))
                                 .withColumn("etl_load_date", current_timestamp().cast(TimestampType()))
                                 )

        for cols in creative_cost_file_df.columns:
            creative_cost_file_df = creative_cost_file_df.withColumnRenamed(cols, cols.lower().strip().replace(" + ",
                                                                                                               "+").replace(
                ":", "").replace(" ", "_").replace("""/""", "_").replace(".", ""))

        #   creative_cost_file_df.printSchema()
        casted_columns_creative_df = creative_cost_file_df.withColumn("ytd_act",
                                                                      regexp_replace("ytd_act", ',', '').cast(
                                                                          DoubleType())).withColumn('ytg_committed',
                                                                                                    regexp_replace(
                                                                                                        "ytg_committed",
                                                                                                        ',', '').cast(
                                                                                                        DoubleType())).withColumn(
            "fy_act+commit", regexp_replace("fy_act+commit", ',', '').cast(DoubleType()))

        df = casted_columns_creative_df.persist()

        s3_path = "s3://" + self.bucket_name + "/" + self.landing_folder + "/" + "costs" + "/" + stg_table_name + "/"
        row_cnt = df.count()
        logger.info("Row counts " + stg_table_name + " : " + str(row_cnt))
        audit_info = [{'table_name': f"{self.landing_database}.{stg_table_name}", 'rows_updated': row_cnt}]
        df.coalesce(1).write.mode('overwrite').format('parquet').save(s3_path)
        self.s3_path_list += [s3_path]

        # Creating list of backup tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.landing_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))
        existing_backup_table_names = []
        for tbl_name in all_table_names:
            if 'backup' in tbl_name:
                existing_backup_table_names.append(tbl_name)

        if backup_table_name in existing_backup_table_names:
            landing_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                          table_name=backup_table_name)
            last_version = landing_df.select([max("version")]).head()[0]
            hist_df = df.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = df.withColumn('version', lit(1))
            logger.info(
                f"Back up table does not exist for creative costs in landing layer")

        audit_info.append(
            {'table_name': f"{self.landing_database}.{backup_table_name}",
             'rows_updated': row_cnt})

        s3_path = (
                    "s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'costs' + "/" + backup_table_name + "/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    # def tam_pccm_interactions(self, athena_client):
    #     logger.info("Loading TAM PCCM Interactions 021895 into landing table")
    #     table_name = 'tam_pccm_interactions'
    #     stg_table_name = table_name
    #     hist_table_name = table_name + '_backup'
    #     tam_pccm_interactions_df = (self.spark.read.format("csv")
    #                                 .option("header", "true")
    #                                 .load(self.config.get(self.env, "tam_pccm_interactions_file_021925_path"))
    #                                 .selectExpr('`Zip Code (Zip5)` as zip_code', '`Product` as product',
    #                                             '`Interaction Date` as interaction_date',
    #                                             '`Interaction Type` as interaction_type',
    #                                             '`Topic Discussed` as topic_discussed',
    #                                             '`# of Patients` as number_of_patients',
    #                                             '`# of Interactions` as number_of_interactions')
    #                                 .withColumn('number_of_patients', col('number_of_patients').cast(DoubleType()))
    #                                 .withColumn('number_of_interactions',
    #                                             col('number_of_interactions').cast(DoubleType()))
    #                                 .withColumn("etl_load_date", current_timestamp().cast(TimestampType())))

    #     s3_path = "s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'tam_pccm_interactions' + "/" + stg_table_name + "/"
    #     df = tam_pccm_interactions_df.persist()
    #     updated_row_cnt = df.count()
    #     logger.info("Row counts for table " + stg_table_name + " : " + str(updated_row_cnt))
    #     audit_info = [{'table_name': f"{self.landing_database}.{stg_table_name}", 'rows_updated': updated_row_cnt}]
    #     df.coalesce(1).write.mode('overwrite').format('parquet').save(s3_path)
    #     self.s3_path_list += [s3_path]

    #     paginator = athena_client.get_paginator('list_table_metadata')
    #     response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.landing_database)

    #     all_table_names = []
    #     for page in response_iterator:
    #         all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

    #     # Creating list of backup tables in normalized database
    #     existing_historical_table_names = []
    #     for tbl_name in all_table_names:
    #         if 'backup' in tbl_name:
    #             existing_historical_table_names.append(tbl_name)

    #     if hist_table_name in existing_historical_table_names:
    #         historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
    #                                                                             table_name=hist_table_name)
    #         last_version = historical_up_df.select([max("version")]).head()[0]
    #         hist_df = df.withColumn('version', lit(int(last_version) + 1))
    #     else:  # This means table is new to landing, it is getting loaded into backup for first time
    #         hist_df = df.withColumn('version', lit(1))
    #         logger.info(
    #             f"Back up table does not exist for tam_pccm_interaction cross over historical in landing layer")

    #     audit_info.append(
    #         {'table_name': f"{self.landing_database}.{hist_table_name}",
    #          'rows_updated': updated_row_cnt})

    #     s3_path = (
    #             "s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'tam_pccm_interactions' + "/" + hist_table_name + "/")
    #     hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
    #     self.s3_path_list += [s3_path]

    #     return audit_info


def audit_job_info(spark_obj, job_srt_time, job_name, batch_id, audit_path, audit_dict):
    """
    This function is used to write audit stats of this etl job to athena table.
    :param audit_path:
    :param spark_obj:
    :param job_srt_time:
    :param job_name:
    :param batch_id:
    :param audit_dict:
    """
    if audit_dict is not None:
        logger.info("Writing completion stats to audit table")
        logger.info(audit_dict)
        audit_df = (spark_obj.createDataFrame(audit_dict)
                    .withColumn("log_id_status", lit("COMPLETED"))
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", current_timestamp().cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("etl_layer", lit("landing"))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)
    else:
        logger.info("Writing initiating stats to audit table")
        audit_df = (spark_obj.createDataFrame([{'etl_layer': 'landing', 'log_id_status': 'INITIATED'}])
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", lit(None).cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("table_name", lit(None).cast(StringType()))
                    .withColumn("rows_updated", lit(None).cast(IntegerType()))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)
        logger.info("Auditing is complete")


if __name__ == "__main__":
    # Getting AWS Glue job parameters, creating session and initiating job
    arg = getResolvedOptions(sys.argv,
                             ['JOB_NAME', 'environment', 'load_demographic_zip_ref_tables', 'load_sales_tables',
                              'load_xo_tables', 'load_speaker_tables', 'load_tam_tables', 'load_hcp_mdm_ref_tables',
                              'load_brand', 'batch_id', 'load_tam_pccm'])

    logger.info("MARS Data Ingestion job started")

    environment = arg['environment']
    config_obj = read_config_file('configuration.ini')
    check_config_section(config_obj, environment)
    job_start_time = datetime.datetime.now()

    sc = SparkContext()
    glueContext = GlueContext(sc)
    sprk = glueContext.spark_session
    job = Job(glueContext)
    job.init(arg['JOB_NAME'], arg)

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'),
                   audit_dict=None)
    audit_list = []

    mars_data_ingestion = DataIngestion(config_obj, arg, glueContext, sprk)

    athena_cl = boto3.client('athena', region_name="us-west-2")

    crawler_client = boto3.client('glue', region_name="us-west-2")

    # for new tam pccm file in landing layer
    if arg['load_tam_pccm'] == 'True':
        logger.info("Refreshing TAM PCCM in landing layer")
        audit_list += mars_data_ingestion.tam_pccm_interactions(athena_cl)

    # audit_list += mars_data_ingestion.creative_cost(athena_cl)

    if arg['load_brand'] != 'True':
        logger.info("Refreshing tables in landing layer")
        mars_data_ingestion.prep_table_load_list()

        audit_list = mars_data_ingestion.write_to_s3(athena_cl)

    elif arg['load_brand'] == 'True':
        logger.info("Loading data for one brand")
        mars_data_ingestion.onboard_prep_table_list()

        audit_list = mars_data_ingestion.onboard_tables_write_to_s3(athena_cl)

    mars_data_ingestion.create_update_crawler(crawler_client)
    
    mars_data_ingestion.start_crawler(crawler_client)
    
    mars_data_ingestion.monitor_crawler(crawler_client)
    
    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'),
                   audit_dict=audit_list)
    
    job.commit()