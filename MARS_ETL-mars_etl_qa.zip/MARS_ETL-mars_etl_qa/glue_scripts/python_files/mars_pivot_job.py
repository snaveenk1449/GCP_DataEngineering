import json
import logging
import configparser
import boto3
import sys
import time
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import *
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.types import *
import datetime
from pyspark.sql.window import Window
from pyspark.sql import functions as F
from pyspark.sql import types as T

MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def read_config_file(config_file_name):
    """
    This function is reading config file and returning config object
    :type config_file_name: string
    """
    config = configparser.ConfigParser()
    config.read(config_file_name)
    return config


def check_config_section(config, env):
    """
    This function check if section specified in job parameters is present in config file or not
    :param config: Config file object
    :param env: environment which is specified in job parameters
    """
    if not config.has_section(env):
        raise Exception("Environment details doesn't exist in configuration file")


class Pivot:
    def __init__(self, config, args, glue_context, spark):
        """
        This is init method used to initialize variables in class
        :param config: Config file object
        :param args: Arguments given to Glue job
        """
        self.env = args['environment']
        self.args = args
        self.bucket_name = config.get(self.env, "bucket_name")
        self.normalized_folder = json.loads(config.get(self.env, "folder_names"))['normalized']
        self.summarized_folder = json.loads(config.get(self.env, "folder_names"))['summarized']
        self.s3_path_list = []
        self.normalized_database = json.loads(config.get(self.env, "athena_database"))['normalized']
        self.summarized_database = json.loads(config.get(self.env, "athena_database"))['summarized']
        self.config = config
        self.crawler_name = 'mars_pivot_tbl_crawler'
        self.glue_context = glue_context
        self.spark = spark
        self.landing_database = json.loads(config.get(self.env, "athena_database"))['landing']
        self.mars_sales_tbl = config.get(self.env, "mars_sales_tbl")
        self.mars_tam_tbl = config.get(self.env, "mars_tam_tbl")
        self.mars_speaker_stg = config.get(self.env, "mars_speaker_stg")
        self.mars_xo_tbl = config.get(self.env, "mars_xo_tbl")
        self.mars_hcp_count = config.get(self.env, "mars_hcp_count")
        self.mars_nvs_digital_staging = config.get(self.env, "mars_nvs_digital_staging")
        self.mars_tam_nvs_staging = config.get(self.env, "mars_tam_nvs_staging")
        self.xo_bimonthly_staging = config.get(self.env, "xo_bimonthly_staging")

    def core(self, athena_client):
        df_prepivot = self.spark.sql(f"""
            with combined_data as( 
                select distinct
                    product_brand_name,
                    year_month,
                    zip as zip_code,
                    upper(audience) as audience,
                    channel,
                    reach,
                    engage,
                    cost
                from
                    {self.normalized_database}.{self.mars_xo_tbl}
                where upper(product_brand_name) != 'XOLAIR'
                union all
                select distinct
                    product_brand_name, 
                    year_month,
                    zip as zip_code,
                    upper(audience) as audience,
                    channel,
                    reach,
                    null as engage,
                    cost
                from
                    {self.normalized_database}.{self.mars_tam_tbl}
                where upper(product_brand_name) != 'XOLAIR'
                union all
                select distinct
                    product_brand_name,
                    year_month,
                    zip as zip_code,
                    upper(audience) as audience,
                    channel,
                    reach,
                    null as engage,
                    cost
                from
                    {self.normalized_database}.{self.mars_speaker_stg}
                where upper(product_brand_name) != 'XOLAIR'
            )
            select * from combined_data
        """)
        df_prepivot.registerTempTable('combined_gene')

        # df_prepivot_novartis = self.spark.sql(f"""
        #     with combined_data as(
        #         select distinct
        #             product_brand_name,
        #             year_month,
        #             zip as zip_code,
        #             upper(audience) as audience,
        #             channel,
        #             reach,
        #             null as engage,
        #             cost
        #         from
        #             {self.normalized_database}.{self.mars_speaker_stg}
        #         where product_brand_name = 'XOLAIR'
        #         union all
        #         select
        #             distinct
        #             product_brand_name,
        #             year_month,
        #             zip as zip_code,
        #             upper(audience) as audience,
        #             channel,
        #             reach,
        #             engage,
        #             cost
        #         from
        #             {self.normalized_database}.{self.mars_xo_tbl}
        #         where product_brand_name = 'XOLAIR'
        #         union all
        #         select distinct
        #             product_brand_name,
        #             year_month,
        #             zip as zip_code,
        #             upper(audience) as audience,
        #             channel,
        #             reach,
        #             null as engage,
        #             cost
        #         from
        #             {self.normalized_database}.{self.mars_tam_tbl}
        #         where product_brand_name = 'XOLAIR'
        #         union all
        #         select distinct
        #             product_brand_name,
        #             year_month,
        #             zip as zip_code,
        #             upper(audience) as audience,
        #             channel,
        #             reach,
        #             engage,
        #             cost
        #         from
        #             {self.normalized_database}.{self.mars_nvs_digital_staging}
        #         union all
        #         select distinct
        #             product_brand_name,
        #             year_month,
        #             zip as zip_code,
        #             upper(audience) as audience,
        #             channel,
        #             reach,
        #             engage,
        #             cost
        #         from {self.normalized_database}.{self.mars_tam_nvs_staging}
        #     )
        #     select * from combined_data
        # """)
        # df_prepivot_novartis.registerTempTable('combined_novartis')

        # df_all_combined = self.spark.sql("""
        #     select * from combined_gene
        #     union all
        #     select * from combined_novartis
        # """)
        # df_all_combined.registerTempTable('all_combined')

        df_pivoted = (
            self.spark.sql(
                """
                    select
                        product_brand_name,
                        zip_code,
                        year_month,
                        channel || '_' || audience AS channel_audience,
                        reach,
                        engage,
                        cost
                    from combined_gene
                """
            )
            .groupBy(
                [
                    "product_brand_name",
                    "zip_code",
                    "year_month"
                ]
            )
            .pivot("channel_audience")
            .sum("reach", "engage", "cost")
        )

        df_pivoted = df_pivoted.select(
            *[
                F.col(col).alias(col.replace("_sum(", "_").replace(")", ""))
                for col in df_pivoted.columns
            ]
        )
        df_pivoted.registerTempTable('post_pivot')

        df_final = self.spark.sql(
            f"""
            with cte as (
                select distinct
                    coalesce(
                        pivoted.product_brand_name,
                        sales.product_brand_name,
                        hcp_count.product_brand_name
                    ) as product_brand_name,
                    coalesce(pivoted.zip_code, sales.zip, hcp_count.zip_code) as zip_code,
                    coalesce(pivoted.year_month, sales.year_month) as date_year_month,
                    addressable_tv_dtc_reach , 
                      addressable_tv_dtc_engage , 
                      addressable_tv_dtc_cost , 
                      alert_dtc_reach , 
                      alert_dtc_engage , 
                      alert_dtc_cost , 
                      alert_hcp_reach , 
                      alert_hcp_engage , 
                      alert_hcp_cost , 
                      connected_tv_dtc_reach , 
                      connected_tv_dtc_engage , 
                      connected_tv_dtc_cost , 
                      cso_ce_reach, 
                      cso_ce_engage,
                      cso_ce_cost,
                      --custom_hcp_reach,
                      --custom_hcp_engage,
                      --custom_hcp_cost,
                      display_dtc_reach , 
                      display_dtc_engage , 
                      display_dtc_cost , 
                      display_hcp_reach , 
                      display_hcp_engage , 
                      display_hcp_cost , 
                      dr_cable_dtc_reach , 
                      dr_cable_dtc_engage , 
                      dr_cable_dtc_cost , 
                      e_detail_dtc_reach , 
                      e_detail_dtc_engage , 
                      e_detail_dtc_cost , 
                      e_detail_hcp_reach , 
                      e_detail_hcp_engage , 
                      e_detail_hcp_cost , 
                      ehr_emr_hcp_reach , 
                      ehr_emr_hcp_engage , 
                      ehr_emr_hcp_cost , 
                      enewsletter_dtc_reach , 
                      enewsletter_dtc_engage , 
                      enewsletter_dtc_cost , 
                      enewsletter_hcp_reach , 
                      enewsletter_hcp_engage , 
                      enewsletter_hcp_cost , 
                      hispanic_connected_tv_dtc_reach , 
                      hispanic_connected_tv_dtc_engage , 
                      hispanic_connected_tv_dtc_cost , 
                      hispanic_linear_tv_dtc_reach , 
                      hispanic_linear_tv_dtc_engage , 
                      hispanic_linear_tv_dtc_cost , 
                      house_email_dtc_reach , 
                      house_email_dtc_engage , 
                      house_email_dtc_cost , 
                      house_email_hcp_reach , 
                      house_email_hcp_engage , 
                      house_email_hcp_cost , 
                      --journals_print_dtc_reach , 
                      --journals_print_dtc_engage , 
                      --journals_print_dtc_cost , 
                      journals_print_hcp_reach , 
                      journals_print_hcp_engage , 
                      journals_print_hcp_cost , 
                      linear_tv_dtc_reach , 
                      linear_tv_dtc_engage , 
                      linear_tv_dtc_cost , 
                      local_tv_dtc_reach, 
                      local_tv_dtc_engage,
                      local_tv_dtc_cost,
                      monograph_hcp_reach , 
                      monograph_hcp_engage , 
                      monograph_hcp_cost , 
                      online_video_dtc_reach , 
                      online_video_dtc_engage , 
                      online_video_dtc_cost , 
                      online_video_hcp_reach , 
                      online_video_hcp_engage , 
                      online_video_hcp_cost , 
                      organic_social_dtc_reach, 
                      organic_social_dtc_engage, 
                      organic_social_dtc_cost,
                      out_of_home_ooh_HCP_reach,
                      out_of_home_ooh_HCP_engage,
                      out_of_home_ooh_HCP_cost,
                      paid_search_dtc_reach , 
                      paid_search_dtc_engage , 
                      paid_search_dtc_cost , 
                      paid_search_hcp_reach , 
                      paid_search_hcp_engage , 
                      paid_search_hcp_cost , 
                      paid_social_dtc_reach , 
                      paid_social_dtc_engage , 
                      paid_social_dtc_cost , 
                      paid_social_hcp_reach , 
                      paid_social_hcp_engage , 
                      paid_social_hcp_cost , 
                      paid_youtube_dtc_reach,
                      paid_youtube_dtc_engage,
                      paid_youtube_dtc_cost,
                      patient_custom_program_dtc_reach, 
                      patient_custom_program_dtc_engage,
                      patient_custom_program_dtc_cost,
                      point_of_care_dtc_reach , 
                      point_of_care_dtc_engage , 
                      point_of_care_dtc_cost , 
                      --point_of_care_hcp_reach,
                      --point_of_care_hcp_engage,
                      --point_of_care_hcp_cost,
                      sms_hcp_reach, 
                      sms_hcp_engage, 
                      sms_hcp_cost,
                      speaker_program_dtc_reach , 
                      speaker_program_dtc_engage , 
                      speaker_program_dtc_cost , 
                      speaker_program_hcp_reach , 
                      speaker_program_hcp_engage , 
                      speaker_program_hcp_cost , 
                      streaming_audio_dtc_reach , 
                      streaming_audio_dtc_engage , 
                      streaming_audio_dtc_cost , 
                      streaming_audio_hcp_reach,
                      streaming_audio_hcp_engage,
                      streaming_audio_hcp_cost,
                      streaming_tv_dtc_reach , 
                      streaming_tv_dtc_engage , 
                      streaming_tv_dtc_cost , 
                      tam_dtc_reach , 
                      tam_dtc_engage , 
                      tam_dtc_cost , 
                      tam_hd_ce_reach , 
                      tam_hd_ce_engage , 
                      tam_hd_ce_cost , 
                      third_party_email_dtc_reach , 
                      third_party_email_dtc_engage , 
                      third_party_email_dtc_cost , 
                      third_party_email_hcp_reach , 
                      third_party_email_hcp_engage , 
                      third_party_email_hcp_cost , 
                      third_party_site_content_hcp_reach , 
                      third_party_site_content_hcp_engage , 
                      third_party_site_content_hcp_cost , 
                      video_dtc_reach , 
                      video_dtc_engage , 
                      video_dtc_cost , 
                      video_hcp_reach , 
                      video_hcp_engage , 
                      video_hcp_cost,
                    sales.sales_qty as gne_867_sales_qty_eqv,
                    hcp_count.hcp_count
                from post_pivot as pivoted
                full outer join
                    {self.summarized_database}.mars_sales as sales
                    on
                        pivoted.product_brand_name = sales.product_brand_name
                        and pivoted.year_month = sales.year_month
                        and pivoted.zip_code = sales.zip
                full outer join
                    {self.summarized_database}.mars_hcp_count as hcp_count
                    on
                        pivoted.product_brand_name = hcp_count.product_brand_name
                        and pivoted.zip_code = hcp_count.zip_code
            )
            select * from cte 
            where date_year_month is not null
        """)

        df_xo_channel_audience = self.spark.sql(f"""
            with channel_list as (
                select distinct lower(regexp_replace(channel, '[^A-Za-z0-9]+', '_')) as channel, lower(audience) as audience 
                from {self.normalized_database}.{self.xo_bimonthly_staging}
            )
            select channel || '_' || audience as channel_audience from channel_list
        """)
        channel_audience_list = df_xo_channel_audience.select("channel_audience").rdd.flatMap(lambda x: x).collect()
        
        exceptions_channel_audience_list = ['journals_print_dtc', 'paid_search_dtp']
        
        logger.info(f"""Channel audience Source data list : {channel_audience_list}""")
        logger.info(f"""List of columns of pivot table : {df_final.columns}""")
        logger.info(f"""List of exception channels : {exceptions_channel_audience_list}""")

        missing_channel_audience = []
        for channel_audience in channel_audience_list:
            flag = False
            for pivot_column in df_final.columns+exceptions_channel_audience_list:
                if channel_audience in pivot_column.lower():
                    flag = True
                    break
            if not flag:
                missing_channel_audience.append(channel_audience)

        if len(missing_channel_audience) != 0:
            raise Exception("Channel audience is missing from pivot table columns : " + str(missing_channel_audience))

        df_final_agg_persisted = df_final.persist()

        audit_info = []
        audit_info += [{'table_name': f"{self.summarized_database}.mars_pivot",
                        'rows_updated': df_final_agg_persisted.count()}]

        s3_path = ("s3://" + self.bucket_name + "/" + self.summarized_folder + "/etl/mars_pivot/")
        df_final_agg_persisted.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.summarized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)

        if 'mars_pivot_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.summarized_database,
                                                                                table_name='mars_pivot_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            hcp_count_hist_df = df_final_agg_persisted.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hcp_count_hist_df = df_final_agg_persisted.withColumn('version', lit(1))
            logger.info(f"Back up table does not exist for mars mars_pivot_historical in summarized layer")

        audit_info.append(
            {'table_name': f"{self.summarized_database}.mars_pivot_historical",
             'rows_updated': df_final_agg_persisted.count()})

        s3_path = ("s3://" + self.bucket_name + "/" + self.summarized_folder + "/etl/mars_pivot_historical/")
        hcp_count_hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def create_update_crawler(self, client):
        """
        Crawler has to be created if it doesn't exist, if it exists then we have to update it s3 path for it.
        :param client: glue boto3 client used to create or update crawler
        """
        # Creating list of s3 path that has to be crawled
        s3_crawl_list = []
        for s3_path in list(set(self.s3_path_list)):
            s3_crawl_list.append(
                {"Path": s3_path, 'Exclusions': json.loads(self.config.get(self.env, "crawl_exclusion_paths"))})

        crawler_exist = True

        # Checking if crawler is already existing or not
        try:
            res = client.get_crawler(Name=self.crawler_name)
            response = json.dumps(res, indent=4, sort_keys=True, default=str)
            print(response)
        except client.exceptions.EntityNotFoundException as e:
            logger.info("Crawler doesnt exist, need to create")
            crawler_exist = False

        # Creating crawler if it doesn't exist
        if crawler_exist:
            response = client.update_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.summarized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Updated\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

        else:
            response = client.create_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.summarized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Created\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

    def start_crawler(self, client):
        """
        This method is used to start the crawler
        :param client: glue boto3 client used to create or update crawler
        """
        response_start = client.start_crawler(Name=self.crawler_name)
        logger.info("Crawler Started\nName : " + self.crawler_name)
        logger.info(json.dumps(response_start, indent=4, sort_keys=True, default=str))

    def monitor_crawler(self, client):
        """
        This method is used to monitor the crawler which we started just now
        :param client: glue boto3 client used to create or update crawler
        """
        need_to_wait = True
        state_previous = None
        while need_to_wait:
            time.sleep(20)
            response_get = client.get_crawler(Name=self.crawler_name)
            state = response_get["Crawler"]["State"]
            if state == "READY" or state == "STOPPING":  # Other known states: RUNNING
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                need_to_wait = False
                break
            if state != state_previous:
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                state_previous = state


def audit_job_info(spark_obj, job_srt_time, job_name, batch_id, audit_path, audit_dict):
    """
    This function is used to write audit stats of this etl job to athena table.
    :param audit_path:
    :param spark_obj:
    :param job_srt_time:
    :param job_name:
    :param batch_id:
    :param audit_dict:
    """
    if audit_dict is not None:
        logger.info("Writing completion stats to audit table")
        logger.info(audit_dict)
        audit_df = (spark_obj.createDataFrame(audit_dict)
                    .withColumn("log_id_status", lit("COMPLETED"))
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", current_timestamp().cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("etl_layer", lit("summarized"))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)
        logger.info("Auditing is complete")
    else:
        logger.info("Writing initiating stats to audit table")
        audit_df = (spark_obj.createDataFrame([{'etl_layer': 'summarized', 'log_id_status': 'INITIATED'}])
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", lit(None).cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("table_name", lit(None).cast(StringType()))
                    .withColumn("rows_updated", lit(None).cast(IntegerType()))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)


if __name__ == "__main__":
    # Getting AWS Glue job parameters, creating session and initiating job
    arg = getResolvedOptions(sys.argv,
                             ['JOB_NAME', 'environment', 'batch_id'])

    logger.info("MARS pivot job started")

    environment = arg['environment']
    config_obj = read_config_file('configuration.ini')
    check_config_section(config_obj, environment)
    job_start_time = datetime.datetime.now()

    sc = SparkContext()
    glueContext = GlueContext(sc)
    sprk = glueContext.spark_session
    job = Job(glueContext)
    job.init(arg['JOB_NAME'], arg)

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'),
                   audit_dict=None)
    audit_list = []

    pivot_etl = Pivot(config_obj, arg, glueContext, sprk)

    crawler_client = boto3.client('glue', region_name="us-west-2")

    athena_cl = boto3.client('athena', region_name="us-west-2")

    audit_list += pivot_etl.core(athena_cl)

    pivot_etl.create_update_crawler(crawler_client)

    pivot_etl.start_crawler(crawler_client)

    pivot_etl.monitor_crawler(crawler_client)

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'),
                   audit_dict=audit_list)

    job.commit()
