import json
import logging
import configparser
import boto3
import sys
import time
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import *
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.types import *
import datetime

MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def read_config_file(config_file_name):
    """
    This function is reading config file and returning config object
    :type config_file_name: string
    """
    config = configparser.ConfigParser()
    config.read(config_file_name)
    return config


def check_config_section(config, env):
    """
    This function check if section specified in job parameters is present in config file or not
    :param config: Config file object
    :param env: environment which is specified in job parameters
    """
    if not config.has_section(env):
        raise Exception("Environment details doesn't exist in configuration file")


class LoadStagingHistorical:
    def __init__(self, config, args, glue_context):
        """
        This is init method used to initialize variables in class
        :param config: Config file object
        :param args: Arguments given to Glue job
        """
        self.env = args['environment']
        self.args = args
        self.bucket_name = config.get(self.env, "bucket_name")
        self.normalized_folder = json.loads(config.get(self.env, "folder_names"))['normalized']
        self.ingestion_table_list = []
        self.onboard_ingestion_table_list = []
        self.s3_path_list = []
        self.landing_database = json.loads(config.get(self.env, "athena_database"))['landing']
        self.normalized_database = json.loads(config.get(self.env, "athena_database"))['normalized']
        self.config = config
        self.crawler_name = 'mars_staging_historical_crawler'
        self.glue_context = glue_context

    def prep_table_load_list(self):
        """
        This function is to prepare list of tables that has to be loaded to staging layer
        """
        # Check do we have to demographic zip ref tables
        if self.args['load_demographic_zip_ref_tables'] == 'True':
            one_time_ingestion_table_list = json.loads(
                self.config.get(self.env, "demographic_zip_ref_ingestion_table_list"))
            self.ingestion_table_list += (s + '.demographic_zip_ref' for s in one_time_ingestion_table_list)
        else:
            logger.info("Not loading demographic zip ref tables as flag in job parameters is not 'True'")

        # Check do we have to load sales tables
        if self.args['load_sales_tables'] == 'True':
            sales_ingestion_table_list = json.loads(self.config.get(self.env, "sales_ingestion_table_list"))
            self.ingestion_table_list += (s + '.sales' for s in sales_ingestion_table_list)
        else:
            logger.info("Not loading sales tables as flag in job parameters is not 'True'")

        # Check do we have to load xo tables
        if self.args['load_xo_tables'] == 'True':
            xo_ingestion_table_list = json.loads(self.config.get(self.env, "xo_ingestion_table_list"))
            self.ingestion_table_list += (s + '.xo' for s in xo_ingestion_table_list)
        else:
            logger.info("Not loading xo tables as flag in job parameters is not 'True'")

        # Check do we have to load speaker tables
        if self.args['load_speaker_tables'] == 'True':
            speaker_ingestion_table_list = json.loads(self.config.get(self.env, "speaker_ingestion_table_list"))
            self.ingestion_table_list += (s + '.speaker' for s in speaker_ingestion_table_list)
        else:
            logger.info("Not loading speaker tables as flag in job parameters is not 'True'")

        # Check do we have to load tam tables
        if self.args['load_tam_tables'] == 'True':
            tam_ingestion_table_list = json.loads(self.config.get(self.env, "tam_ingestion_table_list"))
            self.ingestion_table_list += (s + '.tam' for s in tam_ingestion_table_list)
        else:
            logger.info("Not loading tam tables as flag in job parameters is not 'True'")

        # Check do we have to load hcp mdm ref tables
        if self.args['load_hcp_mdm_ref_tables'] == 'True':
            common_ingestion_table_list = json.loads(self.config.get(self.env, "hcp_mdm_ref_ingestion_table_list"))
            self.ingestion_table_list += (s + '.hcp_mdm_ref' for s in common_ingestion_table_list)
        else:
            logger.info("Not loading hcp mdm ref tables as flag in job parameters is not 'True'")

    def write_to_s3(self, athena_client):
        """
        This method is to write data to s3 for all tables
        :return: audit_info : List of stats for audit purpose
        """
        audit_info = []
        logger.info("Landing Database : " + self.landing_database)
        staging_folder = self.normalized_folder
        landing_database = self.landing_database

        # Checking historical tables in staging database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of historical tables in staging database
        existing_hist_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_hist_table_names.append(tbl_name)

        for ingestion_table in self.ingestion_table_list:
            tbl = ingestion_table.split('.')[1]  # Example tbl = prod_src_sst_mcdm_hcp_site_sales_ndc_monthly
            table = tbl.replace("prodsrc7_", "").replace("prod_stg_",
                                                         "")  # Example table = sst_mcdm_hcp_site_sales_ndc_monthly
            previous_table_name = table
            domain = ingestion_table.split('.')[2]

            staging_tbl = table  # Example  staging_tbl = sst_mcdm_hcp_site_sales_ndc_monthly
            historical_tbl_name = table  # Example  historical_tbl_name = sst_mcdm_hcp_site_sales_ndc_monthly

            if 'mars' not in table:
                tbl_name = 'mars_' + table  # Example   tbl_name = mars_sst_mcdm_hcp_site_sales_ndc_monthly
            else:
                tbl_name = table

            if 'staging' not in tbl_name:
                staging_tbl = tbl_name + '_staging'  # Example   staging_tbl = mars_sst_mcdm_hcp_site_sales_ndc_monthly_staging
            if 'historical' not in tbl_name:
                if 'staging' in tbl_name:
                    tbl_name = tbl_name[: -8]
                historical_tbl_name = tbl_name + '_historical'  # Example  historical_tbl_name = mars_sst_mcdm_hcp_site_sales_ndc_monthly_historical
            logger.info(f"{previous_table_name} --> {staging_tbl}")
            logger.info("Table folder : " + staging_tbl + "/" + historical_tbl_name)
            logger.info("Domain : " + domain)

            # Reading dataframes from Glue Catalog
            df = self.glue_context.create_data_frame.from_catalog(database=landing_database, table_name=table)
            for cols in df.columns:
                df = df.withColumnRenamed(cols, cols.lower())

            # Adding load date
            etl_df = df.withColumn('etl_load_date', current_timestamp())
            full_data_df = etl_df.persist()
            updated_row_cnt = full_data_df.count()

            if historical_tbl_name in existing_hist_table_names:
                hist_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                           table_name=historical_tbl_name)
                last_version = hist_df.select([max("version")]).head()[0]
                full_data_hist_df = full_data_df.withColumn('version', lit(int(last_version) + 1))
            else:  # This means table is new to staging, it is getting loaded into historical for first time
                full_data_hist_df = full_data_df.withColumn('version', lit(1))
                logger.info(f"Historical table does not exist for {historical_tbl_name} in normalized layer")

            # Calculating Audit info
            audit_info.append(
                {'table_name': f"{self.normalized_database}.{staging_tbl}", 'rows_updated': updated_row_cnt})
            audit_info.append(
                {'table_name': f"{self.normalized_database}.{historical_tbl_name}", 'rows_updated': updated_row_cnt})
            logger.info("Row counts for table " + table + " : " + str(updated_row_cnt))

            # Writing to staging layer and backup folders
            full_data_df.coalesce(8).write.mode('overwrite').parquet(
                "s3://" + self.bucket_name + "/" + staging_folder + "/" + domain + "/" + staging_tbl + "/")
            full_data_hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(
                "s3://" + self.bucket_name + "/" + staging_folder + "/" + domain + "/" + historical_tbl_name + "/")
            logger.info("Data has written to s3 for " + table + " as well as backup")

            # Adding to crawl table list
            self.s3_path_list += [
                "s3://" + self.bucket_name + "/" + staging_folder + "/" + domain + "/" + staging_tbl + "/"]
            self.s3_path_list += [
                "s3://" + self.bucket_name + "/" + staging_folder + "/" + domain + "/" + historical_tbl_name + "/"]

        logger.info("Writing to S3 is completed")
        return audit_info

    def create_update_crawler(self, client):
        """
        Crawler has to be created if it doesn't exist, if it exists then we have to update it s3 path for it.
        :param client: glue boto3 client used to create or update crawler
        """
        # Creating list of s3 path that has to be crawled
        s3_crawl_list = []
        for s3_path in list(set(self.s3_path_list)):
            s3_crawl_list.append(
                {"Path": s3_path, 'Exclusions': json.loads(self.config.get(self.env, "crawl_exclusion_paths"))})

        crawler_exist = True

        # Checking if crawler is already existing or not
        try:
            res = client.get_crawler(Name=self.crawler_name)
            response = json.dumps(res, indent=4, sort_keys=True, default=str)
            print(response)
        except client.exceptions.EntityNotFoundException as e:
            logger.info("Crawler doesnt exist, need to create")
            crawler_exist = False

        # Creating crawler if it doesn't exist
        if crawler_exist:
            response = client.update_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.normalized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Updated\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

        else:
            response = client.create_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.normalized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Created\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

    def start_crawler(self, client):
        """
        This method is used to start the crawler
        :param client: glue boto3 client used to create or update crawler
        """
        response_start = client.start_crawler(Name=self.crawler_name)
        logger.info("Crawler Started\nName : " + self.crawler_name)
        logger.info(json.dumps(response_start, indent=4, sort_keys=True, default=str))

    def monitor_crawler(self, client):
        """
        This method is used to monitor the crawler which we started just now
        :param client: glue boto3 client used to create or update crawler
        """
        need_to_wait = True
        state_previous = None
        while need_to_wait:
            time.sleep(20)
            response_get = client.get_crawler(Name=self.crawler_name)
            state = response_get["Crawler"]["State"]
            if state == "READY" or state == "STOPPING":  # Other known states: RUNNING
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                need_to_wait = False
                break
            if state != state_previous:
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                state_previous = state

    def tam_pccm_interactions(self, athena_client, spark):
        logger.info("Loading TAM PCCM Interactions Files into table")
        table_name = 'mars_tam_pccm_interactions'
        stg_table_name = table_name + '_staging'
        backup_table_name = table_name + '_historical'

        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        tam_pccm_interactions_df = (spark.read.format("csv")
                                    .option("header", "true")
                                    .load(self.config.get(self.env, "tam_pccm_interactions_file_path"))
                                    .selectExpr('`Zip Code (Zip5)` as zip_code', '`Product` as product',
                                                '`Interaction Date` as interaction_date',
                                                '`Interaction Type` as interaction_type',
                                                '`Topic Discussed` as topic_discussed',
                                                '`# of Patients` as number_of_patients',
                                                '`# of Interactions` as number_of_interactions')
                                    .withColumn('number_of_patients', col('number_of_patients').cast(DoubleType()))
                                    .withColumn('number_of_interactions',
                                                col('number_of_interactions').cast(DoubleType()))
                                    .withColumn("etl_load_date", current_timestamp().cast(TimestampType()))
                                    .withColumn("File_Interaction_Date", to_date(col('interaction_date'), 'M/d/yyyy')))
        logger.info("Row counts for old file " + str(tam_pccm_interactions_df.count()))

        tam_pccm_interactions_021925_df = (spark.read.format("csv")
                                           .option("header", "true")
                                           .load(self.config.get(self.env, "tam_pccm_interactions_file_021925_path"))
                                           .selectExpr('`Zip Code (Zip5)` as zip_code', '`Product` as product',
                                                       '`Interaction Date` as interaction_date',
                                                       '`Interaction Type` as interaction_type',
                                                       '`Topic Discussed` as topic_discussed',
                                                       '`# of Patients` as number_of_patients',
                                                       '`# of Interactions` as number_of_interactions')
                                           .withColumn('number_of_patients',
                                                       col('number_of_patients').cast(DoubleType()))
                                           .withColumn('number_of_interactions',
                                                       col('number_of_interactions').cast(DoubleType()))
                                           .withColumn("etl_load_date", current_timestamp().cast(TimestampType()))
                                           .withColumn("File_Interaction_Date",
                                                       to_date(col('interaction_date'), 'M/d/yyyy')))
        logger.info("Row counts for 021925 file " + str(tam_pccm_interactions_021925_df.count()))

        min_date_in_021925_file = tam_pccm_interactions_021925_df.select([min("File_Interaction_Date")]).head()[0]

        old_dates_df = tam_pccm_interactions_df.where(col('File_Interaction_Date') < min_date_in_021925_file)

        logger.info("Row counts for after filtering dates " + str(old_dates_df.count()))

        final_tam_pccm_df = old_dates_df.union(tam_pccm_interactions_021925_df).drop(col('File_Interaction_Date'))

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/" + 'tam' +
                   "/" + stg_table_name + "/")
        df = final_tam_pccm_df.persist()
        updated_row_cnt = df.count()
        logger.info("Row counts for table after union " + stg_table_name + " : " + str(updated_row_cnt))
        audit_info = [{'table_name': f"{self.normalized_database}.{stg_table_name}", 'rows_updated': updated_row_cnt}]
        df.coalesce(1).write.mode('overwrite').format('parquet').save(s3_path)
        self.s3_path_list += [s3_path]

        # Creating list of backup tables in normalized database
        existing_backup_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_backup_table_names.append(tbl_name)

        if backup_table_name in existing_backup_table_names:
            landing_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                          table_name=backup_table_name)
            last_version = landing_df.select([max("version")]).head()[0]
            hist_df = df.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = df.withColumn('version', lit(1))
            logger.info(f"Back up table does not exist for tam pccm interactions in landing layer")

        audit_info.append(
            {'table_name': f"{self.normalized_database}.{backup_table_name}",'rows_updated': updated_row_cnt})

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/" + 'tam' + 
                   "/" + backup_table_name + "/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info


def audit_job_info(spark_obj, job_srt_time, job_name, batch_id, audit_path, audit_dict):
    """
    This function is used to write audit stats of this etl job to athena table.
    :param audit_path:
    :param spark_obj:
    :param job_srt_time:
    :param job_name:
    :param batch_id:
    :param audit_dict:
    """
    if audit_dict is not None:
        logger.info("Writing completion stats to audit table")
        logger.info(audit_dict)
        audit_df = (spark_obj.createDataFrame(audit_dict)
                    .withColumn("log_id_status", lit("COMPLETED"))
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", current_timestamp().cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("etl_layer", lit("normalized"))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)
    else:
        logger.info("Writing initiating stats to audit table")
        audit_df = (spark_obj.createDataFrame([{'etl_layer': 'normalized', 'log_id_status': 'INITIATED'}])
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", lit(None).cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("table_name", lit(None).cast(StringType()))
                    .withColumn("rows_updated", lit(None).cast(IntegerType()))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)
        logger.info("Auditing is complete")


if __name__ == "__main__":
    # Getting AWS Glue job parameters, creating session and initiating job
    arg = getResolvedOptions(sys.argv,
                             ['JOB_NAME', 'environment', 'load_demographic_zip_ref_tables', 'load_sales_tables',
                              'load_xo_tables', 'load_speaker_tables', 'load_tam_tables', 'load_hcp_mdm_ref_tables',
                              'batch_id','load_tam_pccm'])

    logger.info("MARS Data Loading to Historical and Staging layer job started")

    environment = arg['environment']
    config_obj = read_config_file('configuration.ini')
    check_config_section(config_obj, environment)
    job_start_time = datetime.datetime.now()

    sc = SparkContext()
    glueContext = GlueContext(sc)
    sprk = glueContext.spark_session
    job = Job(glueContext)
    job.init(arg['JOB_NAME'], arg)

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'),
                   audit_dict=None)

    mars_data_loading = LoadStagingHistorical(config_obj, arg, glueContext)

    logger.info("Refreshing tables in staging layer")
    mars_data_loading.prep_table_load_list()

    athena_cl = boto3.client('athena', region_name="us-west-2")

    audit_list = []

    if arg['load_tam_pccm'] == 'True':
        logger.info("Refreshing TAM PCCM in normalized layer")
        audit_list += mars_data_loading.tam_pccm_interactions(athena_cl, sprk)

    audit_list += mars_data_loading.write_to_s3(athena_cl)

    crawler_client = boto3.client('glue', region_name="us-west-2")

    mars_data_loading.create_update_crawler(crawler_client)

    mars_data_loading.start_crawler(crawler_client)

    mars_data_loading.monitor_crawler(crawler_client)

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'),
                   audit_dict=audit_list)

    job.commit()
