import json
import logging
import configparser
import boto3
import sys
import time
from pyspark.sql.window import Window
from pyspark.sql import functions as F
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import *
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.types import *
import pandas as pd
from datetime import datetime
from cloudpathlib import S3Path

MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def read_config_file(config_file_name):
    """
    This function is reading config file and returning config object
    :type config_file_name: string
    """
    config = configparser.ConfigParser()
    config.read(config_file_name)
    return config


def check_config_section(config, env):
    """
    This function check if section specified in job parameters is present in config file or not
    :param config: Config file object
    :param env: environment which is specified in job parameters
    """
    if not config.has_section(env):
        raise Exception("Environment details doesn't exist in configuration file")


class FeatureCorrelations:
    def __init__(self, config, args, glue_context, spark):
        """
        This is init method used to initialize variables in class
        :param config: Config file object
        :param args: Arguments given to Glue job
        """

        self.env = args['environment']
        self.spark = spark
        self.speaker_event_landing_tbl = config.get(self.env, "event_tbl")
        self.args = args
        self.feature_combines_table = config.get(self.env, "feature_combines_table")
        self.feature_combines_hist_table = config.get(self.env, "feature_combines_hist_table")
        self.feature_combines_hist_version = config.get(self.env, "feature_combines_hist_version")
        self.bucket_name = config.get(self.env, "bucket_name")
        self.normalized_folder = json.loads(config.get(self.env, "folder_names"))['normalized']
        self.s3_path_list = []
        self.normalized_database = json.loads(config.get(self.env, "athena_database"))['normalized']
        self.summarized_database = json.loads(config.get(self.env, "athena_database"))['summarized']
        self.landing_database = json.loads(config.get(self.env, "athena_database"))['landing']
        self.config = config
        self.crawler_name = 'mars_normalized_ft_corr_crawler'
        self.glue_context = glue_context
        self.mars_product_names = "'" + "','".join(
            json.loads(self.config.get(self.env, "mars_product_names_list"))) + "'"
        self.correlation_dashboard_threshold = config.get(self.env, "correlation_dashboard_threshold")

    def create_update_crawler(self, client):
        """
        Crawler has to be created if it doesn't exist, if it exists then we have to update it s3 path for it.
        :param client: glue boto3 client used to create or update crawler
        """
        # Creating list of s3 path that has to be crawled
        s3_crawl_list = []
        for s3_path in list(set(self.s3_path_list)):
            s3_crawl_list.append(
                {"Path": s3_path, 'Exclusions': json.loads(self.config.get(self.env, "crawl_exclusion_paths"))})

        crawler_exist = True

        # Checking if crawler is already existing or not
        try:
            res = client.get_crawler(Name=self.crawler_name)
            response = json.dumps(res, indent=4, sort_keys=True, default=str)
            print(response)
        except client.exceptions.EntityNotFoundException as e:
            logger.info("Crawler doesnt exist, need to create")
            crawler_exist = False

        # Creating crawler if it doesn't exist
        if crawler_exist:
            response = client.update_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.normalized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Updated\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

        else:
            response = client.create_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.normalized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Created\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

    def start_crawler(self, client):
        """
        This method is used to start the crawler
        :param client: glue boto3 client used to create or update crawler
        """
        response_start = client.start_crawler(Name=self.crawler_name)
        logger.info("Crawler Started\nName : " + self.crawler_name)
        logger.info(json.dumps(response_start, indent=4, sort_keys=True, default=str))

    def monitor_crawler(self, client):
        """
        This method is used to monitor the crawler which we started just now
        :param client: glue boto3 client used to create or update crawler
        """
        need_to_wait = True
        state_previous = None
        while need_to_wait:
            time.sleep(20)
            response_get = client.get_crawler(Name=self.crawler_name)
            state = response_get["Crawler"]["State"]
            if state == "READY" or state == "STOPPING":  # Other known states: RUNNING
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                need_to_wait = False
                break
            if state != state_previous:
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                state_previous = state

    def feature_combined_correlations(self, athena_client):
        logger.info("Feature Correlation Job started")
        logger.info(
            f'Table name : {self.feature_combines_hist_table} Version : {str(self.feature_combines_hist_version)}')

        df_old = self.spark.sql(f"""
            select 
                product_brand_name,
                year_month,
                channel,
                audience,
                metric,
                value
            from {self.summarized_database}.{self.feature_combines_hist_table}
	    where version = '{str(self.feature_combines_hist_version)}'
            and upper(product_brand_name) in ({self.mars_product_names})
            and year_month between '202201' and '202406'
        """)

        df_new = self.spark.sql(f"""
            select 
                product_brand_name,
                year_month,
                channel,
                audience,
                metric,
                value
            from {self.summarized_database}.{self.feature_combines_table} 
            where upper(product_brand_name) in ({self.mars_product_names})
            and year_month between '202201' and '202406'
        """)

        df_old_agg = df_old.groupBy("product_brand_name", "year_month", "channel", "audience", "metric") \
            .agg(F.sum("value").alias("value_old"))

        df_new_agg = df_new.groupBy("product_brand_name", "year_month", "channel", "audience", "metric") \
            .agg(F.sum("value").alias("value_new"))

        df_joined = df_old_agg.join(df_new_agg,
                                    on=["product_brand_name", "year_month", "channel", "audience", "metric"],
                                    how="inner")

        df_corr = df_joined.groupBy("product_brand_name", "channel", "audience", "metric").agg(
            F.corr("value_old", "value_new").alias("correlation")
        )

        result_df = df_corr.select(
            "product_brand_name",
            "channel",
            "audience",
            "metric",
            "correlation"
        )
        result_df_cleaned = result_df.filter(F.col("correlation").isNotNull())

        df_final_agg_persisted = result_df_cleaned.persist()

        audit_info = []
        audit_info += [{'table_name': f"{self.normalized_database}.mars_feature_correlations_staging",
                        'rows_updated': df_final_agg_persisted.count()}]

        s3_path = (
                "s3://" + self.bucket_name + "/" + self.normalized_folder + "/etl/mars_feature_correlations_staging/")
        df_final_agg_persisted.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)

        if 'mars_feature_correlations_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                                table_name='mars_feature_correlations_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            final_agg_hist_df = df_final_agg_persisted.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to historical layer, it is getting loaded into historical for first time
            final_agg_hist_df = df_final_agg_persisted.withColumn('version', lit(1))
            logger.info(f"Back up table does not exist for mars_feature_correlations_historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_database}.mars_feature_correlations_historical",
             'rows_updated': df_final_agg_persisted.count()})

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/etl/" +
                   'mars_feature_correlations_historical' + "/")
        final_agg_hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        # Function calling to create Email attachment
        self.email_data(df_final_agg_persisted)

        return audit_info

    def email_data(self, df):
        """
        This function is used to create email attachment for correlation job
        :param df:
        """
        email_df = df.where(col('correlation') < float(self.correlation_dashboard_threshold))
        excel_filename = f"Correlation_{datetime.now().strftime('%Y-%b-%d_%H:%M')}.xlsx"
        with pd.ExcelWriter(excel_filename) as writer:
            email_df.toPandas().to_excel(writer, sheet_name='correlation', index=False)

        s3_client = boto3.resource('s3')
        S3_obj = S3Path(f's3://{self.bucket_name}/correlation_email_files/correlation_excel_consolidated/')
        s3_client.Object(S3_obj.bucket, S3_obj.key + excel_filename).upload_file(excel_filename)
        logger.info(f'Excel file path : {S3_obj.bucket}/{S3_obj.key}{excel_filename}')

        S3_obj = S3Path(f's3://{self.bucket_name}/correlation_email_files/correlation_excel_attachment/')
        s3_client.Object(S3_obj.bucket, S3_obj.key + 'Correlation_report.xlsx').upload_file(excel_filename)
        logger.info(f'Email Excel file path : {S3_obj.bucket}/{S3_obj.key}Correlation_report.xlsx')


def audit_job_info(spark_obj, job_srt_time, job_name, batch_id, audit_path, audit_dict):
    """
    This function is used to write audit stats of this etl job to athena table.
    :param audit_path:
    :param spark_obj:
    :param job_srt_time:
    :param job_name:
    :param batch_id:
    :param audit_dict:
    """
    logger.info("Writing to audit table")
    if audit_dict is not None:
        logger.info(audit_dict)
        audit_df = (spark_obj.createDataFrame(audit_dict)
                    .withColumn("log_id_status", lit("COMPLETED"))
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", current_timestamp().cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("etl_layer", lit("normalized_dq"))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)
    else:
        audit_df = (spark_obj.createDataFrame([{'etl_layer': 'normalized_dq', 'log_id_status': 'INITIATED'}])
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", lit(None).cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("table_name", lit(None).cast(StringType()))
                    .withColumn("rows_updated", lit(None).cast(IntegerType()))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)


if __name__ == "__main__":
    # Getting AWS Glue job parameters, creating session and initiating job
    arg = getResolvedOptions(sys.argv, ['JOB_NAME', 'environment', 'batch_id'])

    logger.info("MARS Feature Correlation Generation job started")

    environment = arg['environment']
    config_obj = read_config_file('configuration.ini')
    check_config_section(config_obj, environment)
    job_start_time = datetime.now()

    sc = SparkContext()
    glueContext = GlueContext(sc)
    sprk = glueContext.spark_session
    job = Job(glueContext)
    job.init(arg['JOB_NAME'], arg)
    sprk.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'), audit_dict=None)

    feature_tbl_corrs = FeatureCorrelations(config_obj, arg, glueContext, sprk)

    audit_list = []

    athena_cl = boto3.client('athena', region_name="us-west-2")

    audit_list += feature_tbl_corrs.feature_combined_correlations(athena_cl)

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'), audit_dict=audit_list)

    crawler_client = boto3.client('glue', region_name="us-west-2")

    feature_tbl_corrs.create_update_crawler(crawler_client)

    feature_tbl_corrs.start_crawler(crawler_client)

    feature_tbl_corrs.monitor_crawler(crawler_client)

    job.commit()
