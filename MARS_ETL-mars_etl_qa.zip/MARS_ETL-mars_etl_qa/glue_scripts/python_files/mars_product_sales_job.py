import json
import logging
import configparser
import boto3
import sys
import time
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import *
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.types import *
import datetime
from pyspark.sql.window import Window
from pyspark.sql.functions import udf

MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def read_config_file(config_file_name):
    """
    This function is reading config file and returning config object
    :type config_file_name: string
    """
    config = configparser.ConfigParser()
    config.read(config_file_name)
    return config


def check_config_section(config, env):
    """
    This function check if section specified in job parameters is present in config file or not
    :param config: Config file object
    :param env: environment which is specified in job parameters
    """
    if not config.has_section(env):
        raise Exception("Environment details doesn't exist in configuration file")


class ProductSales:
    def __init__(self, config, args, glue_context, spark):
        """
        This is init method used to initialize variables in class
        :param config: Config file object
        :param args: Arguments given to Glue job
        """
        self.env = args['environment']
        self.args = args
        self.bucket_name = config.get(self.env, "bucket_name")
        self.normalized_folder = json.loads(config.get(self.env, "folder_names"))['normalized']
        self.summarized_folder = json.loads(config.get(self.env, "folder_names"))['summarized']
        self.s3_path_list = []
        self.normalized_database = json.loads(config.get(self.env, "athena_database"))['normalized']
        self.summarized_database = json.loads(config.get(self.env, "athena_database"))['summarized']
        self.config = config
        self.crawler_name = 'mars_product_sales_etl_crawler'
        self.glue_context = glue_context
        self.spark = spark
        self.hcp_org_map_tbl = config.get(self.env, "hcp_org_map_tbl")
        self.sales_qty_tbl_stg = config.get(self.env, "sales_qty_tbl_stg")
        self.site_sales_table_stg_weekly = config.get(self.env, "sales_qty_tbl_stg_weekly")
        self.evrysdi_hcp_zip_tbl = config.get(self.env, "evrysdi_hcp_zip_tbl")

    def core(self, athena_client):
        df_hcp_org_mapping = self.spark.sql(f"""
            select
                mdm_id,
                product_brand_id,
                product_brand_name,
                mdm_zip
            from {self.normalized_database}.{self.hcp_org_map_tbl}
        """)
        df_hcp_org_mapping.registerTempTable('hcp_org_mapping')

        df_sales_ds = self.spark.sql(f"""
            select
                case when gne.product_brand_name in('ACTEMRA IV', 'ACTEMRA SC') then 'ACTEMRA' 
                            else gne.product_brand_name end as product_brand_name,
                gne.product_brand_id,
                product_description,
                product_id,
                cast(date_year_month as string) as year_month,
                gne_867_sales_qty_eqv,
                gne_867_effective_wac_sales_dollars as gross_sales_dollars,
                coalesce(hom.mdm_id, gne.mdm_id) as mdm_id,
                coalesce(hom.mdm_zip, gne.site_zip) as site_zip,
                -- sales qty with MCE logic
                case 
                    when hom.mdm_id is not null 
                        then gne_867_sales_qty_eqv else 0 end
                    as gne_867_sales_qty_eqv_inc,
                -- sales dollar amount with MCE logic
                case
                    when
                        hom.mdm_id is not null
                        then gne_867_effective_wac_sales_dollars
                    else 0
                end as gross_sales_dollars_inc
            from
                {self.normalized_database}.{self.site_sales_table_stg_weekly} as gne
            left join hcp_org_mapping as hom
                on
                    coalesce(gne.mdm_id, gne.site_mdm_id) = hom.mdm_id
                    and size(
                        array_intersect(
                            array(gne.product_brand_id), hom.product_brand_id
                        )
                    )
                    > 0
            where party_type != 'ORG'
        """)
        df_sales_ds.registerTempTable('sales_ds')

        df_org_sales = self.spark.sql(f"""
                    select
                        case when gne.product_brand_name in('ACTEMRA IV', 'ACTEMRA SC') then 'ACTEMRA' 
                            else gne.product_brand_name end as product_brand_name,
                        product_brand_id,
                        product_description,
                        product_id,
                        cast(date_year_month as string) as year_month,
                        gne_867_sales_qty_eqv,
                        mdm_id,
                        site_zip,
                        gne_867_effective_wac_sales_dollars as gross_sales_dollars,
                        gne_867_sales_qty_eqv as gne_867_sales_qty_eqv_inc,
                        gne_867_effective_wac_sales_dollars as gross_sales_dollars_inc
            from {self.normalized_database}.{self.site_sales_table_stg_weekly} as gne
            where party_type = 'ORG' and site_ecosystem_name != 'UNALIGNED'
                """)
        df_org_sales.registerTempTable('org_sales_ds')

        df_evrysdi_extra_hcps = self.spark.sql(f"""
            select
                case when gne.product_brand_name in('ACTEMRA IV', 'ACTEMRA SC') then 'ACTEMRA' 
                            else gne.product_brand_name end as product_brand_name,
                product_brand_id,
                product_description,
                product_id,
                cast(date_year_month as string) as year_month,
                gne_867_sales_qty_eqv,
                ev.mdm_id,
                ev.mdm_zip as site_zip,
                gne_867_effective_wac_sales_dollars as gross_sales_dollars,
                gne_867_sales_qty_eqv as gne_867_sales_qty_eqv_inc,
                gne_867_effective_wac_sales_dollars as gross_sales_dollars_inc
            from {self.normalized_database}.{self.site_sales_table_stg_weekly} as gne
            inner join 
                {self.normalized_database}.{self.evrysdi_hcp_zip_tbl} as ev
                on gne.mdm_id = ev.mdm_id
        """)
        df_evrysdi_extra_hcps.registerTempTable('evrysdi_extra_hcp_sales')
        # print("evrysdi_extra_hcp_sales : " + str(df_evrysdi_extra_hcps.count()))

        df_all_sales = self.spark.sql("""
            select
                product_brand_name,
                product_brand_id,
                product_description,
                product_id,
                year_month,
                gne_867_sales_qty_eqv,
                mdm_id,
                site_zip,
                gross_sales_dollars,
                gne_867_sales_qty_eqv_inc,
                gross_sales_dollars_inc
            from sales_ds
            union all
            select 
                product_brand_name,
                product_brand_id,
                product_description,
                product_id,
                year_month,
                gne_867_sales_qty_eqv,
                mdm_id,
                site_zip,
                gross_sales_dollars,
                gne_867_sales_qty_eqv_inc,
                gross_sales_dollars_inc
            from org_sales_ds
            union all
            select 
                product_brand_name,
                product_brand_id,
                product_description,
                product_id,
                year_month,
                gne_867_sales_qty_eqv,
                mdm_id,
                site_zip,
                gross_sales_dollars,
                gne_867_sales_qty_eqv_inc,
                gross_sales_dollars_inc
            from evrysdi_extra_hcp_sales
        """)
        df_all_sales.registerTempTable('all_sales')

        df_final_agg = self.spark.sql("""
            with final as(
                select
                    product_brand_name,
                    product_id,
                    max(product_description) as product_description,
                    year_month,
                    site_zip,
                    sum(gne_867_sales_qty_eqv) as sales_eqv_qty,
                    cast(sum(gross_sales_dollars) as double) as gross_sales_dollars,
                    sum(gne_867_sales_qty_eqv_inc) as sales_qty_eqv_mce_inc,
                    cast(sum(gross_sales_dollars_inc) as double)
                        as gross_sales_dollars_mce_inc
                from all_sales
                group by
                    product_id,
                    product_brand_name,
                    year_month,
                    site_zip
            )
            select * from final
        """)
        df_final_agg.registerTempTable('final_agg')

        df_final_agg_persisted = df_final_agg.persist()

        audit_info = []
        audit_info += [{'table_name': f"{self.summarized_database}.mars_product_sales",
                        'rows_updated': df_final_agg_persisted.count()}]

        s3_path = ("s3://" + self.bucket_name + "/" + self.summarized_folder + "/etl/mars_product_sales/")
        df_final_agg_persisted.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.summarized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)

        if 'mars_product_sales_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.summarized_database,
                                                                                table_name='mars_product_sales_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            final_agg_hist_df = df_final_agg_persisted.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to historical layer, it is getting loaded into historical for first time
            final_agg_hist_df = df_final_agg_persisted.withColumn('version', lit(1))
            logger.info(f"Back up table does not exist for mars_product_sales_historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.summarized_database}.mars_product_sales_historical",
             'rows_updated': df_final_agg_persisted.count()})

        s3_path = ("s3://" + self.bucket_name + "/" + self.summarized_folder + "/etl/" +
                  'mars_product_sales_historical' + "/")
        final_agg_hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def create_update_crawler(self, client):
        """
        Crawler has to be created if it doesn't exist, if it exists then we have to update it s3 path for it.
        :param client: glue boto3 client used to create or update crawler
        """
        # Creating list of s3 path that has to be crawled
        s3_crawl_list = []
        for s3_path in list(set(self.s3_path_list)):
            s3_crawl_list.append(
                {"Path": s3_path, 'Exclusions': json.loads(self.config.get(self.env, "crawl_exclusion_paths"))})

        crawler_exist = True

        # Checking if crawler is already existing or not
        try:
            res = client.get_crawler(Name=self.crawler_name)
            response = json.dumps(res, indent=4, sort_keys=True, default=str)
            print(response)
        except client.exceptions.EntityNotFoundException as e:
            logger.info("Crawler doesnt exist, need to create")
            crawler_exist = False

        # Creating crawler if it doesn't exist
        if crawler_exist:
            response = client.update_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.summarized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Updated\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

        else:
            response = client.create_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.summarized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Created\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

    def start_crawler(self, client):
        """
        This method is used to start the crawler
        :param client: glue boto3 client used to create or update crawler
        """
        response_start = client.start_crawler(Name=self.crawler_name)
        logger.info("Crawler Started\nName : " + self.crawler_name)
        logger.info(json.dumps(response_start, indent=4, sort_keys=True, default=str))

    def monitor_crawler(self, client):
        """
        This method is used to monitor the crawler which we started just now
        :param client: glue boto3 client used to create or update crawler
        """
        need_to_wait = True
        state_previous = None
        while need_to_wait:
            time.sleep(20)
            response_get = client.get_crawler(Name=self.crawler_name)
            state = response_get["Crawler"]["State"]
            if state == "READY" or state == "STOPPING":  # Other known states: RUNNING
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                need_to_wait = False
                break
            if state != state_previous:
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                state_previous = state


def audit_job_info(spark_obj, job_srt_time, job_name, batch_id, audit_path, audit_dict):
    """
    This function is used to write audit stats of this etl job to athena table.
    :param audit_path:
    :param spark_obj:
    :param job_srt_time:
    :param job_name:
    :param batch_id:
    :param audit_dict:
    """
    if audit_dict is not None:
        logger.info("Writing completion stats to audit table")
        logger.info(audit_dict)
        audit_df = (spark_obj.createDataFrame(audit_dict)
                    .withColumn("log_id_status", lit("COMPLETED"))
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", current_timestamp().cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("etl_layer", lit("summarized"))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)
        logger.info("Auditing is complete")
    else:
        logger.info("Writing initiating stats to audit table")
        audit_df = (spark_obj.createDataFrame([{'etl_layer': 'summarized', 'log_id_status': 'INITIATED'}])
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", lit(None).cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("table_name", lit(None).cast(StringType()))
                    .withColumn("rows_updated", lit(None).cast(IntegerType()))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)


if __name__ == "__main__":
    # Getting AWS Glue job parameters, creating session and initiating job
    arg = getResolvedOptions(sys.argv,
                             ['JOB_NAME', 'environment', 'batch_id'])

    logger.info("MARS Product Sales job started")

    environment = arg['environment']
    config_obj = read_config_file('configuration.ini')
    check_config_section(config_obj, environment)
    job_start_time = datetime.datetime.now()

    sc = SparkContext()
    glueContext = GlueContext(sc)
    sprk = glueContext.spark_session
    job = Job(glueContext)
    job.init(arg['JOB_NAME'], arg)

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'),
                   audit_dict=None)
    audit_list = []

    product_sales = ProductSales(config_obj, arg, glueContext, sprk)

    crawler_client = boto3.client('glue', region_name="us-west-2")

    athena_cl = boto3.client('athena', region_name="us-west-2")

    audit_list += product_sales.core(athena_cl)

    product_sales.create_update_crawler(crawler_client)

    product_sales.start_crawler(crawler_client)

    product_sales.monitor_crawler(crawler_client)

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'),
                   audit_dict=audit_list)

    job.commit()
