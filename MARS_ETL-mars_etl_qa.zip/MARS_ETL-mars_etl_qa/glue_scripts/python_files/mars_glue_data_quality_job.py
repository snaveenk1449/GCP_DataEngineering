import json
import logging
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import *
from awsglue.context import GlueContext
from awsglue.job import Job
from awsgluedq.transforms import EvaluateDataQuality
from awsglue.transforms import SelectFromCollection
from awsglue.dynamicframe import DynamicFrame
from datetime import datetime
import pandas as pd
import sys
import boto3
from cloudpathlib import S3Path

MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
logger = logging.getLogger()
logger.setLevel(logging.INFO)

if __name__ == "__main__":
    # Getting AWS Glue job parameters, creating session and initiating job
    arg = getResolvedOptions(sys.argv,
                             ['JOB_NAME', 'environment', 'batch_id', 'layer'])

    logger.info("AWS Data Quality Job started")

    sc = SparkContext()
    glueContext = GlueContext(sc)
    spark = glueContext.spark_session
    job = Job(glueContext)
    job.init(arg['JOB_NAME'], arg)

    config_json = json.load(open('data_quality_config.json'))
    # logger.info(config_json)
    first_df = True
    summary_df = None
    rule_outcome_cols = ['Rule', 'Outcome', 'FailureReason', 'EvaluatedMetrics', 'EvaluatedRule', 'DQ_Check_name']
    failed_dq_list = []
    excel_filename = f"DATA_Quality_{arg['layer']}_{datetime.now().strftime('%Y-%b-%d_%H:%M:%S')}.xlsx"
    with pd.ExcelWriter(excel_filename) as writer:

        for query in config_json['Custom_SQL']:
            try:
                if not query.get('Skip_DQ', False):
                    if query.get('DQ_layer', None) == arg['layer']:
                        logger.info(f"""{query['DQ_check_name']} Data Quality started""")
                        sql_df = spark.sql(query['DQ_sql'])
                        if sql_df.count() > 0:
                            EvaluateDataQuality_ruleset = query['DQ_ruleset']

                            EvaluateDataQualityMultiframe = EvaluateDataQuality().process_rows(
                                frame=DynamicFrame.fromDF(sql_df, glueContext, "sql_df"),
                                ruleset=EvaluateDataQuality_ruleset,
                                publishing_options={
                                    "dataQualityEvaluationContext": "EvaluateDataQualityMultiframe",
                                    "enableDataQualityCloudWatchMetrics": False,
                                    "enableDataQualityResultsPublishing": False,
                                },
                                additional_options={"performanceTuning.caching": "CACHE_NOTHING",
                                                    "compositeRuleEvaluation.method": "ROW"},
                            )

                            ruleOutcomes = SelectFromCollection.apply(
                                dfc=EvaluateDataQualityMultiframe,
                                key="ruleOutcomes",
                                transformation_ctx="ruleOutcomes",
                            )

                            ruleOutcomes_df = ruleOutcomes.toDF()
                            if first_df:
                                summary_df = (
                                    ruleOutcomes_df.withColumn("EvaluatedMetrics",
                                                               col("EvaluatedMetrics").cast("string"))
                                    .withColumn('DQ_Check_name', lit(query['DQ_check_name']))
                                    .withColumn('Sheet_Name', when("Failed" == col("Outcome"),
                                                                   lit(query['Sheet_name']))
                                                .otherwise(lit(None)))
                                    .selectExpr('Rule', 'DQ_Check_name', 'Outcome', 'FailureReason', 'EvaluatedMetrics',
                                                'EvaluatedRule', 'Sheet_Name'))
                                first_df = False
                            else:
                                summary_df = summary_df.union(ruleOutcomes_df
                                                              .withColumn("EvaluatedMetrics",
                                                                          col("EvaluatedMetrics").cast("string"))
                                                              .withColumn('DQ_Check_name', lit(query['DQ_check_name']))
                                                              .withColumn('Sheet_Name', when("Failed" == col("Outcome"),
                                                                                             lit(query['Sheet_name']))
                                                                          .otherwise(lit(None)))
                                                              .selectExpr('Rule', 'DQ_Check_name', 'Outcome',
                                                                          'FailureReason', 'EvaluatedMetrics',
                                                                          'EvaluatedRule', 'Sheet_Name'))

                            rowLevelOutcomes = SelectFromCollection.apply(
                                dfc=EvaluateDataQualityMultiframe,
                                key="rowLevelOutcomes",
                                transformation_ctx="rowLevelOutcomes",
                            )

                            rowLevelOutcomes_df = rowLevelOutcomes.toDF()
                            failed_rows = (rowLevelOutcomes_df
                                           .withColumn("DataQualityRulesPass",
                                                       concat_ws(",", col("DataQualityRulesPass")))
                                           .withColumn("DataQualityRulesFail",
                                                       concat_ws(",", col("DataQualityRulesFail")))
                                           .withColumn("DataQualityRulesSkip",
                                                       concat_ws(",", col("DataQualityRulesSkip")))
                                           .where(col('DataQualityEvaluationResult') == 'Failed'))

                            if failed_rows.count() > 0:
                                failed_rows.toPandas().to_excel(writer, sheet_name=query['Sheet_name'], index=False)

                        else:
                            logger.info("Row count of query is 0 so data can't be validated")
                            zero_rows_summary_df = spark.createDataFrame([('Zero rows in result set', 'Failed',
                                                                           'Zero rows are returned after Query execution',
                                                                           '',
                                                                           'Zero rows in result set',
                                                                           query['DQ_check_name'])],
                                                                         rule_outcome_cols)
                            if first_df:
                                summary_df = zero_rows_summary_df.withColumn('Sheet_Name',
                                                                             when("Failed" == col("Outcome"),
                                                                                  lit(query['Sheet_name']))
                                                                             .otherwise(lit(None))
                                                                             ).selectExpr('Rule', 'DQ_Check_name',
                                                                                          'Outcome', 'FailureReason',
                                                                                          'EvaluatedMetrics',
                                                                                          'EvaluatedRule', 'Sheet_Name')
                                first_df = False
                            else:
                                summary_df = summary_df.union(
                                    zero_rows_summary_df.withColumn('Sheet_Name', when("Failed" == col("Outcome"),
                                                                                       lit(query['Sheet_name']))
                                                                    .otherwise(lit(None)))
                                    .selectExpr('Rule', 'DQ_Check_name', 'Outcome', 'FailureReason', 'EvaluatedMetrics',
                                                'EvaluatedRule', 'Sheet_Name'))

                        logger.info(f"""{query['DQ_check_name']} Data Quality completed""")
                else:
                    zero_rows_summary_df = spark.createDataFrame([('Skip_DQ is Active', 'Skipped',
                                                                   'In configuration file Skip_DQ key is Active',
                                                                   '',
                                                                   'Skip_DQ is Active',
                                                                   query['DQ_check_name'])],
                                                                 rule_outcome_cols)
                    if first_df:
                        summary_df = zero_rows_summary_df.withColumn('Sheet_Name', when("Failed" == col("Outcome"),
                                                                                        lit(query['Sheet_name']))
                                                                     .otherwise(lit(None))
                                                                     ).selectExpr('Rule', 'DQ_Check_name', 'Outcome', 'FailureReason', 'EvaluatedMetrics', 'EvaluatedRule', 'Sheet_Name')
                        first_df = False
                    else:
                        summary_df = summary_df.union(
                            zero_rows_summary_df.withColumn('Sheet_Name', when("Failed" == col("Outcome"),
                                                                               lit(query['Sheet_name']))
                                                            .otherwise(lit(None)))
                            .selectExpr('Rule', 'DQ_Check_name', 'Outcome', 'FailureReason', 'EvaluatedMetrics', 'EvaluatedRule', 'Sheet_Name'))

            except Exception as error:
                logger.info(f"""{query['DQ_check_name']} Data Quality error encountered""")
                failed_dq_list.append(query['DQ_check_name'])
                failed_row_summary_df = spark.createDataFrame(
                    [('Exception occurred', 'Failed', str(type(error).__name__), '',
                      str(error), query['DQ_check_name'])],
                    rule_outcome_cols)
                if first_df:
                    summary_df = failed_row_summary_df.withColumn('Sheet_Name', when("Failed" == col("Outcome"),
                                                                                     lit(query['Sheet_name']))
                                                                  .otherwise(lit(None))
                                                                  ).selectExpr('Rule', 'DQ_Check_name', 'Outcome', 'FailureReason', 'EvaluatedMetrics', 'EvaluatedRule', 'Sheet_Name')
                    first_df = False
                else:
                    summary_df = summary_df.union(
                        failed_row_summary_df.withColumn('Sheet_Name', when("Failed" == col("Outcome"),
                                                                            lit(query['Sheet_name']))
                                                         .otherwise(lit(None)))
                        .selectExpr('Rule', 'DQ_Check_name', 'Outcome', 'FailureReason', 'EvaluatedMetrics', 'EvaluatedRule', 'Sheet_Name'))

        for table in config_json['Std_Checks']:

            try:
                if not table.get('Skip_DQ', False):
                    if table['DQ_layer'] == arg['layer']:
                        logger.info(f"""{table['db_name'] + '.' + table['table_name']} Data Quality started""")
                        table_dynamic_frame = glueContext.create_dynamic_frame.from_catalog(database=table['db_name'],
                                                                                            table_name=table[
                                                                                                'table_name'], )
                        if table_dynamic_frame.count() > 0:
                            EvaluateDataQuality_ruleset = (table['DQ_ruleset'])

                            EvaluateDataQualityMultiframe = EvaluateDataQuality().process_rows(
                                frame=table_dynamic_frame,
                                ruleset=EvaluateDataQuality_ruleset,
                                publishing_options={
                                    "dataQualityEvaluationContext": "EvaluateDataQualityMultiframe",
                                    "enableDataQualityCloudWatchMetrics": False,
                                    "enableDataQualityResultsPublishing": False,
                                },
                                additional_options={"performanceTuning.caching": "CACHE_NOTHING",
                                                    "compositeRuleEvaluation.method": "ROW"},
                            )

                            ruleOutcomes = SelectFromCollection.apply(
                                dfc=EvaluateDataQualityMultiframe,
                                key="ruleOutcomes",
                                transformation_ctx="ruleOutcomes",
                            )

                            ruleOutcomes_df = ruleOutcomes.toDF()
                            if first_df:
                                summary_df = (
                                    ruleOutcomes_df.withColumn("EvaluatedMetrics",
                                                               col("EvaluatedMetrics").cast("string"))
                                    .withColumn('DQ_Check_name', lit(table['db_name'] + '.' + table['table_name']))
                                    .withColumn('Sheet_Name', when("Failed" == col("Outcome"),
                                                                   lit(table['Sheet_name']))
                                                .otherwise(lit(None)))
                                    .selectExpr('Rule', 'DQ_Check_name', 'Outcome', 'FailureReason', 'EvaluatedMetrics', 'EvaluatedRule', 'Sheet_Name'))
                                first_df = False
                            else:
                                summary_df = summary_df.union(ruleOutcomes_df
                                                              .withColumn("EvaluatedMetrics",
                                                                          col("EvaluatedMetrics").cast("string"))
                                                              .withColumn('Sheet_Name', when("Failed" == col("Outcome"),
                                                                                             lit(table['Sheet_name']))
                                                                          .otherwise(lit(None)))
                                                              .withColumn('DQ_Check_name',
                                                                          lit(table['db_name'] + '.' + table[
                                                                              'table_name']))
                                                              .selectExpr('Rule', 'DQ_Check_name', 'Outcome', 'FailureReason', 'EvaluatedMetrics', 'EvaluatedRule', 'Sheet_Name'))

                            rowLevelOutcomes = SelectFromCollection.apply(
                                dfc=EvaluateDataQualityMultiframe,
                                key="rowLevelOutcomes",
                                transformation_ctx="rowLevelOutcomes",
                            )

                            rowLevelOutcomes_df = rowLevelOutcomes.toDF()
                            failed_rows = (rowLevelOutcomes_df
                                           .withColumn("DataQualityRulesPass",
                                                       concat_ws(",", col("DataQualityRulesPass")))
                                           .withColumn("DataQualityRulesFail",
                                                       concat_ws(",", col("DataQualityRulesFail")))
                                           .withColumn("DataQualityRulesSkip",
                                                       concat_ws(",", col("DataQualityRulesSkip")))
                                           .where(col('DataQualityEvaluationResult') == 'Failed'))
                            if failed_rows.count() > 0:
                                failed_rows.toPandas().to_excel(writer, sheet_name=table['Sheet_name'], index=False)
                        else:
                            logger.info("Row count of query is 0 so data can't be validated")
                            # rule_outcome_cols = ['Rule', 'Outcome', 'FailureReason', 'EvaluatedMetrics',
                            #                      'EvaluatedRule', 'DQ_Check_name']

                            zero_rows_summary_df = spark.createDataFrame([('Zero rows in table', 'Failed',
                                                                           'Zero rows are returned after reading table',
                                                                           '',
                                                                           'Zero rows in table', table['table_name'])],
                                                                         rule_outcome_cols)
                            if first_df:
                                summary_df = zero_rows_summary_df.withColumn('Sheet_Name',
                                                                             when("Failed" == col("Outcome"),
                                                                                  lit(table['Sheet_name']))
                                                                             .otherwise(lit(None))
                                                                             ).selectExpr('Rule', 'DQ_Check_name', 'Outcome', 'FailureReason', 'EvaluatedMetrics', 'EvaluatedRule', 'Sheet_Name')
                            else:
                                summary_df = summary_df.union(
                                    zero_rows_summary_df.withColumn('Sheet_Name', when("Failed" == col("Outcome"),
                                                                                       lit(table['Sheet_name']))
                                                                    .otherwise(lit(None)))
                                    .selectExpr('Rule', 'DQ_Check_name', 'Outcome', 'FailureReason', 'EvaluatedMetrics', 'EvaluatedRule', 'Sheet_Name'))

                        logger.info(f"""{table['db_name'] + '.' + table['table_name']} Data Quality completed""")
                else:
                    zero_rows_summary_df = spark.createDataFrame([('Skip_DQ is Active', 'Skipped',
                                                                   'In configuration file Skip_DQ key is Active',
                                                                   '',
                                                                   'Skip_DQ is Active',
                                                                   table['db_name'] + '.' + table['table_name']
                                                                   )],
                                                                 rule_outcome_cols)
                    if first_df:
                        summary_df = zero_rows_summary_df.withColumn('Sheet_Name', when("Failed" == col("Outcome"),
                                                                                        lit(table['Sheet_name']))
                                                                     .otherwise(lit(None))
                                                                     ).selectExpr('Rule', 'DQ_Check_name', 'Outcome', 'FailureReason', 'EvaluatedMetrics', 'EvaluatedRule', 'Sheet_Name')
                        first_df = False
                    else:
                        summary_df = summary_df.union(
                            zero_rows_summary_df.withColumn('Sheet_Name', when("Failed" == col("Outcome"),
                                                                               lit(table['Sheet_name']))
                                                            .otherwise(lit(None)))
                            .selectExpr('Rule', 'DQ_Check_name', 'Outcome', 'FailureReason', 'EvaluatedMetrics', 'EvaluatedRule', 'Sheet_Name'))
            except Exception as error:
                logger.info(f"""{table['db_name'] + '.' + table['table_name']} Data Quality error encountered""")
                failed_dq_list.append(table['db_name'] + '.' + table['table_name'])
                failed_row_summary_df = spark.createDataFrame(
                    [('Exception occurred', 'Failed', str(type(error).__name__), '',
                      str(error), table['db_name'] + '.' + table['table_name'])],
                    rule_outcome_cols)
                if first_df:
                    summary_df = failed_row_summary_df.withColumn('Sheet_Name', when("Failed" == col("Outcome"),
                                                                                     lit(table['Sheet_name']))
                                                                  .otherwise(lit(None))
                                                                  ).selectExpr('Rule', 'DQ_Check_name', 'Outcome', 'FailureReason', 'EvaluatedMetrics', 'EvaluatedRule', 'Sheet_Name')
                    first_df = False
                else:
                    summary_df = summary_df.union(
                        failed_row_summary_df.withColumn('Sheet_Name', when("Failed" == col("Outcome"),
                                                                            lit(table['Sheet_name']))
                                                         .otherwise(lit(None)))
                        .selectExpr('Rule', 'DQ_Check_name', 'Outcome', 'FailureReason', 'EvaluatedMetrics', 'EvaluatedRule', 'Sheet_Name'))

        summary_rows = (summary_df
                        .withColumn("EvaluatedMetrics", col("EvaluatedMetrics").cast("string"))
                        .selectExpr('Rule', 'DQ_Check_name', 'Outcome', 'FailureReason', 'EvaluatedMetrics', 'EvaluatedRule', 'Sheet_Name'))
        if summary_rows.count() > 0:
            # summary_rows.show()
            summary_rows.toPandas().to_excel(writer, sheet_name='Summary', index=False)

    s3_client = boto3.resource('s3')
    S3_obj = S3Path(config_json['DQ_detailed_report_path'])
    s3_client.Object(S3_obj.bucket, S3_obj.key + excel_filename).upload_file(excel_filename)
    logger.info(f'Excel file path : {S3_obj.bucket}/{S3_obj.key + excel_filename}')

    S3_obj = S3Path(f"""{config_json['DQ_detailed_report_path']}data_quality_report_attachment/""")
    s3_client.Object(S3_obj.bucket, S3_obj.key + f"""DQ_report_{arg['layer']}.xlsx""").upload_file(excel_filename)
    logger.info(f"""Excel file path : {S3_obj.bucket}/{S3_obj.key}DQ_report_{arg['layer']}.xlsx""")

    if failed_dq_list:
        raise Exception(
            f"This is the list of Data Quality checks that has thrown an error while execution: {str(failed_dq_list)}")
