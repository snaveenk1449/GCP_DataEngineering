import json
import logging
import configparser
import boto3
import sys
import time
from pyspark.sql.window import Window
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import *
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.types import *
import datetime

MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def read_config_file(config_file_name):
    """
    This function is reading config file and returning config object
    :type config_file_name: string
    """
    config = configparser.ConfigParser()
    config.read(config_file_name)
    return config


def check_config_section(config, env):
    """
    This function check if section specified in job parameters is present in config file or not
    :param config: Config file object
    :param env: environment which is specified in job parameters
    """
    if not config.has_section(env):
        raise Exception("Environment details doesn't exist in configuration file")


class HcpOrgMapping:
    def __init__(self, config, args, glue_context, spark):
        """
        This is init method used to initialize variables in class
        :param config: Config file object
        :param args: Arguments given to Glue job
        """
        self.env = args['environment']
        self.args = args
        self.bucket_name = config.get(self.env, "bucket_name")
        self.normalized_folder = json.loads(config.get(self.env, "folder_names"))['normalized']
        self.s3_path_list = []
        self.normalized_database = json.loads(config.get(self.env, "athena_database"))['normalized']
        self.config = config
        self.crawler_name = 'mars_hcp_org_mapping_crawler'
        self.glue_context = glue_context
        self.mstr_cm_mdm_prfl_wkl_tbl = config.get(self.env, "mstr_cm_mdm_prfl_wkl_tbl")
        self.alignment_brnd_crdt_rls_tbl = config.get(self.env, "alignment_brnd_crdt_rls_tbl")
        self.hcp_outlet_affl_wkl_tbl = config.get(self.env, "hcp_outlet_affl_wkl_tbl")
        self.mstr_cm_org_prfl_wkl_tbl = config.get(self.env, "mstr_cm_org_prfl_wkl_tbl")
        self.zip_to_eco_dly_tbl = config.get(self.env, "zip_to_eco_dly_tbl")
        self.spark = spark

    def core(self, athena_client):

        mdm_zip_ds_df = self.spark.sql(f"""select distinct
        mdm_id, mdm_zip, filter( array_distinct( array(primary_phyn_spcl_code, secondary_phyn_spcl_code) ), s -> s is not null ) as spcl_codes
        from {self.normalized_database}.{self.mstr_cm_mdm_prfl_wkl_tbl}
        where party_type = 'IND'""")
        mdm_zip_ds_df.registerTempTable("mdm_zip_ds")

        all_product_incl_codes_df = self.spark.sql(f"""select
        product_brand_name, product_brand_id, array_agg(code) as prod_codes
        from {self.normalized_database}.{self.alignment_brnd_crdt_rls_tbl}
        where upper(trim(exception_type)) in('INCLUDE', 'ALWAYS INCLUDE') and product_flag_competitor = 'N' and source_data = 'XPO'
        group by product_brand_name, product_brand_id""")
        all_product_incl_codes_df.registerTempTable('all_product_incl_codes')

        actemra_standardized_df = self.spark.sql("""select 
        product_brand_id, prod_codes, case when  product_brand_name IN('ACTEMRA IV', 'ACTEMRA SC') then 'ACTEMRA'
        else product_brand_name end as product_brand_name
        from all_product_incl_codes
        """)
        actemra_standardized_df.registerTempTable('actemra_standardized')

        mce_incl_mdm_ds_df = self.spark.sql("""select distinct
        mz.mdm_id, mz.mdm_zip, array_distinct(array_sort(array_agg(pic.product_brand_id))) as product_brand_id,
        array_distinct(array_sort(array_agg(pic.product_brand_name))) as product_brand_name
        from mdm_zip_ds as mz
        cross join actemra_standardized as pic
        where cardinality(array_intersect(mz.spcl_codes, pic.prod_codes)) > 0
        group by mz.mdm_id, mz.mdm_zip
        """)
        mce_incl_mdm_ds_df.registerTempTable("mce_incl_mdm_ds")

        hcp_site_df = self.spark.sql(f"""select distinct
        hcp_outlet_mdm_id as mdm_id, site_zip as mdm_zip
        from {self.normalized_database}.{self.hcp_outlet_affl_wkl_tbl}
        where flag_primary_affiliation = 'Y' and hcp_outlet_mdm_id is not null
        and upper(affiliation_status) = 'ACTIVE'""")
        hcp_site_df.registerTempTable("hcp_site")

        hcp_site_master_ds_df = self.spark.sql("""select distinct
        m.mdm_id, m.product_brand_id, m.product_brand_name, 'HCP' as mdm_type,
        coalesce(hs.mdm_zip, m.mdm_zip) as mdm_zip 
        from mce_incl_mdm_ds as m left join hcp_site as hs 
        on m.mdm_id = hs.mdm_id""")
        hcp_site_master_ds_df.registerTempTable("hcp_site_master_ds")

        org_site_df = self.spark.sql(f"""select distinct
        org_mdm_id as mdm_id, org_zip as mdm_zip, 'SITE' as mdm_type, 
        array_distinct(array_sort(array_agg(pic.product_brand_id))) as product_brand_id,
        array_distinct(array_sort(array_agg(pic.product_brand_name))) as product_brand_name
        from {self.normalized_database}.{self.mstr_cm_org_prfl_wkl_tbl}
        cross join all_product_incl_codes as pic
        group by org_mdm_id, org_zip""")
        org_site_df.registerTempTable('org_site')

        hcp_org_df = self.spark.sql("""select
        mdm_id, mdm_zip, product_brand_id, product_brand_name, mdm_type
        from hcp_site_master_ds
        union
        select
        mdm_id, mdm_zip, product_brand_id, product_brand_name, mdm_type
        from org_site""")
        hcp_org_df.registerTempTable('hcp_org')

        zip_eco_map_df = self.spark.sql(f"""select distinct
        zip, state, ecosystem_dim_id, ecosystem_name
        from {self.normalized_database}.{self.zip_to_eco_dly_tbl}
        where
        flag_active = 'Y' and ecosystem_dim_id > 0""")
        zip_eco_map_df.registerTempTable('zip_eco_map')

        hcp_org_map_df = self.spark.sql("""select distinct
        ho.mdm_id, ho.mdm_zip, ho.product_brand_id, ho.product_brand_name,
        zem.ecosystem_name, zem.ecosystem_dim_id, ho.mdm_type
        from hcp_org as ho inner join zip_eco_map as zem 
        on ho.mdm_zip = zem.zip""")
        hcp_org_map_df.registerTempTable("hcp_org_map")

        final_ds_df = self.spark.sql("""select distinct
        mdm_id, product_brand_id, product_brand_name, mdm_zip, ecosystem_name, ecosystem_dim_id, mdm_type
        from hcp_org_map""")
        final_ds_df.registerTempTable("final_ds")

        hcp_org_map_df_persist = final_ds_df.persist()

        audit_info = []
        audit_info += [{'table_name': f"{self.normalized_database}.mars_hcp_org_mapping_staging",
                        'rows_updated': hcp_org_map_df_persist.count()}]

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/hcp_ref/" +
                   'mars_hcp_org_mapping_staging' + "/")
        hcp_org_map_df_persist.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        evrysdi_extra_hcps_df = self.spark.sql(f"""select
        mdm_id, mdm_zip
        from {self.normalized_database}.{self.mstr_cm_mdm_prfl_wkl_tbl}
        where mdm_id in ('324903', '647970', '2025213', '23546250')
        """)
        evrysdi_extra_hcps_df.registerTempTable("evrysdi_extra_hcps")

        evrysdi_extra_hcp_sites_df = self.spark.sql(f"""select distinct
        hcp_outlet_mdm_id as mdm_id, site_zip as mdm_zip
        from {self.normalized_database}.{self.hcp_outlet_affl_wkl_tbl}
        where
        flag_primary_affiliation = 'Y' and hcp_outlet_mdm_id is not null and upper(affiliation_status) = 'ACTIVE'
        """)
        evrysdi_extra_hcp_sites_df.registerTempTable('evrysdi_hcp_sites')

        evrysdi_extra_hcp_zips_df = self.spark.sql("""select distinct
        e.mdm_id, coalesce(es.mdm_zip, e.mdm_zip) as mdm_zip
        from evrysdi_extra_hcps as e
        left join evrysdi_hcp_sites as es 
        on e.mdm_id = es.mdm_id""")
        evrysdi_extra_hcp_zips_df.registerTempTable('evrysdi_extra_hcp_zips')
        evrysdi_extra_hcp_zips_df_persist = evrysdi_extra_hcp_zips_df.persist()

        audit_info += [{'table_name': f"{self.normalized_database}.mars_evrysdi_extra_hcp_zips_staging",
                        'rows_updated': evrysdi_extra_hcp_zips_df_persist.count()}]

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/hcp_ref/" +
                   'mars_evrysdi_extra_hcp_zips_staging' + "/")
        evrysdi_extra_hcp_zips_df_persist.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)

        if 'mars_evrysdi_extra_hcp_zips_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                                table_name='mars_evrysdi_extra_hcp_zips_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            evrysdi_extra_hcp_zips_hist_df = evrysdi_extra_hcp_zips_df_persist.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            evrysdi_extra_hcp_zips_hist_df = evrysdi_extra_hcp_zips_df_persist.withColumn('version', lit(1))
            logger.info(
                f"Back up table does not exist for mars evrysdi extra hcp zips historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_database}.mars_evrysdi_extra_hcp_zips_historical",
             'rows_updated': evrysdi_extra_hcp_zips_df_persist.count()})

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/hcp_ref/" +
                   'mars_evrysdi_extra_hcp_zips_historical' + "/")
        evrysdi_extra_hcp_zips_hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        if 'mars_hcp_org_mapping_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                                table_name='mars_hcp_org_mapping_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            hcp_org_map_hist_df = hcp_org_map_df_persist.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hcp_org_map_hist_df = hcp_org_map_df_persist.withColumn('version', lit(1))
            logger.info(
                f"Back up table does not exist for mars zip org mapping historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_database}.mars_hcp_org_mapping_historical",
             'rows_updated': evrysdi_extra_hcp_zips_df_persist.count()})

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/hcp_ref/" +
                   'mars_hcp_org_mapping_historical' + "/")
        hcp_org_map_hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def create_update_crawler(self, client):
        """
        Crawler has to be created if it doesn't exist, if it exists then we have to update it s3 path for it.
        :param client: glue boto3 client used to create or update crawler
        """
        # Creating list of s3 path that has to be crawled
        s3_crawl_list = []
        for s3_path in list(set(self.s3_path_list)):
            s3_crawl_list.append(
                {"Path": s3_path, 'Exclusions': json.loads(self.config.get(self.env, "crawl_exclusion_paths"))})

        crawler_exist = True

        # Checking if crawler is already existing or not
        try:
            res = client.get_crawler(Name=self.crawler_name)
            response = json.dumps(res, indent=4, sort_keys=True, default=str)
            print(response)
        except client.exceptions.EntityNotFoundException as e:
            logger.info("Crawler doesnt exist, need to create")
            crawler_exist = False

        # Creating crawler if it doesn't exist
        if crawler_exist:
            response = client.update_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.normalized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Updated\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

        else:
            response = client.create_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.normalized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Created\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

    def start_crawler(self, client):
        """
        This method is used to start the crawler
        :param client: glue boto3 client used to create or update crawler
        """
        response_start = client.start_crawler(Name=self.crawler_name)
        logger.info("Crawler Started\nName : " + self.crawler_name)
        logger.info(json.dumps(response_start, indent=4, sort_keys=True, default=str))

    def monitor_crawler(self, client):
        """
        This method is used to monitor the crawler which we started just now
        :param client: glue boto3 client used to create or update crawler
        """
        need_to_wait = True
        state_previous = None
        while need_to_wait:
            time.sleep(20)
            response_get = client.get_crawler(Name=self.crawler_name)
            state = response_get["Crawler"]["State"]
            if state == "READY" or state == "STOPPING":  # Other known states: RUNNING
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                need_to_wait = False
                break
            if state != state_previous:
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                state_previous = state


def audit_job_info(spark_obj, job_srt_time, job_name, batch_id, audit_path, audit_dict):
    """
    This function is used to write audit stats of this etl job to athena table.
    :param audit_path:
    :param spark_obj:
    :param job_srt_time:
    :param job_name:
    :param batch_id:
    :param audit_dict:
    """
    logger.info("Writing to audit table")
    if audit_dict is not None:
        logger.info(audit_dict)
        audit_df = (spark_obj.createDataFrame(audit_dict)
                    .withColumn("log_id_status", lit("COMPLETED"))
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", current_timestamp().cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("etl_layer", lit("normalized"))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)
    else:
        audit_df = (spark_obj.createDataFrame([{'etl_layer': 'normalized', 'log_id_status': 'INITIATED'}])
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", lit(None).cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("table_name", lit(None).cast(StringType()))
                    .withColumn("rows_updated", lit(None).cast(IntegerType()))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)


if __name__ == "__main__":
    # Getting AWS Glue job parameters, creating session and initiating job
    arg = getResolvedOptions(sys.argv, ['JOB_NAME', 'environment', 'batch_id'])

    logger.info("MARS HCP Org Mapping job started")

    environment = arg['environment']
    config_obj = read_config_file('configuration.ini')
    check_config_section(config_obj, environment)
    job_start_time = datetime.datetime.now()

    sc = SparkContext()
    glueContext = GlueContext(sc)
    sprk = glueContext.spark_session
    job = Job(glueContext)
    job.init(arg['JOB_NAME'], arg)
    sprk.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'), audit_dict=None)

    hcp_org_mapping = HcpOrgMapping(config_obj, arg, glueContext, sprk)

    audit_list = []

    athena_cl = boto3.client('athena', region_name="us-west-2")

    audit_list += hcp_org_mapping.core(athena_cl)

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'), audit_dict=audit_list)

    crawler_client = boto3.client('glue', region_name="us-west-2")

    hcp_org_mapping.create_update_crawler(crawler_client)

    hcp_org_mapping.start_crawler(crawler_client)

    hcp_org_mapping.monitor_crawler(crawler_client)

    job.commit()
