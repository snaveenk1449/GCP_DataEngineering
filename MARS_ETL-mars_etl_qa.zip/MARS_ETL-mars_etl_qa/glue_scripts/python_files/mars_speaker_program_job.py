import json
import logging
import configparser
import boto3
import sys
import time
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import *
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.types import *
import datetime
from pyspark.sql.window import Window
from pyspark.sql.functions import udf

MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def read_config_file(config_file_name):
    """
    This function is reading config file and returning config object
    :type config_file_name: string
    """
    config = configparser.ConfigParser()
    config.read(config_file_name)
    return config


def check_config_section(config, env):
    """
    This function check if section specified in job parameters is present in config file or not
    :param config: Config file object
    :param env: environment which is specified in job parameters
    """
    if not config.has_section(env):
        raise Exception("Environment details doesn't exist in configuration file")


class SpeakerETL:
    def __init__(self, config, args, glue_context, spark):
        """
        This is init method used to initialize variables in class
        :param config: Config file object
        :param args: Arguments given to Glue job
        """
        self.env = args['environment']
        self.args = args
        self.bucket_name = config.get(self.env, "bucket_name")
        self.normalized_folder = json.loads(config.get(self.env, "folder_names"))['normalized']
        self.s3_path_list = []
        self.normalized_database = json.loads(config.get(self.env, "athena_database"))['normalized']
        self.summarized_database = json.loads(config.get(self.env, "athena_database"))['summarized']
        self.config = config
        self.crawler_name = 'mars_speaker_etl_crawler'
        self.glue_context = glue_context
        self.spark = spark
        self.landing_database = json.loads(config.get(self.env, "athena_database"))['landing']
        self.zip_to_eco_dly_tbl = config.get(self.env, "zip_to_eco_dly_tbl")
        self.mars_spkr_evnts_dly_stg = config.get(self.env, "mars_spkr_evnts_dly_stg")
        self.mars_spkr_evnts_curriculm_dly_stg = config.get(self.env, "mars_spkr_evnts_curriculm_dly_stg")
        self.non_assoc_brands = config.get(self.env, "non_assoc_brands")
        self.alignment_emp_dim_daily_staging = config.get(self.env, "alignment_emp_dim_daily_staging")
        self.hcp_org_map_tbl = config.get(self.env, "hcp_org_map_tbl")
        self.speaker_bureau_participants_daily_staging = config.get(self.env, "speaker_bureau_participants_daily_staging")
        self.mars_population_demographics_staging = config.get(self.env, "mars_population_demographics_staging")
    def core(self, athena_client):
        df_zip_eco_map = self.spark.sql(f"""
            select
                zip,
                ecosystem_name, 
                ecosystem_dim_id        
            from {self.normalized_database}.{self.zip_to_eco_dly_tbl}
            where flag_active = 'Y' and ecosystem_dim_id > 0
        """)
        df_zip_eco_map.registerTempTable('zip_eco_map')

        df_speaker_evt_acct = self.spark.sql(f"""
            select distinct
                unix_id,
                fedex_zip
            from {self.normalized_database}.{self.alignment_emp_dim_daily_staging}
        """)
        df_speaker_evt_acct.registerTempTable('speaker_evt_acct')

        df_training_costs = self.spark.sql(f"""
            select
                sum(cast(event_total_cost as double)) as total_training_cost
            from {self.normalized_database}.{self.mars_spkr_evnts_dly_stg}
            where upper(event_sub_type) = 'TRAINING'
        """)
        df_training_costs.registerTempTable('training_cost')

        df_raw_evts = self.spark.sql(f"""
            select distinct
                event_vendor_id,
                event_start_date,
                'speaker_program' as channel,
                case 
                    when upper(event_sub_type) != 'TRAINING' 
                    then cast(sb.event_total_cost as double) 
                    else 0 
                end as event_total_cost,
                case 
                    when upper(event_sub_type) != 'TRAINING' 
                    then customers_attended
                    else 0
                end as customers_attended,
                coalesce(substr(sb.site_postal_code,1,3),substr(azem.zip,1,3)) as zip3_code,
                coalesce(sb.site_postal_code,azem.zip) as zip5_code,
                coalesce(zem.ecosystem_name, azem.ecosystem_name) as ecosystem_name,
                coalesce(zem.ecosystem_dim_id, azem.ecosystem_dim_id) as ecosystem_dim_id,
                event_type,event_format,setting_type,
                upper(event_status) as event_status,
                case
                    when upper(event_status) in ('CLOSED', 'OCCURRED')
                    then cast(patients_attended as double)
                    else 0
                end as patients_attended,
                case 
                    when upper(event_sub_type) = 'PATIENT' and (lower(event_format) like '%virtual%' or lower(setting_type) like '%virtual%') --virtual events for patients should be at a national level 
                    then 'national'
                    when upper(event_type) = 'PRODUCT THEATER' and upper(event_sub_type) = 'PATIENT' --pdt events for patients should be eco
                    then 'ecosystem'
                    when upper(event_type) in ('NATIONAL BROADCAST', 'GPO') and upper(event_sub_type) = 'PATIENT' --national events for patient should be at a national level
                    then 'national'
                    when upper(event_sub_type) != 'PATIENT' -- HCP events for everything should be at a zip level
                    then 'zip'
                    else 'zip' 
                end as event_level,
                cast(year(event_start_date) as string) || lpad(cast(month(event_start_date) as string), 2, '0') as year_month,
                case when upper(event_sub_type) = 'PATIENT' then 'DTC' else 'HCP' end as audience
            from {self.normalized_database}.{self.mars_spkr_evnts_dly_stg} as sb
            left join zip_eco_map as zem on sb.site_postal_code = zem.zip
            left join speaker_evt_acct as sea on sb.accountable_unix_id = sea.unix_id
            left join zip_eco_map as azem on sea.fedex_zip = azem.zip
            where
                upper(event_status) not in ('DROPPED', 'PENDING')
                and (
                    cast(sb.event_total_cost as double)
                    + patients_attended
                    + customers_attended
                ) > 0
                and event_start_date < current_date
                and upper(event_sub_type) != 'TRAINING'
        """)
        df_raw_evts.registerTempTable('raw_evts')

        df_adjusted_raw_evts = self.spark.sql("""
            select
                re.*,
                re.event_total_cost + (tc.total_training_cost / count(*) over()) as adjusted_event_total_cost
            from raw_evts re
            cross join training_cost tc
        """)
        df_adjusted_raw_evts.registerTempTable('adjusted_raw_evts')

        df_evt_curricula = self.spark.sql(f"""
            with evt_curricula as (
                select event_vendor_id,product_brand_name,product_brand_id from (
                    select * from (select distinct
                        s.event_vendor_id,
                        coalesce(upper(n.brand), s.product_brand_name) AS product_brand_name,
                        s.product_brand_id,
                        s.curriculum_prc_code
                    from {self.normalized_database}.{self.mars_spkr_evnts_curriculm_dly_stg} s
                    left join {self.normalized_database}.{self.non_assoc_brands} n
                    on s.curriculum_prc_code = n.curriculum_prc_code
                    where (n.curriculum_prc_code is not null
                    or upper(s.product_brand_name) != 'NOT ASSOCIATED')
                ) )
                where curriculum_prc_code !='M-US-00005290(v3.0)'
                union 
                select event_vendor_id,product_brand_name,product_brand_id from (
                    select distinct
                        s.event_vendor_id,
                        coalesce(upper(n.brand), s.product_brand_name) AS product_brand_name,
                        s.product_brand_id,
                        s.curriculum_prc_code
                    from {self.normalized_database}.{self.mars_spkr_evnts_curriculm_dly_stg} s
                    left join (
                        select 
                            curriculum_prc_code,
                            explode(split(brand, ';')) AS brand
                        from {self.normalized_database}.{self.non_assoc_brands} 
                        where curriculum_prc_code = 'M-US-00005290(v3.0)'
                    ) n
                    on s.curriculum_prc_code = n.curriculum_prc_code
                    where n.curriculum_prc_code is not null
                    or upper(s.product_brand_name) != 'NOT ASSOCIATED'
                ) 
                where curriculum_prc_code ='M-US-00005290(v3.0)'
            )
            select * from evt_curricula
        """)
        df_evt_curricula.registerTempTable('evt_curricula')

        df_evt_curricula_cnt = self.spark.sql("""
            select distinct
                event_vendor_id,
                product_brand_name,
                product_brand_id,
                count(product_brand_id) over (partition by event_vendor_id) as product_count
            from evt_curricula
        """)
        df_evt_curricula_cnt.registerTempTable('evt_curricula_cnt')

        df_evt_ds = self.spark.sql("""
            select distinct
                re.event_vendor_id,
                re.event_start_date,
                re.channel,
                ec.product_brand_name,
                ec.product_brand_id,
                re.zip3_code,
                re.zip5_code,
                re.ecosystem_dim_id,
                re.ecosystem_name, 
                re.event_type,
                re.event_format,
                re.setting_type,
                re.event_status,
                re.patients_attended,
                re.customers_attended,
                re.event_level,
                re.year_month,
                re.audience,
                re.adjusted_event_total_cost / ec.product_count as event_total_cost,
                case
                    when audience = 'DTC' and customers_attended > 0
                    then patients_attended / (patients_attended + customers_attended)
                end as patient_cost_share,
                case
                    when audience = 'DTC' and customers_attended > 0
                    then customers_attended / (patients_attended + customers_attended)
                end as hcp_cost_share
            from adjusted_raw_evts as re
            inner join evt_curricula_cnt as ec
            on re.event_vendor_id = ec.event_vendor_id
        """)
        df_evt_ds.registerTempTable('evt_ds')

        df_patient_evts = self.spark.sql("""
            select distinct
                event_vendor_id,
                year_month,
                product_brand_name,
                product_brand_id,
                zip3_code,
                ecosystem_dim_id,
                ecosystem_name, 
                event_type,
                event_format,
                setting_type,
                event_level,
                channel,
                patients_attended as reach,
                audience,
                patient_cost_share,
                case
                    when patient_cost_share > 0
                    then patient_cost_share * event_total_cost
                    else event_total_cost
                end as event_total_cost
            from evt_ds
            where audience = 'DTC'
        """)
        df_patient_evts.registerTempTable('patient_evts')

        df_dtc_evts_rollup = self.spark.sql("""
            select distinct
                year_month,
                product_brand_name,
                product_brand_id,
                zip3_code,
                ecosystem_name,
                ecosystem_dim_id,
                event_level,
                channel,
                audience,
                case
                    when event_level = 'ecosystem'
                    then sum(reach) over (partition by product_brand_name, year_month, event_level, ecosystem_name)
                    when event_level = 'national'
                    then sum(reach) over (partition by product_brand_name, year_month, event_level)
                else sum(reach) over (partition by product_brand_name, year_month, event_level, zip3_code)
                end as reach,
                case
                    when event_level = 'ecosystem'
                    then sum(event_total_cost) over (partition by product_brand_name, year_month, event_level, ecosystem_name)
                    when event_level = 'national'
                    then sum(event_total_cost) over (partition by product_brand_name, year_month, event_level)
                else sum(event_total_cost) over (partition by product_brand_name, year_month, event_level, zip3_code)
                end as cost
            from patient_evts
        """)
        df_dtc_evts_rollup.registerTempTable('dtc_evts_rollup')

        df_hcp_evts = self.spark.sql("""
            select distinct
                event_vendor_id,
                year_month,
                product_brand_name,
                product_brand_id,
                zip5_code,
                event_type,
                event_format,
                setting_type,
                event_status,
                'zip' as event_level,  
                channel,
                'HCP' as audience,
                case
                    when hcp_cost_share > 0
                    then hcp_cost_share * event_total_cost
                    else event_total_cost
                end as event_total_cost
            from evt_ds
            where audience = 'HCP' or customers_attended > 0
        """)
        df_hcp_evts.registerTempTable('hcp_evts')

        df_hcp_eco_map = self.spark.sql(f"""
            select distinct
                mdm_id,
                product_brand_id,
                product_brand_name,
                ecosystem_dim_id,
                mdm_zip
            from {self.normalized_database}.{self.hcp_org_map_tbl}
            where mdm_type = 'HCP'
        """)
        df_hcp_eco_map.registerTempTable('incl_hcp_eco_map')

        df_incl_hcp_evts = self.spark.sql(f"""
            select distinct
                he.event_vendor_id,
                he.year_month,
                sp.participant_mdm_id as mdm_id,
                he.product_brand_name,
                he.product_brand_id,
                coalesce(ihem.mdm_zip, he.zip5_code, sp.participant_postal_code) as zip5_code,
                he.event_type,
                he.event_format,
                he.setting_type,
                he.event_level,
                he.channel,
                he.audience
            from hcp_evts as he
            inner join {self.normalized_database}.{self.speaker_bureau_participants_daily_staging} as sp
                on he.event_vendor_id = sp.event_vendor_id
            inner join incl_hcp_eco_map as ihem
                on sp.participant_mdm_id = ihem.mdm_id
                and size(array_intersect(array(he.product_brand_name), ihem.product_brand_name)) > 0
            where
                he.event_status in ('CLOSED', 'OCCURRED')
                and upper(sp.participant_role) = 'ATTENDEE'
                and upper(coalesce(attendance, 'No')) != 'NO'
        """)
        df_incl_hcp_evts.registerTempTable('incl_hcp_evts')

        df_hcp_cnts = self.spark.sql("""
            select distinct
                event_vendor_id,
                year_month,
                product_brand_name,
                zip5_code,
                event_level,
                audience,
                channel,
                count(mdm_id) over (partition by event_vendor_id, year_month, product_brand_name, zip5_code) as reach,
                count(mdm_id) over (partition by event_vendor_id) as total_reach
            from incl_hcp_evts
        """)
        df_hcp_cnts.registerTempTable('hcp_cnts')

        df_all_hcp_evts = self.spark.sql("""
            select distinct
                he.event_vendor_id,
                he.year_month,
                he.product_brand_name,
                he.event_level,
                he.audience,
                he.channel,
                he.event_total_cost,
                coalesce(her.zip5_code, he.zip5_code) as zip5_code,
                coalesce(her.reach, 0) as reach,
                coalesce(her.total_reach, 0) as total_reach
            from hcp_evts as he
            left join hcp_cnts as her
                on he.event_vendor_id = her.event_vendor_id
        """)
        df_all_hcp_evts.registerTempTable('all_hcp_evts')

        df_hcp_evts_rollup = self.spark.sql("""
            with all_hcp_evts_cost_breakdown as (
                select distinct
                    event_vendor_id,
                    year_month,
                    product_brand_name,
                    event_level,
                    audience,
                    channel,
                    zip5_code,
                    reach,
                    total_reach,
                    case
                        when reach + total_reach = 0 then event_total_cost 
                        else event_total_cost * reach / total_reach
                    end as event_total_cost
                from all_hcp_evts
            ),
            hcp_evts_rollup as (
                select distinct
                    year_month,
                    product_brand_name,
                    event_level,
                    channel,
                    audience,
                    zip5_code,
                    sum(reach) over (partition by product_brand_name, year_month, zip5_code) as reach,
                    sum(event_total_cost) over (partition by product_brand_name, year_month, zip5_code) as cost
                from all_hcp_evts_cost_breakdown
            )
            select * from hcp_evts_rollup
        """)
        df_hcp_evts_rollup.registerTempTable('hcp_evts_rollup')

        df_pop_wts = self.spark.sql(f"""
            select distinct
                zip3 as zip3_code,
                zip as zip5_code,
                sum(wt_zip5_total) over (partition by zip3) as zip3_weight,
                wt_zip5_total as zip5_weight,
                wt_eco_total as ecosystem_weight,
                ecosystem_dim_id
            from {self.summarized_database}.{self.mars_population_demographics_staging}
        """)
        df_pop_wts.registerTempTable('pop_wts')

        df_wt_dtc_zip_evts = self.spark.sql("""
            select distinct
                ee.year_month,
                ee.product_brand_name,
                pw.zip5_code as zip,
                ee.event_level,
                ee.channel,
                ee.audience,
                ee.reach * (pw.zip5_weight / pw.zip3_weight) as reach,
                ee.cost * (pw.zip5_weight / pw.zip3_weight) as cost
            from dtc_evts_rollup as ee
            inner join (
                select *,
                    zip5_weight / sum(zip5_weight) over (partition by zip3_code) as normalized_weight
                from pop_wts
            ) pw on ee.zip3_code = pw.zip3_code
            where ee.event_level = 'zip'
        """)
        df_wt_dtc_zip_evts.registerTempTable('wt_dtc_zip_evts')

        df_wt_dtc_eco_evts = self.spark.sql("""
            select distinct
                year_month,
                product_brand_name,
                pw.zip5_code as zip,
                ee.event_level,
                channel,
                audience,
                reach * pw.ecosystem_weight as reach,
                round(cost * pw.ecosystem_weight, 2) as cost
            from dtc_evts_rollup as ee
            inner join pop_wts as pw on ee.ecosystem_dim_id = pw.ecosystem_dim_id
            where ee.event_level = 'ecosystem'
        """)
        df_wt_dtc_eco_evts.registerTempTable('wt_dtc_eco_evts')

        df_wt_dtc_natl_evts = self.spark.sql("""
            select distinct
                ne.year_month,
                ne.product_brand_name,
                pw.zip5_code as zip,
                ne.event_level,
                ne.channel,
                ne.audience,
                ne.reach * pw.zip5_weight as reach,
                round(ne.cost * pw.zip5_weight, 2) as cost
            from dtc_evts_rollup as ne
            cross join pop_wts as pw
            where ne.event_level = 'national'
        """)
        df_wt_dtc_natl_evts.registerTempTable('wt_dtc_natl_evts')

        df_all_evts_wt = self.spark.sql("""
            select * from wt_dtc_zip_evts
            union all
            select * from wt_dtc_eco_evts
            union all
            select * from wt_dtc_natl_evts
            union all
            select 
                year_month,
                product_brand_name,
                zip5_code as zip,
                event_level,
                channel,
                audience,
                reach,
                cost
            from hcp_evts_rollup
        """)
        df_all_evts_wt.registerTempTable('all_evts_wt')

        df_final_agg = self.spark.sql("""
                with agg_data as (
                    select distinct
                        year_month,
                        product_brand_name,
                        zip,
                        channel,
                        audience,
                        sum(reach) over (partition by year_month, product_brand_name, audience, zip) as reach,
                        round(sum(cost) over (partition by year_month, product_brand_name, audience, zip), 2) as cost
                    from all_evts_wt
                )
                select *, current_date as etl_load_date from agg_data where zip is not null
        """)
        df_final_agg.registerTempTable('final_agg')

        df_final_agg_persisted = df_final_agg.persist()

        audit_info = []
        audit_info += [{'table_name': f"{self.normalized_database}.mars_speaker_staging",
                        'rows_updated': df_final_agg_persisted.count()}]

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/etl/mars_speaker_staging/")
        df_final_agg_persisted.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)

        if 'mars_speaker_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                                table_name='mars_speaker_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            hcp_count_hist_df = df_final_agg_persisted.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hcp_count_hist_df = df_final_agg_persisted.withColumn('version', lit(1))
            logger.info(f"Back up table does not exist for mars speaker program historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_database}.mars_speaker_historical",
             'rows_updated': df_final_agg_persisted.count()})

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/etl/" +
                   'mars_speaker_historical' + "/")
        hcp_count_hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def create_update_crawler(self, client):
        """
        Crawler has to be created if it doesn't exist, if it exists then we have to update it s3 path for it.
        :param client: glue boto3 client used to create or update crawler
        """
        # Creating list of s3 path that has to be crawled
        s3_crawl_list = []
        for s3_path in list(set(self.s3_path_list)):
            s3_crawl_list.append(
                {"Path": s3_path, 'Exclusions': json.loads(self.config.get(self.env, "crawl_exclusion_paths"))})

        crawler_exist = True

        # Checking if crawler is already existing or not
        try:
            res = client.get_crawler(Name=self.crawler_name)
            response = json.dumps(res, indent=4, sort_keys=True, default=str)
            print(response)
        except client.exceptions.EntityNotFoundException as e:
            logger.info("Crawler doesnt exist, need to create")
            crawler_exist = False

        # Creating crawler if it doesn't exist
        if crawler_exist:
            response = client.update_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.normalized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Updated\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

        else:
            response = client.create_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.normalized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Created\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

    def start_crawler(self, client):
        """
        This method is used to start the crawler
        :param client: glue boto3 client used to create or update crawler
        """
        response_start = client.start_crawler(Name=self.crawler_name)
        logger.info("Crawler Started\nName : " + self.crawler_name)
        logger.info(json.dumps(response_start, indent=4, sort_keys=True, default=str))

    def monitor_crawler(self, client):
        """
        This method is used to monitor the crawler which we started just now
        :param client: glue boto3 client used to create or update crawler
        """
        need_to_wait = True
        state_previous = None
        while need_to_wait:
            time.sleep(20)
            response_get = client.get_crawler(Name=self.crawler_name)
            state = response_get["Crawler"]["State"]
            if state == "READY" or state == "STOPPING":  # Other known states: RUNNING
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                need_to_wait = False
                break
            if state != state_previous:
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                state_previous = state


def audit_job_info(spark_obj, job_srt_time, job_name, batch_id, audit_path, audit_dict):
    """
    This function is used to write audit stats of this etl job to athena table.
    :param audit_path:
    :param spark_obj:
    :param job_srt_time:
    :param job_name:
    :param batch_id:
    :param audit_dict:
    """
    if audit_dict is not None:
        logger.info("Writing completion stats to audit table")
        logger.info(audit_dict)
        audit_df = (spark_obj.createDataFrame(audit_dict)
                    .withColumn("log_id_status", lit("COMPLETED"))
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", current_timestamp().cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("etl_layer", lit("normalized"))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)
        logger.info("Auditing is complete")
    else:
        logger.info("Writing initiating stats to audit table")
        audit_df = (spark_obj.createDataFrame([{'etl_layer': 'normalized', 'log_id_status': 'INITIATED'}])
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", lit(None).cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("table_name", lit(None).cast(StringType()))
                    .withColumn("rows_updated", lit(None).cast(IntegerType()))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)


if __name__ == "__main__":
    # Getting AWS Glue job parameters, creating session and initiating job
    arg = getResolvedOptions(sys.argv,
                             ['JOB_NAME', 'environment', 'batch_id'])

    logger.info("MARS Speaker job started")

    environment = arg['environment']
    config_obj = read_config_file('configuration.ini')
    check_config_section(config_obj, environment)
    job_start_time = datetime.datetime.now()

    sc = SparkContext()
    glueContext = GlueContext(sc)
    sprk = glueContext.spark_session
    job = Job(glueContext)
    job.init(arg['JOB_NAME'], arg)

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'),
                   audit_dict=None)
    audit_list = []

    speaker_etl = SpeakerETL(config_obj, arg, glueContext, sprk)

    crawler_client = boto3.client('glue', region_name="us-west-2")

    athena_cl = boto3.client('athena', region_name="us-west-2")

    audit_list += speaker_etl.core(athena_cl)

    speaker_etl.create_update_crawler(crawler_client)

    speaker_etl.start_crawler(crawler_client)

    speaker_etl.monitor_crawler(crawler_client)

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'),
                   audit_dict=audit_list)

    job.commit()
