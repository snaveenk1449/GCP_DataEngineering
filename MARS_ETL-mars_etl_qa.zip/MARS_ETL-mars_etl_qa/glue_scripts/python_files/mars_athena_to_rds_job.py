import configparser
import json
import boto3
import logging
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import *

MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def read_table_from_athena(database, table_name, glue_context, query=None):
    """
    Method to read data from Athena table
    :param query:
    :param database: Database name in athena
    :param table_name: Table name in Athena
    :param glue_context: Glue Context
    :return:
    """
    try:
        logger.info(f'Reading from {table_name}')
        if query is None:
            logger.info("Reading from complete table for" + table_name)
            return glue_context.create_data_frame.from_catalog(database=database, table_name=table_name)
        else:
            logger.info("Reading from query for table " + table_name)
            logger.info(f"""Query : {query}""")
            return glue_context.sql(query)
    except Exception as e:
        logger.error(f'Failed to read from table, {database}.{table_name} : {str(e)}')
        raise e


def write_df_to_rds_table(df, connection_details, table, schema, partitions):
    """
    Method to write df into postgreSQL DB
    :param df: Data frame that is to be written into db
    :param connection_details: Connection Creds in dict
    :param table: table name that is to be written to db
    :param schema: Schema name where data is to be written
    """
    try:
        logger.info(f'Writing to {table}')
        mode = "append"
        properties = {"user": connection_details['USERNAME'], "password": connection_details['PASSWORD'],
                      "driver": "org.postgresql.Driver"}
                      # "batchsize": str(int(partitions) * 1600), "numPartitions": str(partitions)
                      
        df.repartition(int(partitions)).write.jdbc(url=connection_details['JDBC_CONNECTION_URL'],
                                                   table=schema + '.' + table,
                                                   mode=mode,
                                                   properties=properties)

        logger.info(f'Writing to {table} is completed')
    except Exception as e:
        logger.error(f'Error occurred: {str(e)}')
        raise e


def read_config_file(config_file_name):
    """
    This function is reading config file and returning config object
    :type config_file_name: string
    """
    try:
        if not config_file_name:
            raise ValueError("Config file name cannot be empty")
        config = configparser.ConfigParser()
        config.read(config_file_name)
        return config
    except Exception as e:
        logger.error(f'Error occurred {str(e)}')
        raise e


def check_config_section(config, env):
    """
    This function check if section specified in job parameters is present in config file or not
    :param config: Config file object
    :param env: environment which is specified in job parameters
    """
    if not config.has_section(env):
        raise Exception("Environment details doesn't exist in configuration file")


if __name__ == "__main__":
    # Getting AWS Glue job parameters, creating session and initiating job
    args = getResolvedOptions(sys.argv, ['JOB_NAME', 'rds_connection', 'environment'])

    environment = args['environment']
    config_obj = read_config_file('configuration.ini')
    check_config_section(config_obj, environment)

    sc = SparkContext()
    glueContext = GlueContext(sc)
    sprk = glueContext.spark_session
    job = Job(glueContext)
    job.init(args['JOB_NAME'], args)

    client = boto3.client('glue')
    rds_connection = args["rds_connection"]
    response = client.get_connection(Name=rds_connection, HidePassword=False)

    connection = response['Connection']['ConnectionProperties']

    database_name = json.loads(config_obj.get(environment, "athena_database"))['summarized']
    try:
        table_mars_sales = 'mars_pivot'
        mars_pivot_df = read_table_from_athena(database_name, table_mars_sales, glueContext)
        write_df_to_rds_table(mars_pivot_df, connection, table_mars_sales, 'mars_us', '8')
    except Exception as e:
        logger.error(f"Error processing mars_pivot: {str(e)}")
        raise e

    try:
        table_mars_sales = 'mars_sales'
        mars_sales_df = read_table_from_athena(database_name, table_mars_sales, glueContext)
        write_df_to_rds_table(mars_sales_df, connection, table_mars_sales, 'mars_us', '8')
    except Exception as e:
        logger.error(f"Error processing mars_sales: {str(e)}")
        raise e

    try:
        table_mars_sales = 'mars_net_sales'
        mars_net_sales_df = read_table_from_athena(database_name, table_mars_sales, glueContext)
        write_df_to_rds_table(mars_net_sales_df, connection, table_mars_sales, 'mars_us', '8')
    except Exception as e:
        logger.error(f"Error processing mars_net_sales: {str(e)}")
        raise e

    try:
        table_mars_sales = 'mars_creative_costs'
        mars_creative_costs_df = read_table_from_athena(database_name, table_mars_sales, glueContext)
        write_df_to_rds_table(mars_creative_costs_df, connection, table_mars_sales, 'mars_us', '1')
    except Exception as e:
        logger.error(f"Error processing mars_creative_costs: {str(e)}")
        raise e

    try:
        table_mars_sales = 'mars_population_demographics'
        mars_population_demographics_df = read_table_from_athena(database_name, table_mars_sales, glueContext)
        write_df_to_rds_table(mars_population_demographics_df, connection, table_mars_sales, 'mars_us', '1')
    except Exception as e:
        logger.error(f"Error processing mars_population_demographics: {str(e)}")
        raise e

    # try:
    #     table_mars_feature_combined = 'mars_feature_combined'
    #     query = f"""select * from {database_name}.{table_mars_feature_combined} where year_month in ('202408','202409','202410','202411','202412')"""
    #     mars_feature_combined_df = read_table_from_athena(database_name, table_mars_feature_combined, glueContext,
    #                                                       query)
    #     write_df_to_rds_table(mars_feature_combined_df, connection, table_mars_feature_combined, 'mars_us', '8')
    # except Exception as e:
    #     logger.error(f"Error processing mars_population_demographics: {str(e)}")
    #     raise e

    job.commit()
