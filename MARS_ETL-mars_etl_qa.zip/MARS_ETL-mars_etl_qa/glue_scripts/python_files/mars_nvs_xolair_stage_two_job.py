import json
import logging
import configparser
import boto3
import sys
import time
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import *
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.types import *
import datetime
from pyspark.sql.window import Window
from pyspark.sql.functions import udf
from pyspark.sql import functions as F
from pyspark.sql.types import StringType
import re

MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def read_config_file(config_file_name):
    """
    This function is reading config file and returning config object
    :type config_file_name: string
    """
    config = configparser.ConfigParser()
    config.read(config_file_name)
    return config


def check_config_section(config, env):
    """
    This function check if section specified in job parameters is present in config file or not
    :param config: Config file object
    :param env: environment which is specified in job parameters
    """
    if not config.has_section(env):
        raise Exception("Environment details doesn't exist in configuration file")


class XOETLNVS:
    def __init__(self, config, args, glue_context, spark):
        """
        This is init method used to initialize variables in class
        :param config: Config file object
        :param args: Arguments given to Glue job
        """
        self.env = args['environment']
        self.args = args
        self.bucket_name = config.get(self.env, "bucket_name")
        self.normalized_folder = json.loads(config.get(self.env, "folder_names"))['normalized']
        self.s3_path_list = []
        self.normalized_database = json.loads(config.get(self.env, "athena_database"))['normalized']
        self.summarized_database = json.loads(config.get(self.env, "athena_database"))['summarized']
        self.config = config
        self.crawler_name = 'mars_nvs_digital_etl_crawler'
        self.glue_context = glue_context
        self.spark = spark
        self.landing_database = json.loads(config.get(self.env, "athena_database"))['landing']
        self.mars_population_demographics_staging = config.get(self.env, "population_demo_tbl")
        self.mars_all_city_weights_stg = config.get(self.env, "mars_all_city_weights_stg")
        self.mars_dma_state_code_stg = config.get(self.env, "mars_dma_state_code_stg")
        self.nvs_mars_combined_nvs_data_staging = config.get(self.env, "mars_combined_nvs_data_staging")
        
    def core(self, athena_client):
        df_xo_raw_ds = self.spark.sql(f"""
            select distinct
                brand,
                channel,
                audience,
                month,
                year,
                lpad(zip_code, 5, '0') as zip_code,
                upper(trim(dma)) as dma,
                country,
                reach,
                engage,
                cost,
                case
                    when state like '%District%' then 'District of Columbia' else state
                end as state
            from {self.normalized_database}.{self.nvs_mars_combined_nvs_data_staging}
        """)
        df_xo_raw_ds.registerTempTable('xo_raw_ds')

        df_zips_weights = self.spark.sql(f"""
            select distinct
                zip,
                dma_code,
                dma_name,
                county,
                state,
                state_name,
                dma_state_count,
                total_population,
                total_pop_18_49,
                total_pop_f_18_49,
                total_pop_50_99,
                wt_zip5_total,
                wt_zip5_18_49,
                wt_zip5_f_18_49,
                wt_zip5_50_99,
                wt_county_total,
                wt_county_18_49,
                wt_county_f_18_49,
                wt_county_50_99,
                wt_dma_total,
                wt_dma_18_49,
                wt_dma_f_18_49,
                wt_dma_50_99,
                wt_state_total,
                wt_state_18_49,
                wt_state_f_18_49,
                wt_state_50_99,
                wt_dma_state_total,
                wt_dma_state_18_49,
                wt_dma_state_f_18_49,
                wt_dma_state_50_99
            from {self.summarized_database}.{self.mars_population_demographics_staging}
            where state is not null
        """)
        df_zips_weights.registerTempTable('zips_weights')

        df_city_weights = self.spark.sql(f"""
            select distinct
                zip,
                regexp_replace(
                    regexp_replace(
                        city,
                        '(AIR\s+FORCE\s+BASE|AIR\s+RESERVE\s+BASE|A\s+F\s+B)',
                        'AFB'
                    ),
                    '(TWP)',
                    'TOWNSHIP'
                ) as city,
                state,
                state_name,
                total_population,
                total_pop_18_49,
                total_pop_f_18_49,
                total_pop_50_99,
                wt_city_total,
                wt_city_18_49,
                wt_city_f_18_49,
                wt_city_50_99
            from
            {self.normalized_database}.{self.mars_all_city_weights_stg}
        """)
        df_city_weights.registerTempTable('city_weights')

        df_state_values = self.spark.sql("""
            select distinct
                state,
                state_name
            from zips_weights
        """)
        df_state_values.registerTempTable('state_values')

        df_xo_norm_stg_1 = self.spark.sql("""
            select distinct
                xd.audience,
                xd.zip_code,
                dma,
                xd.country,
                cast(xd.reach as DOUBLE) as reach,
                cast(xd.engage as DOUBLE) as engage,
                cast(xd.cost as DOUBLE) as cost,
                concat(xd.year, lpad(xd.month, 2, '0')) as year_month,
                upper(trim(xd.brand)) as brand,
                lower(regexp_replace(xd.channel, '[^A-Za-z0-9]+', '_')) as channel,
                case
                    when upper(trim(dma)) = 'MC CONNELSVILLE' then 'MCCONNELSVILLE'
                    when upper(trim(dma)) = 'MC KEESPORT' then 'MCKEESPORT'
                    when upper(trim(dma)) in ('NATIONAL', 'PUERTO RICO', 'UNCLASSIFIED', 'UNKNOWN', 'UNASSIGNED', 'OTHER VERIFIED') then null
                    when dma like '%COUNTY%' then trim(split(dma, 'COUNTY')[0])
                    when regexp_replace(upper(trim(dma)), '\\s+', ' ') in ('JACKSON, MS', 'JACKSON MS') or 
                         (regexp_replace(upper(trim(dma)), '\\s+', ' ') = 'JACKSON' and upper(trim(coalesce(sz.state, xd.state))) = 'MS') then 'JACKSON, MS'
                    when regexp_replace(upper(trim(dma)), '\\s+', ' ') in ('JACKSON, TN', 'JACKSON TN') or 
                         (regexp_replace(upper(trim(dma)), '\\s+', ' ') = 'JACKSON' and upper(trim(coalesce(sz.state, xd.state))) = 'TN') then 'JACKSON, TN'
                    when upper(trim(dma)) != 'SANTA FE' and dma rlike '^[a-zA-Z0-9 ]+$' and size(split(dma, ' ')) = 2 and length(trim(split(dma, ' ')[1])) = 2 then trim(split(dma, ' ')[0])
                    when size(split(dma, ',')) = 2 and (length(trim(split(dma, ',')[1])) = 2 OR (split(dma, ',')[1] RLIKE '-' and size(filter(transform(split(trim(split(dma, ',')[1]), '-'), x -> length(trim(x))), x -> x != 2)) = 0)) then trim(split(dma, ',')[0])
                    when upper(dma) like '%WASH%HAG%' or upper(xd.state) like '%HAG%' or upper(trim(xd.state)) = 'DC-MD-PA-VA-WV' then 'WASHINGTON, DC (HAGRSTWN)'
                    else regexp_replace(dma, '(AIR\s+FORCE\s+BASE|AIR\s+RESERVE\s+BASE|A\s+F\s+B)','AFB')
                end as cleaned_dma,
                upper(trim(coalesce(sz.state, xd.state))) as state,
                case
                    when upper(trim(xd.state)) in ('OTHER UNCLASSIFIED', 'UNKNOWN', 'DIGITAL ISSUE') then null
                    when upper(trim(dma)) = 'PUERTO RICO' then 'PR'
                    when dma != 'SANTA FE' and dma rlike '^[a-zA-Z0-9 ]+$' and size(split(dma, ' ')) = 2 and length(trim(split(dma, ' ')[1])) = 2 then trim(split(dma, ' ')[1])
                    when size(split(dma, ',')) = 2 and (length(trim(split(dma, ',')[1])) = 2 or (split(dma, ',')[1] rlike '-' and size(filter(transform(split(trim(split(dma, ',')[1]), '-'), x -> length(trim(x))), x -> x != 2)) = 0)) then array_join(transform(split(trim(split(dma, ',')[1]), '-'), x -> trim(x)), '-')
                    when upper(xd.state) like '%OPELIKA%' then 'GA-AL'
                    when upper(xd.state) like '%HAG%' or upper(trim(xd.state)) = 'D)' or upper(trim(xd.state)) = 'DC-MD-PA-VA-WV' then null
                    else upper(trim(coalesce(sz.state, xd.state)))
                end as cleaned_state
            from xo_raw_ds as xd
            left join state_values as sz on upper(xd.state) = upper(sz.state_name)
        """)
        df_xo_norm_stg_1.registerTempTable('xo_norm_stg_1')

        df_xo_norm_stg_2 = self.spark.sql("""
            select distinct
                audience,
                zip_code,
                dma,
                country,
                reach,
                engage,
                cost,
                year_month,
                brand,
                channel,
                state,
                cleaned_state,
                case
                    when cleaned_dma like '%WARREN AFB%' then 'FT WARREN AFB'
                    when cleaned_dma like '%FORT MITCHELL%' then 'FT MITCHELL'
                    when cleaned_dma like '%FT. POLK%' then 'FORT POLK'
                    when cleaned_dma like '%ST CLAIR%' then 'ST. CLAIR'
                    when
                        cleaned_dma not like 'FT%MITCHELL%'
                        then
                            regexp_replace(
                                regexp_replace(cleaned_dma, '^(FT) ', 'FORT '),
                                '^(ST) ', 'SAINT '
                            )
                    else cleaned_dma
                end as cleaned_dma,
                case
                    when cleaned_state is NULL then 0
                    else size(split(cleaned_state, '-'))
                end as state_count 
            from xo_norm_stg_1
        """)
        df_xo_norm_stg_2.registerTempTable('xo_norm_stg_2')

        df_xo_norm_ds = self.spark.sql("""
            with her2_perjeta as (
                select distinct
                    audience,
                    zip_code,
                    dma,
                    country,
                    year_month,
                    'PERJETA' as brand,
                    channel,
                    cleaned_dma,
                    state,
                    cleaned_state,
                    state_count,
                    reach * 0.6 as reach,
                    engage * 0.6 as engage,
                    cost * 0.6 as cost
                from xo_norm_stg_2
                where brand = 'HER2'
            ),
            her2_phesgo as (
                select distinct
                    audience,
                    zip_code,
                    dma,
                    country,
                    year_month,
                    'PHESGO' as brand,
                    channel,
                    cleaned_dma,
                    state,
                    cleaned_state,
                    state_count,
                    reach * 0.2 as reach,
                    engage * 0.2 as engage,
                    cost * 0.2 as cost
                from xo_norm_stg_2
                where brand = 'HER2'
            ),
            her2_kadcyla as (
                select distinct
                    audience,
                    zip_code,
                    dma,
                    country,
                    year_month,
                    'KADCYLA' as brand,
                    channel,
                    cleaned_dma,
                    state,
                    cleaned_state,
                    state_count,
                    reach * 0.2 as reach,
                    engage * 0.2 as engage,
                    cost * 0.2 as cost
                from xo_norm_stg_2
                where brand = 'HER2'
            ),

            xo_norm_ds as (
                select distinct
                    audience,
                    zip_code,
                    dma,
                    country,
                    reach,
                    engage,
                    cost,
                    year_month,
                    brand,
                    channel,
                    cleaned_dma,
                    state,
                    cleaned_state,
                    state_count
                from xo_norm_stg_2
                where brand != 'HER2'
                union all
                select distinct
                    audience,
                    zip_code,
                    dma,
                    country,
                    reach,
                    engage,
                    cost,
                    year_month,
                    brand,
                    channel,
                    cleaned_dma,
                    state,
                    cleaned_state,
                    state_count
                from her2_perjeta
                union all
                select distinct
                    audience,
                    zip_code,
                    dma,
                    country,
                    reach,
                    engage,
                    cost,
                    year_month,
                    brand,
                    channel,
                    cleaned_dma,
                    state,
                    cleaned_state,
                    state_count
                from her2_phesgo
                union all
                select distinct
                    audience,
                    zip_code,
                    dma,
                    country,
                    reach,
                    engage,
                    cost,
                    year_month,
                    brand,
                    channel,
                    cleaned_dma,
                    state,
                    cleaned_state,
                    state_count
                from her2_kadcyla
            )
            select * from xo_norm_ds 
        """)
        df_xo_norm_ds.registerTempTable('xo_norm_ds')

        df_xo_zip_map = self.spark.sql("""
            select distinct
                xdc.year_month,
                xdc.brand,
                xdc.audience,
                xdc.channel,
                pdz.zip,
                xdc.state,
                xdc.country,
                xdc.cost,
                xdc.reach,
                xdc.engage
            from xo_norm_ds as xdc
            inner join zips_weights as pdz
                on trim(xdc.zip_code) = trim(pdz.zip)
            where
                xdc.zip_code is not null
        """)
        df_xo_zip_map.registerTempTable('xo_zip_map')

        df_xo_state_map = self.spark.sql("""
            select distinct
                xdc.year_month,
                xdc.brand,
                xdc.audience,
                xdc.channel,
                pdz.zip,
                xdc.state,
                xdc.country,
                xdc.reach * pdz.wt_state_total as reach,
                xdc.engage * pdz.wt_state_total as engage,
                xdc.cost * pdz.wt_state_total as cost
            from xo_norm_ds as xdc
            inner join zips_weights as pdz
                on xdc.cleaned_state = pdz.state
            where
                xdc.zip_code is null
                and xdc.cleaned_dma is null
                and xdc.cleaned_state is not null
        """)
        df_xo_state_map.registerTempTable('xo_state_map')

        df_xo_nation_map = self.spark.sql("""
            select distinct
                xdc.year_month,
                xdc.brand,
                xdc.audience,
                xdc.channel,
                pdz.zip,
                pdz.state,
                xdc.country,
                xdc.reach * pdz.wt_zip5_total as reach,
                xdc.engage * pdz.wt_zip5_total as engage,
                xdc.cost * pdz.wt_zip5_total as cost
            from xo_norm_ds as xdc
            cross join zips_weights as pdz
            where
                xdc.zip_code is null
                and xdc.cleaned_dma is null
                and xdc.cleaned_state is null
        """)
        df_xo_nation_map.registerTempTable('xo_nation_map')

        df_xo_county_map = self.spark.sql("""
            select distinct
                xdc.year_month,
                xdc.brand,
                xdc.audience,
                xdc.channel,
                xdc.dma,
                xdc.cleaned_dma,
                xdc.cleaned_state,
                xdc.state_count,
                xdc.zip_code,
                pdz.zip,
                pdz.county,
                xdc.state,
                xdc.country,
                coalesce(xdc.reach *  pdz.wt_county_total,xdc.reach) as reach,
                coalesce(xdc.engage *  pdz.wt_county_total,xdc.engage) as engage,
                coalesce(xdc.cost *  pdz.wt_county_total,xdc.cost) as cost,
                not coalesce (pdz.county is null, false) as is_county
            from xo_norm_ds as xdc
            left join zips_weights as pdz
                on
                    xdc.cleaned_dma = pdz.county
                    and xdc.cleaned_state = pdz.state
            where
                xdc.zip_code is null
                and xdc.cleaned_dma is not null
        """)
        df_xo_county_map.registerTempTable('xo_county_map')

        df_xo_city_map = self.spark.sql("""
            select distinct
                xdc.year_month,
                xdc.brand,
                xdc.audience,
                xdc.channel,
                pdz.zip,
                xdc.zip_code,
                xdc.state,
                xdc.cleaned_state,
                xdc.state_count,
                xdc.country,
                xdc.dma,
                xdc.cleaned_dma,
                coalesce(xdc.reach *  pdz.wt_city_total,xdc.reach) as reach,
                coalesce(xdc.engage *  pdz.wt_city_total,xdc.engage) as engage,
                coalesce(xdc.cost *  pdz.wt_city_total,xdc.cost) as cost,
                not coalesce (pdz.city is null, false) as is_city
            from xo_county_map as xdc
            left join city_weights as pdz
                on
                    xdc.cleaned_dma = pdz.city
                    and xdc.cleaned_state = pdz.state
            where
                not xdc.is_county
        """)
        df_xo_city_map.registerTempTable('xo_city_map')

        @F.udf(StringType())
        def standardize_dma_udf(cleaned_dma):
            if cleaned_dma is None:
                return None

            dma = cleaned_dma.split(',')[0]

            dma = re.sub(r',[^-,&]*', '', dma)
            dma = dma.split(',')[0]
            dma = re.sub(r',\s*[^-]+-', '-', dma)
            dma = re.sub(r'\s*-\s*', '-', dma)
            dma = re.sub(r' ([!@#$%^&{}_+=?|<>-]) *', r'\1', dma)
            dma = dma.strip()
            dma = re.sub(r'([^ ])-', r'\1 - ', dma)
            dma = re.sub(r'\s*&\s*', ' & ', dma)
            dma = re.sub(r'(\S)&', r'\1 &', dma)
            dma = re.sub(r'&(\S)', r'& \1', dma)
            dma = re.sub(r'([^ ])\(', r'\1 (', dma)
            dma = re.sub(r'\.([^ ])', r'. \1', dma)

            return dma

        self.spark.udf.register("standardize_dma_udf", standardize_dma_udf)

        df_xo_dmas = self.spark.sql("""
            with cte AS (
                select distinct 
                    audience, 
                    dma,
                    country,
                    reach,
                    engage,
                    cost,
                    year_month,
                    brand,
                    channel,
                    cleaned_dma,
                    standardize_dma_udf(cleaned_dma) AS standardized_dma,
                    state,
                    cleaned_state,
                    state_count
                from xo_city_map 
                where not is_city
            )
            select * from cte
        """)
        df_xo_dmas.registerTempTable('xo_dmas')

        df_all_dmas_list = self.spark.sql(f"""
            with non_std_dma_list as (
                select distinct 
                    dma_name, 
                    dma_code 
                from {self.normalized_database}.{self.mars_dma_state_code_stg}
            ),

            non_std_dmas_stg_1 as (
                select distinct
                    dma_code,
                    case when dma_name like '%HAG%' THEN 'WASHINGTON, DC (HAGRSTWN)' 
                        else standardize_dma_udf(dma_name) 
                    end as dma_name
                from non_std_dma_list
            )

            select * from non_std_dmas_stg_1 
        """)
        df_all_dmas_list.registerTempTable('non_std_dmas_stg_1')

        df_std_dmas = self.spark.sql("""
            select distinct 
                    dma_name as dma_name_orig,
                    standardize_dma_udf(dma_name) AS dma_name,
                    dma_code,
                    dma_state_count
                from zips_weights
        """)
        df_std_dmas.registerTempTable('std_dmas')

        df_non_std_dmas = self.spark.sql("""
            select distinct
                    nsd.dma_code,
                    nsd.dma_name,
                    sd.dma_state_count
                from non_std_dmas_stg_1 nsd
                join std_dmas sd
                on nsd.dma_code = sd.dma_code
        """)
        df_non_std_dmas.registerTempTable('non_std_dmas')

        df_all_dmas_list = self.spark.sql("""
                select distinct
                    dma_name,
                    dma_code,
                    dma_state_count
                from std_dmas
                union all
                select distinct
                    dma_name,
                    dma_code,
                    dma_state_count
                from non_std_dmas
        """)
        df_all_dmas_list.registerTempTable('all_dmas_list')

        df_xo_dma_match_stg_1 = self.spark.sql("""
            select distinct
                audience,
                dma,
                country,
                reach,
                engage,
                cost,
                year_month,
                brand,
                channel,
                cleaned_dma,
                standardized_dma,
                x.state,
                cleaned_state,
                state_count,
                zw.dma_name,
                zw.dma_code,
                zw.dma_state_count,
                case 
                    when zw.dma_name is null then false 
                else true end as is_std_match
            from xo_dmas as x
            left join
                all_dmas_list as zw
                on
                    trim(x.standardized_dma) = trim(zw.dma_name)
        """)
        df_xo_dma_match_stg_1.registerTempTable('xo_dma_match_stg_1')

        df_xo_dma_match_stg_2 = self.spark.sql("""
            select distinct
                audience,
                dma,
                country,
                reach,
                engage,
                cost,
                year_month,
                brand,
                channel,
                cleaned_dma,
                standardized_dma,
                state,
                cleaned_state,
                state_count,
                dma_state_count
            from xo_dma_match_stg_1 x
            where not is_std_match
        """)
        df_xo_dma_match_stg_2.registerTempTable('xo_dma_match_stg_2')

        df_matching_dmas = self.spark.sql("""
            with unmatched_dmas as (
                select distinct cleaned_dma from xo_dma_match_stg_2
            ),

            good_dmas as (
                select distinct dma_name from zips_weights
            ),

            levenshtein_distances as (
                select
                    cleaned_dma,
                    cast(min(lev_distance) as double) as dist,
                    min_by(dma_name, lev_distance) as dma_name,
                    cast(min(lev_distance) as double) / length(cleaned_dma) as pct_dist
                from (
                    select
                        *,
                        levenshtein(cleaned_dma, dma_name) as lev_distance
                    from unmatched_dmas, good_dmas
                )
                group by cleaned_dma
            ),

            dist_dma_values as (
                select distinct
                    dma_name,
                    dma_code,
                    dma_state_count
                from std_dmas
            ),

            matching_dmas as (
                select distinct
                    ld.cleaned_dma,
                    ld.dma_name,
                    ddv.dma_code,
                    ddv.dma_state_count
                from levenshtein_distances as ld
                inner join dist_dma_values as ddv on ld.dma_name = ddv.dma_name
                where
                    pct_dist < 0.5
                    and ld.cleaned_dma not in (
                        'BANGKOK', 'OAKVILLE', 'ST. JOHN''S', 'ILOILO CITY'
                    )
            )
            select * from matching_dmas
        """)
        df_matching_dmas.registerTempTable('matching_dmas')

        df_dma_match_stg_2_codes = self.spark.sql("""
            select distinct
                audience,
                dma,
                x.cleaned_dma,
                country,
                reach,
                engage,
                cost,
                year_month,
                brand,
                channel,
                state,
                cleaned_state,
                state_count,
                d.dma_code,
                d.dma_state_count
            from xo_dma_match_stg_2 as x
            inner join matching_dmas as d on x.cleaned_dma = d.cleaned_dma
        """)
        df_dma_match_stg_2_codes.registerTempTable('xo_dma_match_stg_2_codes')

        df_all_xo_dma_match = self.spark.sql("""
            select distinct
                year_month,
                brand,
                audience,
                channel,
                state,
                cleaned_state,
                state_count,
                country,
                reach,
                engage,
                cost,
                dma_code,
                dma_state_count
            from xo_dma_match_stg_1
            where is_std_match
            union all
            select distinct
                year_month,
                brand,
                audience,
                channel,
                state,
                cleaned_state,
                state_count,
                country,
                reach,
                engage,
                cost,
                dma_code,
                dma_state_count
            from xo_dma_match_stg_2_codes
        """)
        df_all_xo_dma_match.registerTempTable('all_xo_dma_match')

        df_xo_dma_map_pt_1 = self.spark.sql("""
            select distinct
                xdc.year_month,
                xdc.brand,
                xdc.audience,
                xdc.channel,
                pdz.zip,
                xdc.state,
                xdc.country,
                xdc.state_count,
                pdz.dma_state_count,
                xdc.reach * pdz.wt_dma_total as reach,
                xdc.engage *  pdz.wt_dma_total as engage,
                xdc.cost *  pdz.wt_dma_total as cost
            from all_xo_dma_match as xdc
            inner join zips_weights as pdz
                on
                    xdc.dma_code = pdz.dma_code
            where
                xdc.state_count = 0
                or xdc.state_count = xdc.dma_state_count
        """)
        df_xo_dma_map_pt_1.registerTempTable('xo_dma_map_pt_1')

        df_multi_state_dma_stg_1 = self.spark.sql("""
                select distinct
                    year_month,
                    brand,
                    audience,
                    channel,
                    state,
                    cleaned_state,
                    split(cleaned_state, '-') as state_array,
                    state_count,
                    country,
                    reach,
                    engage,
                    cost,
                    dma_code,
                    dma_state_count
                from all_xo_dma_match
                where state_count > 0 and state_count < dma_state_count
            """
                                                  )
        df_multi_state_dma_stg_1.registerTempTable('multi_state_dma_stg_1')

        df_multi_state_dma_ds = self.spark.sql("""
            select distinct 
                year_month,
                brand,
                audience,
                channel,
                state,
                u.cleaned_state,
                state_count,
                country,
                reach,
                engage,
                cost,
                dma_code,
                dma_state_count
            from multi_state_dma_stg_1
            lateral view explode(state_array) u AS cleaned_state
        """)
        df_multi_state_dma_ds.registerTempTable('multi_state_dma_ds')

        df_xo_dma_map_pt_2 = self.spark.sql("""
            select distinct
                xdc.year_month,
                xdc.brand,
                xdc.audience,
                xdc.channel,
                pdz.zip,
                xdc.state,
                xdc.country,
                xdc.state_count,
                pdz.dma_state_count,
                (xdc.reach / state_count) * pdz.wt_dma_state_total / state_count as reach,
                (xdc.engage / state_count) * pdz.wt_dma_state_total / state_count as engage,
                (xdc.cost / state_count) * pdz.wt_dma_state_total / state_count as cost
            from multi_state_dma_ds as xdc
            inner join zips_weights as pdz
                on
                    xdc.dma_code = pdz.dma_code
                    and xdc.cleaned_state = pdz.state
        """)
        df_xo_dma_map_pt_2.registerTempTable('xo_dma_map_pt_2')

        df_all_xo_data = self.spark.sql("""
            select distinct
                year_month,
                brand,
                zip,
                channel,
                audience,
                reach,
                engage,
                cost
            from xo_zip_map
            union all
            select distinct
                year_month,
                brand,
                zip,
                channel,
                audience,
                reach,
                engage,
                cost
            from xo_state_map
            union all
            select distinct
                year_month,
                brand,
                zip,
                channel,
                audience,
                reach,
                engage,
                cost
            from xo_nation_map
            union all
            select distinct
                year_month,
                brand,
                zip,
                channel,
                audience,
                reach,
                engage,
                cost
            from xo_county_map where is_county
            union all
            select distinct
                year_month,
                brand,
                zip,
                channel,
                audience,
                reach,
                engage,
                cost
            from xo_city_map where is_city
            union all
            select distinct
                year_month,
                brand,
                zip,
                channel,
                audience,
                reach,
                engage,
                cost
            from xo_dma_map_pt_1
            union all
            select distinct
                year_month,
                brand,
                zip,
                channel,
                audience,
                reach,
                engage,
                cost
            from xo_dma_map_pt_2
        """)
        df_all_xo_data.registerTempTable('all_xo_data')

        df_final_agg = self.spark.sql("""
            with agg_data as (
                select distinct
                    brand as product_brand_name,
                    year_month,
                    zip,
                    channel,
                    audience,
                    sum(reach)
                        over (partition by brand, year_month, channel, audience, zip)
                        as reach,
                    sum(engage)
                        over (partition by brand, year_month, channel, audience, zip)
                        as engage,
                    sum(cost)
                        over (partition by brand, year_month, channel, audience, zip)
                        as cost
                    from all_xo_data
                )
            select *
            from agg_data
            where not isnan(reach) or not isnan(cost) or not isnan(engage)
        """)

        df_final_agg_persisted = df_final_agg.persist()

        audit_info = []
        audit_info += [{'table_name': f"{self.normalized_database}.mars_nvs_digital_staging",
                        'rows_updated': df_final_agg_persisted.count()}]

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/etl/nvs/mars_nvs_digital_staging/")
        df_final_agg_persisted.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)

        if 'mars_nvs_digital_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                                table_name='mars_nvs_digital_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            final_agg_hist_df = df_final_agg_persisted.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to historical layer, it is getting loaded into historical for first time
            final_agg_hist_df = df_final_agg_persisted.withColumn('version', lit(1))
            logger.info(f"Back up table does not exist for mars_nvs_digital_historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_database}.mars_nvs_digital_historical",
             'rows_updated': df_final_agg_persisted.count()})

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/etl/nvs/mars_nvs_digital_historical/")
        final_agg_hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def create_update_crawler(self, client):
        """
        Crawler has to be created if it doesn't exist, if it exists then we have to update it s3 path for it.
        :param client: glue boto3 client used to create or update crawler
        """
        # Creating list of s3 path that has to be crawled
        s3_crawl_list = []
        for s3_path in list(set(self.s3_path_list)):
            s3_crawl_list.append(
                {"Path": s3_path, 'Exclusions': json.loads(self.config.get(self.env, "crawl_exclusion_paths"))})

        crawler_exist = True

        # Checking if crawler is already existing or not
        try:
            res = client.get_crawler(Name=self.crawler_name)
            response = json.dumps(res, indent=4, sort_keys=True, default=str)
            print(response)
        except client.exceptions.EntityNotFoundException as e:
            logger.info("Crawler doesnt exist, need to create")
            crawler_exist = False

        # Creating crawler if it doesn't exist
        if crawler_exist:
            response = client.update_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.normalized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Updated\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

        else:
            response = client.create_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.normalized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Created\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

    def start_crawler(self, client):
        """
        This method is used to start the crawler
        :param client: glue boto3 client used to create or update crawler
        """
        response_start = client.start_crawler(Name=self.crawler_name)
        logger.info("Crawler Started\nName : " + self.crawler_name)
        logger.info(json.dumps(response_start, indent=4, sort_keys=True, default=str))

    def monitor_crawler(self, client):
        """
        This method is used to monitor the crawler which we started just now
        :param client: glue boto3 client used to create or update crawler
        """
        need_to_wait = True
        state_previous = None
        while need_to_wait:
            time.sleep(20)
            response_get = client.get_crawler(Name=self.crawler_name)
            state = response_get["Crawler"]["State"]
            if state == "READY" or state == "STOPPING":  # Other known states: RUNNING
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                need_to_wait = False
                break
            if state != state_previous:
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                state_previous = state


def audit_job_info(spark_obj, job_srt_time, job_name, batch_id, audit_path, audit_dict):
    """
    This function is used to write audit stats of this etl job to athena table.
    :param audit_path:
    :param spark_obj:
    :param job_srt_time:
    :param job_name:
    :param batch_id:
    :param audit_dict:
    """
    if audit_dict is not None:
        logger.info("Writing completion stats to audit table")
        logger.info(audit_dict)
        audit_df = (spark_obj.createDataFrame(audit_dict)
                    .withColumn("log_id_status", lit("COMPLETED"))
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", current_timestamp().cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("etl_layer", lit("normalized"))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)
        logger.info("Auditing is complete")
    else:
        logger.info("Writing initiating stats to audit table")
        audit_df = (spark_obj.createDataFrame([{'etl_layer': 'normalized', 'log_id_status': 'INITIATED'}])
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", lit(None).cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("table_name", lit(None).cast(StringType()))
                    .withColumn("rows_updated", lit(None).cast(IntegerType()))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)


if __name__ == "__main__":
    # Getting AWS Glue job parameters, creating session and initiating job
    arg = getResolvedOptions(sys.argv,
                             ['JOB_NAME', 'environment', 'batch_id'])

    logger.info("MARS XO job started")

    environment = arg['environment']
    config_obj = read_config_file('configuration.ini')
    check_config_section(config_obj, environment)
    job_start_time = datetime.datetime.now()

    sc = SparkContext()
    glueContext = GlueContext(sc)
    sprk = glueContext.spark_session
    job = Job(glueContext)
    job.init(arg['JOB_NAME'], arg)

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'),
                   audit_dict=None)
    audit_list = []

    xo_etl = XOETLNVS(config_obj, arg, glueContext, sprk)

    crawler_client = boto3.client('glue', region_name="us-west-2")

    athena_cl = boto3.client('athena', region_name="us-west-2")

    audit_list += xo_etl.core(athena_cl)

    xo_etl.create_update_crawler(crawler_client)

    xo_etl.start_crawler(crawler_client)

    xo_etl.monitor_crawler(crawler_client)

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'),
                   audit_dict=audit_list)

    job.commit()
