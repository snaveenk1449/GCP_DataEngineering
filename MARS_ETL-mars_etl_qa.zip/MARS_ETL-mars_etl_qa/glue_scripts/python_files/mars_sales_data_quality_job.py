import json
import logging
import configparser
import boto3
import sys
import time
from pyspark.sql.window import Window
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import *
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.types import *
import datetime

MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def read_config_file(config_file_name):
    """
    This function is reading config file and returning config object
    :type config_file_name: string
    """
    config = configparser.ConfigParser()
    config.read(config_file_name)
    return config


def check_config_section(config, env):
    """
    This function check if section specified in job parameters is present in config file or not
    :param config: Config file object
    :param env: environment which is specified in job parameters
    """
    if not config.has_section(env):
        raise Exception("Environment details doesn't exist in configuration file")


class SalesDataQualityReports:
    def __init__(self, config, args, glue_context, spark):
        """
        This is init method used to initialize variables in class
        :param config: Config file object
        :param args: Arguments given to Glue job
        """

        self.env = args['environment']
        self.speaker_event_landing_tbl = config.get(self.env, "event_tbl")
        self.args = args
        self.bucket_name = config.get(self.env, "bucket_name")
        self.normalized_folder = json.loads(config.get(self.env, "folder_names"))['normalized']
        self.s3_path_list = []
        self.normalized_database = json.loads(config.get(self.env, "athena_database"))['normalized']
        self.summarized_database = json.loads(config.get(self.env, "athena_database"))['summarized']
        self.landing_database = json.loads(config.get(self.env, "athena_database"))['landing']
        self.config = config
        self.crawler_name = 'mars_normalized_dq_crawler'
        self.glue_context = glue_context
        self.mars_sales_tbl = config.get(self.env, "mars_sales_tbl")
        self.mars_net_sales_tbl = config.get(self.env, "mars_net_sales_tbl")
        self.mars_product_sales_tbl = config.get(self.env, "mars_product_sales_tbl")
        self.mars_pivot_tbl = config.get(self.env, "mars_pivot_table_name")
        self.evrysdi_extra_hcp_zips_tbl = config.get(self.env, "evrysdi_extra_hcp_zips_stg")
        # self.sales_qty_tbl_stg = config.get(self.env, "sales_qty_tbl_stg")
        self.net_sales_tbl_stg = config.get(self.env, "net_sales_tbl_stg")
        self.landing_sales_qty_tbl = config.get(self.env, "sales_qty_tbl")
        self.landing_net_sales_qty_tbl = config.get(self.env, "net_sales_tbl")
        self.hcp_org_map_tbl = config.get(self.env, "hcp_org_map_tbl")
        self.site_sales_table_stg_weekly = config.get(self.env, "sales_qty_tbl_stg_weekly")
        self.spark = spark
        self.upper_bound_year_month = int(config.get(self.env, "upper_bound_year_month"))
        self.lower_bound_year_month = int(config.get(self.env, "lower_bound_year_month"))
        self.mars_product_names = "'" + "','".join(
            json.loads(self.config.get(self.env, "mars_product_names_list"))) + "'"

    def create_update_crawler(self, client):
        """
        Crawler has to be created if it doesn't exist, if it exists then we have to update it s3 path for it.
        :param client: glue boto3 client used to create or update crawler
        """
        # Creating list of s3 path that has to be crawled
        s3_crawl_list = []
        for s3_path in list(set(self.s3_path_list)):
            s3_crawl_list.append(
                {"Path": s3_path, 'Exclusions': json.loads(self.config.get(self.env, "crawl_exclusion_paths"))})

        crawler_exist = True

        # Checking if crawler is already existing or not
        try:
            res = client.get_crawler(Name=self.crawler_name)
            response = json.dumps(res, indent=4, sort_keys=True, default=str)
            print(response)
        except client.exceptions.EntityNotFoundException as e:
            logger.info("Crawler doesnt exist, need to create")
            crawler_exist = False

        # Creating crawler if it doesn't exist
        if crawler_exist:
            response = client.update_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.normalized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Updated\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

        else:
            response = client.create_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.normalized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Created\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

    def start_crawler(self, client):
        """
        This method is used to start the crawler
        :param client: glue boto3 client used to create or update crawler
        """
        response_start = client.start_crawler(Name=self.crawler_name)
        logger.info("Crawler Started\nName : " + self.crawler_name)
        logger.info(json.dumps(response_start, indent=4, sort_keys=True, default=str))

    def monitor_crawler(self, client):
        """
        This method is used to monitor the crawler which we started just now
        :param client: glue boto3 client used to create or update crawler
        """
        need_to_wait = True
        state_previous = None
        while need_to_wait:
            time.sleep(20)
            response_get = client.get_crawler(Name=self.crawler_name)
            state = response_get["Crawler"]["State"]
            if state == "READY" or state == "STOPPING":  # Other known states: RUNNING
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                need_to_wait = False
                break
            if state != state_previous:
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                state_previous = state

    def sales_crosswalk(self, athena_client):
        logger.info("Sales Crosswalk DQ started")
        stage_df = self.spark.sql(f"""select
        case when product_brand_name in('ACTEMRA IV', 'ACTEMRA SC') then 'ACTEMRA' else upper(product_brand_name) end as product_brand_name,
        cast(date_year_month as string) as year_month,
        sum(gne_867_sales_qty_eqv) as total_env
        from {self.normalized_database}.{self.site_sales_table_stg_weekly}
        group by 1, 2""")
        stage_df.registerTempTable('stage')

        pivoted_df = self.spark.sql(f"""select
        product_brand_name, year_month, SUM( sales_qty ) as total_env
        from {self.summarized_database}.{self.mars_sales_tbl}
        where
        year_month >= '{self.lower_bound_year_month}'
        and upper(product_brand_name) IN ({self.mars_product_names})
        group by product_brand_name, year_month""")
        pivoted_df.registerTempTable('pivoted')

        result_df = self.spark.sql("""select
        cast(p.year_month as int) as year_month,
        s.product_brand_name,
        ROUND(COALESCE(s.total_env, 0), 2) as total_sales,
        ROUND(COALESCE(p.total_env, 0), 2) as total_sales_mce_inc,
        ROUND(COALESCE(s.total_env, 0) - COALESCE(p.total_env, 0), 2) as total_sales_mce_exc, 
        ROUND(COALESCE(p.total_env, 0), 2) as sales_qty
        from pivoted as p inner join stage as s
        on
            upper(p.product_brand_name) = upper(s.product_brand_name)
            and p.year_month = s.year_month
        order by 1, 2""")

        result_df.registerTempTable("result")

        compare_df_persisted = (result_df
                                .withColumn('year', col('year_month').cast('string').substr(1, 4))
                                .withColumn('year_quarter', expr(
            "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)"))
                                .persist())
        audit_info = []
        audit_info += [{'table_name': f"{self.normalized_database}.mars_sales_crosswalk_dq_staging",
                        'rows_updated': compare_df_persisted.count()}]
    
        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_sales_crosswalk_dq_staging' + "/")
        compare_df_persisted.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]
    
        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)
    
        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))
    
        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)
    
        if 'mars_sales_crosswalk_dq_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                                table_name='mars_sales_crosswalk_dq_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            hist_df = compare_df_persisted.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = compare_df_persisted.withColumn('version', lit(1))
            logger.info(f"Back up table does not exist for mars_sales_crosswalk_dq_historical in normalized layer")
    
        audit_info.append(
            {'table_name': f"{self.normalized_database}.mars_sales_crosswalk_dq_historical",
             'rows_updated': compare_df_persisted.count()})
    
        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_sales_crosswalk_dq_historical' + "/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]
    
        return audit_info
    
    def sales_input_output(self, athena_client):
        logger.info("Sales input Output DQ started")
        stage_df = self.spark.sql(f"""select
            case when product_brand_name in('ACTEMRA IV', 'ACTEMRA SC') then 'ACTEMRA' else upper(product_brand_name) end as product_brand_name,
            cast(date_year_month as string) as year_month,
            sum(gne_867_sales_qty_eqv) as total_env
            from {self.normalized_database}.{self.site_sales_table_stg_weekly}
            group by 1, 2""")
        stage_df.registerTempTable('stage')
    
        pivoted_df = self.spark.sql(f"""select
            product_brand_name, year_month, SUM( sales_qty ) as total_env
            from {self.summarized_database}.{self.mars_sales_tbl}
            where
            year_month >= '{self.lower_bound_year_month}'
            and upper(product_brand_name) IN ({self.mars_product_names})
            group by product_brand_name, year_month""")
        pivoted_df.registerTempTable('pivoted')
    
        final_df = self.spark.sql("""select
            p.product_brand_name,
            cast(p.year_month as int),
            ROUND(COALESCE(s.total_env, 0), 2) as raw_tbl_sales,
            ROUND(COALESCE(p.total_env, 0), 2) as pivoted_sales,
            ROUND(COALESCE(s.total_env, 0) - COALESCE(p.total_env, 0), 2) as delta_diff
            from pivoted as p inner join stage as s
            on
                upper(p.product_brand_name) = upper(s.product_brand_name)
                and p.year_month = s.year_month
            order by 1, 2""")
    
        final_df.registerTempTable('final')
    
        compare_df_persisted = (final_df
                                .withColumn('year', col('year_month').cast('string').substr(1, 4))
                                .withColumn('year_quarter', expr(
            "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)"))
                                  .persist())
        audit_info = []
        audit_info += [{'table_name': f"{self.normalized_database}.mars_sales_input_output_dq_staging",
                        'rows_updated': compare_df_persisted.count()}]
    
        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_sales_input_output_dq_staging' + "/")
        compare_df_persisted.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]
    
        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)
    
        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))
    
        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)
    
        if 'mars_sales_input_output_dq_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                                table_name='mars_sales_input_output_dq_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            hist_df = compare_df_persisted.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = compare_df_persisted.withColumn('version', lit(1))
            logger.info(f"Back up table does not exist for mars_sales_input_output_dq_historical in normalized layer")
    
        audit_info.append(
            {'table_name': f"{self.normalized_database}.mars_sales_input_output_dq_historical",
             'rows_updated': compare_df_persisted.count()})
    
        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_sales_input_output_dq_historical' + "/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]
    
        return audit_info    
    
    def gross_sales_input_output(self, athena_client):
        logger.info("Gross Sales Input Output DQ started")
        gross_sales_df = self.spark.sql(f"""
                with gross_sales as(
                    select 
                        product_brand_name,
                        year_month,
                        sum(gross_sales_dollars) as in_gross_sales,
                        sum(gross_sales_dollars_mce_inc) as out_gross_sales, 
                        coalesce(sum(gross_sales_dollars) - sum(gross_sales_dollars_mce_inc), 0) as delta_diff
                    from 
                    {self.summarized_database}.{self.mars_product_sales_tbl}
                    where product_brand_name in({self.mars_product_names})
                    and year_month >= '{self.lower_bound_year_month}'
                    group by 1, 2
                )
                select * from gross_sales
            """)
    
        gross_sales_df.registerTempTable('final')
    
        compare_df_persisted = (gross_sales_df
                                .withColumn('year', col('year_month').cast('string').substr(1, 4))
                                .withColumn('year_quarter', expr(
            "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)"))
                                .persist())
        audit_info = []
        audit_info += [{'table_name': f"{self.normalized_database}.mars_gross_sales_input_output_dq_staging",
                        'rows_updated': compare_df_persisted.count()}]
    
        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_gross_sales_input_output_dq_staging' + "/")
        compare_df_persisted.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]
    
        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)
    
        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))
    
        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)
    
        if 'mars_gross_sales_input_output_dq_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                                table_name='mars_gross_sales_input_output_dq_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            hist_df = compare_df_persisted.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = compare_df_persisted.withColumn('version', lit(1))
            logger.info(
                f"Back up table does not exist for mars_gross_sales_input_output_dq_historical in normalized layer")
    
        audit_info.append(
            {'table_name': f"{self.normalized_database}.mars_gross_sales_input_output_dq_historical",
             'rows_updated': compare_df_persisted.count()})
    
        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/" +
                   'mars_gross_sales_input_output_dq_historical' + "/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]
    
        return audit_info


def audit_job_info(spark_obj, job_srt_time, job_name, batch_id, audit_path, audit_dict):
    """
    This function is used to write audit stats of this etl job to athena table.
    :param audit_path:
    :param spark_obj:
    :param job_srt_time:
    :param job_name:
    :param batch_id:
    :param audit_dict:
    """
    logger.info("Writing to audit table")
    if audit_dict is not None:
        logger.info(audit_dict)
        audit_df = (spark_obj.createDataFrame(audit_dict)
                    .withColumn("log_id_status", lit("COMPLETED"))
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", current_timestamp().cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("etl_layer", lit("normalized_dq"))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)
    else:
        audit_df = (spark_obj.createDataFrame([{'etl_layer': 'normalized_dq', 'log_id_status': 'INITIATED'}])
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", lit(None).cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("table_name", lit(None).cast(StringType()))
                    .withColumn("rows_updated", lit(None).cast(IntegerType()))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)


if __name__ == "__main__":
    # Getting AWS Glue job parameters, creating session and initiating job
    arg = getResolvedOptions(sys.argv, ['JOB_NAME', 'environment', 'batch_id'])

    logger.info("MARS Sales Data Quality reports job started")

    environment = arg['environment']
    config_obj = read_config_file('configuration.ini')
    check_config_section(config_obj, environment)
    job_start_time = datetime.datetime.now()

    sc = SparkContext()
    glueContext = GlueContext(sc)
    sprk = glueContext.spark_session
    job = Job(glueContext)
    job.init(arg['JOB_NAME'], arg)
    sprk.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'), audit_dict=None)

    sales_data_quality = SalesDataQualityReports(config_obj, arg, glueContext, sprk)

    audit_list = []

    athena_cl = boto3.client('athena', region_name="us-west-2")

    audit_list += sales_data_quality.sales_input_output(athena_cl)

    audit_list += sales_data_quality.gross_sales_input_output(athena_cl)

    audit_list += sales_data_quality.sales_crosswalk(athena_cl)

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'), audit_dict=audit_list)

    crawler_client = boto3.client('glue', region_name="us-west-2")

    sales_data_quality.create_update_crawler(crawler_client)

    sales_data_quality.start_crawler(crawler_client)

    sales_data_quality.monitor_crawler(crawler_client)

    job.commit()
