import json
import logging
import configparser
import boto3
import sys
import time
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import *
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.types import *
import datetime
from pyspark.sql.window import Window
from pyspark.sql.functions import udf

MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def read_config_file(config_file_name):
    """
    This function is reading config file and returning config object
    :type config_file_name: string
    """
    config = configparser.ConfigParser()
    config.read(config_file_name)
    return config


def check_config_section(config, env):
    """
    This function check if section specified in job parameters is present in config file or not
    :param config: Config file object
    :param env: environment which is specified in job parameters
    """
    if not config.has_section(env):
        raise Exception("Environment details doesn't exist in configuration file")


class NvsETL:
    def __init__(self, config, args, glue_context, spark):
        """
        This is init method used to initialize variables in class
        :param config: Config file object
        :param args: Arguments given to Glue job
        """
        self.env = args['environment']
        self.args = args
        self.bucket_name = config.get(self.env, "bucket_name")
        self.normalized_folder = json.loads(config.get(self.env, "folder_names"))['normalized']
        self.s3_path_list = []
        self.normalized_database = json.loads(config.get(self.env, "athena_database"))['normalized']
        self.landing_database = json.loads(config.get(self.env, "athena_database"))['landing']
        self.summarized_database = json.loads(config.get(self.env, "athena_database"))['summarized']
        self.config = config
        self.crawler_name = 'mars_nvs_crawler'
        self.glue_context = glue_context
        self.spark = spark
        self.mstr_cm_mdm_prfl_wkl_tbl = config.get(self.env, "mstr_cm_mdm_prfl_wkl_tbl")
        self.mars_population_demographics_staging = config.get(self.env, "population_demo_tbl")
        self.hcp_org_map_tbl = config.get(self.env, "hcp_org_map_tbl")
        self.nvs_calls_01232024 = config.get(self.env, "nvs_calls_01232024_staging")
        self.nvs_calls_06252024 = config.get(self.env, "nvs_calls_06252024_staging")
        self.nvs_calls_09252024 = config.get(self.env, "nvs_calls_09252024_staging")
        self.nvs_dtc_display = config.get(self.env, "nvs_display_staging")
        self.nvs_dtc_display_09252024 = config.get(self.env, "nvs_display_09252024_staging")
        self.nvs_costs = config.get(self.env, "nvs_costs_staging")
        self.nvs_dtc_search_01232024 = config.get(self.env, "nvs_dtc_search_01232024_staging")
        self.nvs_dtc_search_09252024 = config.get(self.env, "nvs_dtc_search_09252024_staging")
        self.nvs_poc = config.get(self.env, "nvs_poc_staging")
        self.nvs_poc_09252024 = config.get(self.env, "nvs_poc_09252024_staging")
        self.nvs_social = config.get(self.env, "nvs_social_staging")
        self.nvs_social_09252024 = config.get(self.env, "nvs_social_09252024_staging")
        self.nvs_hcp_search_01232024 = config.get(self.env, "nvs_hcp_search_01232024_staging")
        self.nvs_hcp_search_10032024 = config.get(self.env, "nvs_hcp_search_10032024_staging")
        self.nvs_hcp_all = config.get(self.env, "nvs_hcp_all_staging")
        self.nvs_hcp_all_12022024 = config.get(self.env, "nvs_hcp_all_12022024_staging")

    def nvs_tam(self, athena_client):
        df_tam_ce = self.spark.sql(f"""
                    with raw_calls_unioned as(
                        select 
                            npi_num, zip_cd, city, state, brand, yrmo, call_p1, call_p2, call_p3, calls, lunch_n_learn_calls 
                        from {self.normalized_database}.{self.nvs_calls_01232024}
                        where yrmo between 202201 and 202206
                        union all 
                        select 
                            npi_num, zip_cd, city, state, brand, yrmo, call_p1, call_p2, call_p3, calls, lunch_n_learn_calls 
                        from {self.normalized_database}.{self.nvs_calls_06252024}  
                        where yrmo between 202207 and 202212
                        union all 
                        select 
                            npi_num, zip_cd, city, state, brand, yrmo, call_p1, call_p2, call_p3, calls, lunch_n_learn_calls
                        from {self.normalized_database}.{self.nvs_calls_09252024}
                        where yrmo between 202301 and 202406
                    ),
                    reach_calc as(
                            select 
                                   nvs.yrmo as year_month,
                                   'XOLAIR' as product_brand_name,
                                    case when call_p1 = '1' or lunch_n_learn_calls = '1' then 1 
                                        when call_p2 = '1' then 2
                                        when call_p3 = '1' then 3 
                                   end as display_order
                            from raw_calls_unioned as nvs
                            where npi_num is not null
                      ),
                        reach_agg as(
                           select 
                                product_brand_name,
                                year_month, 
                                1.0 / display_order as reach
                            from reach_calc
                      ),
                        input_agg as(
                            select 
                                product_brand_name,
                                year_month,
                                sum(reach) as input_reach 
                            from reach_agg 
                            group by 1, 2
                       ),
                        output_data as(
                           select 
                                product_brand_name,
                                year_month, 
                                sum(reach) as output_reach
                            from oasis_normalized_mars.mars_tam_nvs_staging
                            group by 1, 2 
                        )
                        select 
                            coalesce(i.product_brand_name, o.product_brand_name) as product_brand_name,
                            coalesce(i.year_month, o.year_month) as year_month, 
                            i.input_reach,
                            o.output_reach, 
                            coalesce(i.input_reach - o.output_reach, 0) as reach_diff
                        from input_agg i 
                        join output_data o  
                        on i.product_brand_name = o.product_brand_name
                        and i.year_month = o.year_month
                """)
        df_tam_ce.registerTempTable('tam_ce')

        tam_df_persisted = df_tam_ce.withColumn('year', col('year_month').cast('string').substr(1, 4)).withColumn(
            'year_quarter', expr(
                "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)")).persist()
        audit_info = []
        audit_info += [{'table_name': f"{self.normalized_database}.mars_tam_nvs_input_output_staging",
                        'rows_updated': tam_df_persisted.count()}]

        s3_path = (
                    "s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/nvs/mars_tam_nvs_input_output_staging/")
        tam_df_persisted.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)

        if 'mars_tam_nvs_input_output_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                                table_name='mars_tam_nvs_input_output_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            hist_df = tam_df_persisted.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = tam_df_persisted.withColumn('version', lit(1))
            logger.info(f"Back up table does not exist for mars_tam_nvs_input_output_historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_database}.mars_tam_nvs_input_output_historical",
             'rows_updated': tam_df_persisted.count()})

        s3_path = (
                    "s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/nvs/mars_tam_nvs_input_output_historical/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def nvs_tam_trend_analysis(self, athena_client):
        df_tam_ce = self.spark.sql(f"""
                    with nvs_calls_aggregated as(
                        select 
                            product_brand_name,
                            year_month,
                            substring(year_month, 1, 4) as year,
                            concat(substring(year_month, 1, 4), 'Q', cast(ceil(cast(substring(year_month, 5, 2) as int) / 3.0) as string)) as year_quarter,
                            sum(reach) as reach,
                            sum(cost) as cost 
                        from oasis_normalized_mars.mars_tam_nvs_staging
                        group by 1, 2, 3, 4
                    )
                    select * from nvs_calls_aggregated
                """)
        df_tam_ce.registerTempTable('tam_ce')

        tam_df_persisted = df_tam_ce.persist()
        audit_info = []
        audit_info += [{'table_name': f"{self.normalized_database}.mars_tam_nvs_dq",
                        'rows_updated': tam_df_persisted.count()}]

        s3_path = (
                    "s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/nvs/mars_tam_nvs_dq/")
        tam_df_persisted.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)

        if 'mars_tam_nvs_dq_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                                table_name='mars_tam_nvs_dq_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            hist_df = tam_df_persisted.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = tam_df_persisted.withColumn('version', lit(1))
            logger.info(f"Back up table does not exist for mars_tam_nvs_dq_historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_database}.mars_tam_nvs_dq_historical",
             'rows_updated': tam_df_persisted.count()})

        s3_path = (
                    "s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/nvs/mars_tam_nvs_dq_historical/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def nvs_digital(self, athena_client):
        df_digital_input_output = self.spark.sql(f"""
                with input_data as(
                    select
                        upper(brand) as product_brand_name,
                        lower(regexp_replace(channel, '[^A-Za-z0-9]+', '_')) as channel,
                        concat(cast(year as string), lpad(cast(month as string), 2, '0')) as year_month,
                        upper(audience) as audience,
                        sum(reach) as input_reach,
                        sum(engage) as input_engage,
                        sum(cost) as input_cost
                    from oasis_normalized_mars.mars_combined_nvs_data_staging
                    group by 1, 2, 3, 4 
                ),
                output_data as(
                    select 
                        upper(product_brand_name) as product_brand_name, 
                        channel,
                        upper(audience) as audience,
                        year_month,
                        sum(reach) as output_reach, 
                        sum(engage) as output_engage, 
                        sum(cost) as output_cost 
                    from oasis_normalized_mars.mars_nvs_digital_staging
                    group by 1, 2, 3, 4 
                )
                select 
                    coalesce(o.product_brand_name, i.product_brand_name) AS product_brand_name, 
                    coalesce(o.audience, i.audience) AS audience,
                    coalesce(o.channel, i.channel) AS channel,
                    coalesce(o.year_month, i.year_month) AS year_month,
                    coalesce(i.input_reach, 0) as input_reach,
                    coalesce(o.output_reach, 0) as output_reach,
                    coalesce(i.input_engage, 0) as input_engage,
                    coalesce(o.output_engage, 0) as output_engage,
                    coalesce(i.input_cost, 0) as input_cost,
                    coalesce(o.output_cost, 0) as output_cost
                from input_data i 
                full join output_data o  
                on i.product_brand_name = o.product_brand_name 
                and i.channel = o.channel 
                and i.audience = o.audience
                and i.year_month = o.year_month
                order by 1, 2, 3, 4                      
        """)
        df_digital_input_output.registerTempTable('digital_input_output')

        df_unioned_persisted = df_digital_input_output.withColumn('year', col('year_month').cast('string').substr(1,
                                                                                                                  4)).withColumn(
            'year_quarter', expr(
                "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)")).persist()
        audit_info = []
        audit_info += [{'table_name': f"{self.normalized_database}.mars_nvs_digital_input_output_staging",
                        'rows_updated': df_unioned_persisted.count()}]

        s3_path = (
                "s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/nvs/mars_nvs_digital_input_output_staging/")
        df_unioned_persisted.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)

        if 'mars_nvs_digital_input_output_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                                table_name='mars_nvs_digital_input_output_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            hist_df = df_unioned_persisted.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = df_unioned_persisted.withColumn('version', lit(1))
            logger.info(
                f"Back up table does not exist for mars_nvs_digital_input_output_historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_database}.mars_nvs_digital_input_output_historical",
             'rows_updated': df_unioned_persisted.count()})

        s3_path = (
                    "s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/nvs/mars_nvs_digital_input_output_historical/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def nvs_digital_trend_analysis(self, athena_client):
        df_digital_trend_analysis = self.spark.sql(f"""
                with input_data as(
                    select
                        brand,
                        lower(regexp_replace(channel, '[^A-Za-z0-9]+', '_')) as channel,
                        audience,
                        year,
                        concat(cast(year as string), lpad(cast(month as string), 2, '0')) as year_month,
                        coalesce(sum(reach), 0) as reach,
                        coalesce(sum(engage), 0) as engage,
                        coalesce(sum(cost), 0) as cost 
                    from oasis_normalized_mars.mars_combined_nvs_data_staging
                    group by 1, 2, 3, 4, 5
                )
                select *, 
                    concat(substring(year_month, 1, 4), 'Q', cast(ceil(cast(substring(year_month, 5, 2) as int) / 3.0) as string)) as year_quarter
                from input_data         
        """)
        df_digital_trend_analysis.registerTempTable('digital_trend_analysis')

        df_unioned_persisted = df_digital_trend_analysis.persist()
        audit_info = []
        audit_info += [{'table_name': f"{self.normalized_database}.mars_nvs_digital_dq",
                        'rows_updated': df_unioned_persisted.count()}]

        s3_path = (
                "s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/nvs/mars_nvs_digital_dq/")
        df_unioned_persisted.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)

        if 'mars_nvs_digital_dq_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                                table_name='mars_nvs_digital_dq_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            hist_df = df_unioned_persisted.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to landing, it is getting loaded into backup for first time
            hist_df = df_unioned_persisted.withColumn('version', lit(1))
            logger.info(
                f"Back up table does not exist for mars_nvs_digital_dq_historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_database}.mars_nvs_digital_dq_historical",
             'rows_updated': df_unioned_persisted.count()})

        s3_path = (
                    "s3://" + self.bucket_name + "/" + self.normalized_folder + "/data_quality_reports/nvs/mars_nvs_digital_dq_historical/")
        hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def create_update_crawler(self, client):
        """
        Crawler has to be created if it doesn't exist, if it exists then we have to update it s3 path for it.
        :param client: glue boto3 client used to create or update crawler
        """
        # Creating list of s3 path that has to be crawled
        s3_crawl_list = []
        for s3_path in list(set(self.s3_path_list)):
            s3_crawl_list.append(
                {"Path": s3_path, 'Exclusions': json.loads(self.config.get(self.env, "crawl_exclusion_paths"))})

        crawler_exist = True

        # Checking if crawler is already existing or not
        try:
            res = client.get_crawler(Name=self.crawler_name)
            response = json.dumps(res, indent=4, sort_keys=True, default=str)
            print(response)
        except client.exceptions.EntityNotFoundException as e:
            logger.info("Crawler doesnt exist, need to create")
            crawler_exist = False

        # Creating crawler if it doesn't exist
        if crawler_exist:
            response = client.update_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.normalized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Updated\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

        else:
            response = client.create_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.normalized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Created\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

    def start_crawler(self, client):
        """
        This method is used to start the crawler
        :param client: glue boto3 client used to create or update crawler
        """
        response_start = client.start_crawler(Name=self.crawler_name)
        logger.info("Crawler Started\nName : " + self.crawler_name)
        logger.info(json.dumps(response_start, indent=4, sort_keys=True, default=str))

    def monitor_crawler(self, client):
        """
        This method is used to monitor the crawler which we started just now
        :param client: glue boto3 client used to create or update crawler
        """
        need_to_wait = True
        state_previous = None
        while need_to_wait:
            time.sleep(20)
            response_get = client.get_crawler(Name=self.crawler_name)
            state = response_get["Crawler"]["State"]
            if state == "READY" or state == "STOPPING":  # Other known states: RUNNING
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                need_to_wait = False
                break
            if state != state_previous:
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                state_previous = state


def audit_job_info(spark_obj, job_srt_time, job_name, batch_id, audit_path, audit_dict):
    """
    This function is used to write audit stats of this etl job to athena table.
    :param audit_path:
    :param spark_obj:
    :param job_srt_time:
    :param job_name:
    :param batch_id:
    :param audit_dict:
    """
    if audit_dict is not None:
        logger.info("Writing completion stats to audit table")
        logger.info(audit_dict)
        audit_df = (spark_obj.createDataFrame(audit_dict)
                    .withColumn("log_id_status", lit("COMPLETED"))
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", current_timestamp().cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("etl_layer", lit("normalized"))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)
        logger.info("Auditing is complete")
    else:
        logger.info("Writing initiating stats to audit table")
        audit_df = (spark_obj.createDataFrame([{'etl_layer': 'normalized', 'log_id_status': 'INITIATED'}])
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", lit(None).cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("table_name", lit(None).cast(StringType()))
                    .withColumn("rows_updated", lit(None).cast(IntegerType()))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)


if __name__ == "__main__":
    # Getting AWS Glue job parameters, creating session and initiating job
    arg = getResolvedOptions(sys.argv,
                             ['JOB_NAME', 'environment', 'batch_id'])

    logger.info("MARS XO job started")

    environment = arg['environment']
    config_obj = read_config_file('configuration.ini')
    check_config_section(config_obj, environment)
    job_start_time = datetime.datetime.now()

    sc = SparkContext()
    glueContext = GlueContext(sc)
    sprk = glueContext.spark_session
    job = Job(glueContext)
    job.init(arg['JOB_NAME'], arg)

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'),
                   audit_dict=None)
    audit_list = []

    nvs_etl = NvsETL(config_obj, arg, glueContext, sprk)

    crawler_client = boto3.client('glue', region_name="us-west-2")

    athena_cl = boto3.client('athena', region_name="us-west-2")

    audit_list += nvs_etl.nvs_tam(athena_cl)

    audit_list += nvs_etl.nvs_tam_trend_analysis(athena_cl)

    audit_list += nvs_etl.nvs_digital(athena_cl)

    audit_list += nvs_etl.nvs_digital_trend_analysis(athena_cl)

    nvs_etl.create_update_crawler(crawler_client)

    nvs_etl.start_crawler(crawler_client)

    nvs_etl.monitor_crawler(crawler_client)

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'),
                   audit_dict=audit_list)

    job.commit()
