import json
import logging
import configparser
import boto3
import sys
import time
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import *
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.types import *
import datetime
from pyspark.sql.window import Window
from pyspark.sql.functions import udf

MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def read_config_file(config_file_name):
    """
    This function is reading config file and returning config object
    :type config_file_name: string
    """
    config = configparser.ConfigParser()
    config.read(config_file_name)
    return config


def check_config_section(config, env):
    """
    This function check if section specified in job parameters is present in config file or not
    :param config: Config file object
    :param env: environment which is specified in job parameters
    """
    if not config.has_section(env):
        raise Exception("Environment details doesn't exist in configuration file")


class TamETL:
    def __init__(self, config, args, glue_context, spark):
        """
        This is init method used to initialize variables in class
        :param config: Config file object
        :param args: Arguments given to Glue job
        """
        self.env = args['environment']
        self.args = args
        self.bucket_name = config.get(self.env, "bucket_name")
        self.normalized_folder = json.loads(config.get(self.env, "folder_names"))['normalized']
        self.s3_path_list = []
        self.normalized_database = json.loads(config.get(self.env, "athena_database"))['normalized']
        self.config = config
        self.crawler_name = 'mars_tam_etl_crawler'
        self.glue_context = glue_context
        self.spark = spark
        self.landing_database = json.loads(config.get(self.env, "athena_database"))['landing']
        self.hcp_org_map_tbl = config.get(self.env, "hcp_org_map_tbl")
        self.mstr_roster_hierarchy_dly_stg_tbl = config.get(self.env, "mstr_roster_hierarchy_dly_stg_tbl")
        self.tam_tbl_stg = config.get(self.env, "tam_tbl_stg")
        self.evrysdi_hcp_zip_tbl = config.get(self.env, "evrysdi_hcp_zip_tbl")
        self.mars_finance_ce_spend_quarterly_stg = config.get(self.env, "mars_finance_ce_spend_quarterly_stg")
        self.tam_pccm_stg_tbl = config.get(self.env, "tam_pccm_stg_tbl")
        self.tam_pccm_hist_tbl = str(config.get(self.env, "tam_pccm_stg_tbl")).replace('_staging', '_historical')
        self.zip_to_eco_dly_tbl = config.get(self.env, "zip_to_eco_dly_tbl")
        self.title_codes = "'" + "','".join(json.loads(self.config.get(self.env, "roster_title_code_list"))) + "'"
        # self.tam_pccm_stg_tbl_021925 = config.get(self.env, "tam_pccm_stg_tbl_021925")
        self.dcx_ramp_daily_staging = config.get(self.env, "dcx_ramp_daily_staging")
        self.crm_commercial_approved_email = config.get(self.env, "crm_commercial_approved_email")


    def core(self, athena_client):
        df_tam_hds = self.spark.sql(f"""
            select position_number,
                min(start_date) as start_date,
                max(end_date) as end_date, 
                field_title_code
            from
                {self.normalized_database}.{self.mstr_roster_hierarchy_dly_stg_tbl}
            group by 1, 4
        """)
        df_tam_hds.registerTempTable('tam_hds')

        df_hcp_org_mapping = self.spark.sql(f"""
            select
                mdm_id,
                product_brand_id,
                product_brand_name,
                mdm_zip
            from {self.normalized_database}.{self.hcp_org_map_tbl}
        """)
        df_hcp_org_mapping.registerTempTable('hcp_org_mapping')

        df_tam_hd_calls = self.spark.sql(f"""
            select distinct
                ci.crm_call_id,
                ci.crm_position_number,
                ci.crm_position_name,
                ci.mdm_id,
                ci.crm_display_order,
                cast(1 / ci.crm_display_order as double) as call_wt,
                ci.crm_call_datetime,
                date(ci.crm_call_datetime) as call_date,
                ci.oasis_brand_name as product_brand_name,
                ci.oasis_product_brand_id as product_brand_id,
                hom.mdm_zip as zip,
                'HCP' as mdm_type, 
                'TAM' as channel
            from
                {self.normalized_database}.{self.tam_tbl_stg}
                    as ci
            inner join hcp_org_mapping as hom
                on
                    ci.mdm_id = hom.mdm_id
                    and size(
                    array_intersect(
                        array(ci.oasis_brand_name), hom.product_brand_name
                    )
                ) > 0
            where
                upper(crm_call_status) = 'SUBMITTED'
                and cast(crm_flag_person_account as integer) = 1
                and upper(oasis_brand_name) not in('EVRYSDI', 'HEMLIBRA', 'ACTEMRA')
        """)
        df_tam_hd_calls.registerTempTable('tam_hd_calls')

        df_call_topic_exclusion = self.spark.sql(f"""
            select distinct
                ci.crm_call_id,
                ci.crm_position_number,
                ci.crm_position_name,
                ci.mdm_id,
                ci.crm_display_order,
                cast(1 / ci.crm_display_order as double) as call_wt,
                ci.crm_call_datetime,
                date(ci.crm_call_datetime) as call_date,
                ci.oasis_brand_name as product_brand_name,
                ci.oasis_product_brand_id as product_brand_id,
                hom.mdm_zip as zip,
                'HCP' as mdm_type,
                'TAM' as channel
            from
                {self.normalized_database}.{self.tam_tbl_stg}
                    as ci
            inner join hcp_org_mapping as hom
                on
                    ci.mdm_id = hom.mdm_id
                    and size(
                    array_intersect(
                        array(ci.oasis_brand_name), hom.product_brand_name
                    )
                ) > 0
            where
                upper(crm_call_status) = 'SUBMITTED'
                and cast(crm_flag_person_account as integer) = 1
                and upper(oasis_brand_name) in('EVRYSDI', 'HEMLIBRA')
                and crm_call_topic not in( 
                        'Access / Coverage', 
                        'Access/Coverage', 
                        'Copay Card Discussion', 
                        'Genentech Patient Support Services', 
                        'Genentech Patient Support Services In-Service', 
                        'Local Coverage and Reimbursement Education', 
                        'Patient Access Issue - Benefits Verification', 
                        'Patient Access Issue - Claims Processing', 
                        'Patient Access Issue - Drug Delivery (B&B) / (SP)', 
                        'Patient Access Issue - Practice Process',
                        'Patient Access Issue - Patient Assistance', 
                        'Patient Access Issue - Prior Authorization', 
                        'Patient Access Issue - Re - verification', 
                        'Patient Access/Support Services', 
                        'Rebate Program Engagement'
                )                                 
        """)

        df_call_topic_exclusion.registerTempTable('call_topic_exclusion')

        df_evrysdi_calls = self.spark.sql(f"""
            select distinct
                ci.crm_call_id,
                ci.crm_position_number,
                ci.crm_position_name,
                ci.mdm_id,
                ci.crm_display_order,
                cast(1 / ci.crm_display_order as double) as call_wt,
                ci.crm_call_datetime,
                date(ci.crm_call_datetime) as call_date,
                ci.oasis_brand_name as product_brand_name,
                ci.oasis_product_brand_id as product_brand_id,
                ev.mdm_zip as zip,
                'HCP' as mdm_type, 
                'TAM' as channel
            from
                {self.normalized_database}.{self.tam_tbl_stg} as ci
            inner join
                {self.normalized_database}.{self.evrysdi_hcp_zip_tbl} as ev
                on ci.mdm_id = ev.mdm_id
            where upper(crm_call_status) = 'SUBMITTED' and cast(crm_flag_person_account as integer) = 1 
        """)
        df_evrysdi_calls.registerTempTable('evrysdi_extra_tam_hd_calls')

        df_actemra_calls = self.spark.sql(f"""
            select distinct
                ci.crm_call_id,
                ci.crm_position_number,
                ci.crm_position_name,
                ci.mdm_id,
                ci.crm_display_order,
                cast(1 / ci.crm_display_order as double) as call_wt,
                ci.crm_call_datetime,
                date(ci.crm_call_datetime) as call_date,
                ci.oasis_brand_name as product_brand_name,
                ci.oasis_product_brand_id as product_brand_id,
                hom.mdm_zip as zip,
                'HCP' as mdm_type, 
                case when th.field_title_code like '%CSO%' then 'CSO' else 'TAM' end as channel
            from
                {self.normalized_database}.{self.tam_tbl_stg}
                    as ci
            left join
                tam_hds as th
                on
                    ci.crm_position_number = th.position_number
                    and ci.crm_call_datetime between th.start_date and th.end_date
            inner join hcp_org_mapping as hom
                on
                    ci.mdm_id = hom.mdm_id
                    and size(
                    array_intersect(
                        array(ci.oasis_brand_name), hom.product_brand_name
                    )
                ) > 0
            where
                upper(crm_call_status) = 'SUBMITTED'
                and cast(crm_flag_person_account as integer) = 1
                and upper(oasis_brand_name) = 'ACTEMRA'
        """)
        df_actemra_calls.registerTempTable('actemra_only_calls')

        df_all_tam_calls = self.spark.sql("""
            with all_tam_hd as (
                select * from tam_hd_calls
                union all 
                select * from call_topic_exclusion
                union all 
                select * from evrysdi_extra_tam_hd_calls
                union all 
                select * from actemra_only_calls
            ),
            all_tam_hd_calls as (
                select 
                    th.crm_call_id,
                    th.crm_position_number,
                    th.crm_position_name,
                    th.mdm_id,
                    th.crm_display_order,
                    th.call_wt,
                    th.crm_call_datetime,
                    th.call_date,
                    th.product_brand_name,
                    th.product_brand_id,
                    th.zip,
                    th.mdm_type,
                    th.channel,
                    case 
                        when f.field_title_code is null then 
                            case
                                when th.crm_position_name like '%CSO%' then 'CSO' 
                                when th.crm_position_name like '%_TAM_%' then 'TAM' 
                                when th.crm_position_name like '%_HD_%' then 'HD' 
                                when th.crm_position_name like '%NRDS_%' then 'NRDS' 
                                when th.crm_position_name like '%_ACM_%' then 'ACM' 
                                else null 
                            end
                        else f.field_title_code 
                    end as field_title_code
                from all_tam_hd th
                left join tam_hds f
                    on th.crm_position_number = f.position_number 
                    and th.call_date between f.start_date and f.end_date
                where f.field_title_code in ('ACM','CRDP_TAM','CS','CSO_CS','CSO_DM','CSO_RD','HD','INTERN_TAM','NRDHD','NRDS','SCS','SNRDS','TAM')
            )
            select * from all_tam_hd_calls
        """)
        df_all_tam_calls.registerTempTable('all_tam_hd_calls')

        df_tam_hd_costs = self.spark.sql(f"""
            select
                upper(brand_name) as product_brand_name,
                channels,
                audience,
                cast(year as string) as year,
                substring(cast(quarter as string), 2, 1) as quarter,
                sum(spend_amount) as quarterly_cost
            from {self.normalized_database}.{self.mars_finance_ce_spend_quarterly_stg}
            group by 1, 2, 3, 4, 5
        """)
        df_tam_hd_costs.registerTempTable('tam_hd_costs')

        df_actemra_cost_allocation = self.spark.sql(f"""
            with daily_reach_actemra as(
                select
                    product_brand_name,
                    call_date,
                    zip,
                    channel,
                    sum(call_wt) as reach
                from all_tam_hd_calls
                where product_brand_name = 'ACTEMRA'
                group by 1, 2, 3, 4                                   
            ),

            quarterly_reach_actemra as (
                select
                    product_brand_name,
                    channel,
                    cast(year(call_date) as string) as year,
                    cast(quarter(call_date) as string) as quarter,
                    sum(reach) as quarterly_reach
                from daily_reach_actemra
                group by 1, 2, 3, 4
            ),  

            tam_only_quarters AS (
                select 
                    c.product_brand_name,
                    c.year,
                    c.quarter,
                    c.quarterly_cost,
                    r.quarterly_reach
                from tam_hd_costs c
                join quarterly_reach_actemra r 
                on c.product_brand_name = r.product_brand_name 
                and c.year = r.year 
                and c.quarter = r.quarter
                where r.channel = 'TAM'
                and not exists (
                    select 1
                    from quarterly_reach_actemra cso
                    where cso.product_brand_name = c.product_brand_name
                    and cso.year = c.year
                    and cso.quarter = c.quarter
                    and cso.channel = 'CSO'
                )
            ),

            tam_unit_cost as (
                select avg(quarterly_cost / nullif(quarterly_reach, 0)) as u_t
                from tam_only_quarters
            ),

            cso_dominant_quarters as (
                select 
                    c.product_brand_name,
                    c.year,
                    c.quarter,
                    c.quarterly_cost,
                    tam.quarterly_reach as tam_reach,
                    cso.quarterly_reach as cso_reach
                from tam_hd_costs c
                join quarterly_reach_actemra tam 
                on c.product_brand_name = tam.product_brand_name 
                and c.year = tam.year 
                and c.quarter = tam.quarter
                and tam.channel = 'TAM'
                join quarterly_reach_actemra cso
                on c.product_brand_name = cso.product_brand_name 
                and c.year = cso.year 
                and c.quarter = cso.quarter
                and cso.channel = 'CSO'
                where cso.quarterly_reach > tam.quarterly_reach
            ),

            cso_unit_cost AS (
                select avg((c.quarterly_cost - (c.tam_reach * t.u_t)) / nullif(c.cso_reach, 0)) as u_c
                from cso_dominant_quarters c
                cross join tam_unit_cost t
            ),

            cost_allocation as (
                select
                    qr.product_brand_name,
                    qr.year,
                    qr.quarter,
                    qr.channel,
                    qr.quarterly_reach,
                    c.quarterly_cost,
                    t.u_t AS tam_unit_cost,
                    cs.u_c AS cso_unit_cost,
                    case
                        when qr.channel = 'TAM' and oc.channel is null then c.quarterly_cost
                        when qr.channel = 'CSO' and oc.channel is null then c.quarterly_cost
                        else
                            case
                                when qr.channel = 'TAM' then
                                    c.quarterly_cost * (qr.quarterly_reach * t.u_t) /
                                    (qr.quarterly_reach * t.u_t + coalesce(oc.quarterly_reach, 0) * cs.u_c)
                                when qr.channel = 'CSO' then
                                    c.quarterly_cost * (qr.quarterly_reach * cs.u_c) /
                                    (coalesce(oc.quarterly_reach, 0) * t.u_t + qr.quarterly_reach * cs.u_c)
                            end
                        end as allocated_cost
                from quarterly_reach_actemra qr
                join tam_hd_costs c on qr.product_brand_name = c.product_brand_name and qr.year = c.year and qr.quarter = c.quarter
                cross join tam_unit_cost t
                cross join cso_unit_cost cs
                left join quarterly_reach_actemra oc on
                    oc.product_brand_name = qr.product_brand_name and
                    oc.year = qr.year and
                    oc.quarter = qr.quarter and
                    oc.channel = case when qr.channel = 'TAM' then 'CSO' else 'TAM' end
            ), 

            daily_allocation as (
                select
                    dr.product_brand_name,
                    dr.call_date,
                    dr.zip,
                    dr.channel,
                    dr.reach,
                    ca.allocated_cost * (dr.reach / ca.quarterly_reach) as allocated_cost
                from daily_reach_actemra dr
                join cost_allocation ca 
                on dr.product_brand_name = ca.product_brand_name
                and cast(year(dr.call_date) as string) = ca.year
                and cast(quarter(dr.call_date) as string) = ca.quarter
                and dr.channel = ca.channel
            )
            select * from daily_allocation 
        """)
        df_actemra_cost_allocation.registerTempTable('cost_allocation_actemra')

        df_daily_reach = self.spark.sql("""
            select
                product_brand_name,
                call_date,
                zip,
                channel,
                sum(call_wt) as reach
            from all_tam_hd_calls
            where upper(product_brand_name) != 'ACTEMRA'
            group by 1, 2, 3, 4
        """)
        df_daily_reach.registerTempTable('daily_reach')

        df_quarterly_reach = self.spark.sql("""
            select
                product_brand_name,
                cast(year(call_date) as string) as year,
                cast(quarter(call_date) as string) as quarter,
                sum(reach) as quarterly_reach
            from daily_reach
            group by 1, 2, 3
        """)
        df_quarterly_reach.registerTempTable('quarterly_reach')

        df_unit_cost = self.spark.sql("""
            with unit_cost as(
                select
                    c.product_brand_name,
                    c.year,
                    c.quarter,
                    c.quarterly_cost / nullif(r.quarterly_reach, 0) as unit_cost_tam
                from tam_hd_costs c
                join quarterly_reach r 
                    on c.product_brand_name = r.product_brand_name 
                    and c.year = r.year 
                    and c.quarter = r.quarter
                where c.channels in('TAM', 'ACM')
                and r.product_brand_name != 'ACTEMRA'
            ), 
            cost_allocation as (
                select
                    dr.product_brand_name,
                    dr.call_date,
                    dr.zip,
                    dr.reach,
                    dr.channel,
                    uc.unit_cost_tam,
                    dr.reach * uc.unit_cost_tam as allocated_cost
                from daily_reach dr
                join unit_cost uc
                    on dr.product_brand_name = uc.product_brand_name
                    and cast(year(dr.call_date) as string) = uc.year
                    and cast(quarter(dr.call_date) as string) = uc.quarter
            )
            select * from cost_allocation
        """)
        df_unit_cost.registerTempTable('cost_allocation')

        df_combined_all = self.spark.sql("""
            select 
                product_brand_name,
                call_date,
                zip,
                channel, 
                reach,
                allocated_cost
            from cost_allocation_actemra
            union all 
            select 
                product_brand_name,
                call_date,
                zip,
                channel, 
                reach,
                allocated_cost
            from cost_allocation
        """)
        df_combined_all.registerTempTable('cost_allocation_all')

        df_final_agg_ce = self.spark.sql("""
            with final_agg as(
                select 
                    product_brand_name, 
                    date_format(call_date, 'yyyyMM') as year_month,
                    zip, 
                    'CE' as audience, 
                    case when upper(channel) like '%TAM%' then 'tam_hd' else 'cso' end as channel,
                    sum(reach) as reach, 
                    sum(allocated_cost) as cost
                from cost_allocation_all
                group by 1, 2, 3, 4, 5
            ), 
            ce_final as(
                select 
                    product_brand_name,
                    year_month, 
                    zip, 
                    audience, 
                    channel, 
                    reach, 
                    case when product_brand_name = 'HEMLIBRA' and year_month >= '202307'
                        then cost / 2
                    else cost end as cost
                from final_agg
            )
            select * from ce_final

        """)
        df_final_agg_ce.registerTempTable('tam_ce_final')

        df_hemlibra_dtc = self.spark.sql(f"""
            with hemlibra_dtc_unioned as(
               -- select 
               --     zip_code, product, interaction_date, interaction_type, topic_discussed, number_of_patients, number_of_interactions
               --  from {self.normalized_database}.{self.tam_pccm_hist_tbl}
               --  where date_format(to_date(interaction_date, 'M/d/yyyy'), 'yyyyMM') between '202201' and '202312'
               --  and version = '21'
               --  union all 
                select 
                    zip_code, product, interaction_date, interaction_type, topic_discussed, number_of_patients, number_of_interactions
                from {self.normalized_database}.{self.tam_pccm_stg_tbl}
               -- where date_format(to_date(interaction_date, 'M/d/yyyy'), 'yyyyMM') >= '202401'
            ), 
            hemlibra_tam_dtc_calls as (
                select
                    pccm.zip_code as zip,
                    upper(pccm.product) as product_brand_name,
                    date_format(to_date(pccm.interaction_date, 'M/d/yyyy'), 'yyyyMM') as year_month,
                    'DTC' as audience,
                    'tam' as channel,
                    sum(pccm.number_of_interactions) as reach
                from hemlibra_dtc_unioned as pccm
                inner join {self.normalized_database}.{self.zip_to_eco_dly_tbl} as eco
                    on pccm.zip_code = eco.zip
                where
                    upper(pccm.product) = 'HEMLIBRA'
                    and eco.flag_active = 'Y'
                    and eco.ecosystem_dim_id > 0
                    and trim(pccm.interaction_type) != 'Attempted Contact'
                group by 1, 2, 3
            ), 
            hemlibra_tam_dtc_quarterly_reach as (
                select
                    product_brand_name,
                    cast(year(to_date(year_month, 'yyyyMM')) as string) AS year,
                    cast(quarter(to_date(year_month, 'yyyyMM')) as string) AS quarter,
                    sum(reach) as quarterly_reach
                from hemlibra_tam_dtc_calls
                group by 1, 2, 3
            ),

            hemlibra_tam_dtc_unit_cost as (
                select
                    c.product_brand_name,
                    c.year,
                    c.quarter,
                    c.quarterly_cost / nullif(r.quarterly_reach, 0) as unit_cost_tam
                from tam_hd_costs c
                join hemlibra_tam_dtc_quarterly_reach r 
                    on c.product_brand_name = r.product_brand_name 
                    and c.year = r.year 
                    and c.quarter = r.quarter
                where c.product_brand_name = 'HEMLIBRA' and c.channels in('ACM', 'PCCM')
            ),

            hemlibra_tam_dtc_cost_allocation as (
                select
                    c.product_brand_name,
                    c.year_month,
                    c.zip,
                    c.audience,
                    c.channel,
                    c.reach,
                    uc.unit_cost_tam,
                    c.reach * uc.unit_cost_tam as allocated_cost
                from hemlibra_tam_dtc_calls c
                join hemlibra_tam_dtc_unit_cost uc
                    on c.product_brand_name = uc.product_brand_name
                    and cast(year(to_date(year_month, 'yyyyMM')) as string) = uc.year
                    and cast(quarter(to_date(year_month, 'yyyyMM')) as string) = uc.quarter
            ),

            hemlibra_tam_dtc_final as (
                select 
                    product_brand_name,
                    year_month,
                    zip,
                    audience,
                    channel,
                    sum(reach) as reach,
                    sum(allocated_cost) as cost
                from hemlibra_tam_dtc_cost_allocation
                group by 1, 2, 3, 4, 5
            ),

            dtc_final as(
                select 
                    product_brand_name,
                    year_month,
                    zip,
                    audience,
                    channel,
                    reach,
                    case when product_brand_name = 'HEMLIBRA' and year_month >= '202307'
                        then cost / 2
                    else cost end as cost
                from hemlibra_tam_dtc_final
            )
            select * from dtc_final 
        """)
        df_hemlibra_dtc.registerTempTable('hemlibra_dtc_final')

        df_combined_final = self.spark.sql("""
            with final_agg as(
                select * from tam_ce_final
                union all 
                select * from hemlibra_dtc_final
            )
            select * from final_agg
        """)
        df_combined_final.registerTempTable('combined_final')

        df_cost_exclusion = self.spark.sql("""
             select 
                product_brand_name,
                year_month,
                zip,
                audience,
                channel,
                case when upper(product_brand_name) = 'LUNSUMIO' and year_month = '202212' then 0 
                    else reach end as reach, 
                case when upper(product_brand_name) = 'LUNSUMIO' and year_month = '202212' then 0
                    when upper(product_brand_name) = 'COLUMVI' and year_month = '202306' then 0 
                    else
                    cost end as cost,
                case  
                    when upper(product_brand_name) = 'LUNSUMIO' and year_month = '202212' then cost
                    when product_brand_name = 'COLUMVI' and year_month = '202306' then cost
                    else 0
                end as cost_to_distribute
            from combined_final                                                         
        """)

        df_cost_exclusion.registerTempTable('product_cost_exclusion')

        df_product_cost_to_distribute = self.spark.sql("""
             with product_all as (
                select 
                    product_brand_name,
                    year_month,
                    zip,
                    audience,
                    channel,
                    reach,
                    cost,
                    cost_to_distribute
                from product_cost_exclusion
            ),
            product_total_cost AS (
                select 
                    product_brand_name,
                    sum(cost_to_distribute) AS total_cost_to_distribute
                from product_cost_exclusion
                where (product_brand_name = 'COLUMVI' and year_month = '202306')
                or (product_brand_name = 'LUNSUMIO' and cost_to_distribute != 0)
                group by 1
            ),
            product_total_reach AS (
                select 
                    product_brand_name,
                    sum(reach) AS total_reach
                from product_cost_exclusion
                where substr(year_month, 1, 4) = '2023' 
                and product_brand_name in ('COLUMVI', 'LUNSUMIO')
                group by 1
            ), 
            cost_distribution AS (
                select 
                    pa.product_brand_name,
                    pa.year_month,
                    pa.zip,
                    pa.audience,
                    pa.channel,
                    pa.reach,
                    case 
                        when pa.product_brand_name = 'COLUMVI' and substr(pa.year_month, 1, 4) = '2023'
                        then pa.cost + (pa.reach / nullif(ptr.total_reach, 0) * ptc.total_cost_to_distribute)
                        when pa.product_brand_name = 'LUNSUMIO' and substr(pa.year_month, 1, 4) = '2023'
                        then pa.cost + (pa.reach / nullif(ptr.total_reach, 0) * ptc.total_cost_to_distribute)
                        else pa.cost 
                    end as cost
                from product_all pa
                left join product_total_cost ptc ON pa.product_brand_name = ptc.product_brand_name
                left join product_total_reach ptr ON pa.product_brand_name = ptr.product_brand_name
            )
            select * from cost_distribution                                          
        """)
        df_product_cost_to_distribute.registerTempTable('cost_distributed')

        df_tam_final_agg = self.spark.sql("""
            select 
                product_brand_name,
                year_month, 
                zip, 
                audience, 
                channel, 
                sum(reach) as reach,
                sum(cost) as cost 
            from cost_distributed 
            group by 1, 2, 3, 4, 5
        """)

        df_tam_final_agg.registerTempTable('tam_final_agg')

        df_vae_all = self.spark.sql(f"""
            with tam_hds as(
                select distinct
                    unix_id,
                    start_date,
                    end_date, 
                    field_title_code, 
                    position_number
                from
                    {self.normalized_database}.{self.mstr_roster_hierarchy_dly_stg_tbl}
                where
                    field_title_code in ('ACM','CRDP_TAM','CS','CSO_CS','CSO_DM','CSO_RD','HD','INTERN_TAM','NRDHD','NRDS','SCS','SNRDS','TAM')
            ),     
            tam_hds_for_crm as(
                    select position_number,
                        min(start_date) as start_date,
                        max(end_date) as end_date, 
                        field_title_code
                    from
                        {self.normalized_database}.{self.mstr_roster_hierarchy_dly_stg_tbl}
                        group by 1,4
            ), 
            dcx_ramp_raw as(
                select 
                    distinct 
                    mdm_id, 
                    imdb_id,
                    group_id, 
                    sender_username, 
                    case when product_brand_name in('ACTEMRA IV', 'ACTEMRA SC') then 'ACTEMRA' else upper(product_brand_name) 
                            end as product_brand_name,
                    territory_id,
                    to_date(from_unixtime(unix_timestamp(input_date_time, 'yyyy-MM-dd HH:mm:ss'))) as input_date_time,
                    activity_type
                from {self.normalized_database}.{self.dcx_ramp_daily_staging}
                where upper(activity_type) in('DELIVERED', 'OPEN')
            ), 
            dcx_ramp_emails as(
                select 
                    dr.product_brand_name, 
                    date_format(input_date_time, 'yyyyMM') as date_year_month,
                    hom.mdm_zip as zip, 
                    'CE' as audience, 
                    'VAE' as channel,
                    th.field_title_code, 
                    count(
                        distinct 
                        case when upper(activity_type) in('DELIVERED') then group_id end
                    ) as reach, 
                    count(
                        distinct 
                        case when upper(activity_type) in ('OPEN') then group_id end
                    ) as engage
                from dcx_ramp_raw as dr 
                inner join tam_hds as th 
                on
                    dr.sender_username = th.unix_id
                    and dr.input_date_time between th.start_date and th.end_date
                inner join hcp_org_mapping as hom
                    on dr.mdm_id = hom.mdm_id
                        and size(
                            array_intersect(
                                array(dr.product_brand_name), hom.product_brand_name
                            )
                        ) > 0
                    group by 1, 2, 3, 4, 5, 6    
            ), 
            vae_raw as(
                select 
                    distinct 
                    mdm_id, 
                    product_brand_name, 
                    position_number,
                    position_name,
                    date_year_month, 
                    email_status,
                    activity_type,
                    sent_email_id,
                    crm_activity_client_name,
                    crm_activity_client_operating_system,
                    crm_activity_client_type,
                    crm_activity_device_type,
                    crm_activity_user_agent,
                    date(email_sent_date) as email_sent_date
                from {self.normalized_database}.{self.crm_commercial_approved_email} 
                where upper(activity_type) not in('DROPPED', 'BOUNCED')
            ), 
            vae_emails as(
                    select 
                        vr.product_brand_name,
                        vr.date_year_month,
                        hom.mdm_zip as zip, 
                        'CE' as audience, 
                        'VAE' as channel,
                        case 
                            when th.field_title_code is null then 
                                case
                                    when vr.position_name like '%CSO%' then 'CSO' 
                                    when vr.position_name like '%_TAM_%' then 'TAM' 
                                    when vr.position_name like '%_HD_%' then 'HD' 
                                    when vr.position_name like '%NRDS_%' then 'NRDS' 
                                    when vr.position_name like '%_ACM_%' then 'ACM' 
                                    else null 
                                end
                            else th.field_title_code 
                        end as field_title_code,
                        count(
                            distinct 
                            case when upper(email_status) in('DELIVERED', 'MARKED_SPAM', 'UNSUBSCRIBED') then sent_email_id end
                        ) as reach, 
                        count(
                            distinct 
                            case when 
                                upper(activity_type) = 'OPENED' 
                                and (
                                    crm_activity_client_name != 'unknown'
                                    or crm_activity_client_operating_system != 'unknown'
                                    or crm_activity_client_type != 'unknown'
                                    or crm_activity_device_type != 'unknown'
                                    or crm_activity_user_agent != 'Mozilla/5.0'
                                )
                            then sent_email_id end
                        ) as engage
                    from vae_raw as vr 
                    left join tam_hds th
                        on vr.position_number = th.position_number 
                        and vr.email_sent_date between th.start_date and th.end_date            
                    inner join hcp_org_mapping as hom
                        on vr.mdm_id = hom.mdm_id
                            and size(
                                array_intersect(
                                    array(vr.product_brand_name), hom.product_brand_name
                                )
                            ) > 0
                    where th.field_title_code in ('ACM','CRDP_TAM','CS','CSO_CS','CSO_DM','CSO_RD','HD','INTERN_TAM','NRDHD','NRDS','SCS','SNRDS','TAM')
                    group by 1, 2, 3, 4, 5, 6
                )
                select 
                    product_brand_name,
                    date_year_month as year_month, 
                    zip,
                    lower(audience) as audience,
                    lower(channel) as channel,
                    sum(reach) as reach,
                    sum(engage) as engage 
                from dcx_ramp_emails
                group by 1, 2, 3, 4, 5
                union all 
                select 
                    product_brand_name,
                    date_year_month as year_month, 
                    zip,
                    lower(audience) as audience,
                    lower(channel) as channel,
                    sum(reach) as reach,
                    sum(engage) as engage 
                from vae_emails
                group by 1, 2, 3, 4, 5
            """)
        df_vae_all.registerTempTable('vae_unioned')

        df_final_agg = self.spark.sql("""
            select 
                product_brand_name,
                year_month,
                zip, 
                audience,
                channel,
                reach,
                engage,
                cast(null as double) as cost 
            from vae_unioned
            where year_month >= '202201'
            union all 
            select 
                product_brand_name,
                year_month, 
                zip, 
                lower(audience) as audience,
                lower(channel) as channel,
                reach,
                cast(null as double) as engage,
                cost
            from tam_final_agg
        """)
        df_final_agg.registerTempTable('final_agg')
        df_final_agg_persisted = df_final_agg.persist()

        audit_info = []
        audit_info += [{'table_name': f"{self.normalized_database}.mars_tam_staging",
                        'rows_updated': df_final_agg_persisted.count()}]

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/etl/mars_tam_staging/")
        df_final_agg_persisted.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.normalized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)

        if 'mars_tam_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.normalized_database,
                                                                                table_name='mars_tam_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            final_agg_hist_df = df_final_agg_persisted.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to historical layer, it is getting loaded into historical for first time
            final_agg_hist_df = df_final_agg_persisted.withColumn('version', lit(1))
            logger.info(f"Back up table does not exist for mars_tam_historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.normalized_database}.mars_tam_historical",
             'rows_updated': df_final_agg_persisted.count()})

        s3_path = ("s3://" + self.bucket_name + "/" + self.normalized_folder + "/etl/" +
                   'mars_tam_historical' + "/")
        final_agg_hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def create_update_crawler(self, client):
        """
        Crawler has to be created if it doesn't exist, if it exists then we have to update it s3 path for it.
        :param client: glue boto3 client used to create or update crawler
        """
        # Creating list of s3 path that has to be crawled
        s3_crawl_list = []
        for s3_path in list(set(self.s3_path_list)):
            s3_crawl_list.append(
                {"Path": s3_path, 'Exclusions': json.loads(self.config.get(self.env, "crawl_exclusion_paths"))})

        crawler_exist = True

        # Checking if crawler is already existing or not
        try:
            res = client.get_crawler(Name=self.crawler_name)
            response = json.dumps(res, indent=4, sort_keys=True, default=str)
            print(response)
        except client.exceptions.EntityNotFoundException as e:
            logger.info("Crawler doesnt exist, need to create")
            crawler_exist = False

        # Creating crawler if it doesn't exist
        if crawler_exist:
            response = client.update_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.normalized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Updated\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

        else:
            response = client.create_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.normalized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Created\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

    def start_crawler(self, client):
        """
        This method is used to start the crawler
        :param client: glue boto3 client used to create or update crawler
        """
        response_start = client.start_crawler(Name=self.crawler_name)
        logger.info("Crawler Started\nName : " + self.crawler_name)
        logger.info(json.dumps(response_start, indent=4, sort_keys=True, default=str))

    def monitor_crawler(self, client):
        """
        This method is used to monitor the crawler which we started just now
        :param client: glue boto3 client used to create or update crawler
        """
        need_to_wait = True
        state_previous = None
        while need_to_wait:
            time.sleep(20)
            response_get = client.get_crawler(Name=self.crawler_name)
            state = response_get["Crawler"]["State"]
            if state == "READY" or state == "STOPPING":  # Other known states: RUNNING
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                need_to_wait = False
                break
            if state != state_previous:
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                state_previous = state


def audit_job_info(spark_obj, job_srt_time, job_name, batch_id, audit_path, audit_dict):
    """
    This function is used to write audit stats of this etl job to athena table.
    :param audit_path:
    :param spark_obj:
    :param job_srt_time:
    :param job_name:
    :param batch_id:
    :param audit_dict:
    """
    if audit_dict is not None:
        logger.info("Writing completion stats to audit table")
        logger.info(audit_dict)
        audit_df = (spark_obj.createDataFrame(audit_dict)
                    .withColumn("log_id_status", lit("COMPLETED"))
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", current_timestamp().cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("etl_layer", lit("normalized"))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)
        logger.info("Auditing is complete")
    else:
        logger.info("Writing initiating stats to audit table")
        audit_df = (spark_obj.createDataFrame([{'etl_layer': 'normalized', 'log_id_status': 'INITIATED'}])
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", lit(None).cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("table_name", lit(None).cast(StringType()))
                    .withColumn("rows_updated", lit(None).cast(IntegerType()))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)


if __name__ == "__main__":
    # Getting AWS Glue job parameters, creating session and initiating job
    arg = getResolvedOptions(sys.argv,
                             ['JOB_NAME', 'environment', 'batch_id'])

    logger.info("MARS TAM job started")

    environment = arg['environment']
    config_obj = read_config_file('configuration.ini')
    check_config_section(config_obj, environment)
    job_start_time = datetime.datetime.now()

    sc = SparkContext()
    glueContext = GlueContext(sc)
    sprk = glueContext.spark_session
    job = Job(glueContext)
    job.init(arg['JOB_NAME'], arg)

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'),
                   audit_dict=None)
    audit_list = []

    tam_etl = TamETL(config_obj, arg, glueContext, sprk)

    athena_cl = boto3.client('athena', region_name="us-west-2")

    crawler_client = boto3.client('glue', region_name="us-west-2")

    audit_list += tam_etl.core(athena_cl)

    tam_etl.create_update_crawler(crawler_client)

    tam_etl.start_crawler(crawler_client)

    tam_etl.monitor_crawler(crawler_client)

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'),
                   audit_dict=audit_list)

    job.commit()
