
def main():
    job_name = "my_glue_job"
    print(f"Creating AWS Glue job: {job_name}")

if __name__ == "__main__":
    main()
