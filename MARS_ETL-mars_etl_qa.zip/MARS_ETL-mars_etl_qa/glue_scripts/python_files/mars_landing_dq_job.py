import json
import logging
import configparser
import boto3
import sys
import time
from pyspark.sql.window import Window
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import *
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.types import *
import pandas as pd
from datetime import datetime
from cloudpathlib import S3Path

MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def read_config_file(config_file_name):
    """
    This function is reading config file and returning config object
    :type config_file_name: string
    """
    config = configparser.ConfigParser()
    config.read(config_file_name)
    return config


def check_config_section(config, env):
    """
    This function check if section specified in job parameters is present in config file or not
    :param config: Config file object
    :param env: environment which is specified in job parameters
    """
    if not config.has_section(env):
        raise Exception("Environment details doesn't exist in configuration file")


class DataQualityReport:
    def __init__(self, config, args, glue_context, spark):
        """
        This is init method used to initialize variables in class
        :param config: Config file object
        :param args: Arguments given to Glue job
        """

        self.env = args['environment']
        self.spark = spark
        self.tam_previous_version_num = config.get(self.env, "tam_previous_version_num", fallback=None)
        self.tam_pccm_previous_version_num = config.get(self.env, "tam_pccm_previous_version_num", fallback=None)
        self.speaker_previous_version_num = config.get(self.env, "speaker_previous_version_num", fallback=None)
        self.event_previous_version_num = config.get(self.env, "event_previous_version_num", fallback=None)
        self.net_sales_previous_version_num = config.get(self.env, "net_sales_previous_version_num", fallback=None)
        self.sales_previous_version_num = config.get(self.env, "sales_previous_version_num", fallback=None)
        self.xo_previous_version_num = config.get(self.env, "xo_previous_version_num", fallback=None)
        self.tam_cost_previous_version_num = config.get(self.env, "tam_cost_previous_version_num", fallback=None)
        self.args = args
        self.bucket_name = config.get(self.env, "bucket_name")
        self.landing_folder = json.loads(config.get(self.env, "folder_names"))['landing']
        self.s3_path_list = []
        self.landing_database = json.loads(config.get(self.env, "athena_database"))['landing']
        self.config = config
        self.crawler_name = 'mars_landing_dq_crawler'
        self.glue_context = glue_context
        self.sales_qty_tbl = config.get(self.env, "sales_weekly_tble")
        self.dcx_ramp_daily_tbl = config.get(self.env, "dcx_ramp_daily_tbl")
        self.crm_commercial_approved_email_tbl = config.get(self.env, "crm_commercial_approved_email_tbl")
        self.speaker_tbl = config.get(self.env, "speaker_tbl")
        self.event_tbl = config.get(self.env, "event_tbl")
        self.net_sales_tbl = config.get(self.env, "net_sales_tbl")
        self.alignment_roster_hierarchy_daily_tbl = config.get(self.env, "alignment_roster_hierarchy_daily_tbl")
        # self.xo_digital_tbl = config.get(self.env, "xo_digital_tbl")
        self.sst_all_media_summary_bimonthly = config.get(self.env, "sst_all_media_summary_bimonthly")
        self.tam_tbl = config.get(self.env, "tam_tbl")
        # self.tam_pccm_tbl_021925 = config.get(self.env, "tam_pccm_tbl_021925")
        self.tam_pccm_tbl = config.get(self.env, "tam_pccm_tbl")
        self.tam_cost = config.get(self.env, "tam_cost_tbl")
        self.tam_old_cost = config.get(self.env, "tam_old_cost_tbl")
        self.zip_to_ecosystem = config.get(self.env, "zip_to_ecosystem_tbl")
        self.zip_zcta_crosswalk = config.get(self.env, "zip_zcta_crosswalk_tbl")
        self.zip_to_dma = config.get(self.env, "zip_to_dma_tbl")
        self.mstr_cm_mdm = config.get(self.env, "mstr_cm_mdm_tbl")
        self.mstr_cm_org = config.get(self.env, "mstr_cm_org_tbl")
        self.speaker_participant = config.get(self.env, "speaker_participant_tbl")
        self.mars_product_names = json.loads(self.config.get(self.env, "mars_product_names_list"))
        self.population_demo_tbl = config.get(self.env, "population_demo_tbl")
        self.speaker_non_assoc_brands = config.get(self.env, "speaker_non_assoc_brands")
        self.title_codes = "'" + "','".join(json.loads(self.config.get(self.env, "roster_title_code_list"))) + "'"
        self.upper_bound_year_month = int(config.get(self.env, "upper_bound_year_month"))
        self.lower_bound_year_month = int(config.get(self.env, "lower_bound_year_month"))
        self.group_channels = json.loads(config.get(self.env, "grp_channels"))

    def exception_reports(self):
        logger.info("Started creating Exception reports")

        audit_info = []
        zip_to_eco_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                         table_name=self.zip_to_ecosystem)
        zip_zcta_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                       table_name=self.zip_zcta_crosswalk)
        xo_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                 table_name=self.sst_all_media_summary_bimonthly)
        zip_to_dma_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                         table_name=self.zip_to_dma)

        sales_qty_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                        table_name=self.sales_qty_tbl)
        speaker_participant_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                                  table_name=self.speaker_participant)
        mstr_cm_mdm_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                          table_name=self.mstr_cm_mdm)
        mstr_cm_org_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                          table_name=self.mstr_cm_org)
        tam_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                  table_name=self.tam_tbl)

        mdm_df = (mstr_cm_mdm_df
                  .selectExpr("mdm_id")
                  .where(col('mdm_id').isNotNull())
                  .union(mstr_cm_org_df
                         .selectExpr("org_mdm_id as mdm_id")
                         .where(col('mdm_id').isNotNull()))
                  .distinct()
                  .persist()
                  )
        sales_df = (sales_qty_df
                    .where(upper(col('product_brand_name')).isin(self.mars_product_names))
                    .withColumn('year_month', col('date_year_month').cast(IntegerType()))
                    .where(col('year_month') >= self.lower_bound_year_month)
                    #                   .where(col('year_month') <= self.upper_bound_year_month)
                    )
        sales_mdm_df = (sales_df
                        .selectExpr("mdm_id")
                        .union(sales_df.
                               selectExpr("site_mdm_id as mdm_id"))
                        .where(col('mdm_id').isNotNull())
                        .distinct()
                        )

        sales_exception_df = sales_mdm_df.join(mdm_df,
                                               upper(trim(mdm_df["mdm_id"])) == upper(trim(sales_mdm_df["mdm_id"])),
                                               'left_anti')
        tam_mdm_df = (tam_df
                      .where(upper(col('oasis_brand_name')).isin(self.mars_product_names))
                      .selectExpr("mdm_id", 'cast(crm_call_datetime as date) as call_date')
                      .withColumn('year_month', date_format(col('call_date'), 'yyyyMM').cast(IntegerType()))
                      .where(col('year_month') >= self.lower_bound_year_month)
                      #                      .where(col('year_month') <= self.upper_bound_year_month)
                      .where(col('mdm_id').isNotNull()).drop('year_month', 'call_date')
                      .distinct())

        tam_exception_df = (tam_mdm_df
                            .join(mdm_df,
                                  upper(trim(mdm_df["mdm_id"])) == upper(trim(tam_mdm_df["mdm_id"])),
                                  'left_anti')
                            )

        speaker_df = (speaker_participant_df
                      .selectExpr("participant_mdm_id as mdm_id")
                      .where(col('mdm_id').isNotNull())
                      .distinct())

        speaker_exception_df = (speaker_df
                                .join(mdm_df,
                                      upper(trim(mdm_df["mdm_id"])) == upper(trim(speaker_df["mdm_id"])),
                                      'left_anti')
                                )

        audit_info += [{'table_name': f"{self.landing_database}.mars_mdm_tam_exceptions",
                        'rows_updated': tam_exception_df.count()}]
        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/exception_folder/" +
                   'mars_mdm_tam_exceptions' + "/")
        tam_exception_df.coalesce(1).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        audit_info += [{'table_name': f"{self.landing_database}.mars_mdm_sales_exceptions",
                        'rows_updated': sales_exception_df.count()}]
        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/exception_folder/" +
                   'mars_mdm_sales_exceptions' + "/")
        sales_exception_df.coalesce(1).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        audit_info += [{'table_name': f"{self.landing_database}.mars_mdm_speaker_exceptions",
                        'rows_updated': speaker_exception_df.count()}]
        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/exception_folder/" +
                   'mars_mdm_speaker_exceptions' + "/")
        speaker_exception_df.coalesce(1).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        logger.info("Row count for MDM : " + str(mdm_df.count()))

        geo_demo_xo_df = (xo_df
                          .where(upper(col('brand_name')).isin(self.mars_product_names))
                          .where(col('year') >= int(str(self.lower_bound_year_month)[:-2]))
                          #                          .where(col('year') <= int(str(self.upper_bound_year_month)[:-2]))
                          .selectExpr('zip_code as ZIP', 'upper(dma) as DMA').persist())
        logger.info("Row count for XO : " + str(geo_demo_xo_df.count()))

        dma_df = zip_to_dma_df.selectExpr("upper(`designated market area`) as DMA").distinct()

        exception_dma = (geo_demo_xo_df
                         .where(col('DMA').isNotNull())
                         .select("DMA")
                         .distinct()
                         .join(dma_df,
                               upper(trim(geo_demo_xo_df.DMA)) == upper(trim(dma_df.DMA)),
                               'left_anti'))

        audit_info += [{'table_name': f"{self.landing_database}.mars_dma_exceptions",
                        'rows_updated': exception_dma.count()}]
        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/exception_folder/" +
                   'mars_dma_exceptions' + "/")
        exception_dma.coalesce(1).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        union_zip_df = (zip_to_eco_df
                        .selectExpr("zip as ZIP")
                        .union(zip_zcta_df.selectExpr("zip as ZIP"))
                        .where(col('ZIP').isNotNull())
                        .distinct())

        exception_zip = (geo_demo_xo_df
                         .where(col('ZIP').isNotNull())
                         .select("ZIP")
                         .distinct()
                         .join(union_zip_df,
                               upper(trim(geo_demo_xo_df.ZIP)) == upper(trim(union_zip_df.ZIP)),
                               'left_anti'))

        audit_info += [{'table_name': f"{self.landing_database}.mars_zip_exceptions",
                        'rows_updated': exception_zip.count()}]
        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/exception_folder/" +
                   'mars_zip_exceptions' + "/")
        self.s3_path_list += [s3_path]
        exception_zip.coalesce(1).write.mode('overwrite').parquet(s3_path)

        return audit_info

    def tam_aggregate_data(self, spark):
        """
        This method is to write data quality for tam data to s3
        :return: audit_info : List of stats for audit purpose
        """
        logger.info("Started tam data quality aggregation")
        reporting_folder = json.loads(self.config.get(self.env, "dq_report_paths"))['tam_dq_report_path']

        df_tam_hds = spark.sql(f"""
                select position_number,
                    min(start_date) as start_date,
                    max(end_date) as end_date, 
                    field_title_code
                from
                    {self.landing_database}.{self.alignment_roster_hierarchy_daily_tbl}
                group by 1, 4
                """)
        df_tam_hds.registerTempTable('tam_hds')

        df_tam_hd_calls = spark.sql(f"""
                    select distinct
                        ci.crm_call_id,
                        ci.crm_position_number,
                        ci.crm_position_name,
                        ci.mdm_id,
                        ci.crm_display_order,
                        cast(1 / ci.crm_display_order as double) as call_wt,
                        ci.crm_call_datetime,
                        date(ci.crm_call_datetime) as call_date,
                        ci.oasis_brand_name as product_brand_name,
                        ci.oasis_product_brand_id as product_brand_id,
                        'HCP' as mdm_type,
                        'TAM' as channel
                    from
                        {self.landing_database}.{self.tam_tbl} as ci 
                    where
                        upper(crm_call_status) = 'SUBMITTED'
                        and cast(crm_flag_person_account as integer) = 1
                        and ci.oasis_brand_name != 'ACTEMRA'
                        and ci.oasis_brand_name in ({"'" + "','".join(json.loads(self.config.get(self.env, "mars_product_names_list"))) + "'"}) 
                """)
        df_tam_hd_calls.registerTempTable('tam_hd_calls')

        df_tam_hd_actemra_calls = self.spark.sql(f"""
                            select distinct
                                ci.crm_call_id,
                                ci.crm_position_number,
                                ci.crm_position_name,
                                ci.mdm_id,
                                ci.crm_display_order,
                                cast(1 / ci.crm_display_order as double) as call_wt,
                                ci.crm_call_datetime,
                                date(ci.crm_call_datetime) as call_date,
                                ci.oasis_brand_name as product_brand_name,
                                ci.oasis_product_brand_id as product_brand_id,
                                'HCP' as mdm_type,
                                case when th.field_title_code like '%CSO%' then 'CSO' else 'TAM' end as channel
                            from
                                {self.landing_database}.{self.tam_tbl} as ci 
                            left join
                                tam_hds as th
                                on
                                    ci.crm_position_number = th.position_number
                                    and ci.crm_call_datetime between th.start_date and th.end_date
                            where
                                upper(crm_call_status) = 'SUBMITTED'
                                and cast(crm_flag_person_account as integer) = 1
                                and ci.oasis_brand_name = 'ACTEMRA'                 
                        """)
        df_tam_hd_actemra_calls.registerTempTable('tam_hd_actemra_calls')

        union_df = self.spark.sql("""
                with all_tam_hd as(
                    select crm_position_name, crm_position_number, product_brand_name, channel, call_date, call_wt from tam_hd_actemra_calls
                    union all
                    select crm_position_name, crm_position_number, product_brand_name, channel, call_date, call_wt from tam_hd_calls  
                ), 
                all_tam_hd_calls as (
                    select 
                        th.crm_position_number,
                        th.crm_position_name,
                        th.call_wt,
                        th.call_date,
                        th.product_brand_name,
                        th.channel,
                        case 
                            when f.field_title_code is null then 
                                case
                                    when th.crm_position_name like '%CSO%' then 'CSO' 
                                    when th.crm_position_name like '%_TAM_%' then 'TAM' 
                                    when th.crm_position_name like '%_HD_%' then 'HD' 
                                    when th.crm_position_name like '%NRDS_%' then 'NRDS' 
                                    when th.crm_position_name like '%_ACM_%' then 'ACM' 
                                    else null 
                                end
                            else f.field_title_code 
                        end as field_title_code
                    from all_tam_hd th
                    left join tam_hds f
                        on th.crm_position_number = f.position_number 
                        and th.call_date between f.start_date and f.end_date
                    where f.field_title_code in ('ACM','CRDP_TAM','CS','CSO_CS','CSO_DM','CSO_RD','HD','INTERN_TAM','NRDHD','NRDS','SCS','SNRDS','TAM')
            )
            select * from all_tam_hd_calls
        """)
        union_df.registerTempTable('all_tam_hd_calls')

        df_daily_reach = spark.sql("""
                    select
                        product_brand_name,
                        call_date,
                        channel,
                        sum(call_wt) as reach
                    from all_tam_hd_calls
                    where upper(product_brand_name) != 'ACTEMRA'
                    group by 1, 2, 3
                """)
        df_daily_reach.registerTempTable('daily_reach')

        df_quarterly_reach = spark.sql("""
                    select
                        product_brand_name,
                        cast(year(call_date) as string) as year,
                        cast(quarter(call_date) as string) as quarter,
                        sum(reach) as quarterly_reach
                    from daily_reach
                    group by 1, 2, 3
                """)
        df_quarterly_reach.registerTempTable('quarterly_reach')

        df_tam_hd_costs = spark.sql(f"""
                    select
                        upper(brand_name) as product_brand_name,
                        channels,
                        audience,
                        cast(year as string) as year,
                        substring(cast(quarter as string), 2, 1) as quarter,
                        sum(spend_amount) as quarterly_cost
                    from {self.landing_database}.{self.tam_cost}
                    group by 1, 2, 3, 4, 5
                """)
        df_tam_hd_costs.registerTempTable('tam_hd_costs')

        df_unit_cost = spark.sql("""
                    with unit_cost as(
                        select
                            c.product_brand_name,
                            c.year,
                            c.quarter,
                            c.quarterly_cost / nullif(r.quarterly_reach, 0) as unit_cost_tam
                        from tam_hd_costs c
                        join quarterly_reach r 
                            on c.product_brand_name = r.product_brand_name 
                            and c.year = r.year 
                            and c.quarter = r.quarter
                        where c.channels in('TAM', 'ACM')
                        and r.product_brand_name != 'ACTEMRA'
                    ), 
                    cost_allocation as (
                        select
                            dr.product_brand_name,
                            dr.call_date,
                            dr.channel,
                            dr.reach,
                            uc.unit_cost_tam,
                            dr.reach * uc.unit_cost_tam as allocated_cost
                        from daily_reach dr
                        join unit_cost uc
                            on dr.product_brand_name = uc.product_brand_name
                            and cast(year(dr.call_date) as string) = uc.year
                            and cast(quarter(dr.call_date) as string) = uc.quarter
                    )
                    select * from cost_allocation
                """)
        df_unit_cost.createOrReplaceTempView('cost_allocation')

        df_tam_hd_calls_actemra = spark.sql(f"""
                    select
                        product_brand_name,
                        call_date,
                        channel,
                        call_wt
                    from all_tam_hd_calls
                    where upper(product_brand_name) = 'ACTEMRA'

            """)
        df_tam_hd_calls_actemra.createOrReplaceTempView('all_tam_hd_calls_actemra')

        df_actemra_cost_allocation = spark.sql(f"""
                with daily_reach_actemra as(
                    select
                        product_brand_name,
                        call_date,
                        channel,
                        sum(call_wt) as reach
                    from all_tam_hd_calls_actemra
                    group by 1, 2, 3                               
                ),

                quarterly_reach_actemra as (
                    select
                        product_brand_name,
                        channel,
                        cast(year(call_date) as string) as year,
                        cast(quarter(call_date) as string) as quarter,
                        sum(reach) as quarterly_reach
                    from daily_reach_actemra
                    group by 1, 2, 3, 4
                ),  

                tam_only_quarters AS (
                    select 
                        c.product_brand_name,
                        c.year,
                        c.quarter,
                        c.quarterly_cost,
                        r.quarterly_reach
                    from tam_hd_costs c
                    join quarterly_reach_actemra r 
                    on c.product_brand_name = r.product_brand_name 
                    and c.year = r.year 
                    and c.quarter = r.quarter
                    where r.channel = 'TAM'
                    and not exists (
                        select 1
                        from quarterly_reach_actemra cso
                        where cso.product_brand_name = c.product_brand_name
                        and cso.year = c.year
                        and cso.quarter = c.quarter
                        and cso.channel = 'CSO'
                    )
                ),

                tam_unit_cost as (
                    select avg(quarterly_cost / nullif(quarterly_reach, 0)) as u_t
                    from tam_only_quarters
                ),

                cso_dominant_quarters as (
                    select 
                        c.product_brand_name,
                        c.year,
                        c.quarter,
                        c.quarterly_cost,
                        tam.quarterly_reach as tam_reach,
                        cso.quarterly_reach as cso_reach
                    from tam_hd_costs c
                    join quarterly_reach_actemra tam 
                    on c.product_brand_name = tam.product_brand_name 
                    and c.year = tam.year 
                    and c.quarter = tam.quarter
                    and tam.channel = 'TAM'
                    join quarterly_reach_actemra cso
                    on c.product_brand_name = cso.product_brand_name 
                    and c.year = cso.year 
                    and c.quarter = cso.quarter
                    and cso.channel = 'CSO'
                    where cso.quarterly_reach > tam.quarterly_reach
                ),

                cso_unit_cost AS (
                    select avg((c.quarterly_cost - (c.tam_reach * t.u_t)) / nullif(c.cso_reach, 0)) as u_c
                    from cso_dominant_quarters c
                    cross join tam_unit_cost t
                ),

                cost_allocation as (
                    select
                        qr.product_brand_name,
                        qr.year,
                        qr.quarter,
                        qr.channel,
                        qr.quarterly_reach,
                        c.quarterly_cost,
                        t.u_t AS tam_unit_cost,
                        cs.u_c AS cso_unit_cost,
                        case
                            when qr.channel = 'TAM' and oc.channel is null then c.quarterly_cost
                            when qr.channel = 'CSO' and oc.channel is null then c.quarterly_cost
                            else
                                case
                                    when qr.channel = 'TAM' then
                                        c.quarterly_cost * (qr.quarterly_reach * t.u_t) /
                                        (qr.quarterly_reach * t.u_t + coalesce(oc.quarterly_reach, 0) * cs.u_c)
                                    when qr.channel = 'CSO' then
                                        c.quarterly_cost * (qr.quarterly_reach * cs.u_c) /
                                        (coalesce(oc.quarterly_reach, 0) * t.u_t + qr.quarterly_reach * cs.u_c)
                                end
                            end as allocated_cost
                    from quarterly_reach_actemra qr
                    join tam_hd_costs c on qr.product_brand_name = c.product_brand_name and qr.year = c.year and qr.quarter = c.quarter
                    cross join tam_unit_cost t
                    cross join cso_unit_cost cs
                    left join quarterly_reach_actemra oc on
                        oc.product_brand_name = qr.product_brand_name and
                        oc.year = qr.year and
                        oc.quarter = qr.quarter and
                        oc.channel = case when qr.channel = 'TAM' then 'CSO' else 'TAM' end
                ), 

                daily_allocation as (
                    select
                        dr.product_brand_name,
                        dr.call_date,
                        dr.channel,
                        dr.reach,
                        ca.allocated_cost * (dr.reach / ca.quarterly_reach) as allocated_cost
                    from daily_reach_actemra dr
                    join cost_allocation ca 
                    on dr.product_brand_name = ca.product_brand_name
                    and cast(year(dr.call_date) as string) = ca.year
                    and cast(quarter(dr.call_date) as string) = ca.quarter
                    and dr.channel = ca.channel
                )
                select * from daily_allocation 
            """)
        df_actemra_cost_allocation.createOrReplaceTempView('cost_allocation_actemra')

        df_combined_all = spark.sql("""
                select 
                    product_brand_name,
                    call_date,
                    channel, 
                    reach,
                    allocated_cost
                from cost_allocation_actemra
                union all 
                select 
                    product_brand_name,
                    call_date,
                    channel, 
                    reach,
                    allocated_cost
                from cost_allocation
            """)
        df_combined_all.createOrReplaceTempView('df_combined_all')

        tam_ce_df = spark.sql("""
                    with final_agg as(
                        select 
                            product_brand_name, 
                            date_format(call_date, 'yyyyMM') as year_month,
                            'CE' as audience, 
                            case when upper(channel) like '%TAM%' then 'tam_hd' else 'cso' end as channel,
                            sum(reach) as reach, 
                            sum(allocated_cost) as cost
                        from df_combined_all
                        group by 1, 2, 3, 4
                    ), 
                    ce_final as(
                        select 
                            product_brand_name,
                            year_month, 
                            audience, 
                            channel, 
                            reach, 
                            case when product_brand_name = 'HEMLIBRA' and year_month >= '202307'
                                then cost / 2
                            else cost end as cost
                        from final_agg
                    ), 
                    product_cost_exclusion as(
                         select 
                            product_brand_name,
                            year_month,
                            audience,
                            channel,
                            case when upper(product_brand_name) = 'LUNSUMIO' and year_month = '202212' then 0 
                                else reach end as reach, 
                            case when upper(product_brand_name) = 'LUNSUMIO' and year_month = '202212' then 0
                                when upper(product_brand_name) = 'COLUMVI' and year_month = '202306' then 0 
                                else
                                cost end as cost,
                            case  
                                when upper(product_brand_name) = 'LUNSUMIO' and year_month = '202212' then cost
                                when product_brand_name = 'COLUMVI' and year_month = '202306' then cost
                                else 0
                            end as cost_to_distribute
                        from ce_final                       
                    ), 
                    product_all as (
                        select 
                            product_brand_name,
                            year_month,
                            audience,
                            channel,
                            reach,
                            cost,
                            cost_to_distribute
                        from product_cost_exclusion
                    ),
                    product_total_cost AS (
                        select 
                            product_brand_name,
                            sum(cost_to_distribute) AS total_cost_to_distribute
                        from product_cost_exclusion
                        where (product_brand_name = 'COLUMVI' and year_month = '202306')
                        or (product_brand_name = 'LUNSUMIO' and cost_to_distribute != 0)
                        group by 1
                    ),
                    product_total_reach AS (
                        select 
                            product_brand_name,
                            sum(reach) AS total_reach
                        from product_cost_exclusion
                        where substr(year_month, 1, 4) = '2023' 
                        and product_brand_name in ('COLUMVI', 'LUNSUMIO')
                        group by 1
                    ), 
                    cost_distribution AS (
                        select 
                            pa.product_brand_name,
                            pa.year_month,
                            pa.audience,
                            pa.channel,
                            pa.reach,
                            case 
                                when pa.product_brand_name = 'COLUMVI' and substr(pa.year_month, 1, 4) = '2023'
                                then pa.cost + (pa.reach / nullif(ptr.total_reach, 0) * ptc.total_cost_to_distribute)
                                when pa.product_brand_name = 'LUNSUMIO' and substr(pa.year_month, 1, 4) = '2023'
                                then pa.cost + (pa.reach / nullif(ptr.total_reach, 0) * ptc.total_cost_to_distribute)
                                else pa.cost 
                            end as cost
                        from product_all pa
                        left join product_total_cost ptc ON pa.product_brand_name = ptc.product_brand_name
                        left join product_total_reach ptr ON pa.product_brand_name = ptr.product_brand_name
                    ), 
                    agg_final as(
                        select 
                            product_brand_name,
                            year_month, 
                            audience, 
                            channel, 
                            sum(reach) as reach,
                            sum(cost) as cost 
                        from cost_distribution 
                        group by 1, 2, 3, 4
                    )
                    select * from agg_final                      
        """)
        tam_ce_df.createOrReplaceTempView('tam_ce_final_agg')

        df_vae_all = self.spark.sql(f"""
                with tam_hds as(
                    select distinct
                        unix_id,
                        start_date,
                        end_date, 
                        field_title_code, 
                        position_number
                    from
                        {self.landing_database}.{self.alignment_roster_hierarchy_daily_tbl}
                    where
                        field_title_code in ('ACM','CRDP_TAM','CS','CSO_CS','CSO_DM','CSO_RD','HD','INTERN_TAM','NRDHD','NRDS','SCS','SNRDS','TAM')
                ),     
                tam_hds_for_crm as(
                        select position_number,
                            min(start_date) as start_date,
                            max(end_date) as end_date, 
                            field_title_code
                        from
                            {self.landing_database}.{self.alignment_roster_hierarchy_daily_tbl}
                            group by 1,4
                ), 
                dcx_ramp_raw as(
                    select 
                        distinct 
                        mdm_id, 
                        imdb_id,
                        group_id, 
                        sender_username, 
                        case when product_brand_name in('ACTEMRA IV', 'ACTEMRA SC') then 'ACTEMRA' else upper(product_brand_name) 
                                end as product_brand_name,
                        territory_id,
                        to_date(from_unixtime(unix_timestamp(input_date_time, 'yyyy-MM-dd HH:mm:ss'))) as input_date_time,
                        activity_type
                    from {self.landing_database}.{self.dcx_ramp_daily_tbl}
                    where upper(activity_type) in('DELIVERED', 'OPEN') 
                ), 
                dcx_ramp_emails as(
                    select 
                        dr.product_brand_name, 
                        date_format(input_date_time, 'yyyyMM') as date_year_month,
                        'CE' as audience, 
                        'VAE' as channel,
                        th.field_title_code, 
                        count(
                            distinct 
                            case when upper(activity_type) in('DELIVERED') then group_id end
                        ) as reach, 
                        count(
                            distinct 
                            case when upper(activity_type) in ('OPEN') then group_id end
                        ) as engage
                    from dcx_ramp_raw as dr 
                    inner join tam_hds as th 
                    on
                        dr.sender_username = th.unix_id
                        and dr.input_date_time between th.start_date and th.end_date
                    group by 1, 2, 3, 4, 5   
                ), 
                vae_raw as(
                    select 
                        distinct 
                        mdm_id, 
                        product_brand_name, 
                        position_number,
                        position_name,
                        date_year_month, 
                        email_status,
                        activity_type,
                        sent_email_id,
                        crm_activity_client_name,
                        crm_activity_client_operating_system,
                        crm_activity_client_type,
                        crm_activity_device_type,
                        crm_activity_user_agent,
                        date(email_sent_date) as email_sent_date
                    from {self.landing_database}.{self.crm_commercial_approved_email_tbl} 
                    where upper(activity_type) not in('DROPPED', 'BOUNCED')
                ), 
                vae_emails as(
                        select 
                            vr.product_brand_name,
                            vr.date_year_month,
                            'CE' as audience, 
                            'VAE' as channel,
                            case 
                                when th.field_title_code is null then 
                                    case
                                        when vr.position_name like '%CSO%' then 'CSO' 
                                        when vr.position_name like '%_TAM_%' then 'TAM' 
                                        when vr.position_name like '%_HD_%' then 'HD' 
                                        when vr.position_name like '%NRDS_%' then 'NRDS' 
                                        when vr.position_name like '%_ACM_%' then 'ACM' 
                                        else null 
                                    end
                                else th.field_title_code 
                            end as field_title_code,
                            count(
                                distinct 
                                case when upper(email_status) in('DELIVERED', 'MARKED_SPAM', 'UNSUBSCRIBED') then sent_email_id end
                            ) as reach, 
                            count(
                                distinct 
                                case when 
                                    upper(activity_type) = 'OPENED' 
                                    and (
                                        crm_activity_client_name != 'unknown'
                                        or crm_activity_client_operating_system != 'unknown'
                                        or crm_activity_client_type != 'unknown'
                                        or crm_activity_device_type != 'unknown'
                                        or crm_activity_user_agent != 'Mozilla/5.0'
                                    )
                                then sent_email_id end
                            ) as engage
                        from vae_raw as vr 
                        left join tam_hds th
                            on vr.position_number = th.position_number 
                            and vr.email_sent_date between th.start_date and th.end_date         
                        where th.field_title_code in ('ACM','CRDP_TAM','CS','CSO_CS','CSO_DM','CSO_RD','HD','INTERN_TAM','NRDHD','NRDS','SCS','SNRDS','TAM')
                        group by 1, 2, 3, 4, 5
                    )
                    select 
                        product_brand_name,
                        date_year_month as year_month, 
                        lower(audience) as audience,
                        lower(channel) as channel,
                        sum(reach) as reach,
                        sum(engage) as engage 
                    from dcx_ramp_emails
                    where product_brand_name in ({"'" + "','".join(json.loads(self.config.get(self.env, "mars_product_names_list"))) + "'"})
                    group by 1, 2, 3, 4
                    union all 
                    select 
                        product_brand_name,
                        date_year_month as year_month, 
                        lower(audience) as audience,
                        lower(channel) as channel,
                        sum(reach) as reach,
                        sum(engage) as engage 
                    from vae_emails
                    where product_brand_name in ({"'" + "','".join(json.loads(self.config.get(self.env, "mars_product_names_list"))) + "'"})
                    group by 1, 2, 3, 4
                    """)
        df_vae_all.registerTempTable('vae_unioned')

        df_final_agg = self.spark.sql("""
                    select 
                        product_brand_name,
                        year_month,
                        lower(audience) as audience,
                        lower(channel) as channel,
                        reach,
                        engage,
                        cast(null as double) as cost 
                    from vae_unioned
                    where year_month >= '202201'
                    union all 
                    select 
                        product_brand_name,
                        year_month, 
                        lower(audience) as audience,
                        lower(channel) as channel,
                        reach,
                        cast(null as double) as engage,
                        cost
                    from tam_ce_final_agg
                """)

        tam_dtc_df = spark.sql(f"""
                    with hemlibra_dtc_union as (
                    --     select 
                    --     zip_code, product, interaction_date, interaction_type, topic_discussed, number_of_patients, number_of_interactions
                    -- from {self.landing_database}.{self.tam_pccm_tbl}_backup
                    -- where (date_format(to_date(interaction_date, 'M/d/yyyy'), 'yyyyMM') between '202201' and '202312')
                    -- and  
                    -- (version = (select cast(max(cast(version as int))-1 as string) as version from {self.landing_database}.{self.tam_pccm_tbl}_backup))
                    -- union all 
                        select 
                            zip_code, product, interaction_date, interaction_type, topic_discussed, number_of_patients, number_of_interactions
                        from {self.landing_database}.{self.tam_pccm_tbl}
                    -- where date_format(to_date(interaction_date, 'M/d/yyyy'), 'yyyyMM') >= '202401'                     
                     ),
                    hemlibra_tam_dtc_calls as (
                        select
                            upper(pccm.product) as product_brand_name,
                            date_format(to_date(pccm.interaction_date, 'M/d/yyyy'), 'yyyyMM') as year_month,
                            'DTC' as audience,
                            'tam' as channel,
                            sum(pccm.number_of_interactions) as reach
                        from hemlibra_dtc_union as pccm
                        where
                            upper(pccm.product) = 'HEMLIBRA'
                            and trim(pccm.interaction_type) != 'Attempted Contact'
                        group by 1, 2
                    ), 

                    hemlibra_tam_dtc_quarterly_reach as (
                        select
                            product_brand_name,
                            cast(year(to_date(year_month, 'yyyyMM')) as string) AS year,
                            cast(quarter(to_date(year_month, 'yyyyMM')) as string) AS quarter,
                            sum(reach) as quarterly_reach
                        from hemlibra_tam_dtc_calls
                        group by 1, 2, 3
                    ),

                    hemlibra_tam_dtc_unit_cost as (
                        select
                            c.product_brand_name,
                            c.year,
                            c.quarter,
                            c.quarterly_cost / nullif(r.quarterly_reach, 0) as unit_cost_tam
                        from tam_hd_costs c
                        join hemlibra_tam_dtc_quarterly_reach r 
                            on c.product_brand_name = r.product_brand_name 
                            and c.year = r.year 
                            and c.quarter = r.quarter
                        where c.product_brand_name = 'HEMLIBRA' and c.channels in('ACM', 'PCCM')
                    ),

                    hemlibra_tam_dtc_cost_allocation as (
                        select
                            c.product_brand_name,
                            c.year_month,
                            c.audience,
                            c.channel,
                            c.reach,
                            uc.unit_cost_tam,
                            c.reach * uc.unit_cost_tam as allocated_cost
                        from hemlibra_tam_dtc_calls c
                        join hemlibra_tam_dtc_unit_cost uc
                            on c.product_brand_name = uc.product_brand_name
                            and cast(year(to_date(year_month, 'yyyyMM')) as string) = uc.year
                            and cast(quarter(to_date(year_month, 'yyyyMM')) as string) = uc.quarter
                    ),

                    hemlibra_tam_dtc_final as (
                        select 
                            product_brand_name,
                            year_month,
                            audience,
                            channel,
                            sum(reach) as reach,
                            sum(allocated_cost) as cost
                        from hemlibra_tam_dtc_cost_allocation
                        group by 1, 2, 3, 4
                    ),

                    dtc_final as(
                        select 
                            product_brand_name,
                            year_month,
                            lower(audience) as audience,
                            lower(channel) as channel,
                            reach,
                            case when product_brand_name = 'HEMLIBRA' and year_month >= '202307'
                                then cost / 2
                            else cost end as cost
                        from hemlibra_tam_dtc_final
                    )
                    select * from dtc_final 
                """)

        pl_full_tam_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                          table_name=self.tam_tbl + '_backup').select(
            'version').distinct()
        pl_full_tam_pccm_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                          table_name=self.tam_pccm_tbl + '_backup').select(
            'version').distinct()

        pl_full_tam_cost_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                               table_name=self.tam_cost + '_backup').select(
            'version').distinct()

        if self.tam_previous_version_num == None or self.tam_previous_version_num == 'None':
            logger.info("TAM Previous version in config is None or key is missing"
                        " that's why we are using max version minus 1")
            tam_previous_version_num = int(pl_full_tam_df.select([max("version")]).head()[0]) - 1
        else:
            logger.info("TAM Previous version in config is " + str(self.tam_previous_version_num))
            tam_previous_version_num = self.tam_previous_version_num
        logger.info(f'TAM previous version used for variance : {str(tam_previous_version_num)}')

        if self.tam_pccm_previous_version_num == None or self.tam_pccm_previous_version_num == 'None':
            logger.info("TAM PCCM Previous version in config is None or key is missing"
                        " that's why we are using max version minus 1")
            tam_pccm_previous_version_num = int(pl_full_tam_pccm_df.select([max("version")]).head()[0]) - 1
        else:
            logger.info("TAM PCCM Previous version in config is " + str(self.tam_pccm_previous_version_num))
            tam_pccm_previous_version_num = self.tam_pccm_previous_version_num
        logger.info(f'TAM PCCM previous version used for variance : {str(tam_pccm_previous_version_num)}')

        if self.tam_cost_previous_version_num == None or self.tam_cost_previous_version_num == 'None':
            logger.info("TAM Cost Previous version in config is None or key is missing"
                        " that's why we are using max version minus 1")
            tam_cost_previous_version_num = int(pl_full_tam_cost_df.select([max("version")]).head()[0]) - 1
        else:
            logger.info("TAM Previous version in config is " + str(self.tam_cost_previous_version_num))
            tam_cost_previous_version_num = self.tam_cost_previous_version_num
        logger.info(f'TAM previous version used for variance : {str(tam_cost_previous_version_num)}')

        if tam_cost_previous_version_num == 0:
            logger.info('No previous version')
        else:
            logger.info(f'Previous version tam : {str(tam_cost_previous_version_num)}')

        if tam_previous_version_num == 0:
            logger.info('No previous version')
        else:
            logger.info(f'Previous version tam : {str(tam_previous_version_num)}')

        if tam_pccm_previous_version_num == 0:
            logger.info('No previous version')
        else:
            logger.info(f'Previous version tam pccm : {str(tam_pccm_previous_version_num)}')

        pl_df_tam_hd_calls = spark.sql(f"""
                            select distinct
                                ci.crm_call_id,
                                ci.crm_position_number,
                                ci.crm_position_name,
                                ci.mdm_id,
                                ci.crm_display_order,
                                cast(1 / ci.crm_display_order as double) as call_wt,
                                ci.crm_call_datetime,
                                date(ci.crm_call_datetime) as call_date,
                                ci.oasis_brand_name as product_brand_name,
                                ci.oasis_product_brand_id as product_brand_id,
                                'HCP' as mdm_type,
                                'TAM' as channel
                            from
                                {self.landing_database}.{self.tam_tbl}_backup as ci 
                            where
                                upper(crm_call_status) = 'SUBMITTED'
                                and cast(crm_flag_person_account as integer) = 1
                                and version = {tam_previous_version_num}
                                and ci.oasis_brand_name != 'ACTEMRA'
                                and ci.oasis_brand_name in ({"'" + "','".join(json.loads(self.config.get(self.env, "mars_product_names_list"))) + "'"}) 
                        """)
        pl_df_tam_hd_calls.registerTempTable('pl_tam_hd_calls')

        pl_df_tam_hd_actemra_calls = self.spark.sql(f"""
                                    select distinct
                                        ci.crm_call_id,
                                        ci.crm_position_number,
                                        ci.crm_position_name,
                                        ci.mdm_id,
                                        ci.crm_display_order,
                                        cast(1 / ci.crm_display_order as double) as call_wt,
                                        ci.crm_call_datetime,
                                        date(ci.crm_call_datetime) as call_date,
                                        ci.oasis_brand_name as product_brand_name,
                                        ci.oasis_product_brand_id as product_brand_id,
                                        'HCP' as mdm_type,
                                        case when th.field_title_code like '%CSO%' then 'CSO' else 'TAM' end as channel
                                    from
                                        {self.landing_database}.{self.tam_tbl}_backup as ci 
                                    left join
                                        tam_hds as th
                                        on
                                            ci.crm_position_number = th.position_number
                                            and ci.crm_call_datetime between th.start_date and th.end_date
                                    where
                                        upper(crm_call_status) = 'SUBMITTED'
                                        and cast(crm_flag_person_account as integer) = 1
                                        and version = {tam_previous_version_num}
                                        and ci.oasis_brand_name = 'ACTEMRA'                 
                                """)
        pl_df_tam_hd_actemra_calls.registerTempTable('pl_tam_hd_actemra_calls')

        pl_union_df = self.spark.sql("""
                with pl_all_tam_hd as(
                    select crm_position_name, crm_position_number, product_brand_name, channel, call_date, call_wt from pl_tam_hd_actemra_calls
                    union all
                    select crm_position_name, crm_position_number, product_brand_name, channel, call_date, call_wt from pl_tam_hd_calls  
                ), 
                pl_all_tam_hd_calls as (
                    select 
                        th.crm_position_number,
                        th.crm_position_name,
                        th.call_wt,
                        th.call_date,
                        th.product_brand_name,
                        th.channel,
                        case 
                            when f.field_title_code is null then 
                                case
                                    when th.crm_position_name like '%CSO%' then 'CSO' 
                                    when th.crm_position_name like '%_TAM_%' then 'TAM' 
                                    when th.crm_position_name like '%_HD_%' then 'HD' 
                                    when th.crm_position_name like '%NRDS_%' then 'NRDS' 
                                    when th.crm_position_name like '%_ACM_%' then 'ACM' 
                                    else null 
                                end
                            else f.field_title_code 
                        end as field_title_code
                    from pl_all_tam_hd th
                    left join tam_hds f
                        on th.crm_position_number = f.position_number 
                        and th.call_date between f.start_date and f.end_date
                    where f.field_title_code in ('ACM','CRDP_TAM','CS','CSO_CS','CSO_DM','CSO_RD','HD','INTERN_TAM','NRDHD','NRDS','SCS','SNRDS','TAM')
            )
            select * from pl_all_tam_hd_calls
        """)
        pl_union_df.registerTempTable('pl_all_tam_hd_calls')

        pl_df_daily_reach = spark.sql("""
                            select
                                product_brand_name,
                                call_date,
                                channel,
                                sum(call_wt) as reach
                            from pl_all_tam_hd_calls
                            where upper(product_brand_name) != 'ACTEMRA'
                            group by 1, 2, 3
                        """)
        pl_df_daily_reach.registerTempTable('pl_daily_reach')

        pl_df_quarterly_reach = spark.sql("""
                    select
                        product_brand_name,
                        cast(year(call_date) as string) as year,
                        cast(quarter(call_date) as string) as quarter,
                        sum(reach) as quarterly_reach
                    from pl_daily_reach
                    group by 1, 2, 3
                """)
        pl_df_quarterly_reach.registerTempTable('pl_quarterly_reach')

        pl_df_daily_reach = spark.sql("""
                            select
                                product_brand_name,
                                call_date,
                                channel,
                                sum(call_wt) as reach
                            from pl_all_tam_hd_calls
                            where upper(product_brand_name) != 'ACTEMRA'
                            group by 1, 2, 3
                        """)
        pl_df_daily_reach.registerTempTable('pl_daily_reach')

        pl_df_tam_hd_costs = spark.sql(f"""
                            select
                                upper(brand_name) as product_brand_name,
                                channels,
                                audience,
                                cast(year as string) as year,
                                substring(cast(quarter as string), 2, 1) as quarter,
                                sum(spend_amount) as quarterly_cost
                            from {self.landing_database}.{self.tam_cost}_backup
                            where version = '{tam_cost_previous_version_num}'
                            group by 1, 2, 3, 4, 5
                        """)
        pl_df_tam_hd_costs.registerTempTable('pl_tam_hd_costs')

        pl_df_unit_cost = spark.sql("""
                            with pl_unit_cost as(
                                select
                                    c.product_brand_name,
                                    c.year,
                                    c.quarter,
                                    c.quarterly_cost / nullif(r.quarterly_reach, 0) as unit_cost_tam
                                from pl_tam_hd_costs c
                                join pl_quarterly_reach r 
                                    on c.product_brand_name = r.product_brand_name 
                                    and c.year = r.year 
                                    and c.quarter = r.quarter
                                where c.channels in('TAM', 'ACM')
                                and r.product_brand_name != 'ACTEMRA'
                            ), 
                            pl_cost_allocation as (
                                select
                                    dr.product_brand_name,
                                    dr.call_date,
                                    dr.channel,
                                    dr.reach,
                                    uc.unit_cost_tam,
                                    dr.reach * uc.unit_cost_tam as allocated_cost
                                from pl_daily_reach dr
                                join pl_unit_cost uc
                                    on dr.product_brand_name = uc.product_brand_name
                                    and cast(year(dr.call_date) as string) = uc.year
                                    and cast(quarter(dr.call_date) as string) = uc.quarter
                            )
                            select * from pl_cost_allocation
                        """)
        pl_df_unit_cost.createOrReplaceTempView('pl_cost_allocation')

        pl_df_tam_hd_calls_actemra = spark.sql(f"""
                    select
                        product_brand_name,
                        call_date,
                        channel,
                        call_wt
                    from pl_all_tam_hd_calls
                    where upper(product_brand_name) = 'ACTEMRA'

            """)
        pl_df_tam_hd_calls_actemra.createOrReplaceTempView('pl_all_tam_hd_calls_actemra')

        pl_df_actemra_cost_allocation = spark.sql(f"""
                        with pl_daily_reach_actemra as(
                            select
                                product_brand_name,
                                call_date,
                                channel,
                                sum(call_wt) as reach
                            from pl_all_tam_hd_calls_actemra
                            group by 1, 2, 3                               
                        ),

                        pl_quarterly_reach_actemra as (
                            select
                                product_brand_name,
                                channel,
                                cast(year(call_date) as string) as year,
                                cast(quarter(call_date) as string) as quarter,
                                sum(reach) as quarterly_reach
                            from pl_daily_reach_actemra
                            group by 1, 2, 3, 4
                        ),  

                        pl_tam_only_quarters AS (
                            select 
                                c.product_brand_name,
                                c.year,
                                c.quarter,
                                c.quarterly_cost,
                                r.quarterly_reach
                            from pl_tam_hd_costs c
                            join pl_quarterly_reach_actemra r 
                            on c.product_brand_name = r.product_brand_name 
                            and c.year = r.year 
                            and c.quarter = r.quarter
                            where r.channel = 'TAM'
                            and not exists (
                                select 1
                                from pl_quarterly_reach_actemra cso
                                where cso.product_brand_name = c.product_brand_name
                                and cso.year = c.year
                                and cso.quarter = c.quarter
                                and cso.channel = 'CSO'
                            )
                        ),

                        pl_tam_unit_cost as (
                            select avg(quarterly_cost / nullif(quarterly_reach, 0)) as u_t
                            from pl_tam_only_quarters
                        ),

                        pl_cso_dominant_quarters as (
                            select 
                                c.product_brand_name,
                                c.year,
                                c.quarter,
                                c.quarterly_cost,
                                tam.quarterly_reach as tam_reach,
                                cso.quarterly_reach as cso_reach
                            from pl_tam_hd_costs c
                            join pl_quarterly_reach_actemra tam 
                            on c.product_brand_name = tam.product_brand_name 
                            and c.year = tam.year 
                            and c.quarter = tam.quarter
                            and tam.channel = 'TAM'
                            join pl_quarterly_reach_actemra cso
                            on c.product_brand_name = cso.product_brand_name 
                            and c.year = cso.year 
                            and c.quarter = cso.quarter
                            and cso.channel = 'CSO'
                            where cso.quarterly_reach > tam.quarterly_reach
                        ),

                        pl_cso_unit_cost AS (
                            select avg((c.quarterly_cost - (c.tam_reach * t.u_t)) / nullif(c.cso_reach, 0)) as u_c
                            from pl_cso_dominant_quarters c
                            cross join pl_tam_unit_cost t
                        ),

                        pl_cost_allocation as (
                            select
                                qr.product_brand_name,
                                qr.year,
                                qr.quarter,
                                qr.channel,
                                qr.quarterly_reach,
                                c.quarterly_cost,
                                t.u_t AS tam_unit_cost,
                                cs.u_c AS cso_unit_cost,
                                case
                                    when qr.channel = 'TAM' and oc.channel is null then c.quarterly_cost
                                    when qr.channel = 'CSO' and oc.channel is null then c.quarterly_cost
                                    else
                                        case
                                            when qr.channel = 'TAM' then
                                                c.quarterly_cost * (qr.quarterly_reach * t.u_t) /
                                                (qr.quarterly_reach * t.u_t + coalesce(oc.quarterly_reach, 0) * cs.u_c)
                                            when qr.channel = 'CSO' then
                                                c.quarterly_cost * (qr.quarterly_reach * cs.u_c) /
                                                (coalesce(oc.quarterly_reach, 0) * t.u_t + qr.quarterly_reach * cs.u_c)
                                        end
                                    end as allocated_cost
                            from pl_quarterly_reach_actemra qr
                            join pl_tam_hd_costs c on qr.product_brand_name = c.product_brand_name and qr.year = c.year and qr.quarter = c.quarter
                            cross join pl_tam_unit_cost t
                            cross join pl_cso_unit_cost cs
                            left join pl_quarterly_reach_actemra oc on
                                oc.product_brand_name = qr.product_brand_name and
                                oc.year = qr.year and
                                oc.quarter = qr.quarter and
                                oc.channel = case when qr.channel = 'TAM' then 'CSO' else 'TAM' end
                        ), 

                        pl_daily_allocation as (
                            select
                                dr.product_brand_name,
                                dr.call_date,
                                dr.channel,
                                dr.reach,
                                ca.allocated_cost * (dr.reach / ca.quarterly_reach) as allocated_cost
                            from pl_daily_reach_actemra dr
                            join pl_cost_allocation ca 
                            on dr.product_brand_name = ca.product_brand_name
                            and cast(year(dr.call_date) as string) = ca.year
                            and cast(quarter(dr.call_date) as string) = ca.quarter
                            and dr.channel = ca.channel
                        )
                        select * from pl_daily_allocation 
                    """)
        pl_df_actemra_cost_allocation.createOrReplaceTempView('pl_cost_allocation_actemra')

        pl_df_combined_all = spark.sql("""
                        select 
                            product_brand_name,
                            call_date,
                            channel, 
                            reach,
                            allocated_cost
                        from pl_cost_allocation_actemra
                        union all 
                        select 
                            product_brand_name,
                            call_date,
                            channel, 
                            reach,
                            allocated_cost
                        from pl_cost_allocation
                    """)
        pl_df_combined_all.createOrReplaceTempView('pl_df_combined_all')

        pl_tam_ce_df = spark.sql("""
                            with pl_final_agg as(
                                select 
                                    product_brand_name, 
                                    date_format(call_date, 'yyyyMM') as year_month,
                                    'CE' as audience, 
                                    case when upper(channel) like '%TAM%' then 'tam_hd' else 'cso' end as channel,
                                    sum(reach) as reach, 
                                    sum(allocated_cost) as cost
                                from pl_df_combined_all
                                group by 1, 2, 3, 4
                            ), 
                            pl_ce_final as(
                                select 
                                    product_brand_name,
                                    year_month, 
                                    audience, 
                                    channel, 
                                    reach, 
                                    case when product_brand_name = 'HEMLIBRA' and year_month >= '202307'
                                        then cost / 2
                                    else cost end as cost
                                from pl_final_agg
                            ), 
                            pl_product_cost_exclusion as(
                                 select 
                                    product_brand_name,
                                    year_month,
                                    audience,
                                    channel,
                                    case when upper(product_brand_name) = 'LUNSUMIO' and year_month = '202212' then 0 
                                        else reach end as reach, 
                                    case when upper(product_brand_name) = 'LUNSUMIO' and year_month = '202212' then 0
                                        when upper(product_brand_name) = 'COLUMVI' and year_month = '202306' then 0 
                                        else
                                        cost end as cost,
                                    case  
                                        when upper(product_brand_name) = 'LUNSUMIO' and year_month = '202212' then cost
                                        when product_brand_name = 'COLUMVI' and year_month = '202306' then cost
                                        else 0
                                    end as cost_to_distribute
                                from pl_ce_final                       
                            ), 
                            pl_product_all as (
                                select 
                                    product_brand_name,
                                    year_month,
                                    audience,
                                    channel,
                                    reach,
                                    cost,
                                    cost_to_distribute
                                from pl_product_cost_exclusion
                            ),
                            pl_product_total_cost AS (
                                select 
                                    product_brand_name,
                                    sum(cost_to_distribute) AS total_cost_to_distribute
                                from pl_product_cost_exclusion
                                where (product_brand_name = 'COLUMVI' and year_month = '202306')
                                or (product_brand_name = 'LUNSUMIO' and cost_to_distribute != 0)
                                group by 1
                            ),
                            pl_product_total_reach AS (
                                select 
                                    product_brand_name,
                                    sum(reach) AS total_reach
                                from pl_product_cost_exclusion
                                where substr(year_month, 1, 4) = '2023' 
                                and product_brand_name in ('COLUMVI', 'LUNSUMIO')
                                group by 1
                            ), 
                            pl_cost_distribution AS (
                                select 
                                    pa.product_brand_name,
                                    pa.year_month,
                                    pa.audience,
                                    pa.channel,
                                    pa.reach,
                                    case 
                                        when pa.product_brand_name = 'COLUMVI' and substr(pa.year_month, 1, 4) = '2023'
                                        then pa.cost + (pa.reach / nullif(ptr.total_reach, 0) * ptc.total_cost_to_distribute)
                                        when pa.product_brand_name = 'LUNSUMIO' and substr(pa.year_month, 1, 4) = '2023'
                                        then pa.cost + (pa.reach / nullif(ptr.total_reach, 0) * ptc.total_cost_to_distribute)
                                        else pa.cost 
                                    end as cost
                                from pl_product_all pa
                                left join pl_product_total_cost ptc ON pa.product_brand_name = ptc.product_brand_name
                                left join pl_product_total_reach ptr ON pa.product_brand_name = ptr.product_brand_name
                            ), 
                            pl_agg_final as(
                                select 
                                    product_brand_name,
                                    year_month, 
                                    lower(audience) as audience,
                                    lower(channel) as channel,
                                    sum(reach) as reach,
                                    sum(cost) as cost 
                                from pl_cost_distribution 
                                group by 1, 2, 3, 4
                            )
                            select * from pl_agg_final                      
                """)
        pl_tam_ce_df.createOrReplaceTempView('pl_tam_ce_final_agg')

        pl_tam_dtc_df = spark.sql(f"""
                            with pl_hemlibra_tam_dtc_calls as (
                                select
                                    upper(pccm.product) as product_brand_name,
                                    date_format(to_date(pccm.interaction_date, 'M/d/yyyy'), 'yyyyMM') as year_month,
                                    'DTC' as audience,
                                    'tam' as channel,
                                    sum(pccm.number_of_interactions) as reach
                                from {self.landing_database}.{self.tam_pccm_tbl}_backup as pccm
                                where
                                    upper(pccm.product) = 'HEMLIBRA'
                                    and trim(pccm.interaction_type) != 'Attempted Contact'
                                    and version = '{self.tam_pccm_previous_version_num}'
                                group by 1, 2
                            ), 

                            pl_hemlibra_tam_dtc_quarterly_reach as (
                                select
                                    product_brand_name,
                                    cast(year(to_date(year_month, 'yyyyMM')) as string) AS year,
                                    cast(quarter(to_date(year_month, 'yyyyMM')) as string) AS quarter,
                                    sum(reach) as quarterly_reach
                                from pl_hemlibra_tam_dtc_calls
                                group by 1, 2, 3
                            ),

                            pl_hemlibra_tam_dtc_unit_cost as (
                                select
                                    c.product_brand_name,
                                    c.year,
                                    c.quarter,
                                    c.quarterly_cost / nullif(r.quarterly_reach, 0) as unit_cost_tam
                                from pl_tam_hd_costs c
                                join pl_hemlibra_tam_dtc_quarterly_reach r 
                                    on c.product_brand_name = r.product_brand_name 
                                    and c.year = r.year 
                                    and c.quarter = r.quarter
                                where c.product_brand_name = 'HEMLIBRA' and c.channels in('ACM', 'PCCM')
                            ),

                            pl_hemlibra_tam_dtc_cost_allocation as (
                                select
                                    c.product_brand_name,
                                    c.year_month,
                                    c.audience,
                                    c.channel,
                                    c.reach,
                                    uc.unit_cost_tam,
                                    c.reach * uc.unit_cost_tam as allocated_cost
                                from pl_hemlibra_tam_dtc_calls c
                                join pl_hemlibra_tam_dtc_unit_cost uc
                                    on c.product_brand_name = uc.product_brand_name
                                    and cast(year(to_date(year_month, 'yyyyMM')) as string) = uc.year
                                    and cast(quarter(to_date(year_month, 'yyyyMM')) as string) = uc.quarter
                            ),

                            pl_hemlibra_tam_dtc_final as (
                                select 
                                    product_brand_name,
                                    year_month,
                                    audience,
                                    channel,
                                    sum(reach) as reach,
                                    sum(allocated_cost) as cost
                                from pl_hemlibra_tam_dtc_cost_allocation
                                group by 1, 2, 3, 4
                            ),

                            pl_dtc_final as(
                                select 
                                    product_brand_name,
                                    year_month,
                                    lower(audience) as audience,
                                    lower(channel) as channel,
                                    reach,
                                    case when product_brand_name = 'HEMLIBRA' and year_month >= '202307'
                                        then cost / 2
                                    else cost end as cost
                                from pl_hemlibra_tam_dtc_final
                            )
                            select * from pl_dtc_final 
                        """)
        pl_tam_dtc_df.registerTempTable('pl_hemlibra_dtc_final')
        logger.info(f'Row count DTC : {pl_tam_dtc_df.count()}')

        pl_tam_dtc_monthly_df = (pl_tam_dtc_df.groupby('product_brand_name', 'year_month')
        .agg(sum('cost').alias('pl_monthly_cost'),
             sum('reach').alias('pl_monthly_reach')).where(
            col('year_month') >= self.lower_bound_year_month))
        #                                 .where(col('year_month') <= self.upper_bound_year_month))
        pl_tam_ce_monthly_df = (pl_tam_ce_df.groupby('product_brand_name', 'channel', 'year_month')
                                .agg(sum('cost').alias('pl_monthly_cost'),
                                     sum('reach').alias('pl_monthly_reach'))
                                .where(col('year_month') >= self.lower_bound_year_month))
        #                                .where(col('year_month') <= self.upper_bound_year_month))
        tam_dtc_monthly_df = (tam_dtc_df.groupby('product_brand_name', 'year_month')
        .agg(sum('cost').alias('monthly_cost'),
             sum('reach').alias('monthly_reach')).where(
            col('year_month') >= self.lower_bound_year_month))
        tam_ce_monthly_df = (df_final_agg.groupby('product_brand_name', 'channel', 'year_month')
        .agg(sum('cost').alias('monthly_cost'),
             sum('engage').alias('monthly_engage'),
             sum('reach').alias('monthly_reach')).where(
            col('year_month') >= self.lower_bound_year_month))

        tam_ce_monthly = (tam_ce_monthly_df.alias('tcm')
                          .join(pl_tam_ce_monthly_df.alias('pl_tcm'),
                                (col('tcm.product_brand_name') == col('pl_tcm.product_brand_name')) & (
                                        col('tcm.year_month') == col('pl_tcm.year_month')) & (
                                        col('tcm.channel') == col('pl_tcm.channel')),
                                'left')
                          .selectExpr('tcm.*', 'pl_tcm.pl_monthly_cost as pl_monthly_cost',
                                      'pl_tcm.pl_monthly_reach as pl_monthly_reach',
                                      '(-pl_tcm.pl_monthly_cost+tcm.monthly_cost)/pl_tcm.pl_monthly_cost as delta_percent_cost',
                                      '(-pl_tcm.pl_monthly_reach+tcm.monthly_reach)/pl_tcm.pl_monthly_reach as delta_percent_reach')
                          .withColumn('previous_month_reach', lag(col('monthly_reach'), 1, 0)
                                      .over(Window.partitionBy('product_brand_name').orderBy('year_month')))
                          .withColumn('previous_month_cost', lag(col('monthly_cost'), 1, 0)
                                      .over(Window.partitionBy('product_brand_name').orderBy('year_month')))
                          .withColumn('year_month', col('year_month').cast(IntegerType()))
                          .withColumn('year', col('year_month').cast('string').substr(1, 4))
                          .withColumn('year_quarter', expr(
            "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)"))
                          )

        tam_dtc_monthly = (tam_dtc_monthly_df.alias('tdm')
                           .join(pl_tam_dtc_monthly_df.alias('pl_tdm'),
                                 (col('tdm.product_brand_name') == col('pl_tdm.product_brand_name')) & (
                                         col('tdm.year_month') == col('pl_tdm.year_month')),
                                 'left')
                           .selectExpr('tdm.*', 'pl_tdm.pl_monthly_cost as pl_monthly_cost',
                                       'pl_tdm.pl_monthly_reach as pl_monthly_reach',
                                       '(-pl_tdm.pl_monthly_cost+tdm.monthly_cost)/pl_tdm.pl_monthly_cost as delta_percent_cost',
                                       '(-pl_tdm.pl_monthly_reach+tdm.monthly_reach)/pl_tdm.pl_monthly_reach as delta_percent_reach')
                           .withColumn('previous_month_reach', lag(col('monthly_reach'), 1, 0)
                                       .over(Window.partitionBy('product_brand_name').orderBy('year_month')))
                           .withColumn('previous_month_cost', lag(col('monthly_cost'), 1, 0)
                                       .over(Window.partitionBy('product_brand_name').orderBy('year_month')))
                           .withColumn('year_month', col('year_month').cast(IntegerType()))
                           .withColumn('year', col('year_month').cast('string').substr(1, 4))
                           .withColumn('year_quarter', expr(
            "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)"))
                           )

        tam_dtc_monthly_dfp = tam_dtc_monthly.persist()
        row_count = tam_dtc_monthly_dfp.count()
        logger.info(f"Row count for TAM monthly DTC : {row_count}")

        audit_info = []

        audit_info += [{'table_name': f"{self.landing_database}.mars_tam_dtc_monthly_dq",
                        'rows_updated': row_count}]
        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + reporting_folder + "/" +
                   'mars_tam_dtc_monthly_dq' + "/")
        tam_dtc_monthly_dfp.coalesce(1).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        tam_ce_monthly_dfp = tam_ce_monthly.persist()
        row_count = tam_ce_monthly_dfp.count()
        logger.info(f"Row count for TAM monthly CE : {row_count}")

        audit_info += [{'table_name': f"{self.landing_database}.mars_tam_ce_monthly_dq",
                        'rows_updated': row_count}]
        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + reporting_folder + "/" +
                   'mars_tam_ce_monthly_dq' + "/")
        tam_ce_monthly_dfp.coalesce(1).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        tam_dtc_quarter_agg_df = (
            tam_dtc_monthly_dfp.groupby("product_brand_name", "year_quarter")
            .agg(sum("pl_monthly_reach").alias("pl_monthly_reach"),
                 sum("pl_monthly_cost").alias("pl_monthly_cost"),
                 sum("monthly_reach").alias("monthly_reach"),
                 sum("monthly_cost").alias("monthly_cost")))

        tam_dtc_quarterly_agg_df = tam_dtc_quarter_agg_df.selectExpr(
            '*', "round((-pl_monthly_reach+monthly_reach)/pl_monthly_reach,4) as delta_percent_reach",
            "round((-pl_monthly_cost+monthly_cost)/pl_monthly_cost,4) as delta_percent_cost")

        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" +
                   'mars_tam_dtc_cost_exception' + "/")
        (tam_dtc_quarterly_agg_df
         .filter(
            '(delta_percent_cost > 0.03 or delta_percent_cost < -0.03) or (pl_monthly_cost is null and monthly_cost is not null) or (pl_monthly_cost = 0 and monthly_cost != 0)')
         .coalesce(1).write.mode('overwrite').parquet(s3_path))
        self.s3_path_list += [s3_path]

        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" +
                   'mars_tam_dtc_reach_exception' + "/")
        (tam_dtc_quarterly_agg_df
         .filter(
            '(delta_percent_reach > 0.03 or delta_percent_reach < -0.03) or (pl_monthly_reach is null and monthly_reach is not null) or (pl_monthly_reach = 0 and monthly_reach != 0)')
         .coalesce(1).write.mode('overwrite').parquet(s3_path))
        self.s3_path_list += [s3_path]

        tam_ce_quarter_agg_df = (
            tam_ce_monthly_dfp.where(col('channel') != 'vae').groupby("product_brand_name", "year_quarter")
            .agg(sum("pl_monthly_reach").alias("pl_monthly_reach"),
                 sum("pl_monthly_cost").alias("pl_monthly_cost"),
                 sum("monthly_reach").alias("monthly_reach"),
                 sum("monthly_cost").alias("monthly_cost")))

        tam_ce_delta_percent_df = tam_ce_quarter_agg_df.selectExpr(
            '*', "round((-pl_monthly_reach+monthly_reach)/pl_monthly_reach,4) as delta_percent_reach",
            "round((-pl_monthly_cost+monthly_cost)/pl_monthly_cost,4) as delta_percent_cost")

        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" +
                   'mars_tam_ce_cost_exception' + "/")
        (tam_ce_delta_percent_df
         .filter(
            '(delta_percent_cost > 0.03 or delta_percent_cost < -0.03) or (pl_monthly_cost is null and monthly_cost is not null) or (pl_monthly_cost = 0 and monthly_cost != 0)')
         .coalesce(1).write.mode('overwrite').parquet(s3_path))
        self.s3_path_list += [s3_path]

        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" +
                   'mars_tam_ce_reach_exception' + "/")
        (tam_ce_delta_percent_df
         .filter(
            '(delta_percent_reach > 0.03 or delta_percent_reach < -0.03) or (pl_monthly_reach is null and monthly_reach is not null) or (pl_monthly_reach = 0 and monthly_reach != 0)')
         .coalesce(1).write.mode('overwrite').parquet(s3_path))
        self.s3_path_list += [s3_path]

        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + reporting_folder + "/" +
                   'mars_tam_dtc_delta_exception' + "/")
        dtc_exception_dashboard_df = (tam_dtc_monthly_dfp.withColumn('reach_range', expr(
            "CASE WHEN delta_percent_reach < 0.03 or delta_percent_reach > -0.03 THEN "
            "'0-3' WHEN delta_percent_reach < 0.05 or delta_percent_reach > -0.05 THEN "
            "'3-5' WHEN delta_percent_reach < 0.10 or delta_percent_reach > -0.10 THEN "
            "'5-10' WHEN delta_percent_reach = '' THEN '0-3' WHEN delta_percent_reach is "
            "null THEN '0-3' ELSE '+10' END"))
                                      .withColumn('delta_percent_reach', expr(
            "CASE WHEN delta_percent_reach = '' or delta_percent_reach is null "
            "THEN 0 ELSE delta_percent_reach END"))
                                      .withColumn('cost_range', expr(
            "CASE WHEN delta_percent_cost < 0.03 or delta_percent_cost > -0.03 THEN "
            "'0-3' WHEN delta_percent_cost < 0.05 or delta_percent_cost > -0.05 THEN "
            "'3-5' WHEN delta_percent_cost < 0.10 or delta_percent_cost > -0.10 THEN "
            "'5-10' WHEN delta_percent_cost = '' THEN '0-3' WHEN delta_percent_cost is "
            "null THEN '0-3' ELSE '+10' END"))
                                      .withColumn('delta_percent_cost', expr(
            "CASE WHEN delta_percent_cost = '' or delta_percent_cost is null "
            "THEN 0 ELSE delta_percent_cost END")))

        dtc_exception_dashboard_df.coalesce(1).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + reporting_folder + "/" +
                   'mars_tam_ce_delta_exception' + "/")
        ce_exception_dashboard_df = (tam_ce_monthly_dfp.where(col('channel') != 'vae').withColumn('reach_range', expr(
            "CASE WHEN delta_percent_reach < 0.03 or delta_percent_reach > -0.03 THEN "
            "'0-3' WHEN delta_percent_reach < 0.05 or delta_percent_reach > -0.05 THEN "
            "'3-5' WHEN delta_percent_reach < 0.10 or delta_percent_reach > -0.10 THEN "
            "'5-10' WHEN delta_percent_reach = '' THEN '0-3' WHEN delta_percent_reach is "
            "null THEN '0-3' ELSE '+10' END"))
                                     .withColumn('delta_percent_reach', expr(
            "CASE WHEN delta_percent_reach = '' or delta_percent_reach is null "
            "THEN 0 ELSE delta_percent_reach END"))
                                     .withColumn('cost_range', expr(
            "CASE WHEN delta_percent_cost < 0.03 or delta_percent_cost > -0.03 THEN "
            "'0-3' WHEN delta_percent_cost < 0.05 or delta_percent_cost > -0.05 THEN "
            "'3-5' WHEN delta_percent_cost < 0.10 or delta_percent_cost > -0.10 THEN "
            "'5-10' WHEN delta_percent_cost = '' THEN '0-3' WHEN delta_percent_cost is "
            "null THEN '0-3' ELSE '+10' END"))
                                     .withColumn('delta_percent_cost', expr(
            "CASE WHEN delta_percent_cost = '' or delta_percent_cost is null "
            "THEN 0 ELSE delta_percent_cost END")))

        ce_exception_dashboard_df.coalesce(1).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def speaker_aggregate_data(self, spark):
        """
        This method is to write data quality for speaker data to s3
        :return: audit_info : List of stats for audit purpose
        """
        logger.info("Started speaker data quality aggregation")
        reporting_folder = json.loads(self.config.get(self.env, "dq_report_paths"))['speaker_dq_report_path']

        #        full_xo_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
        #                                                                      table_name=self.xo_digital_tbl)

        #        week_df = (full_xo_df.selectExpr('date(week_begin_date) AS week_begin_date', 'year', 'week',
        #                                         'date(week_end_date) AS week_end_date')
        #                   .withColumn('year_week', concat(col('year'), lpad(col('week'), 2, '0')).cast(IntegerType()))
        #                   .where(col('week').cast(IntegerType()) > 0)
        #                   .where(col('year_week') >= self.lower_bound_year_month)
        #                    .where(col('year_week') <= 202353)
        #                  .distinct())
        #        persisted_week_df = week_df.persist()

        df_training_costs = spark.sql(f"""
                    select
                        sum(cast(event_total_cost as double)) as total_training_cost
                    from {self.landing_database}.{self.speaker_tbl}
                    where upper(event_sub_type) = 'TRAINING'
                """)
        df_training_costs.registerTempTable('training_cost')

        df_raw_evts = spark.sql(f"""
                    select distinct
                        event_vendor_id,
                        event_start_date,
                        'speaker_program' as channel,
                        case 
                            when upper(event_sub_type) != 'TRAINING' 
                            then cast(sb.event_total_cost as double) 
                            else 0 
                        end as event_total_cost,
                        case 
                            when upper(event_sub_type) != 'TRAINING' 
                            then cast(customers_attended as double)
                            else 0
                        end as customers_attended,
                        event_type,event_format,setting_type,
                        upper(event_status) as event_status,
                        case
                            when upper(event_status) in ('CLOSED', 'OCCURRED')
                            then cast(patients_attended as double)
                            else 0
                        end as patients_attended,
                        cast(year(event_start_date) as string) || lpad(cast(month(event_start_date) as string), 2, '0') as year_month,
                        case when upper(event_sub_type) = 'PATIENT' then 'DTC' else 'HCP' end as audience
                    from {self.landing_database}.{self.speaker_tbl} as sb
                    where
                        upper(event_status) not in ('DROPPED', 'PENDING')
                        and (
                            cast(sb.event_total_cost as double)
                            + patients_attended
                            + customers_attended
                        ) > 0
                        and event_start_date < current_date
                        and upper(event_sub_type) != 'TRAINING'
                        and site_postal_code is not null
                """)
        df_raw_evts.registerTempTable('raw_evts')

        df_adjusted_raw_evts = spark.sql("""
                    select
                        re.*,
                        re.event_total_cost + (tc.total_training_cost / count(*) over()) as adjusted_event_total_cost
                    from raw_evts re
                    cross join training_cost tc
                """)
        df_adjusted_raw_evts.registerTempTable('adjusted_raw_evts')

        df_evt_curricula = spark.sql(f"""
                    with evt_curricula as (
                        select event_vendor_id,product_brand_name,product_brand_id from (
                            select * from (select distinct
                                s.event_vendor_id,
                                coalesce(upper(n.brand), s.product_brand_name) AS product_brand_name,
                                s.product_brand_id,
                                s.curriculum_prc_code
                            from {self.landing_database}.{self.event_tbl} s
                            left join {self.landing_database}.{self.speaker_non_assoc_brands} n
                            on s.curriculum_prc_code = n.curriculum_prc_code
                            where (n.curriculum_prc_code is not null
                            or upper(s.product_brand_name) != 'NOT ASSOCIATED')
                        ) )
                        where curriculum_prc_code !='M-US-00005290(v3.0)'
                        union 
                        select event_vendor_id,product_brand_name,product_brand_id from (
                            select distinct
                                s.event_vendor_id,
                                coalesce(upper(n.brand), s.product_brand_name) AS product_brand_name,
                                s.product_brand_id,
                                s.curriculum_prc_code
                            from {self.landing_database}.{self.event_tbl} s
                            left join (
                                select 
                                    curriculum_prc_code,
                                    explode(split(brand, ';')) AS brand
                                from {self.landing_database}.{self.speaker_non_assoc_brands} 
                                where curriculum_prc_code = 'M-US-00005290(v3.0)'
                            ) n
                            on s.curriculum_prc_code = n.curriculum_prc_code
                            where n.curriculum_prc_code is not null
                            or upper(s.product_brand_name) != 'NOT ASSOCIATED'
                        ) 
                        where curriculum_prc_code ='M-US-00005290(v3.0)'
                    )
                    select * from evt_curricula
                """)
        df_evt_curricula.registerTempTable('evt_curricula')

        df_evt_curricula_cnt = spark.sql("""
                    select distinct
                        event_vendor_id,
                        product_brand_name,
                        product_brand_id,
                        count(product_brand_id) over (partition by event_vendor_id) as product_count
                    from evt_curricula
                """)
        df_evt_curricula_cnt.registerTempTable('evt_curricula_cnt')

        speaker_product_df = spark.sql("""
                    select distinct
                        re.event_start_date,
                        re.channel,
                        ec.product_brand_name,
                        re.patients_attended + re.customers_attended as reach,
                        cast(re.year_month as int) year_month,
                        re.audience,
                        re.adjusted_event_total_cost / ec.product_count as cost
                    from adjusted_raw_evts as re
                    inner join evt_curricula_cnt as ec
                    on re.event_vendor_id = ec.event_vendor_id
                """)
        speaker_product_df.registerTempTable('evt_ds')

        speaker_df = speaker_product_df.where(col('year_month') >= self.lower_bound_year_month).where(
            upper(col('product_brand_name')).isin(self.mars_product_names)).persist()
        logger.info(f"Rows in speaker data : {speaker_df.count()}")

        #       condition = [speaker_df.event_start_date >= week_df.week_begin_date,
        #                    speaker_df.event_start_date <= week_df.week_end_date]
        #       weekly_speaker_df = (speaker_df
        #                            .join(persisted_week_df, condition, "inner")
        #                            .selectExpr('year_week', 'product_brand_name', 'event_start_date', 'week_begin_date',
        #                                        'cost', 'reach', 'week_end_date'))

        #       agg_weekly_speaker_df = (weekly_speaker_df.groupby("product_brand_name", "year_week")
        #                                .agg(sum("reach").alias("weekly_reach"),
        #                                     sum("cost").alias("weekly_cost")))

        agg_monthly_speaker_df = (speaker_df
                                  .groupby("product_brand_name", "year_month", "audience")
                                  .agg(sum("reach").alias("monthly_reach"),
                                       sum("cost").alias("monthly_cost")))

        pl_full_speaker_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                              table_name=self.speaker_tbl + '_backup').select(
            'version').distinct()
        pl_full_event_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                            table_name=self.event_tbl + '_backup').select(
            'version').distinct()

        if self.speaker_previous_version_num == None or self.speaker_previous_version_num == 'None':
            logger.info("Speaker Previous version in config is None or key is missing"
                        " that's why we are using max version minus 1")
            speaker_previous_version_num = int(pl_full_speaker_df.select([max("version")]).head()[0]) - 1
        else:
            logger.info("Speaker Previous version in config is " + str(self.speaker_previous_version_num))
            speaker_previous_version_num = self.speaker_previous_version_num

        if self.event_previous_version_num == None or self.event_previous_version_num == 'None':
            logger.info("Speaker Event Previous version in config is None or key is missing"
                        " that's why we are using max version minus 1")
            event_previous_version_num = int(pl_full_event_df.select([max("version")]).head()[0]) - 1
        else:
            logger.info("Speaker Event Previous version in config is " + str(self.event_previous_version_num))
            event_previous_version_num = self.event_previous_version_num

        logger.info(f'Speaker events previous version used for variance : {str(event_previous_version_num)}')

        logger.info(f'Speaker previous version used for variance : {str(event_previous_version_num)}')

        pl_df_training_costs = spark.sql(f"""
                            select
                                sum(cast(event_total_cost as double)) as total_training_cost
                            from {self.landing_database}.{self.speaker_tbl}_backup
                            where upper(event_sub_type) = 'TRAINING' and version = {speaker_previous_version_num}
                        """)
        pl_df_training_costs.registerTempTable('pl_training_cost')

        pl_df_raw_evts = spark.sql(f"""
                            select distinct
                                event_vendor_id,
                                event_start_date,
                                'speaker_program' as channel,
                                case 
                                    when upper(event_sub_type) != 'TRAINING' 
                                    then cast(sb.event_total_cost as double) 
                                    else 0 
                                end as event_total_cost,
                                case 
                                    when upper(event_sub_type) != 'TRAINING' 
                                    then cast(customers_attended as double)
                                    else 0
                                end as customers_attended,
                                event_type,event_format,setting_type,
                                upper(event_status) as event_status,
                                case
                                    when upper(event_status) in ('CLOSED', 'OCCURRED')
                                    then cast(patients_attended as double)
                                    else 0
                                end as patients_attended,
                                cast(year(event_start_date) as string) || lpad(cast(month(event_start_date) as string), 2, '0') as year_month,
                                case when upper(event_sub_type) = 'PATIENT' then 'DTC' else 'HCP' end as audience
                            from {self.landing_database}.{self.speaker_tbl}_backup as sb
                            where
                                upper(event_status) not in ('DROPPED', 'PENDING')
                                and (
                                    cast(sb.event_total_cost as double)
                                    + patients_attended
                                    + customers_attended
                                ) > 0
                                and event_start_date < current_date
                                and upper(event_sub_type) != 'TRAINING'
                                and site_postal_code is not null
                                and version = {speaker_previous_version_num}
                        """)
        pl_df_raw_evts.registerTempTable('pl_raw_evts')

        pl_df_adjusted_raw_evts = spark.sql("""
                            select
                                re.*,
                                re.event_total_cost + (tc.total_training_cost / count(*) over()) as adjusted_event_total_cost
                            from pl_raw_evts re
                            cross join pl_training_cost tc
                        """)
        pl_df_adjusted_raw_evts.registerTempTable('pl_adjusted_raw_evts')

        pl_df_evt_curricula = spark.sql(f"""
                            with pl_evt_curricula as (
                                select event_vendor_id,product_brand_name,product_brand_id from (
                                    select * from (select distinct
                                        s.event_vendor_id,
                                        coalesce(upper(n.brand), s.product_brand_name) AS product_brand_name,
                                        s.product_brand_id,
                                        s.curriculum_prc_code
                                    from {self.landing_database}.{self.event_tbl}_backup s
                                    left join {self.landing_database}.{self.speaker_non_assoc_brands} n
                                    on s.curriculum_prc_code = n.curriculum_prc_code
                                    where (n.curriculum_prc_code is not null
                                    or upper(s.product_brand_name) != 'NOT ASSOCIATED') 
                                    and s.version = {event_previous_version_num}                            
                                ) )
                                where curriculum_prc_code !='M-US-00005290(v3.0)'
                                union 
                                select event_vendor_id,product_brand_name,product_brand_id from (
                                    select distinct
                                        s.event_vendor_id,
                                        coalesce(upper(n.brand), s.product_brand_name) AS product_brand_name,
                                        s.product_brand_id,
                                        s.curriculum_prc_code
                                    from {self.landing_database}.{self.event_tbl}_backup s
                                    left join (
                                        select 
                                            curriculum_prc_code,
                                            explode(split(brand, ';')) AS brand
                                        from {self.landing_database}.{self.speaker_non_assoc_brands} 
                                        where curriculum_prc_code = 'M-US-00005290(v3.0)'   
                                    ) n
                                    on s.curriculum_prc_code = n.curriculum_prc_code
                                    where (n.curriculum_prc_code is not null
                                    or upper(s.product_brand_name) != 'NOT ASSOCIATED')  
                                    and s.version = {event_previous_version_num}  
                                ) 
                                where curriculum_prc_code ='M-US-00005290(v3.0)'
                            )
                            select * from pl_evt_curricula
                        """)
        pl_df_evt_curricula.registerTempTable('pl_evt_curricula')

        pl_df_evt_curricula_cnt = spark.sql("""
                            select distinct
                                event_vendor_id,
                                product_brand_name,
                                product_brand_id,
                                count(product_brand_id) over (partition by event_vendor_id) as product_count
                            from pl_evt_curricula
                        """)
        pl_df_evt_curricula_cnt.registerTempTable('pl_evt_curricula_cnt')

        pl_speaker_product_df = spark.sql("""
                            select distinct
                                re.event_start_date,
                                re.channel,
                                ec.product_brand_name,
                                re.patients_attended + re.customers_attended as reach,
                                cast(re.year_month as int) year_month,
                                re.audience,
                                re.adjusted_event_total_cost / ec.product_count as cost
                            from pl_adjusted_raw_evts as re
                            inner join pl_evt_curricula_cnt as ec
                            on re.event_vendor_id = ec.event_vendor_id
                        """)
        pl_speaker_product_df.registerTempTable('pl_evt_ds')

        pl_speaker_df = pl_speaker_product_df.where(col('year_month') >= self.lower_bound_year_month).where(
            upper(col('product_brand_name')).isin(self.mars_product_names)).persist()
        #                                             .where(col('year_month') <= self.upper_bound_year_month)

        logger.info(f"Rows in speaker data : {pl_speaker_df.count()}")

        #       condition = [pl_speaker_df.event_start_date >= week_df.week_begin_date,
        #                    pl_speaker_df.event_start_date <= week_df.week_end_date]
        #       pl_weekly_speaker_df = (pl_speaker_df
        #                               .join(persisted_week_df, condition, "inner")
        #                               .selectExpr('year_week', 'product_brand_name', 'event_start_date', 'week_begin_date',
        #                                           'cost', 'reach', 'week_end_date'))

        #        pl_agg_weekly_speaker_df = (pl_weekly_speaker_df.groupby("product_brand_name", "year_week")
        #                                    .agg(sum("reach").alias("pl_weekly_reach"),
        #                                         sum("cost").alias("pl_weekly_cost")))

        pl_agg_monthly_speaker_df = (pl_speaker_df
                                     .groupby("product_brand_name", "year_month", "audience")
                                     .agg(sum("reach").alias("pl_monthly_reach"),
                                          sum("cost").alias("pl_monthly_cost")))

        speaker_monthly_df = (agg_monthly_speaker_df.alias('ams')
                              .join(pl_agg_monthly_speaker_df.alias('pl_ams'),
                                    (col('ams.product_brand_name') == col('pl_ams.product_brand_name')) & (
                                            col('ams.year_month') == col('pl_ams.year_month')) & (
                                            col('ams.audience') == col('pl_ams.audience')),
                                    'left')
                              .selectExpr('ams.*', 'pl_ams.pl_monthly_cost as pl_monthly_cost',
                                          'pl_ams.pl_monthly_reach as pl_monthly_reach',
                                          '(-pl_ams.pl_monthly_cost+ams.monthly_cost)/pl_ams.pl_monthly_cost'
                                          ' as delta_percent_cost',
                                          '(-pl_ams.pl_monthly_reach+ams.monthly_reach)/pl_ams.pl_monthly_reach'
                                          ' as delta_percent_reach')
                              .withColumn('previous_month_reach', lag(col('monthly_reach'), 1, 0)
                                          .over(Window.partitionBy('product_brand_name').orderBy('year_month')))
                              .withColumn('previous_month_cost', lag(col('monthly_cost'), 1, 0)
                                          .over(Window.partitionBy('product_brand_name').orderBy('year_month')))
                              .withColumn('year', col('year_month').cast('string').substr(1, 4))
                              .withColumn('year_quarter', expr(
            "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)"))
                              )

        audit_info = []

        speaker_monthly_dfp = speaker_monthly_df.persist()
        row_count = speaker_monthly_dfp.count()
        logger.info(f"Row count for Speaker monthly CE : {row_count}")

        audit_info += [{'table_name': f"{self.landing_database}.mars_speaker_monthly_dq",
                        'rows_updated': row_count}]
        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + reporting_folder + "/" +
                   'mars_speaker_monthly_dq' + "/")
        speaker_monthly_dfp.coalesce(1).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" +
                   'mars_speaker_cost_exception' + "/")
        (speaker_monthly_dfp
         .filter(
            '(delta_percent_cost > 0.03 or delta_percent_cost < -0.03) or (pl_monthly_cost is null and monthly_cost is not null) or (pl_monthly_cost = 0 and monthly_cost != 0)')
         .coalesce(1).write.mode('overwrite').parquet(s3_path))
        self.s3_path_list += [s3_path]

        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" +
                   'mars_speaker_reach_exception' + "/")
        (speaker_monthly_dfp
         .filter(
            '(delta_percent_reach > 0.03 or delta_percent_reach < -0.03) or (pl_monthly_reach is null and monthly_reach is not null) or (pl_monthly_reach = 0 and monthly_reach != 0)')
         .coalesce(1).write.mode('overwrite').parquet(s3_path))
        self.s3_path_list += [s3_path]

        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + reporting_folder + "/" +
                   'mars_speaker_delta_exception' + "/")
        exception_dashboard_df = (speaker_monthly_dfp.withColumn('reach_range', expr(
            "CASE WHEN delta_percent_reach < 0.03 or delta_percent_reach > -0.03 THEN "
            "'0-3' WHEN delta_percent_reach < 0.05 or delta_percent_reach > -0.05 THEN "
            "'3-5' WHEN delta_percent_reach < 0.10 or delta_percent_reach > -0.10 THEN "
            "'5-10' WHEN delta_percent_reach = '' THEN '0-3' WHEN delta_percent_reach is "
            "null THEN '0-3' ELSE '+10' END"))
                                  .withColumn('delta_percent_reach', expr(
            "CASE WHEN delta_percent_reach = '' or delta_percent_reach is null "
            "THEN 0 ELSE delta_percent_reach END"))
                                  .withColumn('cost_range', expr(
            "CASE WHEN delta_percent_cost < 0.03 or delta_percent_cost > -0.03 THEN "
            "'0-3' WHEN delta_percent_cost < 0.05 or delta_percent_cost > -0.05 THEN "
            "'3-5' WHEN delta_percent_cost < 0.10 or delta_percent_cost > -0.10 THEN "
            "'5-10' WHEN delta_percent_cost = '' THEN '0-3' WHEN delta_percent_cost is "
            "null THEN '0-3' ELSE '+10' END"))
                                  .withColumn('delta_percent_cost', expr(
            "CASE WHEN delta_percent_cost = '' or delta_percent_cost is null "
            "THEN 0 ELSE delta_percent_cost END")))

        exception_dashboard_df.coalesce(1).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]
        #        audit_info += [{'table_name': f"{self.landing_database}.mars_speaker_weekly_dq",
        #                        'rows_updated': speaker_weekly_df.count()}]
        #       s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + reporting_folder + "/" +
        #                   'mars_speaker_weekly_dq' + "/")
        #        speaker_weekly_df.coalesce(1).write.mode('overwrite').parquet(s3_path)
        #        self.s3_path_list += [s3_path]
        return audit_info

    def sales_aggregate_data(self):
        """
        This method is to write data quality for sales data to s3
        :return: audit_info : List of stats for audit purpose
        """
        logger.info("Started sales data quality aggregation")
        reporting_folder = json.loads(self.config.get(self.env, "dq_report_paths"))['sales_dq_report_path']

        full_sales_qty_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                             table_name=self.sales_qty_tbl)
        full_net_sales_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                             table_name=self.net_sales_tbl)

        sales_qty_df = (full_sales_qty_df
                        .where(upper(col('product_brand_name')).isin(self.mars_product_names))
                        .selectExpr('date_year_month',
                                    "case when product_brand_name in ('ACTEMRA IV', 'ACTEMRA SC') "
                                    "then 'ACTEMRA' else product_brand_name end as product_brand_name",
                                    'gne_867_sales_qty_eqv',
                                    'gne_867_effective_wac_sales_dollars')
                        .withColumn('year_month', col('date_year_month').cast(IntegerType()))
                        .withColumn('gross_sales_dollars', col('gne_867_effective_wac_sales_dollars'))
                        .drop(col('date_year_month')).where(col('year_month') >= self.lower_bound_year_month)
                        # .where(col('year_month') <= 202312)
                        )
        agg_sales_qty_df = (sales_qty_df
                            .groupby("product_brand_name", "year_month")
                            .agg(sum("gne_867_sales_qty_eqv").alias("sales_qty"),
                                 sum("gross_sales_dollars").alias('gross_sales'))
                            )

        net_sales_df = (full_net_sales_df
                        .selectExpr("case when product_brand_name in ('ACTEMRA IV', 'ACTEMRA SC') then 'ACTEMRA' "
                                    "else product_brand_name end as product_brand_name",
                                    "date_year_month", "gne_867_net_sales_dollars")
                        .withColumn('year_month', col('date_year_month').cast(IntegerType()))
                        .drop(col('date_year_month')).where(col('year_month') >= self.lower_bound_year_month)
                        # .where(col('year_month') <= 202312)
                        )
        agg_net_sales_df = (net_sales_df
                            .groupby("product_brand_name", "year_month")
                            .agg(sum("gne_867_net_sales_dollars").alias("net_sales")))

        sales_df = (
            agg_sales_qty_df
            .join(agg_net_sales_df,
                  (agg_sales_qty_df.year_month == agg_net_sales_df.year_month) &
                  (agg_sales_qty_df.product_brand_name == agg_net_sales_df.product_brand_name),
                  "inner")
            .select(
                coalesce(agg_sales_qty_df.year_month, agg_net_sales_df.year_month).cast(IntegerType()).alias(
                    'year_month'),
                coalesce(agg_sales_qty_df.product_brand_name, agg_net_sales_df.product_brand_name).cast('string').alias(
                    'product_brand_name'),
                round("sales_qty", 3).alias('sales_qty'),
                round("gross_sales", 3).alias('gross_sales'),
                round("net_sales", 3).alias('net_sales')))

        pl_full_sales_qty_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                                table_name=self.sales_qty_tbl + '_backup')
        pl_full_net_sales_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                                table_name=self.net_sales_tbl + '_backup')

        if self.net_sales_previous_version_num == None or self.net_sales_previous_version_num == 'None':
            logger.info("Net Sales Previous version in config is None or key is missing"
                        " that's why we are using max version minus 1")
            net_sales_previous_version_num = int(pl_full_net_sales_df.select('version').distinct()
                                                 .select([max("version")]).head()[0]) - 1
        else:
            logger.info("Net Sales Previous version in config is " + str(self.net_sales_previous_version_num))
            net_sales_previous_version_num = self.net_sales_previous_version_num

        if self.sales_previous_version_num == None or self.sales_previous_version_num == 'None':
            logger.info("Sales Previous version in config is None or key is missing"
                        " that's why we are using max version minus 1")
            sales_previous_version_num = int(pl_full_sales_qty_df.select('version').distinct()
                                             .select([max("version")]).head()[0]) - 1
        else:
            logger.info("Sales Previous version in config is " + str(self.sales_previous_version_num))
            sales_previous_version_num = self.sales_previous_version_num

        logger.info(f'Sales previous version used for variance : {str(sales_previous_version_num)}')

        logger.info(f'Net sales previous version used for variance : {str(net_sales_previous_version_num)}')

        pl_sales_qty_df = (pl_full_sales_qty_df.where(col('version') == sales_previous_version_num)
                           .where(upper(col('product_brand_name')).isin(self.mars_product_names))
                           .selectExpr('date_year_month',
                                       "case when product_brand_name in ('ACTEMRA IV', 'ACTEMRA SC') "
                                       "then  'ACTEMRA' else product_brand_name end as product_brand_name",
                                       'gne_867_sales_qty_eqv',
                                       'gne_867_effective_wac_sales_dollars')
                           .withColumn('year_month', col('date_year_month').cast(IntegerType()))
                           .withColumn('gross_sales_dollars', col('gne_867_effective_wac_sales_dollars'))
                           .drop(col('date_year_month')).where(col('year_month') >= self.lower_bound_year_month)
                           #                           .where(col('year_month') <= self.upper_bound_year_month)
                           )
        pl_agg_sales_qty_df = (pl_sales_qty_df
                               .groupby("product_brand_name", "year_month")
                               .agg(sum("gne_867_sales_qty_eqv").alias("pl_sales_qty"),
                                    sum("gross_sales_dollars").alias('pl_gross_sales')))

        pl_net_sales_df = (pl_full_net_sales_df.where(col('version') == net_sales_previous_version_num)
                           .selectExpr(
            "case when product_brand_name in ('ACTEMRA IV', 'ACTEMRA SC') then 'ACTEMRA' else "
            "product_brand_name end as product_brand_name", "date_year_month",
            "gne_867_net_sales_dollars")
                           .withColumn('year_month', col('date_year_month').cast(IntegerType()))
                           .drop(col('date_year_month')).where(col('year_month') >= self.lower_bound_year_month)
                           #                           .where(col('year_month') <= self.upper_bound_year_month)
                           )
        pl_agg_net_sales_df = (pl_net_sales_df
                               .groupby("product_brand_name", "year_month")
                               .agg(sum("gne_867_net_sales_dollars").alias("pl_net_sales")))

        pl_sales_df = (
            pl_agg_sales_qty_df
            .join(pl_agg_net_sales_df,
                  (pl_agg_sales_qty_df.year_month == pl_agg_net_sales_df.year_month) &
                  (pl_agg_sales_qty_df.product_brand_name == pl_agg_net_sales_df.product_brand_name),
                  "inner")
            .select(
                coalesce(pl_agg_sales_qty_df.year_month, pl_agg_net_sales_df.year_month).cast(IntegerType()).alias(
                    'year_month'),
                coalesce(pl_agg_sales_qty_df.product_brand_name, pl_agg_net_sales_df.product_brand_name).cast(
                    'string').alias(
                    'product_brand_name'),
                round("pl_sales_qty", 3).alias('pl_sales_qty'),
                round("pl_gross_sales", 3).alias('pl_gross_sales'),
                round("pl_net_sales", 3).alias('pl_net_sales')))

        dq_sales_df = (pl_sales_df.alias('pl_sales')
                       .join(sales_df.alias('sales'),
                             (col('sales.product_brand_name') == col('pl_sales.product_brand_name')) & (
                                     col('sales.year_month') == col('pl_sales.year_month')),
                             'right')
                       .selectExpr('sales.*', 'pl_sales.pl_sales_qty as pl_sales_qty',
                                   'pl_sales.pl_net_sales as pl_net_sales', 'pl_sales.pl_gross_sales as pl_gross_sales',
                                   '(-pl_sales.pl_sales_qty+sales.sales_qty)/pl_sales.pl_sales_qty as delta_percent_sales_qty',
                                   '(-pl_sales.pl_gross_sales+sales.gross_sales)/pl_sales.pl_gross_sales as delta_percent_gross_sales',
                                   '(-pl_sales.pl_net_sales+sales.net_sales)/pl_sales.pl_net_sales as delta_percent_net_sales'
                                   )
                       .withColumn('previous_month_sales_qty', lag(col('sales_qty'), 1, 0)
                                   .over(Window.partitionBy('product_brand_name').orderBy('year_month')))
                       .withColumn('previous_month_gross_sales', lag(col('gross_sales'), 1, 0)
                                   .over(Window.partitionBy('product_brand_name').orderBy('year_month')))
                       .withColumn('previous_month_net_sales', lag(col('net_sales'), 1, 0)
                                   .over(Window.partitionBy('product_brand_name').orderBy('year_month')))
                       .withColumn('unit_price', col('net_sales') / col('sales_qty'))
                       .withColumn('year', col('year_month').cast('string').substr(1, 4))
                       .withColumn('year_quarter', expr(
            "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)"))
                       )

        persisted_df = dq_sales_df.persist()
        updated_row_cnt = persisted_df.count()
        audit_info = [{'table_name': f"{self.landing_database}.mars_sales_dq", 'rows_updated': updated_row_cnt}]

        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + reporting_folder + "/" +
                   'mars_sales_dq' + "/")
        persisted_df.coalesce(1).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + reporting_folder + "/" +
                   'mars_sales_delta_exception' + "/")
        exception_dashboard_df = (persisted_df.withColumn('sales_qty_range', expr(
            "CASE WHEN delta_percent_sales_qty < 0.03 or delta_percent_sales_qty > -0.03 THEN "
            "'0-3' WHEN delta_percent_sales_qty < 0.05 or delta_percent_sales_qty > -0.05 THEN "
            "'3-5' WHEN delta_percent_sales_qty < 0.10 or delta_percent_sales_qty > -0.10 THEN "
            "'5-10' WHEN delta_percent_sales_qty = '' THEN '0-3' WHEN delta_percent_sales_qty is "
            "null THEN '0-3' ELSE '+10' END"))
                                  .withColumn('delta_percent_sales_qty', expr(
            "CASE WHEN delta_percent_sales_qty = '' or delta_percent_sales_qty is null "
            "THEN 0 ELSE delta_percent_sales_qty END"))
                                  .withColumn('net_sales_range', expr(
            "CASE WHEN delta_percent_net_sales < 0.03 or delta_percent_net_sales > -0.03 THEN "
            "'0-3' WHEN delta_percent_net_sales < 0.05 or delta_percent_net_sales > -0.05 THEN "
            "'3-5' WHEN delta_percent_net_sales < 0.10 or delta_percent_net_sales > -0.10 THEN "
            "'5-10' WHEN delta_percent_net_sales = '' THEN '0-3' WHEN delta_percent_net_sales is "
            "null THEN '0-3' ELSE '+10' END"))
                                  .withColumn('delta_percent_net_sales', expr(
            "CASE WHEN delta_percent_net_sales = '' or delta_percent_net_sales is null "
            "THEN 0 ELSE delta_percent_net_sales END"))
                                  .withColumn('gross_sales_range', expr(
            "CASE WHEN delta_percent_gross_sales < 0.03 or delta_percent_gross_sales > -0.03 THEN "
            "'0-3' WHEN delta_percent_gross_sales < 0.05 or delta_percent_gross_sales > -0.05 THEN "
            "'3-5' WHEN delta_percent_gross_sales < 0.10 or delta_percent_gross_sales > -0.10 THEN "
            "'5-10' WHEN delta_percent_gross_sales = '' THEN '0-3' WHEN delta_percent_gross_sales is "
            "null THEN '0-3' ELSE '+10' END"))
                                  .withColumn('delta_percent_gross_sales', expr(
            "CASE WHEN delta_percent_gross_sales = '' or delta_percent_gross_sales is null "
            "THEN 0 ELSE delta_percent_gross_sales END")))

        exception_dashboard_df.coalesce(1).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" +
                   'mars_sales_qty_exception' + "/")
        (persisted_df
         .filter(
            '(delta_percent_sales_qty > 0.03 or delta_percent_sales_qty < -0.03) or (pl_sales_qty = 0 and sales_qty != 0) or (pl_sales_qty is null and sales_qty is not null)')
         .coalesce(1).write.mode('overwrite').parquet(s3_path))
        self.s3_path_list += [s3_path]

        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" +
                   'mars_gross_sales_exception' + "/")
        (persisted_df
         .filter(
            '(delta_percent_gross_sales > 0.03 or delta_percent_gross_sales < -0.03) or (pl_gross_sales = 0 and gross_sales != 0) or (pl_gross_sales is null and gross_sales is not null)')
         .coalesce(1).write.mode('overwrite').parquet(s3_path))
        self.s3_path_list += [s3_path]

        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" +
                   'mars_net_sales_exception' + "/")
        (persisted_df
         .filter(
            '(delta_percent_net_sales > 0.03 or delta_percent_net_sales < -0.03) or (pl_net_sales = 0 and  net_sales != 0) or (pl_net_sales is null and  net_sales is not null)')
         .coalesce(1).write.mode('overwrite').parquet(s3_path))
        self.s3_path_list += [s3_path]

        return audit_info

    def xo_digital_indication_aggregate_data(self):
        """
        This method is to write data quality for xo data to s3
        :return: audit_info : List of stats for audit purpose
        """
        logger.info("Started XO digital data quality aggregation")
        reporting_folder = json.loads(self.config.get(self.env, "dq_report_paths"))['xo_dq_report_path']
        full_xo_digital_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                              table_name=self.sst_all_media_summary_indication_bimonthly)

        xo_df = (full_xo_digital_df
                 .where(upper(col('brand_name')).isin(self.mars_product_names + ['HER2 MU']))
                 .selectExpr('year', 'month', 'indication',
                             "case when upper(brand_name) in ('ACTEMRA IV', 'ACTEMRA SC') then 'ACTEMRA' "
                             "     when upper(brand_name) = 'HER2 MU' then 'HER2' "
                             "     else upper(brand_name) end as product_brand_name",
                             "lower(regexp_replace(channel, '[^A-Za-z0-9]+', '_')) as channel", 'audience',
                             'lower(trim(publisher)) as publisher',
                             'cast(reach as DOUBLE) as reach', 'cast(cost as DOUBLE) as cost',
                             'cast(engage as DOUBLE) as engage')
                 .withColumn('year_month',
                             concat(col('year'), lpad(col('month'), 2, '0')).cast(IntegerType()))
                 .drop('year', 'month')
                 .where(col('year_month') >= self.lower_bound_year_month)
                 .where(upper(col('audience')).isin(['DTC', 'HCP']))
                 .where(~col('channel').isin(['dr_cable', 'linear_tv', 'hispanic_linear_tv', 'local_tv']))
                 )
        xo_persisted_df = xo_df.persist()
        logger.info(f"XO data without splitting HER2 count : {xo_persisted_df.count()}")
        hers_perjeta_df = (xo_persisted_df.where(col("product_brand_name") == "HER2")
                           .withColumn('reach', col('reach') * 0.6)
                           .withColumn('cost', col('cost') * 0.6)
                           .withColumn('engage', col('engage') * 0.6)
                           .withColumn('product_brand_name', lit('Perjeta')))

        hers_phesgo_df = (xo_persisted_df.where(col("product_brand_name") == "HER2")
                          .withColumn('reach', col('reach') * 0.2)
                          .withColumn('cost', col('cost') * 0.2)
                          .withColumn('engage', col('engage') * 0.2)
                          .withColumn('product_brand_name', lit('Phesgo')))

        xo_with_hers_df = (hers_perjeta_df
                           .union(hers_phesgo_df)
                           .union(xo_persisted_df.where(col("product_brand_name") != "HER2")))

        xo_df = xo_with_hers_df.withColumn('product_brand_name', upper(col('product_brand_name')))
        logger.info(f"XO data with splitting HER2 count : {xo_df.count()}")

        group_channel_case_str = f'case '
        for gc in self.group_channels:
            group_channel_case_str += (" WHEN lower(audience) = '" + gc['audience'] +
                                       "' AND upper(product_brand_name) = '" + gc['product_brand_name'] +
                                       "' AND lower(channel) = '" + gc['channel'] + "'  THEN '" + gc['group_chanel'] +
                                       "' ")
        group_channel_case_str += " ELSE 'Not Grouped' END"

        agg_xo_channel_monthly_df = (xo_df
                                     .groupby("product_brand_name", "year_month", "audience", "channel", "publisher",
                                              "indication")
                                     .agg(sum("reach").alias("reach"),
                                          sum("engage").alias("engage"),
                                          sum("cost").alias("cost"))
                                     .withColumn('year', col('year_month').cast('string').substr(1, 4))
                                     .withColumn('year_quarter', expr(
            "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)"))
                                     .withColumn('Group_channel', expr(group_channel_case_str))
                                     )

        audit_info = []
        audit_info += [{'table_name': f"{self.landing_database}.mars_xo_indication_dq",
                        'rows_updated': agg_xo_channel_monthly_df.count()}]

        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + reporting_folder + "/" +
                   'mars_xo_indication_dq' + "/")
        agg_xo_channel_monthly_df.coalesce(1).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def xo_digital_aggregate_data(self, spark):
        """
        This method is to write data quality for xo data to s3
        :return: audit_info : List of stats for audit purpose
        """
        logger.info("Started XO digital data quality aggregation")
        reporting_folder = json.loads(self.config.get(self.env, "dq_report_paths"))['xo_dq_report_path']
        full_xo_digital_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                              table_name=self.sst_all_media_summary_bimonthly)

        current_load_date_df = spark.sql(
            f"""select distinct etl_load_date from {self.landing_database}.{self.sst_all_media_summary_bimonthly}""")
        current_load_date_df.show()
        current_load_date = current_load_date_df.head()[0]
        print(current_load_date)

        xo_digital_df = (full_xo_digital_df
                         .where(upper(col('brand_name')).isin(self.mars_product_names + ['HER2 MU']))
                         .selectExpr('year', 'month',
                                     "case when upper(brand_name) in ('ACTEMRA IV', 'ACTEMRA SC') then 'ACTEMRA' "
                                     "     when upper(brand_name) = 'HER2 MU' then 'HER2' "
                                     "     else upper(brand_name) end as product_brand_name",
                                     "lower(regexp_replace(channel, '[^A-Za-z0-9]+', '_')) as channel", 'audience',
                                     'lower(trim(publisher)) as publisher',
                                     'cast(reach as DOUBLE) as reach', 'cast(cost as DOUBLE) as cost',
                                     'cast(engage as DOUBLE) as engage')
                         .withColumn('year_month',
                                     concat(col('year'), lpad(col('month'), 2, '0')).cast(IntegerType()))
                         .drop('year', 'month')
                         .where(col('year_month') >= self.lower_bound_year_month)
                         .where(upper(col('audience')).isin(['DTC', 'HCP']))
                         .where(~col('channel').isin(['dr_cable', 'linear_tv', 'hispanic_linear_tv', 'local_tv']))
                         )
        xo_digital_df.persist()
        logger.info(f"XO data without splitting HER2 count : {xo_digital_df.count()}")
        hers_perjeta_df = (xo_digital_df.where(col("product_brand_name") == "HER2")
                           .withColumn('reach', col('reach') * 0.6)
                           .withColumn('cost', col('cost') * 0.6)
                           .withColumn('engage', col('engage') * 0.6)
                           .withColumn('product_brand_name', lit('Perjeta')))

        hers_phesgo_df = (xo_digital_df.where(col("product_brand_name") == "HER2")
                          .withColumn('reach', col('reach') * 0.2)
                          .withColumn('cost', col('cost') * 0.2)
                          .withColumn('engage', col('engage') * 0.2)
                          .withColumn('product_brand_name', lit('Phesgo')))

        hers_kadcyla_df = (xo_digital_df.where(col("product_brand_name") == "HER2")
                           .withColumn('reach', col('reach') * 0.2)
                           .withColumn('cost', col('cost') * 0.2)
                           .withColumn('engage', col('engage') * 0.2)
                           .withColumn('product_brand_name', lit('Kadcyla')))

        xo_with_hers_df = (hers_perjeta_df
                           .union(hers_phesgo_df)
                           # .union(hers_kadcyla_df)
                           .union(xo_digital_df.where(col("product_brand_name") != "HER2")))

        xo_digital_persist_df = (xo_with_hers_df
                                 .withColumn('product_brand_name', upper(col('product_brand_name')))
                                 .persist())
        logger.info(f"XO data with splitting HER2 count : {xo_digital_persist_df.count()}")

        agg_xo_audience_monthly_df = (xo_digital_persist_df
                                      .groupby("product_brand_name", "year_month", "audience")
                                      .agg(sum("reach").alias("monthly_reach"),
                                           sum("engage").alias("monthly_engage"),
                                           sum("cost").alias("monthly_cost")))

        agg_xo_channel_monthly_df = (xo_digital_persist_df
                                     .groupby("product_brand_name", "year_month", "audience", "channel", "publisher")
                                     .agg(sum("reach").alias("monthly_reach"),
                                          sum("engage").alias("monthly_engage"),
                                          sum("cost").alias("monthly_cost")))

        agg_xo_channel_monthly_without_publisher_df = (xo_digital_persist_df
                                                       .groupby("product_brand_name", "year_month", "channel")
                                                       .agg(sum("reach").alias("monthly_reach"),
                                                            sum("engage").alias("monthly_engage"),
                                                            sum("cost").alias("monthly_cost")))

        pl_full_xo_digital_df = self.glue_context.create_data_frame.from_catalog(database=self.landing_database,
                                                                                 table_name=self.sst_all_media_summary_bimonthly + '_backup')

        if self.xo_previous_version_num == None or self.xo_previous_version_num == 'None':
            logger.info("XO Previous version in config is None or key is missing"
                        " that's why we are using max version minus 1")
            xo_previous_version_num = int(pl_full_xo_digital_df.select('version').distinct()
                                          .select([max("version")]).head()[0]) - 1
        else:
            logger.info("XO Previous version in config is " + str(self.xo_previous_version_num))
            xo_previous_version_num = self.xo_previous_version_num

        logger.info(f'XO previous version used for variance : {str(xo_previous_version_num)}')

        previous_load_date_df = spark.sql(
            f"""select distinct etl_load_date from {self.landing_database}.{self.sst_all_media_summary_bimonthly}_backup where version = '{xo_previous_version_num}'""")
        previous_load_date_df.show()
        previous_load_date = previous_load_date_df.head()[0]
        print(previous_load_date)

        pl_xo_digital_df = (pl_full_xo_digital_df.where(col('version') == xo_previous_version_num)
        .where(upper(col('brand_name')).isin(self.mars_product_names))
        .selectExpr('year', 'month',
                    "case when upper(brand_name) in ('ACTEMRA IV', 'ACTEMRA SC') then "
                    " 'ACTEMRA' else upper(brand_name) end as product_brand_name",
                    "lower(regexp_replace(channel, '[^A-Za-z0-9]+', '_')) as channel",
                    'audience', 'lower(trim(publisher)) as publisher',
                    'cast(reach as DOUBLE) as reach', 'cast(cost as DOUBLE) as cost',
                    'cast(engage as DOUBLE) as engage')
        .withColumn('year_month',
                    concat(col('year'), lpad(col('month'), 2, '0')).cast(IntegerType()))
        .drop('year', 'month')
        .where(col('year_month') >= self.lower_bound_year_month)
        .where(upper(col('audience')).isin(['DTC', 'HCP']))
        .where(
            ~col('channel').isin(['dr_cable', 'linear_tv', 'hispanic_linear_tv', 'local_tv']))
        )
        pl_xo_digital_df.persist()
        logger.info(f"PL XO data without splitting HER2 count : {pl_xo_digital_df.count()}")

        pl_hers_perjeta_df = (pl_xo_digital_df.where(col("product_brand_name") == "HER2")
                              .withColumn('reach', col('reach') * 0.6)
                              .withColumn('cost', col('cost') * 0.6)
                              .withColumn('engage', col('engage') * 0.6)
                              .withColumn('product_brand_name', lit('Perjeta')))

        pl_hers_phesgo_df = (pl_xo_digital_df.where(col("product_brand_name") == "HER2")
                             .withColumn('reach', col('reach') * 0.2)
                             .withColumn('cost', col('cost') * 0.2)
                             .withColumn('engage', col('engage') * 0.2)
                             .withColumn('product_brand_name', lit('Phesgo')))

        pl_hers_kadcyla_df = (pl_xo_digital_df.where(col("product_brand_name") == "HER2")
                              .withColumn('reach', col('reach') * 0.2)
                              .withColumn('cost', col('cost') * 0.2)
                              .withColumn('engage', col('engage') * 0.2)
                              .withColumn('product_brand_name', lit('Kadcyla')))

        pl_xo_with_hers_df = (pl_hers_perjeta_df
                              .union(pl_hers_phesgo_df)
                              # .union(pl_hers_kadcyla_df)
                              .union(pl_xo_digital_df.where(col("product_brand_name") != "HER2")))

        pl_xo_digital_persist_df = (pl_xo_with_hers_df
                                    .withColumn('product_brand_name', upper(col('product_brand_name')))
                                    .persist())
        logger.info(f"PL XO data with splitting HER2 count : {pl_xo_digital_persist_df.count()}")

        pl_agg_xo_audience_monthly_df = (pl_xo_digital_persist_df
                                         .groupby("product_brand_name", "year_month", "audience")
                                         .agg(sum("reach").alias("pl_monthly_reach"),
                                              sum("engage").alias("pl_monthly_engage"),
                                              sum("cost").alias("pl_monthly_cost")))

        pl_agg_xo_channel_monthly_without_publisher_df = (pl_xo_digital_persist_df
                                                          .groupby("product_brand_name", "year_month", "channel")
                                                          .agg(sum("reach").alias("pl_monthly_reach"),
                                                               sum("engage").alias("pl_monthly_engage"),
                                                               sum("cost").alias("pl_monthly_cost")))

        pl_agg_xo_channel_monthly_df = (pl_xo_digital_persist_df
                                        .groupby("product_brand_name", "year_month", "audience", "channel", "publisher")
                                        .agg(sum("reach").alias("pl_monthly_reach"),
                                             sum("engage").alias("pl_monthly_engage"),
                                             sum("cost").alias("pl_monthly_cost")))

        group_channel_case_str = f'case '
        for gc in self.group_channels:
            group_channel_case_str += (" WHEN lower(audience) = '" + gc['audience'] +
                                       "' AND upper(product_brand_name) = '" + gc['product_brand_name'] +
                                       "' AND lower(channel) = '" + gc['channel'] + "'  THEN '" + gc['group_chanel'] +
                                       "' ")
        group_channel_case_str += " ELSE 'Not Grouped' END"

        # logger.info(f'Group Channel Case statement: {group_channel_case_str}')

        xo_audience_monthly_df = (agg_xo_audience_monthly_df.alias('xam')
                                  .join(pl_agg_xo_audience_monthly_df.alias('pl_xam'),
                                        (col('xam.product_brand_name') == col('pl_xam.product_brand_name'))
                                        & (col('xam.year_month') == col('pl_xam.year_month'))
                                        & (col('xam.audience') == col('pl_xam.audience')),
                                        'left')
                                  .selectExpr('xam.*', 'pl_xam.pl_monthly_reach as pl_monthly_reach',
                                              'pl_xam.pl_monthly_engage as pl_monthly_engage',
                                              'pl_xam.pl_monthly_cost as pl_monthly_cost',
                                              '(-pl_xam.pl_monthly_reach+xam.monthly_reach)/pl_xam.pl_monthly_reach as delta_percent_reach',
                                              '(-pl_xam.pl_monthly_engage+xam.monthly_engage)/pl_xam.pl_monthly_engage as delta_percent_engage',
                                              '(-pl_xam.pl_monthly_cost+xam.monthly_cost)/pl_xam.pl_monthly_cost as delta_percent_cost'
                                              )
                                  .withColumn('previous_month_reach', lag(col('monthly_reach'), 1, 0)
                                              .over(Window.partitionBy('product_brand_name', 'audience')
                                                    .orderBy('year_month')))
                                  .withColumn('previous_month_cost', lag(col('monthly_cost'), 1, 0)
                                              .over(Window.partitionBy('product_brand_name', 'audience')
                                                    .orderBy('year_month')))
                                  .withColumn('previous_month_engage', lag(col('monthly_engage'), 1, 0)
                                              .over(Window.partitionBy('product_brand_name', 'audience')
                                                    .orderBy('year_month')))
                                  .withColumn('year', col('year_month').cast('string').substr(1, 4))
                                  .withColumn('year_quarter', expr(
            "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)"))
                                  .withColumn('current_data_load_date', lit(current_load_date))
                                  .withColumn('previous_version_load_date', lit(previous_load_date))
                                  )

        xo_channel_audience_monthly_df = (agg_xo_channel_monthly_df.alias('xcm')
                                          .join(pl_agg_xo_channel_monthly_df.alias('pl_xcm'),
                                                (col('xcm.product_brand_name') == col('pl_xcm.product_brand_name'))
                                                & (col('xcm.year_month') == col('pl_xcm.year_month'))
                                                & (col('xcm.channel') == col('pl_xcm.channel'))
                                                & (col('xcm.publisher') == col('pl_xcm.publisher'))
                                                & (col('xcm.audience') == col('pl_xcm.audience')),
                                                'left')
                                          .selectExpr('xcm.*',
                                                      'coalesce(pl_xcm.pl_monthly_reach,0) as pl_monthly_reach',
                                                      'coalesce(pl_xcm.pl_monthly_engage,0) as pl_monthly_engage',
                                                      'coalesce(pl_xcm.pl_monthly_cost,0) as pl_monthly_cost',
                                                      'coalesce((-pl_xcm.pl_monthly_reach+xcm.monthly_reach)/pl_xcm.pl_monthly_reach,0) as delta_percent_reach',
                                                      'coalesce((-pl_xcm.pl_monthly_engage+xcm.monthly_engage)/pl_xcm.pl_monthly_engage,0) as delta_percent_engage',
                                                      'coalesce((-pl_xcm.pl_monthly_cost+xcm.monthly_cost)/pl_xcm.pl_monthly_cost,0) as delta_percent_cost'
                                                      )
                                          .withColumn('publisher',
                                                      when(col('publisher') == '', 'NA').otherwise(col('publisher')))
                                          .withColumn('previous_month_reach', lag(col('monthly_reach'), 1, 0)
                                                      .over(
            Window.partitionBy('product_brand_name', 'channel', 'publisher')
            .orderBy('year_month')))
                                          .withColumn('previous_month_cost', lag(col('monthly_cost'), 1, 0)
                                                      .over(
            Window.partitionBy('product_brand_name', 'channel', 'publisher')
            .orderBy('year_month')))
                                          .withColumn('previous_month_engage', lag(col('monthly_engage'), 1, 0)
                                                      .over(
            Window.partitionBy('product_brand_name', 'channel', 'publisher')
            .orderBy('year_month')))
                                          .withColumn('year', col('year_month').cast('string').substr(1, 4))
                                          .withColumn('Group_channel', expr(group_channel_case_str))
                                          .withColumn('year_quarter', expr(
            "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)"))
                                          .withColumn('current_data_load_date', lit(current_load_date))
                                          .withColumn('previous_version_load_date', lit(previous_load_date))
                                          )

        xo_channel_monthly_without_publisher_df = (agg_xo_channel_monthly_without_publisher_df.alias('xcm')
                                                   .join(pl_agg_xo_channel_monthly_without_publisher_df.alias('pl_xcm'),
                                                         (col('xcm.product_brand_name') == col(
                                                             'pl_xcm.product_brand_name'))
                                                         & (col('xcm.year_month') == col('pl_xcm.year_month'))
                                                         & (col('xcm.channel') == col('pl_xcm.channel')),
                                                         'left')
                                                   .selectExpr('xcm.*', 'pl_xcm.pl_monthly_reach as pl_monthly_reach',
                                                               'pl_xcm.pl_monthly_engage as pl_monthly_engage',
                                                               'pl_xcm.pl_monthly_cost as pl_monthly_cost',
                                                               '(-pl_xcm.pl_monthly_reach+xcm.monthly_reach)/pl_xcm.pl_monthly_reach as delta_percent_reach',
                                                               '(-pl_xcm.pl_monthly_engage+xcm.monthly_engage)/pl_xcm.pl_monthly_engage as delta_percent_engage',
                                                               '(-pl_xcm.pl_monthly_cost+xcm.monthly_cost)/pl_xcm.pl_monthly_cost as delta_percent_cost'
                                                               )
                                                   .withColumn('previous_month_reach', lag(col('monthly_reach'), 1, 0)
                                                               .over(Window.partitionBy('product_brand_name', 'channel')
                                                                     .orderBy('year_month')))
                                                   .withColumn('previous_month_cost', lag(col('monthly_cost'), 1, 0)
                                                               .over(Window.partitionBy('product_brand_name', 'channel')
                                                                     .orderBy('year_month')))
                                                   .withColumn('previous_month_engage', lag(col('monthly_engage'), 1, 0)
                                                               .over(Window.partitionBy('product_brand_name', 'channel')
                                                                     .orderBy('year_month')))
                                                   .withColumn('year', col('year_month').cast('string').substr(1, 4))
                                                   .withColumn('year_quarter', expr(
            "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)"))
                                                   .withColumn('current_data_load_date', lit(current_load_date))
                                                   .withColumn('previous_version_load_date', lit(previous_load_date))
                                                   )

        xo_channel_audience_monthly_dfp = xo_channel_audience_monthly_df.persist()
        row_count = xo_channel_audience_monthly_dfp.count()

        xo_pivot_channel_monthly = (
            xo_channel_audience_monthly_dfp.selectExpr('product_brand_name', 'year_month', "channel",
                                                       'monthly_reach as reach',
                                                       'monthly_engage as engage',
                                                       'monthly_cost as cost')
            .groupBy("product_brand_name", "year_month")
            .pivot("channel")
            .sum("reach", "engage", "cost")
        )
        df_pivoted = (xo_pivot_channel_monthly.select(
            *[
                col(clmn).alias(clmn.replace("_sum(", "_").replace(")", "")) for clmn in
                xo_pivot_channel_monthly.columns
            ]).withColumn('year', col('year_month').cast('string').substr(1, 4))
                      .withColumn('current_data_load_date', lit(current_load_date))
                      .withColumn('previous_version_load_date', lit(previous_load_date))
                      .withColumn('year_quarter', expr(
            "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)")))

        audit_info = []
        audit_info += [{'table_name': f"{self.landing_database}.mars_xo_audience_monthly_dq",
                        'rows_updated': xo_audience_monthly_df.count()}]
        audit_info += [{'table_name': f"{self.landing_database}.mars_xo_channel_monthly_dq",
                        'rows_updated': row_count}]
        audit_info += [{'table_name': f"{self.landing_database}.mars_xo_channel_monthly_without_publisher_dq",
                        'rows_updated': xo_channel_monthly_without_publisher_df.count()}]
        audit_info += [{'table_name': f"{self.landing_database}.mars_xo_pivot_channel_monthly_dq",
                        'rows_updated': df_pivoted.count()}]

        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + reporting_folder + "/" +
                   'mars_xo_audience_monthly_dq' + "/")
        xo_audience_monthly_df.coalesce(1).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]
        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + reporting_folder + "/" +
                   'mars_xo_channel_monthly_dq' + "/")
        xo_channel_audience_monthly_dfp.coalesce(1).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]
        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + reporting_folder + "/" +
                   'mars_xo_pivot_channel_monthly_dq' + "/")
        df_pivoted.na.fill(value=0).coalesce(1).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]
        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + reporting_folder + "/" +
                   'mars_xo_pivot_channel_monthly_without_publisher_dq' + "/")
        xo_channel_monthly_without_publisher_df.na.fill(value=0).coalesce(1).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" +
                   'mars_xo_delta_exception' + "/")

        (xo_channel_audience_monthly_dfp
         .withColumn('reach_range', expr("CASE WHEN delta_percent_reach < 0.03 or delta_percent_reach > -0.03 THEN "
                                         "'0-3' WHEN delta_percent_reach < 0.05 or delta_percent_reach > -0.05 THEN "
                                         "'3-5' WHEN delta_percent_reach < 0.10 or delta_percent_reach > -0.10 THEN "
                                         "'5-10' WHEN delta_percent_reach = '' THEN '0-3' WHEN delta_percent_reach is "
                                         "null THEN '0-3' ELSE '+10' END"))
         .withColumn('delta_percent_reach', expr("CASE WHEN delta_percent_reach = '' or delta_percent_reach is null "
                                                 "THEN 0 ELSE delta_percent_reach END"))
         .withColumn('cost_range', expr("CASE WHEN delta_percent_cost < 0.03 or delta_percent_cost > -0.03 THEN "
                                        "'0-3' WHEN delta_percent_cost < 0.05 or delta_percent_cost > -0.05 THEN "
                                        "'3-5' WHEN delta_percent_cost < 0.10 or delta_percent_cost > -0.10 THEN "
                                        "'5-10' WHEN delta_percent_cost = '' THEN '0-3' WHEN delta_percent_cost is null "
                                        "THEN '0-3' ELSE '+10' END"))
         .withColumn('delta_percent_cost', expr(
            "CASE WHEN delta_percent_cost = '' or delta_percent_cost is null THEN 0 ELSE delta_percent_cost END"))
         .withColumn('engage_range', expr("CASE WHEN delta_percent_engage < 0.03 or delta_percent_engage > -0.03 THEN "
                                          "'0-3' WHEN delta_percent_engage < 0.05 or delta_percent_engage > -0.05 THEN "
                                          "'3-5' WHEN delta_percent_engage < 0.10 or delta_percent_engage > -0.10 THEN "
                                          "'5-10' WHEN delta_percent_engage = '' THEN '0-3' WHEN delta_percent_engage is "
                                          "null THEN '0-3' ELSE '+10' END"))
         .withColumn('delta_percent_engage', expr(
            "CASE WHEN delta_percent_engage = '' or delta_percent_engage is null THEN 0 ELSE delta_percent_engage END"))
         .coalesce(1).write.mode('overwrite').parquet(s3_path))
        self.s3_path_list += [s3_path]

        year_quarter_agg_df = (
            xo_channel_audience_monthly_dfp.groupby("product_brand_name", "year_quarter", "channel", "publisher",
                                                    "audience", "Group_channel")
            .agg(sum("pl_monthly_reach").alias("pl_monthly_reach"),
                 sum("pl_monthly_engage").alias("pl_monthly_engage"),
                 sum("pl_monthly_cost").alias("pl_monthly_cost"),
                 sum("monthly_reach").alias("monthly_reach"),
                 sum("monthly_engage").alias("monthly_engage"),
                 sum("monthly_cost").alias("monthly_cost")))

        delta_percent_df = year_quarter_agg_df.selectExpr(
            '*', "round((-pl_monthly_reach+monthly_reach)/pl_monthly_reach,4) as delta_percent_reach",
            "round((-pl_monthly_engage+monthly_engage)/pl_monthly_engage,4) as delta_percent_engage",
            "round((-pl_monthly_cost+monthly_cost)/pl_monthly_cost,4) as delta_percent_cost")

        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" +
                   'mars_xo_engage_exception' + "/")
        (delta_percent_df
         .filter(
            '(delta_percent_engage > 0.03 or delta_percent_engage < -0.03) or (pl_monthly_engage = 0 and monthly_engage != 0 )')

         .coalesce(1).write.mode('overwrite').parquet(s3_path))
        self.s3_path_list += [s3_path]

        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" +
                   'mars_xo_cost_exception' + "/")
        (delta_percent_df
         .filter(
            '(delta_percent_cost > 0.03 or delta_percent_cost < -0.03) or (pl_monthly_cost = 0 and monthly_cost != 0 )')
         .coalesce(1).write.mode('overwrite').parquet(s3_path))
        self.s3_path_list += [s3_path]

        s3_path = ("s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" +
                   'mars_xo_reach_exception' + "/")
        (delta_percent_df
         .filter(
            '(delta_percent_reach > 0.03 or delta_percent_reach < -0.03) or (pl_monthly_reach = 0 and monthly_reach != 0)')
         .coalesce(1).write.mode('overwrite').parquet(s3_path))
        self.s3_path_list += [s3_path]

        return audit_info

    def email_attachment(self, spark):

        logger.info("Exception Email Attachment Creation")
        excel_filename = f"Exception_report_{datetime.now().strftime('%Y-%b-%d_%H:%M')}.xlsx"
        with pd.ExcelWriter(excel_filename) as writer:
            mars_xo_reach_exception_df = spark.read.parquet(
                "s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" + 'mars_xo_reach_exception' + "/"
            ).selectExpr('product_brand_name as brand_name', 'Group_channel', 'channel', 'publisher', 'audience',
                         'year_quarter', 'monthly_reach as reach', 'pl_monthly_reach as old_reach',
                         "coalesce(round(delta_percent_reach*100,2),'infinity') as reach_delta_percent")

            if mars_xo_reach_exception_df.count() > 0:
                mars_xo_reach_exception_df.toPandas().to_excel(writer, sheet_name='xo_reach', index=False)

            mars_xo_cost_exception_df = spark.read.parquet(
                "s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" + 'mars_xo_cost_exception' + "/"
            ).selectExpr('product_brand_name as brand_name', 'Group_channel', 'channel', 'publisher', 'audience',
                         'year_quarter', 'monthly_cost as cost', 'pl_monthly_cost as old_cost',
                         "coalesce(round(delta_percent_cost*100,2),'infinity') as delta_percent_cost")
            if mars_xo_cost_exception_df.count() > 0:
                mars_xo_cost_exception_df.toPandas().to_excel(writer, sheet_name='xo_cost', index=False)

            mars_xo_engage_exception_df = spark.read.parquet(
                "s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" + 'mars_xo_engage_exception' + "/"
            ).selectExpr('product_brand_name as brand_name', 'Group_channel', 'channel', 'publisher', 'audience',
                         'year_quarter', 'monthly_engage as engage', 'pl_monthly_engage as old_engage',
                         "coalesce(round(delta_percent_engage*100,2),'infinity') as delta_percent_engage")
            if mars_xo_engage_exception_df.count():
                mars_xo_engage_exception_df.toPandas().to_excel(writer, sheet_name='xo_engage', index=False)

            mars_sales_qty_exception_df = spark.read.parquet(
                "s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" + 'mars_sales_qty_exception' + "/"
            ).selectExpr('product_brand_name as brand_name', 'year_month', 'sales_qty', 'pl_sales_qty as old_sales_qty',
                         "coalesce(round(delta_percent_sales_qty*100,2),'infinity') as delta_percent_sales_qty").withColumn(
                'year_quarter', expr(
                    "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)"))
            if mars_sales_qty_exception_df.count() > 0:
                mars_sales_qty_exception_df.toPandas().to_excel(writer, sheet_name='sales_qty', index=False)

            mars_gross_sales_exception_df = spark.read.parquet(
                "s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" + 'mars_gross_sales_exception' + "/"
            ).selectExpr('product_brand_name as brand_name', 'year_month', 'gross_sales',
                         'pl_gross_sales as old_gross_sales',
                         "coalesce(round(delta_percent_gross_sales*100,2),'infinity') as delta_percent_gross_sales").withColumn(
                'year_quarter', expr(
                    "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)"))
            if mars_gross_sales_exception_df.count() > 0:
                mars_gross_sales_exception_df.toPandas().to_excel(writer, sheet_name='gross_sales', index=False)

            mars_net_sales_exception_df = spark.read.parquet(
                "s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" + 'mars_net_sales_exception' + "/"
            ).selectExpr('product_brand_name as brand_name', 'year_month', 'net_sales', 'pl_net_sales as old_net_sales',
                         "coalesce(round(delta_percent_net_sales*100,2),'infinity') as delta_percent_net_sales").withColumn(
                'year_quarter', expr(
                    "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)"))
            if mars_net_sales_exception_df.count() > 0:
                mars_net_sales_exception_df.toPandas().to_excel(writer, sheet_name='net_sales', index=False)

            mars_speaker_cost_exception_df = spark.read.parquet(
                "s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" + 'mars_speaker_cost_exception' + "/"
            ).selectExpr('product_brand_name as brand_name', 'audience', 'year_month', 'monthly_cost as cost',
                         'pl_monthly_cost as old_cost',
                         "coalesce(round(delta_percent_cost*100,2),'infinity') as delta_percent_cost").withColumn(
                'year_quarter', expr(
                    "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)"))
            if mars_speaker_cost_exception_df.count() > 0:
                mars_speaker_cost_exception_df.toPandas().to_excel(writer, sheet_name='speaker_cost', index=False)

            mars_speaker_reach_exception_df = spark.read.parquet(
                "s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" + 'mars_speaker_reach_exception' + "/"
            ).selectExpr('product_brand_name as brand_name', 'audience', 'year_month', 'monthly_reach as reach',
                         'pl_monthly_reach as old_reach',
                         "coalesce(round(delta_percent_reach*100,2),'infinity') as delta_percent_reach").withColumn(
                'year_quarter', expr(
                    "substr(year_month, 1, 4) || 'Q' || cast(ceil(cast(substr(year_month, 5, 2) as int) / 3.0) as string)"))
            if mars_speaker_reach_exception_df.count() > 0:
                mars_speaker_reach_exception_df.toPandas().to_excel(writer, sheet_name='speaker_reach', index=False)

            mars_tam_ce_cost_exception_df = spark.read.parquet(
                "s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" + 'mars_tam_ce_cost_exception' + "/"
            ).selectExpr('product_brand_name as brand_name', 'year_quarter', 'monthly_cost as cost',
                         'pl_monthly_cost as old_cost',
                         "coalesce(round(delta_percent_cost*100,2),'infinity') as delta_percent_cost")
            if mars_tam_ce_cost_exception_df.count() > 0:
                mars_tam_ce_cost_exception_df.toPandas().to_excel(writer, sheet_name='tam_ce_cost', index=False)

            mars_tam_ce_reach_exception_df = spark.read.parquet(
                "s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" + 'mars_tam_ce_reach_exception' + "/"
            ).selectExpr('product_brand_name as brand_name', 'year_quarter', 'monthly_reach as reach',
                         'pl_monthly_reach as old_reach',
                         "coalesce(round(delta_percent_reach*100,2),'infinity') as delta_percent_reach")
            if mars_tam_ce_reach_exception_df.count() > 0:
                mars_tam_ce_reach_exception_df.toPandas().to_excel(writer, sheet_name='tam_ce_reach', index=False)

            mars_tam_dtc_cost_exception_df = spark.read.parquet(
                "s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" + 'mars_tam_dtc_cost_exception' + "/"
            ).selectExpr('product_brand_name as brand_name', 'year_quarter', 'monthly_cost as cost',
                         'pl_monthly_cost as old_cost',
                         "coalesce(round(delta_percent_cost*100,2),'infinity') as delta_percent_cost")
            if mars_tam_dtc_cost_exception_df.count() > 0:
                mars_tam_dtc_cost_exception_df.toPandas().to_excel(writer, sheet_name='tam_dtc_cost', index=False)

            mars_tam_dtc_reach_exception_df = spark.read.parquet(
                "s3://" + self.bucket_name + "/" + self.landing_folder + "/" + 'exception_report_folder' + "/" + 'mars_tam_dtc_reach_exception' + "/"
            ).selectExpr('product_brand_name as brand_name', 'year_quarter', 'monthly_reach as reach',
                         'pl_monthly_reach as old_reach',
                         "coalesce(round(delta_percent_reach*100,2),'infinity') as delta_percent_reach")
            if mars_tam_dtc_reach_exception_df.count() > 0:
                mars_tam_dtc_reach_exception_df.toPandas().to_excel(writer, sheet_name='tam_dtc_reach', index=False)

        s3_client = boto3.resource('s3')
        S3_obj = S3Path(f's3://{self.bucket_name}/oasis_landing/exception_report_folder/exception_report_consolidated/')
        s3_client.Object(S3_obj.bucket, S3_obj.key + excel_filename).upload_file(excel_filename)
        logger.info(f'Excel file path : {S3_obj.bucket}/{S3_obj.key + excel_filename}')

        S3_obj = S3Path(f's3://{self.bucket_name}/oasis_landing/exception_report_folder/exception_report_attachment/')
        s3_client.Object(S3_obj.bucket, S3_obj.key + 'Exception_report.xlsx').upload_file(excel_filename)
        logger.info(f'Excel file path : {S3_obj.bucket}/{S3_obj.key}Exception_report.xlsx')

    def create_update_crawler(self, client):
        """
        Crawler has to be created if it doesn't exist, if it exists then we have to update it s3 path for it.
        :param client: glue boto3 client used to create or update crawler
        """
        # Creating list of s3 path that has to be crawled

        s3_crawl_list = []
        for s3_path in list(set(self.s3_path_list)):
            s3_crawl_list.append(
                {"Path": s3_path, 'Exclusions': json.loads(self.config.get(self.env, "crawl_exclusion_paths"))})

        crawler_exist = True

        # Checking if crawler is already existing or not
        try:
            res = client.get_crawler(Name=self.crawler_name)
            response = json.dumps(res, indent=4, sort_keys=True, default=str)
            print(response)
        except client.exceptions.EntityNotFoundException as e:
            logger.info("Crawler doesnt exist, need to create")
            crawler_exist = False

        # Creating crawler if it doesn't exist
        if crawler_exist:
            response = client.update_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.landing_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Updated\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

        else:
            response = client.create_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.landing_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Created\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

    def start_crawler(self, client):
        """
        This method is used to start the crawler
        :param client: glue boto3 client used to create or update crawler
        """
        response_start = client.start_crawler(Name=self.crawler_name)
        logger.info("Crawler Started\nName : " + self.crawler_name)
        logger.info(json.dumps(response_start, indent=4, sort_keys=True, default=str))

    def monitor_crawler(self, client):
        """
        This method is used to monitor the crawler which we started just now
        :param client: glue boto3 client used to create or update crawler
        """
        need_to_wait = True
        state_previous = None
        while need_to_wait:
            time.sleep(20)
            response_get = client.get_crawler(Name=self.crawler_name)
            state = response_get["Crawler"]["State"]
            if state == "READY" or state == "STOPPING":  # Other known states: RUNNING
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                need_to_wait = False
                break
            if state != state_previous:
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                state_previous = state


def audit_job_info(spark_obj, job_srt_time, job_name, batch_id, audit_path, audit_dict):
    """
    This function is used to write audit stats of this etl job to athena table.
    :param audit_path:
    :param spark_obj:
    :param job_srt_time:
    :param job_name:
    :param batch_id:
    :param audit_dict:
    """
    logger.info("Writing to audit table")
    if audit_dict is not None:
        logger.info(audit_dict)
        audit_df = (spark_obj.createDataFrame(audit_dict)
                    .withColumn("log_id_status", lit("COMPLETED"))
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", current_timestamp().cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("etl_layer", lit("reporting"))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)
    else:
        audit_df = (spark_obj.createDataFrame([{'etl_layer': 'reporting', 'log_id_status': 'INITIATED'}])
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", lit(None).cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("table_name", lit(None).cast(StringType()))
                    .withColumn("rows_updated", lit(None).cast(IntegerType()))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)


if __name__ == "__main__":
    # Getting AWS Glue job parameters, creating session and initiating job
    arg = getResolvedOptions(sys.argv, ['JOB_NAME', 'environment', 'batch_id'])

    logger.info("MARS landing layer data quality job started")

    environment = arg['environment']
    config_obj = read_config_file('configuration.ini')
    check_config_section(config_obj, environment)
    job_start_time = datetime.now()

    sc = SparkContext()
    glueContext = GlueContext(sc)
    sprk = glueContext.spark_session
    job = Job(glueContext)
    job.init(arg['JOB_NAME'], arg)
    sprk.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'), audit_dict=None)

    data_quality = DataQualityReport(config_obj, arg, glueContext, sprk)

    audit_list = []

    audit_list += data_quality.sales_aggregate_data()

    audit_list += data_quality.xo_digital_aggregate_data(sprk)

    # audit_list += data_quality.xo_digital_indication_aggregate_data()

    audit_list += data_quality.speaker_aggregate_data(sprk)

    audit_list += data_quality.tam_aggregate_data(sprk)

    data_quality.email_attachment(sprk)

    athena_cl = boto3.client('athena', region_name="us-west-2")

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'), audit_dict=audit_list)

    crawler_client = boto3.client('glue', region_name="us-west-2")

    data_quality.create_update_crawler(crawler_client)

    data_quality.start_crawler(crawler_client)

    data_quality.monitor_crawler(crawler_client)

    job.commit()
