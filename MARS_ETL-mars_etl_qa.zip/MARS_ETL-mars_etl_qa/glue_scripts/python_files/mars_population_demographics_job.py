import json
import logging
import configparser
import boto3
import sys
import time
from awsglue.utils import getResolvedOptions
from pyspark.sql.functions import *
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.types import *
import datetime
from pyspark.sql.window import Window
from pyspark.sql.functions import udf

MSG_FORMAT = '%(asctime)s %(levelname)s %(name)s: %(message)s'
DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
logging.basicConfig(format=MSG_FORMAT, datefmt=DATETIME_FORMAT)
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def read_config_file(config_file_name):
    """
    This function is reading config file and returning config object
    :type config_file_name: string
    """
    config = configparser.ConfigParser()
    config.read(config_file_name)
    return config


def check_config_section(config, env):
    """
    This function check if section specified in job parameters is present in config file or not
    :param config: Config file object
    :param env: environment which is specified in job parameters
    """
    if not config.has_section(env):
        raise Exception("Environment details doesn't exist in configuration file")


class PopulationDemoFinal:
    def __init__(self, config, args, glue_context, spark):
        """
        This is init method used to initialize variables in class
        :param config: Config file object
        :param args: Arguments given to Glue job
        """
        self.env = args['environment']
        self.args = args
        self.bucket_name = config.get(self.env, "bucket_name")
        self.normalized_folder = json.loads(config.get(self.env, "folder_names"))['normalized']
        self.summarized_folder = json.loads(config.get(self.env, "folder_names"))['summarized']
        self.s3_path_list = []
        self.normalized_database = json.loads(config.get(self.env, "athena_database"))['normalized']
        self.summarized_database = json.loads(config.get(self.env, "athena_database"))['summarized']
        self.config = config
        self.crawler_name = 'mars_pop_demo_final_crawler'
        self.glue_context = glue_context
        self.spark = spark
        self.landing_database = json.loads(config.get(self.env, "athena_database"))['landing']
        self.mars_population_demographics_us_islands_stg = config.get(self.env, "mars_population_demographics_us_islands_stg")
        self.mars_population_demographics_us_stg = config.get(self.env, "mars_population_demographics_us_stg")
        self.mars_zip_zcta_crosswalk_stg = config.get(self.env, "mars_zip_zcta_crosswalk_stg")
        self.zip_to_eco_dly_tbl = config.get(self.env, "zip_to_eco_dly_tbl")
        self.hcp_outlet_affl_wkl_tbl = config.get(self.env, "hcp_outlet_affl_wkl_tbl")
        self.mars_hrr_staging = config.get(self.env, "mars_hrr_staging")
        self.mars_zipcode_to_all_cities_mapping_stg = config.get(self.env, "mars_zipcode_to_all_cities_mapping_stg")
        self.mars_zip_to_dma_dedupe_stg = config.get(self.env, "mars_zip_to_dma_dedupe_stg")

    def core(self, athena_client):

        df_pop_demo_islands = self.spark.sql(f"""
                select
                    zip_code as zip,
                    dp1_0001c as zip_total,
                    upper(state) as state,
                    upper(name) as city,
                    (
                        dp1_0006c
                        + dp1_0007c
                        + dp1_0008c
                        + dp1_0009c
                        + dp1_0010c
                        + dp1_0011c
                    ) as zip_total_18_49,
                    (
                        dp1_0054c
                        + dp1_0055c
                        + dp1_0056c
                        + dp1_0057c
                        + dp1_0058c
                        + dp1_0059c
                    ) as zip_female_18_49,
                    (
                        dp1_0012c
                        + dp1_0013c
                        + dp1_0014c
                        + dp1_0015c
                        + dp1_0016c
                        + dp1_0017c
                        + dp1_0018c
                        + dp1_0019c
                    ) as zip_total_50_99
                from {self.normalized_database}.{self.mars_population_demographics_us_islands_stg}
        """)
        df_pop_demo_islands.registerTempTable('pop_demo_islands')

        df_pop_demo_zcta = self.spark.sql(f"""    
            select
                zcta,
                null as state,
                null as city,
                (s0101_c01_001e) as total,
                (
                    s0101_c01_023e
                    + s0101_c01_007e
                    + s0101_c01_008e
                    + s0101_c01_009e
                    + s0101_c01_010e
                    + s0101_c01_011e
                ) as total_18_49,
                (
                    s0101_c05_023e
                    + s0101_c05_007e
                    + s0101_c05_008e
                    + s0101_c05_009e
                    + s0101_c05_010e
                    + s0101_c05_011e
                ) as female_18_49,
                (
                    s0101_c01_012e
                    + s0101_c01_013e
                    + s0101_c01_014e
                    + s0101_c01_015e
                    + s0101_c01_016e
                    + s0101_c01_017e 
                    + s0101_c01_018e 
                    + s0101_c01_019e
                ) as total_50_99
            from {self.normalized_database}.{self.mars_population_demographics_us_stg}
        """)
        df_pop_demo_zcta.registerTempTable('pop_demo_zcta')

        df_zcta_to_zip = self.spark.sql(f"""
            select distinct
                zip,
                state,
                zcta,
                sum(1) over (partition by zcta) as zip_per_zcta
            from {self.normalized_database}.{self.mars_zip_zcta_crosswalk_stg}
        """)
        df_zcta_to_zip.registerTempTable('zcta_to_zip')

        df_pop_demo_zcta_distributed = self.spark.sql(f"""
            select distinct
                z.zip,
                p.city,
                p.state,
                sum(coalesce(
                    (p.total / z.zip_per_zcta),
                    p.total
                )) as zip_total,
                sum(coalesce(
                    (p.total_18_49 / z.zip_per_zcta),
                    p.total_18_49
                )) as zip_total_18_49,
                sum(coalesce(
                    (p.female_18_49 / z.zip_per_zcta),
                    p.female_18_49
                )) as zip_female_18_49,
                sum(coalesce(
                    (p.total_50_99 / z.zip_per_zcta),
                    p.total_50_99
                )) as zip_total_50_99
            from pop_demo_zcta as p
            inner join zcta_to_zip as z on p.zcta = z.zcta
            group by z.zip, p.state, p.city
        """)
        df_pop_demo_zcta_distributed.registerTempTable('pop_demo_zcta_distributed')

        df_pop_demo_combined = self.spark.sql("""
            select distinct
                zip,
                city,
                state,
                zip_total,
                zip_total_18_49,
                zip_female_18_49,
                zip_total_50_99
            from pop_demo_islands
            union all
            select distinct
                zip,
                city,
                state,
                zip_total,
                zip_total_18_49,
                zip_female_18_49,
                zip_total_50_99
            from pop_demo_zcta_distributed
        """)
        df_pop_demo_combined.registerTempTable('pop_demo_combined')

        df_zip_state_eco = self.spark.sql(f"""
            select distinct
                zip,
                city,
                state,
                ecosystem_name,
                ecosystem_dim_id
            from {self.normalized_database}.{self.zip_to_eco_dly_tbl}
            where flag_active = 'Y' and ecosystem_dim_id > 0
        """)
        df_zip_state_eco.registerTempTable('zip_state_eco')

        df_state_mapping = self.spark.sql(f"""
            select distinct
                site_state as state,
                site_state_name as state_name
            from {self.normalized_database}.{self.hcp_outlet_affl_wkl_tbl}
            where coalesce(site_state, 'unknown') != 'unknown'
        """)
        df_state_mapping.registerTempTable('state_mapping')

        df_hrr = self.spark.sql(f"""
            select distinct
                hospital_service_area_number,
                hospital_service_area_state_code,
                hospital_referral_region_number,
                lpad(cast(zip as string), 5, '0') as zip,
                trim(upper(hospital_service_area_city)) as hospital_service_area_city,
                trim(upper(hospital_referral_region_city))
                    as hospital_referral_region_city,
                trim(upper(hospital_referral_region_state_code))
                    as hospital_referral_region_state_code
            from
                {self.normalized_database}.{self.mars_hrr_staging}
        """)
        df_hrr.registerTempTable('hrr_data')

        df_all_cities_mapping = self.spark.sql(f"""
            select distinct
                zip_code,
                county,
                state,
                array_join(
                    transform(
                        filter(
                            split(all_cities, ';'), c -> c is not null and length(c) > 0
                        ),
                        c -> trim(c)
                    ),
                    ';'
                ) as all_cities
            from {self.normalized_database}.{self.mars_zipcode_to_all_cities_mapping_stg}
        """)
        df_all_cities_mapping.registerTempTable('all_cities_mapping')

        df_zips_dma_deduped = self.spark.sql(f"""
            with zips_dma_deduped as (
                select distinct
                    zip_code,
                    dma_code,
                    dma_name,
                    county,
                    state
                from {self.normalized_database}.{self.mars_zip_to_dma_dedupe_stg}
                ),
                dma_state as (
                    select distinct
                        dma_code,
                        state
                    from zips_dma_deduped
                ),

                dma_state_count as (
                    select
                        dma_code,
                        count(*) as dma_state_count
                    from dma_state
                    group by dma_code
                ), 

                zips_dma_joined as (
                    select distinct
                        zips.zip_code,
                        zips.dma_name,
                        zips.dma_code,
                        acm.all_cities,
                        zips.state,
                        dma.dma_state_count,
                        coalesce(acm.county, zips.county) as county
                    from zips_dma_deduped as zips
                    left join all_cities_mapping as acm on zips.zip_code = acm.zip_code
                    left join dma_state_count as dma on zips.dma_code = dma.dma_code
                )

                select * from zips_dma_joined
        """)
        df_zips_dma_deduped.registerTempTable('zips_dma_joined')

        df_all_cols = self.spark.sql("""
            select distinct
                d.all_cities,
                d.dma_code,
                d.dma_name,
                st.state_name,
                d.dma_state_count,
                hrr.hospital_service_area_number,
                hrr.hospital_service_area_city,
                hrr.hospital_service_area_state_code,
                hrr.hospital_referral_region_number,
                hrr.hospital_referral_region_city,
                hrr.hospital_referral_region_state_code,
                zip_total,
                zip_total_18_49,
                zip_female_18_49,
                zip_total_50_99,
                coalesce(zse.city, p.city) as city,
                upper(d.county) as county,
                coalesce(zse.ecosystem_name, 'NO ECOSYSTEM') as ecosystem_name,
                coalesce(zse.ecosystem_dim_id, 999) as ecosystem_dim_id,
                coalesce(zse.state, p.state) as state,
                coalesce(zse.zip, p.zip) as zip,
                substr(coalesce(zse.zip, p.zip), 1, 3) as zip3
            from pop_demo_combined as p
            left join zips_dma_joined as d on p.zip = d.zip_code
            left join zip_state_eco as zse on p.zip = zse.zip
            left join state_mapping as st on coalesce(zse.state, p.state) = st.state
            left join hrr_data as hrr on hrr.zip = coalesce(zse.zip, p.zip)
        """)
        df_all_cols.registerTempTable('all_cols')

        df_final_agg = self.spark.sql("""
            select distinct
                zip,
                zip3,
                city,
                all_cities,
                county,
                cast(dma_code as string) as dma_code,
                dma_name,
                state,
                state_name,
                dma_state_count,
                ecosystem_name,
                ecosystem_dim_id,
                hospital_service_area_number,
                hospital_service_area_city,
                hospital_service_area_state_code,
                hospital_referral_region_number,
                hospital_referral_region_city,
                hospital_referral_region_state_code,
                cast(zip_total as bigint) as total_population,
                cast(zip_total_18_49 as bigint) as total_pop_18_49,
                cast(zip_female_18_49 as bigint) as total_pop_f_18_49,
                cast(zip_total_50_99 as bigint) as total_pop_50_99,

                zip_total / sum(cast(zip_total as double)) over () as wt_zip5_total,
                zip_total_18_49
                / sum(cast(zip_total_18_49 as double)) over () as wt_zip5_18_49,
                zip_female_18_49
                / sum(cast(zip_female_18_49 as double)) over () as wt_zip5_f_18_49,
                zip_total_50_99
                / sum(cast(zip_total_50_99 as double)) over () as wt_zip5_50_99,

                zip_total
                / sum(cast(zip_total as double))
                    over (partition by city, state)
                    as wt_city_total,
                zip_total_18_49
                / sum(cast(zip_total_18_49 as double))
                    over (partition by city, state)
                    as wt_city_18_49,
                zip_female_18_49
                / sum(cast(zip_female_18_49 as double))
                    over (partition by city, state)
                    as wt_city_f_18_49,
                zip_total_50_99
                / sum(cast(zip_total_50_99 as double))
                    over (partition by city, state)
                    as wt_city_50_99,

                zip_total
                / sum(cast(zip_total as double))
                    over (partition by county, state)
                    as wt_county_total,
                zip_total_18_49
                / sum(cast(zip_total_18_49 as double))
                    over (partition by county, state)
                    as wt_county_18_49,
                zip_female_18_49
                / sum(cast(zip_female_18_49 as double))
                    over (partition by county, state)
                    as wt_county_f_18_49,
                zip_total_50_99
                / sum(cast(zip_total_50_99 as double))
                    over (partition by county, state)
                    as wt_county_50_99,

                zip_total
                / sum(cast(zip_total as double))
                    over (partition by dma_code)
                    as wt_dma_total,
                zip_total_18_49
                / sum(cast(zip_total_18_49 as double)) over (partition by dma_code)
                    as wt_dma_18_49,
                zip_female_18_49
                / sum(cast(zip_female_18_49 as double)) over (partition by dma_code)
                    as wt_dma_f_18_49,
                zip_total_50_99
                / sum(cast(zip_total_50_99 as double)) over (partition by dma_code)
                    as wt_dma_50_99,

                zip_total
                / sum(cast(zip_total as double))
                    over (partition by state)
                    as wt_state_total,
                zip_total_18_49
                / sum(cast(zip_total_18_49 as double))
                    over (partition by state)
                    as wt_state_18_49,
                zip_female_18_49
                / sum(cast(zip_female_18_49 as double))
                    over (partition by state)
                    as wt_state_f_18_49,
                zip_total_50_99
                / sum(cast(zip_total_50_99 as double))
                    over (partition by state)
                    as wt_state_50_99,

                zip_total
                / sum(cast(zip_total as double))
                    over (partition by dma_code, state)
                    as wt_dma_state_total,
                zip_total_18_49
                / sum(cast(zip_total_18_49 as double))
                    over (partition by dma_code, state)
                    as wt_dma_state_18_49,
                zip_female_18_49
                / sum(cast(zip_female_18_49 as double))
                    over (partition by dma_code, state)
                    as wt_dma_state_f_18_49,
                zip_total_50_99
                / sum(cast(zip_total_50_99 as double))
                    over (partition by dma_code, state)
                    as wt_dma_state_50_99,

                zip_total
                / sum(cast(zip_total as double))
                    over (partition by ecosystem_dim_id)
                    as wt_eco_total,
                zip_total_18_49
                / sum(cast(zip_total_18_49 as double))
                    over (partition by ecosystem_dim_id)
                    as wt_eco_18_49,
                zip_female_18_49
                / sum(cast(zip_female_18_49 as double))
                    over (partition by ecosystem_dim_id)
                    as wt_eco_f_18_49,
                zip_total_50_99
                / sum(cast(zip_total_50_99 as double))
                    over (partition by ecosystem_dim_id)
                    as wt_eco_50_99
                from all_cols
        """)
        df_final_agg.registerTempTable('final_agg')

        df_final_agg_persisted = df_final_agg.persist()

        audit_info = []
        audit_info += [{'table_name': f"{self.summarized_database}.mars_population_demographics",
                        'rows_updated': df_final_agg_persisted.count()}]

        s3_path = ("s3://" + self.bucket_name + "/" + self.summarized_folder + "/etl/" +
                   'mars_population_demographics' + "/")
        df_final_agg_persisted.coalesce(8).write.mode('overwrite').parquet(s3_path)
        self.s3_path_list += [s3_path]

        # Checking historical tables in normalized database
        paginator = athena_client.get_paginator('list_table_metadata')
        response_iterator = paginator.paginate(CatalogName='AwsDataCatalog', DatabaseName=self.summarized_database)

        all_table_names = []
        for page in response_iterator:
            all_table_names.extend((i['Name'] for i in page['TableMetadataList']))

        # Creating list of backup tables in normalized database
        existing_historical_table_names = []
        for tbl_name in all_table_names:
            if 'historical' in tbl_name:
                existing_historical_table_names.append(tbl_name)

        if 'mars_population_demographics_historical' in existing_historical_table_names:
            historical_up_df = self.glue_context.create_data_frame.from_catalog(database=self.summarized_database,
                                                                                table_name='mars_population_demographics_historical')
            last_version = historical_up_df.select([max("version")]).head()[0]
            df_final_agg_hist_df = df_final_agg_persisted.withColumn('version', lit(int(last_version) + 1))
        else:  # This means table is new to normalized, it is getting loaded into historical for first time
            df_final_agg_hist_df = df_final_agg_persisted.withColumn('version', lit(1))
            logger.info(f"Back up table does not exist for mars_hcp_counts_historical in normalized layer")

        audit_info.append(
            {'table_name': f"{self.summarized_database}.mars_population_demographics_historical",
             'rows_updated': df_final_agg_persisted.count()})

        s3_path = ("s3://" + self.bucket_name + "/" + self.summarized_folder + "/etl/" +
                   'mars_population_demographics_historical' + "/")
        df_final_agg_hist_df.coalesce(8).write.partitionBy("version").mode('append').parquet(s3_path)
        self.s3_path_list += [s3_path]

        return audit_info

    def create_update_crawler(self, client):
        """
        Crawler has to be created if it doesn't exist, if it exists then we have to update it s3 path for it.
        :param client: glue boto3 client used to create or update crawler
        """
        # Creating list of s3 path that has to be crawled
        s3_crawl_list = []
        for s3_path in list(set(self.s3_path_list)):
            s3_crawl_list.append(
                {"Path": s3_path, 'Exclusions': json.loads(self.config.get(self.env, "crawl_exclusion_paths"))})

        crawler_exist = True

        # Checking if crawler is already existing or not
        try:
            res = client.get_crawler(Name=self.crawler_name)
            response = json.dumps(res, indent=4, sort_keys=True, default=str)
            print(response)
        except client.exceptions.EntityNotFoundException as e:
            logger.info("Crawler doesnt exist, need to create")
            crawler_exist = False

        # Creating crawler if it doesn't exist
        if crawler_exist:
            response = client.update_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.summarized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Updated\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

        else:
            response = client.create_crawler(
                Name=self.crawler_name,
                Role=self.config.get(self.env, "crawler_role"),
                DatabaseName=self.summarized_database,
                Targets={
                    'S3Targets': s3_crawl_list
                },
                SchemaChangePolicy={
                    'UpdateBehavior': 'UPDATE_IN_DATABASE',
                    'DeleteBehavior': 'DEPRECATE_IN_DATABASE'
                },
                RecrawlPolicy={
                    'RecrawlBehavior': 'CRAWL_EVERYTHING'
                },
                LineageConfiguration={
                    'CrawlerLineageSettings': 'DISABLE'
                }
            )
            logger.info("Crawler Created\nName : " + self.crawler_name)
            logger.info(json.dumps(response, indent=4, sort_keys=True, default=str))

    def start_crawler(self, client):
        """
        This method is used to start the crawler
        :param client: glue boto3 client used to create or update crawler
        """
        response_start = client.start_crawler(Name=self.crawler_name)
        logger.info("Crawler Started\nName : " + self.crawler_name)
        logger.info(json.dumps(response_start, indent=4, sort_keys=True, default=str))

    def monitor_crawler(self, client):
        """
        This method is used to monitor the crawler which we started just now
        :param client: glue boto3 client used to create or update crawler
        """
        need_to_wait = True
        state_previous = None
        while need_to_wait:
            time.sleep(20)
            response_get = client.get_crawler(Name=self.crawler_name)
            state = response_get["Crawler"]["State"]
            if state == "READY" or state == "STOPPING":  # Other known states: RUNNING
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                need_to_wait = False
                break
            if state != state_previous:
                logger.info(f"Crawler {self.crawler_name} is {state.lower()}.")
                state_previous = state


def audit_job_info(spark_obj, job_srt_time, job_name, batch_id, audit_path, audit_dict):
    """
    This function is used to write audit stats of this etl job to athena table.
    :param audit_path:
    :param spark_obj:
    :param job_srt_time:
    :param job_name:
    :param batch_id:
    :param audit_dict:
    """
    if audit_dict is not None:
        logger.info("Writing completion stats to audit table")
        logger.info(audit_dict)
        audit_df = (spark_obj.createDataFrame(audit_dict)
                    .withColumn("log_id_status", lit("COMPLETED"))
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", current_timestamp().cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("etl_layer", lit("summarized"))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)
        logger.info("Auditing is complete")
    else:
        logger.info("Writing initiating stats to audit table")
        audit_df = (spark_obj.createDataFrame([{'etl_layer': 'summarized', 'log_id_status': 'INITIATED'}])
                    .withColumn("script_exe_start_time", lit(job_srt_time))
                    .withColumn("script_exe_end_time", lit(None).cast(TimestampType()))
                    .withColumn("etl_script", lit(job_name))
                    .withColumn("table_name", lit(None).cast(StringType()))
                    .withColumn("rows_updated", lit(None).cast(IntegerType()))
                    .withColumn("batch_id", lit(batch_id)))
        audit_df.write.mode('append').parquet(audit_path)


if __name__ == "__main__":
    # Getting AWS Glue job parameters, creating session and initiating job
    arg = getResolvedOptions(sys.argv,
                             ['JOB_NAME', 'environment', 'batch_id'])

    logger.info("MARS final demographics job started")

    environment = arg['environment']
    config_obj = read_config_file('configuration.ini')
    check_config_section(config_obj, environment)
    job_start_time = datetime.datetime.now()

    sc = SparkContext()
    glueContext = GlueContext(sc)
    sprk = glueContext.spark_session
    job = Job(glueContext)
    job.init(arg['JOB_NAME'], arg)

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'),
                   audit_dict=None)
    audit_list = []

    pop_demo = PopulationDemoFinal(config_obj, arg, glueContext, sprk)

    crawler_client = boto3.client('glue', region_name="us-west-2")

    athena_cl = boto3.client('athena', region_name="us-west-2")

    audit_list += pop_demo.core(athena_cl)

    pop_demo.create_update_crawler(crawler_client)

    pop_demo.start_crawler(crawler_client)

    pop_demo.monitor_crawler(crawler_client)

    audit_job_info(sprk, job_start_time, arg['JOB_NAME'], arg['batch_id'],
                   audit_path=config_obj.get(environment, 'audit_path'),
                   audit_dict=audit_list)

    job.commit()
