import zipcodes
import csv

# Fetch all zip codes including territories

all_zip_codes = zipcodes.list_all()

# Open a CSV file to write the data
with open("zipcode_names.csv", mode="w", newline="") as file:
    writer = csv.writer(file)
    # Write the header
    writer.writerow(["zip_code", "county", "state", "all_cities"])

    # Iterate over each zip code and gather names
    for zipcode_info in all_zip_codes:
        # Zip code
        zip_code = zipcode_info["zip_code"]

        # County
        county = zipcode_info["county"].split("County")[0].strip().upper()

        # State code
        state_code = zipcode_info["state"]

        # Main city name, converted to upper case
        city_names = {zipcode_info["city"].upper()}

        # Add acceptable city names if available, converted to upper case
        if "acceptable_cities" in zipcode_info and zipcode_info["acceptable_cities"]:
            city_names.update(
                city.upper() for city in zipcode_info["acceptable_cities"]
            )

        # Add unacceptable city names if available, converted to upper case
        if (
            "unacceptable_cities" in zipcode_info
            and zipcode_info["unacceptable_cities"]
        ):
            city_names.update(
                city.upper() for city in zipcode_info["unacceptable_cities"]
            )

        # Write the zip code and all associated city names to the CSV, joined by semicolons
        writer.writerow([zip_code, county, state_code, ";".join(city_names)])

print("CSV file has been created with all city names in uppercase.")
